# Boardwalk: project docs

Boardwalk is a 3D explorer for learning computer science. The first pack is PC hardware: a motherboard you can pull apart, click, follow a video file through, and be quizzed on. The idea comes from the open-source anatomy explorer (thebuggeddev/anatomy), moved from organs to computers.

These 15 files are everything needed to build it, and to build it so it looks made by a person.

## Read in this order

| File | What it is |
| --- | --- |
| 01-master-prompt.md | The prompt to give an AI coding assistant to build the whole app |
| 02-human-rules-visual.md | Rules that keep the design from looking AI-generated |
| 03-human-rules-copywriting.md | Rules for the words on screen |
| 04-human-rules-code.md | Rules for code that reads like a person wrote it |
| 05-architecture.md | Folders, data flow, who owns what state |
| 06-design-tokens.md | Colours, type, spacing, exact values |
| 07-3d-viewer-guide.md | How the Three.js scene is built and why |
| 08-adding-a-pack.md | How to add networking, data structures, or anything else |
| 09-hotspot-authoring.md | How to place and tune part callouts |
| 10-content-style-guide.md | How to write part descriptions, specs and quiz clues |
| 11-accessibility.md | Keyboard, screen reader, contrast, motion |
| 12-performance.md | Render-on-demand, budgets, mobile |
| 13-qa-checklist.md | What to test before calling it done |
| 14-roadmap.md | What to build after version 1 |

## The short version

- Stack: Vite, React, TypeScript, Three.js. No UI kit, no CSS framework, hand-written CSS.
- Every 3D part is built from boxes and cylinders in code. No downloaded models.
- All text and numbers live in one data file. The 3D code only knows part ids.
- Three modes: Explore, Journey, Quiz.
- Design direction: a workbench. Grey-green mat, dark ink, one yellow accent, Barlow type.

## Using the prompt

1. Open 01-master-prompt.md and paste it to your assistant.
2. Attach 02, 03 and 04 with it. They are the "human rules".
3. Attach 06 so the colours and type come out exactly.
4. Keep 13 open for the final check.

## A note on the sources

Numbers in the part descriptions are typical values for current desktop hardware, not one specific product. Check any figure you plan to publish against a manufacturer datasheet.
