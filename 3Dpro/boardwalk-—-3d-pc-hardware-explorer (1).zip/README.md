# Boardwalk — 3D PC Hardware Explorer

Boardwalk is an interactive 3D browser explorer for learning computer hardware architecture. Inspired by 3D anatomy tools, it presents an ATX desktop motherboard that learners can pull apart, click, follow a video file through, and be quizzed on.

## Who it is for

Students and self-taught beginners who have never opened a computer. A ten-minute session gives the learner the confidence to identify the CPU, RAM, GPU, SSD, VRM, power connector, and chipset on a physical motherboard and understand what each component does.

## Stack

- **Framework**: React 19, TypeScript (strict mode), Vite 8.
- **3D Graphics**: Three.js (r183+). Procedural geometry from boxes and cylinders; instanced meshes for cooling fins and surface-mount components; canvas-generated textures for trace routing, silk-screen labels, and the CPU heatspreader lid.
- **Styling**: Hand-written CSS (`src/styles.css`) based on the workbench design tokens (grey-green anti-static mat, dark ink, one yellow probe accent, cutting-mat grid background).
- **Typography**: Self-hosted Barlow and Barlow Condensed WOFF2 fonts in `/public/fonts/`.
- **Server proxy**: Lightweight server route `/api/ask` for Gemini API calls, keeping API keys securely on the server with visitor rate limits and hardware-only guardrails.
- **Storage**: Safe `localStorage` with try/catch wrapping for user notes, theme preference, and quiz best scores.

## How to run

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Type check
npm run typecheck
```

## Directory structure

```
boardwalk/
├── index.html                  # HTML entry point with Barlow font links and metadata
├── metadata.json               # Applet capabilities and identification
├── src/
│   ├── main.tsx                # Mounts React application
│   ├── App.tsx                 # Core application controller (mode, explode, theme, selection)
│   ├── styles.css              # Workbench stylesheet with tokens and layout rules
│   ├── data/
│   │   └── parts.ts            # Hardware component data, typical numbers, failure notes, clues
│   ├── lib/
│   │   ├── quiz.ts             # Pure quiz state machine (randomizer, grading, feedback)
│   │   └── storage.ts          # Safe localStorage wrapper for notes and high scores
│   ├── scene/
│   │   ├── BoardScene.ts       # Three.js viewport controller, orbit controls, raycaster, camera fly-to
│   │   ├── build.ts            # Procedural builder for the 12 hardware parts & PCB textures
│   │   └── layout.ts           # Explode trajectories, sub-assembly offsets, anchor coordinates
│   └── components/
│       ├── BoardView.tsx       # Canvas container, callout buttons overlay, bottom workbench dock
│       ├── Rail.tsx            # Left column: 12-part list, journey progression, quiz clue
│       └── Sheet.tsx           # Right column: technical spec sheets, notes textarea, quiz scorecard
```

## Modes

1. **Explore**:
   - Left rail lists all 12 hardware parts with matching numbers.
   - 3D stage allows full orbit, smooth zoom, and polar angle clamping preventing camera inversion under the table.
   - Explode slider smoothly expands the assembly along tuned 3D trajectories, lifting heatsinks to expose underlying power chokes and CPU socket.
   - Numbered callout discs float directly over parts in screen space.
   - Right sheet displays technical lede, 2-paragraph architecture summary, "Typical numbers" spec table, "When it goes wrong" troubleshooting symptoms, and persistent browser notes.
2. **Journey**:
   - Walks through 6 steps following a video file being opened:
     1. Storage read request (NVMe SSD)
     2. High-speed caching (System RAM)
     3. Instruction & audio decoding (CPU)
     4. Power delivery under load (VRM)
     5. Frame rendering & video out (GPU)
     6. Thermal dissipation (CPU Cooler)
   - Synchronised camera fly-to framing on each step. Left/right arrow keyboard shortcuts support rapid traversal.
3. **Quiz**:
   - 8 randomised questions drawn from the hardware catalog.
   - Clues describe function and appearance without mentioning component names.
   - Callout discs are hidden during the test to avoid giving away answers.
   - Direct 3D picking with instant visual flash feedback (green for correct, red for wrong with correct answer revealed).
   - End screen calculates score, updates persistent best score, and provides a question-by-question breakdown.

## What is not finished (Roadmap items)

- **Keyboard board rotation**: Arrow keys currently navigate journey steps; keyboard rotation of the Three.js viewport via numpad/arrows is planned for v1.1.
- **Additional packs**: The system architecture is designed to support future networking packs (routers, packets, switches) and data structure packs (trees, linked lists).
- **Print stylesheet**: Exporting formatted notes for student study guides.
