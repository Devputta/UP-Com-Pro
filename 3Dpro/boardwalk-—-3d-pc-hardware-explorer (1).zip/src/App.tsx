/**
 * Boardwalk — Main Application Container
 *
 * Coordinates educational packs (PC Hardware, Networking, Data Structures),
 * interactive modes (Explore, Journey, Quiz, Build), algorithm step-through player,
 * custom quiz link generation & URL hydration, collapsible side panels,
 * and bilingual language support (English & Hindi).
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BoardView } from './components/BoardView.tsx';
import { BuildMode } from './components/BuildMode.tsx';
import { CompareModal } from './components/CompareModal.tsx';
import { CustomQuizModal } from './components/CustomQuizModal.tsx';
import { PrintNotesView } from './components/PrintNotesView.tsx';
import { Rail } from './components/Rail.tsx';
import { Sheet } from './components/Sheet.tsx';
import { Language, useI18n } from './i18n/index.tsx';
import { advanceQuiz, answerQuestion, newCustomQuiz, newQuiz, QuizState, skipQuestion } from './lib/quiz.ts';
import { getStoredTheme, setStoredTheme } from './lib/storage.ts';
import { getPackById, getStoredPackId, PACKS, setStoredPackId } from './packs/index.ts';
import { BoardScene } from './scene/BoardScene.ts';

export default function App() {
  const { language, setLanguage, t, isHindi } = useI18n();

  // Pack state
  const [activePackId, setActivePackId] = useState<string>(() => {
    // Check if pack is specified in URL query
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlPack = params.get('pack');
      if (urlPack && PACKS.some((p) => p.id === urlPack)) {
        return urlPack;
      }
    }
    return getStoredPackId();
  });

  const activePack = useMemo(() => getPackById(activePackId), [activePackId]);
  const activePartsMap = useMemo(
    () => Object.fromEntries(activePack.parts.map((p) => [p.id, p])),
    [activePack]
  );

  // Panel minimization state (allows full unobstructed view of 3D diagram)
  const [leftCollapsed, setLeftCollapsed] = useState(false);
  const [rightCollapsed, setRightCollapsed] = useState(false);

  // Mode and view state
  const [mode, setMode] = useState<'explore' | 'journey' | 'quiz' | 'build'>('explore');
  const [selectedPartId, setSelectedPartId] = useState<string | null>(() => activePack.parts[0]?.id || 'cpu');
  const [explode, setExplode] = useState(0);
  const [isolate, setIsolate] = useState(false);
  const [showNumbers, setShowNumbers] = useState(true);
  const [showDataFlow, setShowDataFlow] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Build mode installed models tracking
  const [installedModelIds, setInstalledModelIds] = useState<Set<string>>(new Set());

  // Compare modal state
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [comparePairId, setComparePairId] = useState<string | undefined>(undefined);

  // Custom Quiz modal state
  const [isCustomQuizOpen, setIsCustomQuizOpen] = useState(false);

  // Journey state
  const [journeyStepIndex, setJourneyStepIndex] = useState(0);

  // Quiz state
  const [quizState, setQuizState] = useState<QuizState | null>(null);

  const sceneRef = useRef<BoardScene | null>(null);
  const settleAnimRef = useRef<number | null>(null);

  // Initialize theme from storage / system preference
  useEffect(() => {
    const initialTheme = getStoredTheme();
    setTheme(initialTheme);
    document.documentElement.setAttribute('data-theme', initialTheme);
  }, []);

  // Parse shareable Custom Quiz link on initial mount
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const quizParam = params.get('quiz');
      const packParam = params.get('pack');

      if (quizParam) {
        const targetPackId = packParam && PACKS.some((p) => p.id === packParam) ? packParam : activePackId;
        const targetPack = getPackById(targetPackId);
        const partIds = quizParam.split(',').filter(Boolean);

        if (partIds.length > 0) {
          if (targetPackId !== activePackId) {
            setActivePackId(targetPackId);
            setStoredPackId(targetPackId);
          }
          const customQuiz = newCustomQuiz(targetPack.parts, partIds, targetPackId);
          setQuizState(customQuiz);
          setMode('quiz');
          setSelectedPartId(null);
        }
      }
    } catch {
      // Graceful fallback
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    document.documentElement.setAttribute('data-theme', nextTheme);
    setStoredTheme(nextTheme);
  };

  // Opening settle moment: board starts 80% exploded and settles to 0% over ~1.7 seconds
  useEffect(() => {
    const prefersReducedMotion =
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReducedMotion) {
      setExplode(0);
      return;
    }

    setExplode(0.8);
    const startTime = performance.now();
    const duration = 1700;

    const animateSettle = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Cubic ease-out
      const factor = 1 - Math.pow(1 - progress, 3);
      const val = 0.8 * (1 - factor);

      setExplode(val);

      if (progress < 1) {
        settleAnimRef.current = requestAnimationFrame(animateSettle);
      } else {
        settleAnimRef.current = null;
      }
    };

    settleAnimRef.current = requestAnimationFrame(animateSettle);

    return () => {
      if (settleAnimRef.current) {
        cancelAnimationFrame(settleAnimRef.current);
      }
    };
  }, []);

  const handleExplodeChange = (val: number) => {
    // User manual adjustment cancels opening settle animation
    if (settleAnimRef.current) {
      cancelAnimationFrame(settleAnimRef.current);
      settleAnimRef.current = null;
    }
    setExplode(val);
  };

  // Switch educational packs
  const handlePackChange = (newPackId: string) => {
    if (newPackId === activePackId) return;

    setStoredPackId(newPackId);
    setActivePackId(newPackId);

    const nextPack = getPackById(newPackId);
    setSelectedPartId(nextPack.parts[0]?.id || null);
    setJourneyStepIndex(0);
    setIsolate(false);

    // If in build mode and pack doesn't support build mode, reset to explore
    if (mode === 'build' && newPackId !== 'hardware') {
      setMode('explore');
      sceneRef.current?.setBuildMode(false);
    }

    if (mode === 'quiz') {
      setQuizState(newQuiz(nextPack.parts, newPackId, Math.min(8, nextPack.parts.length)));
    }
  };

  // Selection handler from 3D canvas or lists
  const handleSelectPart = useCallback(
    (partId: string) => {
      if (mode === 'quiz') {
        if (!quizState || quizState.isComplete || quizState.activeFeedback !== null) {
          return;
        }

        const { nextState, wasCorrect } = answerQuestion(quizState, partId, activePartsMap);
        setQuizState(nextState);

        if (wasCorrect) {
          sceneRef.current?.flashPart(partId, 'correct');
        } else {
          // Flash clicked part red, and reveal correct part in green
          sceneRef.current?.flashPart(partId, 'wrong');
          const currentTarget = quizState.questions[quizState.currentIndex].targetPartId;
          setTimeout(() => {
            sceneRef.current?.flashPart(currentTarget, 'correct');
          }, 300);
        }
        return;
      }

      setSelectedPartId(partId);
      sceneRef.current?.flyToPart(partId);

      // If in Journey mode, sync matching journey step if this part is on the journey
      if (mode === 'journey') {
        const stepIdx = activePack.journey.findIndex((s) => s.partId === partId);
        if (stepIdx !== -1) {
          setJourneyStepIndex(stepIdx);
        }
      }
    },
    [mode, quizState, activePack, activePartsMap]
  );

  // Mode switching
  const handleModeChange = (nextMode: 'explore' | 'journey' | 'quiz' | 'build') => {
    if (nextMode === mode) return;

    setMode(nextMode);
    setIsolate(false);

    if (nextMode === 'build') {
      sceneRef.current?.clearFlash();
      sceneRef.current?.setBuildMode(true, installedModelIds);
      sceneRef.current?.resetCameraHome(true);
    } else {
      sceneRef.current?.setBuildMode(false);
    }

    if (nextMode === 'explore') {
      sceneRef.current?.clearFlash();
      if (!selectedPartId && activePack.parts[0]) {
        setSelectedPartId(activePack.parts[0].id);
      }
    } else if (nextMode === 'journey') {
      sceneRef.current?.clearFlash();
      const step = activePack.journey[journeyStepIndex] || activePack.journey[0];
      if (step) {
        setSelectedPartId(step.partId);
        sceneRef.current?.flyToPart(step.partId);
      }
    } else if (nextMode === 'quiz') {
      setSelectedPartId(null);
      if (!quizState || quizState.isComplete || quizState.packId !== activePack.id) {
        setQuizState(newQuiz(activePack.parts, activePack.id, Math.min(8, activePack.parts.length)));
      }
      sceneRef.current?.resetCameraHome(true);
    }
  };

  // Journey navigation
  const handleJourneyStepSelect = (idx: number) => {
    setJourneyStepIndex(idx);
    const step = activePack.journey[idx];
    if (step) {
      setSelectedPartId(step.partId);
      sceneRef.current?.flyToPart(step.partId);
    }
  };

  const handleNextJourneyStep = () => {
    if (journeyStepIndex < activePack.journey.length - 1) {
      handleJourneyStepSelect(journeyStepIndex + 1);
    }
  };

  const handlePrevJourneyStep = () => {
    if (journeyStepIndex > 0) {
      handleJourneyStepSelect(journeyStepIndex - 1);
    }
  };

  const handleResetJourney = () => {
    handleJourneyStepSelect(0);
  };

  // Quiz actions
  const handleSkipQuizQuestion = () => {
    if (!quizState || quizState.activeFeedback !== null) return;
    const currentTarget = quizState.questions[quizState.currentIndex].targetPartId;
    sceneRef.current?.flashPart(currentTarget, 'correct');
    const nextState = skipQuestion(quizState, activePartsMap);
    setQuizState(nextState);
  };

  const handleNextQuizQuestion = () => {
    if (!quizState) return;
    sceneRef.current?.clearFlash();
    const nextState = advanceQuiz(quizState);
    setQuizState(nextState);
  };

  const handleRestartQuiz = () => {
    sceneRef.current?.clearFlash();
    setQuizState(newQuiz(activePack.parts, activePack.id, Math.min(8, activePack.parts.length)));
  };

  const handleStartCustomQuiz = (selectedPartIds: string[]) => {
    sceneRef.current?.clearFlash();
    const customQuiz = newCustomQuiz(activePack.parts, selectedPartIds, activePack.id);
    setQuizState(customQuiz);
    setMode('quiz');
    setSelectedPartId(null);
    sceneRef.current?.resetCameraHome(true);
  };

  // Reset view to default workbench angle
  const handleResetView = () => {
    sceneRef.current?.resetCameraHome(true);
  };

  // Keyboard navigation for Journey mode (ArrowLeft / ArrowRight)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTag = document.activeElement?.tagName.toLowerCase();
      if (activeTag === 'textarea' || activeTag === 'input') return;

      if (mode === 'journey') {
        if (e.key === 'ArrowRight') {
          e.preventDefault();
          handleNextJourneyStep();
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          handlePrevJourneyStep();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mode, journeyStepIndex, activePack]);

  return (
    <>
      {/* Dark Header Bar */}
      <header className="boardwalk-header" role="banner">
        <div className="header-brand">
          <span className="brand-mark" aria-hidden="true" />
          <span className="brand-title">{t.header.brandName}</span>
          <span className="brand-subtitle">{activePack.name} {t.header.workbenchSuffix}</span>
        </div>

        {/* Pack Switcher Dropdown */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <label htmlFor="pack-select" style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            {t.header.packLabel}
          </label>
          <select
            id="pack-select"
            className="pack-select"
            value={activePackId}
            onChange={(e) => handlePackChange(e.target.value)}
            aria-label="Select system pack"
          >
            {PACKS.map((pack) => (
              <option key={pack.id} value={pack.id}>
                {pack.name}
              </option>
            ))}
          </select>
        </div>

        {/* Navigation Mode Tabs */}
        <nav className="header-nav" role="tablist" aria-label="Workbench modes">
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'explore'}
            className="mode-tab"
            onClick={() => handleModeChange('explore')}
          >
            {t.header.modes.explore}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'journey'}
            className="mode-tab"
            onClick={() => handleModeChange('journey')}
          >
            {t.header.modes.journey}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'quiz'}
            className="mode-tab"
            onClick={() => handleModeChange('quiz')}
          >
            {t.header.modes.quiz}
          </button>

          {/* Build mode available for hardware pack */}
          {activePack.id === 'hardware' && (
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'build'}
              className="mode-tab"
              onClick={() => handleModeChange('build')}
            >
              {t.header.modes.build}
            </button>
          )}
        </nav>

        <div className="header-actions">
          {/* Custom Quiz builder & link sharing */}
          <button
            type="button"
            className="theme-toggle-btn"
            onClick={() => setIsCustomQuizOpen(true)}
            title="Create and share a custom quiz"
          >
            🔗 {t.header.shareQuizBtn}
          </button>

          {/* Quick trigger for 3D Compare View */}
          {activePack.id === 'hardware' && (
            <button
              type="button"
              className="theme-toggle-btn"
              onClick={() => {
                setComparePairId(undefined);
                setIsCompareOpen(true);
              }}
              title="Compare hardware side by side"
            >
              {t.header.compareBtn}
            </button>
          )}

          {/* Language Switcher */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <label htmlFor="lang-select" style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase' }}>
              {t.header.languageLabel}:
            </label>
            <select
              id="lang-select"
              className="pack-select"
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              aria-label="Select display language"
              style={{ padding: '3px 8px', fontSize: '13px' }}
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी</option>
            </select>
          </div>

          <button
            type="button"
            className="theme-toggle-btn"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}
          >
            {theme === 'light' ? t.header.themeDark : t.header.themeLight}
          </button>
        </div>
      </header>

      {/* Main Workbench Shell */}
      <main className="workbench-shell">
        {mode === 'build' ? (
          <BuildMode
            leftCollapsed={leftCollapsed}
            rightCollapsed={rightCollapsed}
            onToggleLeftCollapse={() => setLeftCollapsed(true)}
            onToggleRightCollapse={() => setRightCollapsed(true)}
            onUpdateInstalledParts={(ids) => {
              setInstalledModelIds(ids);
              sceneRef.current?.setBuildMode(true, ids);
            }}
          >
            <section className="workbench-stage" aria-label="3D hardware workbench viewport">
              {leftCollapsed && (
                <button
                  type="button"
                  className="dock-restore-btn dock-restore-left"
                  onClick={() => setLeftCollapsed(false)}
                  title={t.rail.expandButton}
                  aria-label={t.rail.expandButton}
                >
                  ☰ {t.rail.expandButton}
                </button>
              )}
              {rightCollapsed && (
                <button
                  type="button"
                  className="dock-restore-btn dock-restore-right"
                  onClick={() => setRightCollapsed(false)}
                  title={t.sheet.expandButton}
                  aria-label={t.sheet.expandButton}
                >
                  ℹ {t.sheet.expandButton}
                </button>
              )}
              <BoardView
                pack={activePack}
                mode={mode}
                selectedPartId={selectedPartId}
                onSelectPart={handleSelectPart}
                explode={explode}
                onExplodeChange={handleExplodeChange}
                isolate={isolate}
                onToggleIsolate={() => setIsolate(!isolate)}
                showNumbers={showNumbers}
                onToggleNumbers={() => setShowNumbers(!showNumbers)}
                showDataFlow={showDataFlow}
                onToggleDataFlow={() => setShowDataFlow(!showDataFlow)}
                onResetView={handleResetView}
                sceneRef={sceneRef}
                isQuizComplete={quizState?.isComplete}
              />
            </section>
          </BuildMode>
        ) : (
          <>
            {/* Left Rail (Collapsible) */}
            {!leftCollapsed && (
              <Rail
                pack={activePack}
                mode={mode}
                selectedPartId={selectedPartId}
                onSelectPart={handleSelectPart}
                journeyStepIndex={journeyStepIndex}
                onSelectJourneyStep={handleJourneyStepSelect}
                quizState={quizState}
                onSkipQuizQuestion={handleSkipQuizQuestion}
                onNextQuizQuestion={handleNextQuizQuestion}
                onToggleCollapse={() => setLeftCollapsed(true)}
              />
            )}

            {/* Center 3D Stage */}
            <section className="workbench-stage" aria-label="3D diagram workbench viewport">
              {/* Floating restore tabs when panels are collapsed */}
              {leftCollapsed && (
                <button
                  type="button"
                  className="dock-restore-btn dock-restore-left"
                  onClick={() => setLeftCollapsed(false)}
                  title={t.rail.expandButton}
                  aria-label={t.rail.expandButton}
                >
                  ☰ {t.rail.expandButton}
                </button>
              )}

              {rightCollapsed && (
                <button
                  type="button"
                  className="dock-restore-btn dock-restore-right"
                  onClick={() => setRightCollapsed(false)}
                  title={t.sheet.expandButton}
                  aria-label={t.sheet.expandButton}
                >
                  ℹ {t.sheet.expandButton}
                </button>
              )}

              <BoardView
                pack={activePack}
                mode={mode}
                selectedPartId={selectedPartId}
                onSelectPart={handleSelectPart}
                explode={explode}
                onExplodeChange={handleExplodeChange}
                isolate={isolate}
                onToggleIsolate={() => setIsolate(!isolate)}
                showNumbers={showNumbers}
                onToggleNumbers={() => setShowNumbers(!showNumbers)}
                showDataFlow={showDataFlow}
                onToggleDataFlow={() => setShowDataFlow(!showDataFlow)}
                onResetView={handleResetView}
                sceneRef={sceneRef}
                isQuizComplete={quizState?.isComplete}
              />
            </section>

            {/* Right Sheet (Collapsible) */}
            {!rightCollapsed && (
              <Sheet
                pack={activePack}
                mode={mode}
                selectedPartId={selectedPartId}
                journeyStepIndex={journeyStepIndex}
                onNextJourneyStep={handleNextJourneyStep}
                onPrevJourneyStep={handlePrevJourneyStep}
                onResetJourney={handleResetJourney}
                quizState={quizState}
                onRestartQuiz={handleRestartQuiz}
                onBackToExplore={() => handleModeChange('explore')}
                onNextQuizQuestion={handleNextQuizQuestion}
                onOpenCompare={(pairId) => {
                  setComparePairId(pairId);
                  setIsCompareOpen(true);
                }}
                onToggleCollapse={() => setRightCollapsed(true)}
                onFlashNode={(partId) => sceneRef.current?.flashPart(partId, 'active')}
                onSelectPart={handleSelectPart}
              />
            )}
          </>
        )}
      </main>

      {/* Hardware Compare Modal */}
      <CompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        initialPairId={comparePairId}
      />

      {/* Custom Quiz & Link Sharing Modal */}
      <CustomQuizModal
        isOpen={isCustomQuizOpen}
        onClose={() => setIsCustomQuizOpen(false)}
        pack={activePack}
        onStartCustomQuiz={handleStartCustomQuiz}
      />

      {/* Printable Study Notes (activated during window.print()) */}
      <PrintNotesView pack={activePack} />
    </>
  );
}
