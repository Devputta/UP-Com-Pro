/**
 * Boardwalk — Algorithm Step-Through Player
 *
 * Interactive step-through controller for Binary Search and Breadth-First Search (BFS).
 * Synchronizes with the 3D scene by flashing the active node via `sceneRef.flashPart(partId, 'active')`,
 * displays a small code panel highlighting matching lines of code,
 * and provides exactly one plain sentence explanation per step.
 */

import React, { useEffect, useState } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { ALGORITHMS, AlgorithmData } from '../packs/datastructures/algorithms.ts';

interface AlgorithmPlayerProps {
  onFlashNode: (partId: string) => void;
  onSelectPart: (partId: string) => void;
}

export function AlgorithmPlayer({ onFlashNode, onSelectPart }: AlgorithmPlayerProps) {
  const { t } = useI18n();
  const [algoId, setAlgoId] = useState<'binary_search' | 'bfs'>('binary_search');
  const [stepIndex, setStepIndex] = useState(0);

  const currentAlgo: AlgorithmData =
    ALGORITHMS.find((a) => a.id === algoId) || ALGORITHMS[0];
  const step = currentAlgo.steps[stepIndex] || currentAlgo.steps[0];
  const isFirst = stepIndex === 0;
  const isLast = stepIndex === currentAlgo.steps.length - 1;

  // Whenever step or algo changes, highlight the active node in 3D scene
  useEffect(() => {
    if (step) {
      onFlashNode(step.activePartId);
      onSelectPart(step.activePartId);
    }
  }, [algoId, stepIndex, step?.activePartId]);

  const handleAlgoChange = (newId: 'binary_search' | 'bfs') => {
    setAlgoId(newId);
    setStepIndex(0);
  };

  const handleNext = () => {
    if (stepIndex < currentAlgo.steps.length - 1) {
      setStepIndex(stepIndex + 1);
    }
  };

  const handlePrev = () => {
    if (stepIndex > 0) {
      setStepIndex(stepIndex - 1);
    }
  };

  const handleReset = () => {
    setStepIndex(0);
  };

  return (
    <div className="algo-player-container" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* Algorithm Selector Switch */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--ink-2)', textTransform: 'uppercase' }}>
          {t.algorithms.selectAlgorithm}
        </span>
        <div style={{ display: 'flex', gap: '4px' }}>
          <button
            type="button"
            className="theme-toggle-btn"
            style={{
              backgroundColor: algoId === 'binary_search' ? 'var(--probe)' : 'transparent',
              color: algoId === 'binary_search' ? 'var(--probe-ink)' : 'inherit',
              fontWeight: algoId === 'binary_search' ? 700 : 500
            }}
            onClick={() => handleAlgoChange('binary_search')}
          >
            {t.algorithms.binarySearchTitle}
          </button>
          <button
            type="button"
            className="theme-toggle-btn"
            style={{
              backgroundColor: algoId === 'bfs' ? 'var(--probe)' : 'transparent',
              color: algoId === 'bfs' ? 'var(--probe-ink)' : 'inherit',
              fontWeight: algoId === 'bfs' ? 700 : 500
            }}
            onClick={() => handleAlgoChange('bfs')}
          >
            {t.algorithms.bfsTitle}
          </button>
        </div>
      </div>

      {/* Step Header */}
      <div>
        <div style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--ink-2)', textTransform: 'uppercase' }}>
          {t.algorithms.stepCounter(step.stepNumber, currentAlgo.steps.length)} — {step.title}
        </div>
        {/* Exactly One Plain Sentence Explanation */}
        <p
          style={{
            fontSize: '15.5px',
            color: 'var(--ink)',
            lineHeight: 1.5,
            marginTop: '6px',
            padding: '10px 12px',
            backgroundColor: 'var(--mat)',
            borderLeft: '4px solid var(--probe)',
            borderRadius: '0 3px 3px 0'
          }}
        >
          {step.explanation}
        </p>
      </div>

      {/* Code Snippet Panel with active line highlighting */}
      <div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '6px'
          }}
        >
          <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--ink-2)', textTransform: 'uppercase' }}>
            {t.algorithms.codePanelTitle}
          </span>
          <span style={{ fontSize: '11.5px', color: 'var(--ink-3)' }}>
            Active: Line {step.highlightLine}
          </span>
        </div>

        <div
          style={{
            backgroundColor: 'var(--mat)',
            border: '1px solid var(--line)',
            borderRadius: '4px',
            overflow: 'hidden',
            fontFamily: 'monospace',
            fontSize: '12px',
            lineHeight: 1.5
          }}
        >
          {currentAlgo.codeSnippet.map((line, idx) => {
            const lineNum = idx + 1;
            const isHighlighted = lineNum === step.highlightLine;

            return (
              <div
                key={lineNum}
                style={{
                  display: 'flex',
                  padding: '2px 8px',
                  backgroundColor: isHighlighted ? 'rgba(241, 194, 50, 0.22)' : 'transparent',
                  borderLeft: isHighlighted ? '3px solid var(--probe)' : '3px solid transparent'
                }}
              >
                <span
                  style={{
                    width: '24px',
                    color: isHighlighted ? 'var(--ink)' : 'var(--ink-3)',
                    fontWeight: isHighlighted ? 700 : 400,
                    userSelect: 'none'
                  }}
                >
                  {lineNum}
                </span>
                <span
                  style={{
                    whiteSpace: 'pre',
                    color: isHighlighted ? 'var(--ink)' : 'var(--ink-2)',
                    fontWeight: isHighlighted ? 600 : 400
                  }}
                >
                  {line}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* State Variables Table */}
      <div>
        <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--ink-2)', marginBottom: '4px', textTransform: 'uppercase' }}>
          Runtime State
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {Object.entries(step.stateVariables).map(([key, val]) => (
            <span
              key={key}
              style={{
                fontSize: '12px',
                fontFamily: 'monospace',
                backgroundColor: 'var(--mat)',
                border: '1px solid var(--line)',
                padding: '2px 7px',
                borderRadius: '3px',
                color: 'var(--ink)'
              }}
            >
              <strong>{key}</strong>: {String(val)}
            </span>
          ))}
        </div>
      </div>

      {/* Navigation Controls: Back and Next / Restart */}
      <div className="quiz-action-bar" style={{ marginTop: '4px' }}>
        <button
          type="button"
          className="secondary-btn"
          disabled={isFirst}
          onClick={handlePrev}
        >
          {t.algorithms.prevStep}
        </button>

        {isLast ? (
          <button
            type="button"
            className="primary-btn"
            onClick={handleReset}
          >
            {t.algorithms.resetAlgo}
          </button>
        ) : (
          <button
            type="button"
            className="primary-btn"
            onClick={handleNext}
          >
            {t.algorithms.nextStep}
          </button>
        )}
      </div>
    </div>
  );
}
