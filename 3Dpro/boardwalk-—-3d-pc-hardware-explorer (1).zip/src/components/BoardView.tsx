/**
 * Boardwalk — 3D Board View Component
 *
 * Mounts the WebGL canvas, coordinates callout disc overlays, data flow route captions,
 * and hosts the workbench control dock (Explode slider, Isolate, Data flow, Numbers, Reset view).
 */

import React, { useEffect, useRef, useState } from 'react';
import { Pack } from '../packs/types.ts';
import { BoardScene, CalloutProjection, DataFlowCaption } from '../scene/BoardScene.ts';

interface BoardViewProps {
  pack: Pack;
  mode: 'explore' | 'journey' | 'quiz' | 'build';
  selectedPartId: string | null;
  onSelectPart: (partId: string) => void;
  explode: number;
  onExplodeChange: (value: number) => void;
  isolate: boolean;
  onToggleIsolate: () => void;
  showNumbers: boolean;
  onToggleNumbers: () => void;
  showDataFlow: boolean;
  onToggleDataFlow: () => void;
  onResetView: () => void;
  sceneRef: React.MutableRefObject<BoardScene | null>;
  isQuizComplete?: boolean;
}

export function BoardView({
  pack,
  mode,
  selectedPartId,
  onSelectPart,
  explode,
  onExplodeChange,
  isolate,
  onToggleIsolate,
  showNumbers,
  onToggleNumbers,
  showDataFlow,
  onToggleDataFlow,
  onResetView,
  sceneRef,
  isQuizComplete = false
}: BoardViewProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [webGlAvailable, setWebGlAvailable] = useState(true);
  const [projections, setProjections] = useState<CalloutProjection[]>([]);
  const [dataFlowCaptions, setDataFlowCaptions] = useState<DataFlowCaption[]>([]);

  // Initialize WebGL Scene
  useEffect(() => {
    if (!mountRef.current) return;

    // Test WebGL support
    const testCanvas = document.createElement('canvas');
    const gl = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl');
    if (!gl) {
      setWebGlAvailable(false);
      return;
    }

    const scene = new BoardScene(mountRef.current, pack, {
      onPick: (partId) => {
        onSelectPart(partId);
      },
      onHover: () => {},
      onProject: (projList) => {
        setProjections(projList);
      },
      onProjectDataFlow: (captions) => {
        setDataFlowCaptions(captions);
      }
    });

    sceneRef.current = scene;

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  // Sync active pack to scene
  useEffect(() => {
    sceneRef.current?.setPack(pack);
  }, [pack]);

  // Sync explode value to scene
  useEffect(() => {
    sceneRef.current?.setExplode(explode);
  }, [explode]);

  // Sync selection to scene
  useEffect(() => {
    sceneRef.current?.selectPart(selectedPartId);
  }, [selectedPartId]);

  // Sync isolation mode to scene
  useEffect(() => {
    sceneRef.current?.setIsolate(isolate);
  }, [isolate]);

  // Sync data flow visibility to scene
  useEffect(() => {
    sceneRef.current?.setShowDataFlow(showDataFlow);
  }, [showDataFlow]);

  // Hide callout discs during active quiz or build mode, or when numbers are disabled
  const hideDiscs = mode === 'build' || (mode === 'quiz' && !isQuizComplete) || !showNumbers;

  return (
    <div className="stage-canvas-wrap">
      {/* 3D Canvas Mount Point */}
      <div
        ref={mountRef}
        style={{ width: '100%', height: '100%', position: 'absolute', inset: 0 }}
      />

      {/* WebGL Missing Fallback */}
      {!webGlAvailable && (
        <div className="webgl-missing-card" role="alert">
          <h2 className="webgl-missing-title">WebGL unavailable</h2>
          <p className="empty-instruction">
            This browser cannot draw the 3D board. WebGL is switched off or unavailable.
            Try another browser, or check that hardware acceleration is turned on in your settings.
          </p>
        </div>
      )}

      {/* 2D Callout Discs Overlay */}
      {!hideDiscs && (
        <div className="callout-overlay" aria-hidden="true">
          {projections.map((proj) => {
            if (!proj.visible) return null;
            const part = pack.parts.find((p) => p.id === proj.partId);
            if (!part) return null;
            const isSelected = selectedPartId === proj.partId;

            return (
              <button
                key={proj.partId}
                type="button"
                className="callout-disc"
                data-selected={isSelected}
                style={{
                  transform: `translate3d(${proj.x}px, ${proj.y}px, 0)`
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectPart(proj.partId);
                }}
                title={part.name}
                aria-label={`${part.number}, ${part.name}`}
              >
                {part.number}
              </button>
            );
          })}
        </div>
      )}

      {/* 2D Data Flow Captions Overlay */}
      {showDataFlow && (
        <div className="callout-overlay" aria-hidden="true">
          {dataFlowCaptions.map((cap) => {
            if (!cap.visible) return null;
            return (
              <div
                key={cap.id}
                className="data-flow-caption"
                style={{
                  transform: `translate3d(${cap.x}px, ${cap.y}px, 0)`
                }}
              >
                {cap.label}
              </div>
            );
          })}
        </div>
      )}

      {/* Bottom Workbench Controls Dock */}
      <div className="stage-controls-dock" role="toolbar" aria-label="Workbench 3D controls">
        <div className="control-group">
          <label htmlFor="explode-slider" className="control-label">
            Explode
          </label>
          <input
            id="explode-slider"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={explode}
            onChange={(e) => onExplodeChange(parseFloat(e.target.value))}
            className="explode-slider"
            aria-label="Explode hardware components"
          />
          <span className="explode-value-label">
            {Math.round(explode * 100)}%
          </span>
        </div>

        <button
          type="button"
          className="dock-btn"
          aria-pressed={isolate}
          disabled={!selectedPartId}
          onClick={onToggleIsolate}
          title={selectedPartId ? 'Fade out all other parts' : 'Select a part first to isolate'}
        >
          Isolate part
        </button>

        <button
          type="button"
          className="dock-btn"
          aria-pressed={showDataFlow}
          onClick={onToggleDataFlow}
          title="Toggle animated data flow pulses along motherboard buses"
        >
          Data flow
        </button>

        {mode !== 'quiz' && mode !== 'build' && (
          <button
            type="button"
            className="dock-btn"
            aria-pressed={showNumbers}
            onClick={onToggleNumbers}
          >
            {showNumbers ? 'Hide numbers' : 'Show numbers'}
          </button>
        )}

        <button
          type="button"
          className="dock-btn"
          onClick={onResetView}
        >
          Reset view
        </button>
      </div>
    </div>
  );
}
