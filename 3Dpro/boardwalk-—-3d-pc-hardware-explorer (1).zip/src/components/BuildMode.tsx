/**
 * Boardwalk — Build Mode Component
 *
 * Implements the fourth interactive mode: starting with an empty motherboard,
 * dragging/installing components from the parts tray into matching slots,
 * validating physical/electrical compatibility, and reporting one-sentence failure reasons.
 */

import React, { useState } from 'react';
import { BUILD_SLOTS, BuildPart, BuildSlot, TRAY_PARTS } from '../data/build.ts';
import { useI18n } from '../i18n/index.tsx';

interface BuildModeProps {
  onUpdateInstalledParts: (installedModelPartIds: Set<string>) => void;
  onSelectSlotIn3D?: (slotId: string) => void;
  leftCollapsed?: boolean;
  rightCollapsed?: boolean;
  onToggleLeftCollapse?: () => void;
  onToggleRightCollapse?: () => void;
  children?: React.ReactNode;
}

export function BuildMode({
  onUpdateInstalledParts,
  leftCollapsed = false,
  rightCollapsed = false,
  onToggleLeftCollapse,
  onToggleRightCollapse,
  children
}: BuildModeProps) {
  const { t } = useI18n();
  const [slots, setSlots] = useState<BuildSlot[]>(BUILD_SLOTS);
  const [selectedSlotId, setSelectedSlotId] = useState<string>('slot_cpu');
  const [selectedTrayPartId, setSelectedTrayPartId] = useState<string | null>(null);
  const [failureMessage, setFailureMessage] = useState<string | null>(null);
  const [draggedPartId, setDraggedPartId] = useState<string | null>(null);

  // Set of installed part IDs in the tray
  const installedTrayPartIds = new Set(
    slots.map((s) => s.installedPartId).filter((id): id is string => id !== null)
  );

  const activeSlot = slots.find((s) => s.id === selectedSlotId) || slots[0];
  const allInstalled = slots.every((s) => s.installedPartId !== null);

  // Update installed 3D model IDs for the 3D viewport
  const syncSceneParts = (updatedSlots: BuildSlot[]) => {
    const modelIds = new Set<string>();
    for (const slot of updatedSlots) {
      if (slot.installedPartId) {
        const part = TRAY_PARTS.find((p) => p.id === slot.installedPartId);
        if (part) {
          modelIds.add(part.modelPartId);
        }
      }
    }
    onUpdateInstalledParts(modelIds);
  };

  const handleInstallPart = (part: BuildPart, targetSlot: BuildSlot) => {
    // Check category match
    if (part.category !== targetSlot.acceptedCategory) {
      setFailureMessage(
        `This component is not designed for the ${targetSlot.name}.`
      );
      return;
    }

    // Check compatibility
    if (!part.isCompatible) {
      setFailureMessage(
        part.failureSentence || 'This component is incompatible with the system configuration.'
      );
      return;
    }

    // Success: install into slot
    setFailureMessage(null);
    const updated = slots.map((s) =>
      s.id === targetSlot.id ? { ...s, installedPartId: part.id } : s
    );
    setSlots(updated);
    setSelectedTrayPartId(null);
    syncSceneParts(updated);

    // Auto-select next empty slot
    const nextEmpty = updated.find((s) => s.installedPartId === null);
    if (nextEmpty) {
      setSelectedSlotId(nextEmpty.id);
    }
  };

  const handleUninstallSlot = (slotId: string) => {
    const updated = slots.map((s) =>
      s.id === slotId ? { ...s, installedPartId: null } : s
    );
    setSlots(updated);
    setFailureMessage(null);
    syncSceneParts(updated);
  };

  const handleResetBuild = () => {
    const reset = slots.map((s) => ({ ...s, installedPartId: null }));
    setSlots(reset);
    setSelectedSlotId('slot_cpu');
    setSelectedTrayPartId(null);
    setFailureMessage(null);
    syncSceneParts(reset);
  };

  return (
    <>
      {/* Left Column: Component Tray */}
      {!leftCollapsed && (
        <aside className="workbench-rail" aria-label="Component parts tray">
          <div className="rail-header">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
              <h2 className="rail-title" style={{ margin: 0 }}>{t.build.trayTitle || 'Parts tray'}</h2>
              {onToggleLeftCollapse && (
                <button
                  type="button"
                  className="panel-toggle-btn"
                  onClick={onToggleLeftCollapse}
                  title={t.rail.collapseButton}
                  aria-label={t.rail.collapseButton}
                >
                  ❮ {t.rail.collapseButton}
                </button>
              )}
            </div>
            <p className="rail-subtitle">
              {allInstalled ? 'All parts installed' : 'Drag or select parts to install'}
            </p>
          </div>

          <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {TRAY_PARTS.map((part) => {
              const isInstalled = installedTrayPartIds.has(part.id);
              const isSelected = selectedTrayPartId === part.id;
              const matchesActiveSlot = part.category === activeSlot.acceptedCategory;

              return (
                <div
                  key={part.id}
                  draggable={!isInstalled}
                  onDragStart={() => setDraggedPartId(part.id)}
                  onDragEnd={() => setDraggedPartId(null)}
                  className="part-row-btn"
                  data-active={isSelected}
                  style={{
                    padding: '10px 12px',
                    borderRadius: '3px',
                    border: '1px solid var(--line)',
                    opacity: isInstalled ? 0.45 : 1,
                    cursor: isInstalled ? 'default' : 'grab',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px'
                  }}
                  onClick={() => {
                    if (!isInstalled) {
                      setSelectedTrayPartId(part.id);
                      setFailureMessage(null);
                    }
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
                    <span style={{ fontSize: '14.5px', fontWeight: 600, color: 'var(--ink)' }}>
                      {part.name}
                    </span>
                    {isInstalled && (
                      <span style={{ fontSize: '11px', color: 'var(--good)', fontWeight: 700 }}>
                        Installed
                      </span>
                    )}
                    {!isInstalled && matchesActiveSlot && (
                      <span style={{ fontSize: '11px', color: 'var(--probe-ink)', backgroundColor: 'var(--probe)', padding: '1px 5px', borderRadius: '2px', fontWeight: 700 }}>
                        Match
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: '12.5px', color: 'var(--ink-2)', lineHeight: 1.3 }}>
                    {part.summary}
                  </div>
                </div>
              );
            })}
          </div>
        </aside>
      )}

      {/* Center 3D Viewport */}
      {children}

      {/* Right Column: Slot Inspector & Assembly Summary */}
      {!rightCollapsed && (
        <section className="workbench-sheet" aria-label="Motherboard assembly inspector">
          <div className="sheet-inner">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
                {t.build.boardTitle || 'Motherboard assembly'}
              </span>
              {onToggleRightCollapse && (
                <button
                  type="button"
                  className="panel-toggle-btn"
                  onClick={onToggleRightCollapse}
                  title={t.sheet.collapseButton}
                  aria-label={t.sheet.collapseButton}
                >
                  {t.sheet.collapseButton} ❯
                </button>
              )}
            </div>
            <div className="sheet-header">
              <h1 className="sheet-part-title" style={{ fontSize: '32px' }}>
                {allInstalled ? t.build.summaryTitle : t.build.title}
              </h1>
            </div>

          {/* Compatibility failure notification box */}
          {failureMessage && (
            <div
              className="ai-error-block"
              role="alert"
              style={{ backgroundColor: 'rgba(176, 47, 37, 0.1)', borderColor: 'var(--bad)', color: 'var(--ink)', padding: '12px' }}
            >
              <div style={{ fontWeight: 700, color: 'var(--bad)', marginBottom: '3px' }}>
                Compatibility check failed
              </div>
              <p style={{ fontSize: '14.5px', lineHeight: 1.45 }}>{failureMessage}</p>
            </div>
          )}

          {!allInstalled ? (
            <>
              <div>
                <h2 className="sheet-section-title" style={{ margin: '0 0 8px 0' }}>
                  Motherboard slots ({slots.filter((s) => s.installedPartId).length} / {slots.length})
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {slots.map((slot) => {
                    const isSelected = selectedSlotId === slot.id;
                    const installedPart = TRAY_PARTS.find((p) => p.id === slot.installedPartId);

                    return (
                      <div
                        key={slot.id}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={() => {
                          if (draggedPartId) {
                            const p = TRAY_PARTS.find((item) => item.id === draggedPartId);
                            if (p) handleInstallPart(p, slot);
                          }
                        }}
                        style={{
                          padding: '10px 12px',
                          border: `1px solid ${isSelected ? 'var(--ink)' : 'var(--line)'}`,
                          backgroundColor: isSelected ? 'var(--mat)' : 'var(--mat-2)',
                          borderRadius: '3px',
                          cursor: 'pointer'
                        }}
                        onClick={() => {
                          setSelectedSlotId(slot.id);
                          setFailureMessage(null);
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ fontSize: '15px', fontWeight: 600, color: 'var(--ink)' }}>
                            {slot.name}
                          </span>
                          {installedPart ? (
                            <span style={{ fontSize: '12px', color: 'var(--good)', fontWeight: 600 }}>
                              {installedPart.name}
                            </span>
                          ) : (
                            <span style={{ fontSize: '12px', color: 'var(--ink-3)' }}>
                              Empty
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: '13px', color: 'var(--ink-2)', marginTop: '2px' }}>
                          {slot.description}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Install action button for selected tray part */}
              {selectedTrayPartId && (
                <div style={{ padding: '14px', backgroundColor: 'var(--mat)', border: '1px solid var(--line)', borderRadius: '3px' }}>
                  <div style={{ fontSize: '14px', color: 'var(--ink-2)', marginBottom: '4px' }}>
                    Selected part to install:
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--ink)', marginBottom: '8px' }}>
                    {TRAY_PARTS.find((p) => p.id === selectedTrayPartId)?.name}
                  </div>
                  <button
                    type="button"
                    className="primary-btn"
                    style={{ width: '100%' }}
                    onClick={() => {
                      const part = TRAY_PARTS.find((p) => p.id === selectedTrayPartId);
                      if (part) handleInstallPart(part, activeSlot);
                    }}
                  >
                    Install into {activeSlot.name}
                  </button>
                </div>
              )}

              {activeSlot.installedPartId && (
                <button
                  type="button"
                  className="secondary-btn"
                  style={{ alignSelf: 'flex-start' }}
                  onClick={() => handleUninstallSlot(activeSlot.id)}
                >
                  Remove part from {activeSlot.name}
                </button>
              )}
            </>
          ) : (
            /* Assembly Completion Summary */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ padding: '14px 16px', backgroundColor: 'rgba(31, 107, 64, 0.1)', border: '1px solid var(--good)', borderRadius: '3px' }}>
                <p style={{ fontSize: '16px', fontWeight: 600, color: 'var(--ink)', lineHeight: 1.45 }}>
                  System assembled. All components are compatible and the build boots successfully.
                </p>
              </div>

              <h2 className="sheet-section-title" style={{ margin: 0 }}>
                Build manifest
              </h2>
              <table className="specs-table">
                <tbody>
                  {slots.map((s) => {
                    const p = TRAY_PARTS.find((item) => item.id === s.installedPartId);
                    return (
                      <tr key={s.id}>
                        <td className="spec-label">{s.name}</td>
                        <td className="spec-val">{p?.name || 'Empty'}</td>
                      </tr>
                    );
                  })}
                  <tr>
                    <td className="spec-label">Power margin</td>
                    <td className="spec-val">410 W load on 650 W supply (Stable)</td>
                  </tr>
                </tbody>
              </table>

              <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
                <button
                  type="button"
                  className="primary-btn"
                  onClick={handleResetBuild}
                >
                  Start another build
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    )}
  </>
);
}
