/**
 * Boardwalk — Printable Study Notes View
 *
 * Dedicated print layout displayed during window.print().
 * Formats every part in the current pack with its name, summary, specs, failure mode,
 * and the user's personal notes saved in localStorage.
 */

import React from 'react';
import { getPartNote } from '../lib/storage.ts';
import { Pack } from '../packs/types.ts';

interface PrintNotesViewProps {
  pack: Pack;
}

export function PrintNotesView({ pack }: PrintNotesViewProps) {
  return (
    <div className="print-study-notes" aria-hidden="true">
      <header className="print-header">
        <h1 className="print-title">Boardwalk — Study Notes: {pack.name}</h1>
        <p className="print-subtitle">
          Generated study guide with technical specifications and user revision notes.
        </p>
      </header>

      <div className="print-parts-list">
        {pack.parts.map((part) => {
          const userNote = getPartNote(part.id);

          return (
            <article key={part.id} className="print-part-card">
              <div className="print-part-header">
                <span className="print-part-num">Part #{part.number}</span>
                <h2 className="print-part-name">{part.name}</h2>
              </div>

              <p className="print-part-summary"><strong>Summary:</strong> {part.summary}</p>

              <div className="print-part-body">
                <p>{part.body[0]}</p>
                <p>{part.body[1]}</p>
              </div>

              <div className="print-specs-section">
                <h3 className="print-section-title">Key Specifications</h3>
                <table className="print-specs-table">
                  <tbody>
                    {part.specs.map((spec) => (
                      <tr key={spec.label}>
                        <td className="print-spec-label">{spec.label}</td>
                        <td className="print-spec-val">{spec.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="print-fails-section">
                <h3 className="print-section-title">Failure Modes</h3>
                <p className="print-fails-text">{part.fails}</p>
              </div>

              <div className="print-notes-section">
                <h3 className="print-section-title">Personal Study Notes</h3>
                <div className="print-notes-box">
                  {userNote ? userNote : <em>No personal notes recorded for this part.</em>}
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
