/**
 * Boardwalk — Left Rail Component
 *
 * Houses the numbered part list in Explore mode, sequential dataflow progress tracker
 * in Journey mode, and the current question clue in Quiz mode.
 * Fully localized with collapsible minimize capability.
 */

import React from 'react';
import { useI18n } from '../i18n/index.tsx';
import { QuizState } from '../lib/quiz.ts';
import { Pack } from '../packs/types.ts';

interface RailProps {
  pack: Pack;
  mode: 'explore' | 'journey' | 'quiz' | 'build';
  selectedPartId: string | null;
  onSelectPart: (partId: string) => void;
  journeyStepIndex: number;
  onSelectJourneyStep: (index: number) => void;
  quizState: QuizState | null;
  onSkipQuizQuestion: () => void;
  onNextQuizQuestion: () => void;
  onToggleCollapse?: () => void;
}

export function Rail({
  pack,
  mode,
  selectedPartId,
  onSelectPart,
  journeyStepIndex,
  onSelectJourneyStep,
  quizState,
  onSkipQuizQuestion,
  onNextQuizQuestion,
  onToggleCollapse
}: RailProps) {
  const { t, isHindi, needsReview } = useI18n();

  const renderCollapseBtn = () => {
    if (!onToggleCollapse) return null;
    return (
      <button
        type="button"
        className="panel-toggle-btn"
        onClick={onToggleCollapse}
        title={t.rail.collapseButton}
        aria-label={t.rail.collapseButton}
      >
        ❮ {t.rail.collapseButton}
      </button>
    );
  };

  const renderReviewBadge = () => {
    if (!isHindi || !needsReview) return null;
    return <span className="review-badge" title="Translation needs human review">{t.meta.reviewPendingNotice}</span>;
  };

  if (mode === 'explore') {
    return (
      <aside className="workbench-rail" aria-label="Component directory">
        <div className="rail-header">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
            <h2 className="rail-title" style={{ margin: 0 }}>
              {t.rail.componentsTitle(pack.name)}
            </h2>
            {renderCollapseBtn()}
          </div>
          <p className="rail-subtitle">
            {t.rail.partsCount(pack.parts.length)}
            {renderReviewBadge()}
          </p>
        </div>

        <ul className="rail-parts-list" role="list">
          {pack.parts.map((part) => {
            const isSelected = selectedPartId === part.id;
            return (
              <li key={part.id}>
                <button
                  type="button"
                  className="part-row-btn"
                  data-active={isSelected}
                  onClick={() => onSelectPart(part.id)}
                  aria-pressed={isSelected}
                >
                  <span className="part-num-badge">{part.number}</span>
                  <span className="part-name-label">{part.name}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </aside>
    );
  }

  if (mode === 'journey') {
    return (
      <aside className="workbench-rail" aria-label="Journey steps">
        <div className="rail-header">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
            <h2 className="rail-title" style={{ margin: 0 }}>
              {t.rail.dataJourneyTitle}
            </h2>
            {renderCollapseBtn()}
          </div>
          <p className="rail-subtitle">
            {pack.journeySubtitle || 'Step-by-step data trace'}
            {renderReviewBadge()}
          </p>
        </div>

        <div className="rail-parts-list" role="list">
          {pack.journey.map((step, idx) => {
            const isActive = journeyStepIndex === idx;
            return (
              <div
                key={step.stepNumber}
                className="journey-step-item"
                data-active={isActive}
                onClick={() => onSelectJourneyStep(idx)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectJourneyStep(idx);
                  }
                }}
                aria-current={isActive ? 'step' : undefined}
              >
                <div className="journey-step-header">
                  <span className="journey-num">{t.rail.stepNumber(step.stepNumber)}</span>
                </div>
                <div className="journey-step-title">{step.title}</div>
                <div className="journey-step-desc">{step.lede}</div>
              </div>
            );
          })}
        </div>
      </aside>
    );
  }

  // Quiz mode
  const currentQuestion = quizState?.questions[quizState.currentIndex];
  const isComplete = quizState?.isComplete;

  return (
    <aside className="workbench-rail" aria-label={`${pack.name} quiz question`}>
      <div className="rail-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
          <h2 className="rail-title" style={{ margin: 0 }}>
            {t.rail.quizTitle(pack.name)}
          </h2>
          {renderCollapseBtn()}
        </div>
        <p className="rail-subtitle">
          {isComplete ? t.rail.quizSubtitleFinished : t.rail.quizSubtitleActive}
          {renderReviewBadge()}
        </p>
      </div>

      <div className="quiz-rail-panel">
        {!isComplete && currentQuestion && (
          <>
            <div className="quiz-counter">
              {t.rail.questionCounter(quizState.currentIndex + 1, quizState.total)}
            </div>

            <div className="quiz-clue-box">
              <div className="quiz-clue-label">{t.rail.clueLabel}</div>
              <div className="quiz-clue-text">{currentQuestion.clue}</div>
            </div>

            <p style={{ fontSize: '14px', color: 'var(--ink-2)', lineHeight: 1.45 }}>
              {t.rail.instructionClick}
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {quizState.activeFeedback ? (
                <button
                  type="button"
                  className="primary-btn"
                  onClick={onNextQuizQuestion}
                >
                  {quizState.currentIndex === quizState.total - 1
                    ? t.rail.seeResultsBtn
                    : t.rail.nextQuestionBtn}
                </button>
              ) : (
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={onSkipQuizQuestion}
                >
                  {t.rail.skipQuestionBtn}
                </button>
              )}
            </div>
          </>
        )}

        {isComplete && (
          <div>
            <p style={{ fontSize: '15px', color: 'var(--ink)', lineHeight: 1.5 }}>
              {t.sheet.answersBreakdown}
            </p>
          </div>
        )}
      </div>
    </aside>
  );
}
