/**
 * Boardwalk — Right Sheet Component
 *
 * Houses component technical documentation and notes in Explore mode,
 * hardware/network dataflow narrative or Data Structures algorithm step-through player
 * in Journey mode, and quiz feedback / final scorecards.
 * Fully localized with collapsible minimize capability and print support.
 */

import React, { useEffect, useState } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { QuizState } from '../lib/quiz.ts';
import { getBestScore, getPartNote, setPartNote } from '../lib/storage.ts';
import { Pack } from '../packs/types.ts';
import { AlgorithmPlayer } from './AlgorithmPlayer.tsx';

interface SheetProps {
  pack: Pack;
  mode: 'explore' | 'journey' | 'quiz' | 'build';
  selectedPartId: string | null;
  journeyStepIndex: number;
  onNextJourneyStep: () => void;
  onPrevJourneyStep: () => void;
  onResetJourney: () => void;
  quizState: QuizState | null;
  onRestartQuiz: () => void;
  onBackToExplore: () => void;
  onNextQuizQuestion: () => void;
  onOpenCompare?: (pairId?: string) => void;
  onToggleCollapse?: () => void;
  onFlashNode?: (partId: string) => void;
  onSelectPart?: (partId: string) => void;
}

export function Sheet({
  pack,
  mode,
  selectedPartId,
  journeyStepIndex,
  onNextJourneyStep,
  onPrevJourneyStep,
  onResetJourney,
  quizState,
  onRestartQuiz,
  onBackToExplore,
  onNextQuizQuestion,
  onOpenCompare,
  onToggleCollapse,
  onFlashNode,
  onSelectPart
}: SheetProps) {
  const { t, isHindi, needsReview } = useI18n();

  // Local state for part notes in Explore mode
  const [noteText, setNoteText] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  // Local state for "Ask about this part"
  const [questionInput, setQuestionInput] = useState('');
  const [askLoading, setAskLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [echoQuestion, setEchoQuestion] = useState<string | null>(null);
  const [askError, setAskError] = useState<string | null>(null);

  // Sync loaded note and reset AI Q&A when selected part changes
  useEffect(() => {
    if (selectedPartId) {
      setNoteText(getPartNote(selectedPartId));
      setIsSaved(false);
      setQuestionInput('');
      setAiResponse(null);
      setEchoQuestion(null);
      setAskError(null);
    }
  }, [selectedPartId]);

  const handleNoteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!selectedPartId) return;
    const val = e.target.value;
    setNoteText(val);
    setPartNote(selectedPartId, val);
    setIsSaved(true);
  };

  const handleAskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartId || !questionInput.trim() || askLoading) return;

    const trimmedQuestion = questionInput.trim();
    const currentPart = pack.parts.find((p) => p.id === selectedPartId);
    if (!currentPart) return;

    setAskLoading(true);
    setAskError(null);

    try {
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: trimmedQuestion,
          partName: currentPart.name,
          partSummary: currentPart.summary,
          partBody: currentPart.body,
          partSpecs: currentPart.specs
        })
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setAskError(data.error || 'Failed to receive an answer. Please try again.');
      } else if (data.answer) {
        setAiResponse(data.answer);
        setEchoQuestion(trimmedQuestion);
        setQuestionInput('');
      } else {
        setAskError('No response returned. Please rephrase your question.');
      }
    } catch {
      setAskError('Could not reach the server. Please check your network connection.');
    } finally {
      setAskLoading(false);
    }
  };

  const renderCollapseBtn = () => {
    if (!onToggleCollapse) return null;
    return (
      <button
        type="button"
        className="panel-toggle-btn"
        onClick={onToggleCollapse}
        title={t.sheet.collapseButton}
        aria-label={t.sheet.collapseButton}
      >
        {t.sheet.collapseButton} ❯
      </button>
    );
  };

  const renderReviewBadge = () => {
    if (!isHindi || !needsReview) return null;
    return <span className="review-badge" title="Translation needs human review">{t.meta.reviewPendingNotice}</span>;
  };

  // --------------------------------------------------------------------------
  // EXPLORE MODE
  // --------------------------------------------------------------------------
  if (mode === 'explore') {
    const part = selectedPartId ? pack.parts.find((p) => p.id === selectedPartId) : null;

    if (!part) {
      return (
        <section className="workbench-sheet" aria-label="Component specifications">
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' }}>
            {renderCollapseBtn()}
          </div>
          <div className="empty-state-card">
            <h2 className="empty-title">{t.sheet.pickPartTitle}</h2>
            <p className="empty-instruction">{t.sheet.pickPartInstruction}</p>
          </div>
        </section>
      );
    }

    return (
      <section className="workbench-sheet" aria-label={`Specifications for ${part.name}`}>
        <div className="sheet-inner">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <div className="sheet-part-badge">
              <span className="sheet-number-tag">{part.number}</span>
              <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
                {t.sheet.partCounter(part.number, pack.parts.length)}
                {renderReviewBadge()}
              </span>
            </div>
            {renderCollapseBtn()}
          </div>

          <div className="sheet-header">
            <h1 className="sheet-part-title">{part.name}</h1>
          </div>

          <p className="sheet-lede">{part.summary}</p>

          <div className="sheet-body-text">
            <p>{part.body[0]}</p>
            <p>{part.body[1]}</p>
          </div>

          {/* Architecture Compare Trigger for hardware pack */}
          {pack.id === 'hardware' && onOpenCompare && (
            <div style={{ marginTop: '2px' }}>
              <button
                type="button"
                className="secondary-btn"
                style={{ width: '100%', fontSize: '13.5px' }}
                onClick={() => {
                  if (part.id === 'ram') onOpenCompare('ddr4_ddr5');
                  else if (part.id === 'ssd') onOpenCompare('sata_nvme');
                  else onOpenCompare();
                }}
              >
                {part.id === 'ram'
                  ? 'Compare DDR4 vs DDR5'
                  : part.id === 'ssd'
                  ? 'Compare SATA vs NVMe SSD'
                  : t.sheet.compareWithOthers}
              </button>
            </div>
          )}

          <div>
            <h2 className="sheet-section-title">{t.sheet.typicalNumbers}</h2>
            <table className="specs-table">
              <tbody>
                {part.specs.map((spec) => (
                  <tr key={spec.label}>
                    <td className="spec-label">{spec.label}</td>
                    <td className="spec-val">{spec.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div>
            <h2 className="sheet-section-title">{t.sheet.whenItGoesWrong}</h2>
            <div className="fails-box">{part.fails}</div>
          </div>

          {/* Personal Study Notes */}
          <div className="notes-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <label htmlFor={`notes-${part.id}`} className="sheet-section-title" style={{ margin: 0 }}>
                {t.sheet.personalNotes}
              </label>
              <button
                type="button"
                className="panel-toggle-btn"
                onClick={() => window.print()}
                title="Print your study notes"
                style={{ fontSize: '11.5px' }}
              >
                🖨 {t.sheet.printNotesBtn}
              </button>
            </div>
            <textarea
              id={`notes-${part.id}`}
              className="notes-textarea"
              placeholder={t.sheet.notesPlaceholder}
              value={noteText}
              onChange={handleNoteChange}
              aria-label={`Notes for ${part.name}`}
            />
            <span className="notes-save-indicator">
              {isSaved ? t.sheet.notesSaved : t.sheet.notesSavedBrowser}
            </span>
          </div>

          {/* Ask About This Part */}
          <div className="ask-container">
            <h2 className="sheet-section-title" style={{ margin: 0 }}>
              {t.sheet.askAboutPart}
            </h2>
            <form className="ask-form" onSubmit={handleAskSubmit}>
              <textarea
                className="ask-input"
                placeholder={t.sheet.askPlaceholder(part.name)}
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                rows={2}
                aria-label={`Ask a question about ${part.name}`}
                disabled={askLoading}
              />
              <div className="ask-btn-row">
                <button
                  type="submit"
                  className="primary-btn"
                  disabled={askLoading || !questionInput.trim()}
                >
                  {askLoading ? t.sheet.consultingButton : t.sheet.askButton}
                </button>
              </div>
            </form>

            {askError && (
              <div className="ai-error-block" role="alert">
                {askError}
              </div>
            )}

            {aiResponse && (
              <div className="ai-answer-block">
                {echoQuestion && (
                  <div className="ai-question-echo">
                    {t.sheet.aiAnswerQuestion} {echoQuestion}
                  </div>
                )}
                <div className="ai-answer-text">{aiResponse}</div>
                <div className="ai-disclaimer">
                  {t.sheet.aiDisclaimer}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    );
  }

  // --------------------------------------------------------------------------
  // JOURNEY MODE
  // --------------------------------------------------------------------------
  if (mode === 'journey') {
    // If Data Structures pack, render the algorithm player step-through!
    if (pack.id === 'datastructures') {
      return (
        <section className="workbench-sheet" aria-label="Algorithm step-through player">
          <div className="sheet-inner">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <div className="sheet-part-badge">
                <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
                  Interactive Algorithm Trace
                  {renderReviewBadge()}
                </span>
              </div>
              {renderCollapseBtn()}
            </div>

            <div className="sheet-header">
              <h1 className="sheet-part-title" style={{ fontSize: '30px' }}>
                Algorithm Walkthrough
              </h1>
            </div>

            <AlgorithmPlayer
              onFlashNode={(partId) => onFlashNode?.(partId)}
              onSelectPart={(partId) => onSelectPart?.(partId)}
            />
          </div>
        </section>
      );
    }

    const step = pack.journey[journeyStepIndex] || pack.journey[0];
    const isFirst = journeyStepIndex === 0;
    const isLast = journeyStepIndex === pack.journey.length - 1;
    const part = step ? pack.parts.find((p) => p.id === step.partId) : null;

    return (
      <section className="workbench-sheet" aria-label="Data journey narrative">
        <div className="sheet-inner">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
              {t.sheet.stepCounter(step?.stepNumber || 1, pack.journey.length)}
              {renderReviewBadge()}
            </span>
            {renderCollapseBtn()}
          </div>

          <div className="sheet-header">
            <h1 className="sheet-part-title" style={{ fontSize: '32px' }}>
              {step?.title || 'Journey step'}
            </h1>
          </div>

          <p className="sheet-lede">{step?.lede}</p>

          <div className="sheet-body-text">
            <p>{step?.body}</p>
          </div>

          {part && (
            <div>
              <h2 className="sheet-section-title">{t.sheet.activeComponent}</h2>
              <p style={{ fontSize: '16px', color: 'var(--ink)', marginBottom: '8px' }}>
                <strong>{part.name}:</strong> {part.summary}
              </p>
              <table className="specs-table">
                <tbody>
                  {part.specs.map((spec) => (
                    <tr key={spec.label}>
                      <td className="spec-label">{spec.label}</td>
                      <td className="spec-val">{spec.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="quiz-action-bar" style={{ marginTop: '16px' }}>
            <button
              type="button"
              className="secondary-btn"
              disabled={isFirst}
              onClick={onPrevJourneyStep}
            >
              {t.sheet.backStepBtn}
            </button>

            {isLast ? (
              <button
                type="button"
                className="primary-btn"
                onClick={onResetJourney}
              >
                {t.sheet.startAgainBtn}
              </button>
            ) : (
              <button
                type="button"
                className="primary-btn"
                onClick={onNextJourneyStep}
              >
                {t.sheet.nextStepBtn}
              </button>
            )}
          </div>

          <p style={{ fontSize: '13px', color: 'var(--ink-3)', marginTop: '4px' }}>
            {t.sheet.arrowKeyHint}
          </p>
        </div>
      </section>
    );
  }

  // --------------------------------------------------------------------------
  // QUIZ MODE
  // --------------------------------------------------------------------------
  const isComplete = quizState?.isComplete;
  const best = getBestScore();

  if (isComplete) {
    return (
      <section className="workbench-sheet" aria-label={`${pack.name} quiz final results`}>
        <div className="sheet-inner">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
              {t.sheet.sessionResults}
              {renderReviewBadge()}
            </span>
            {renderCollapseBtn()}
          </div>

          <div className="sheet-header">
            <h1 className="sheet-part-title">{t.sheet.quizComplete}</h1>
          </div>

          <div className="quiz-results-container">
            <div className="big-score-wrap">
              <span className="big-score">
                {quizState.score} / {quizState.total}
              </span>
              {best && (
                <span className="best-score-label">
                  {t.sheet.bestScore(best.score, best.total)}
                </span>
              )}
            </div>

            <p style={{ fontSize: '16px', color: 'var(--ink)', lineHeight: 1.5 }}>
              {quizState.score === quizState.total
                ? t.sheet.allCorrect
                : t.sheet.partialScore(quizState.score, quizState.total)}
            </p>

            <h2 className="sheet-section-title">{t.sheet.answersBreakdown}</h2>
            <ul className="quiz-answers-log">
              {quizState.questions.map((q) => {
                const target = pack.parts.find((p) => p.id === q.targetPartId);
                const targetName = target ? target.name : q.targetPartId;
                const isRight = q.status === 'correct';
                return (
                  <li key={q.questionNumber} className="quiz-log-row">
                    <span>
                      {q.questionNumber}. {targetName}
                    </span>
                    <span
                      className="quiz-log-status"
                      data-res={q.status}
                    >
                      {isRight ? 'Right' : 'Missed'}
                    </span>
                  </li>
                );
              })}
            </ul>

            <div className="quiz-action-bar">
              <button
                type="button"
                className="primary-btn"
                onClick={onRestartQuiz}
              >
                {t.sheet.retakeQuizBtn}
              </button>
              <button
                type="button"
                className="secondary-btn"
                onClick={onBackToExplore}
              >
                {t.sheet.backToExploreBtn}
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // Active quiz in progress
  const activeFeedback = quizState?.activeFeedback;

  return (
    <section className="workbench-sheet" aria-label="Quiz feedback">
      <div className="sheet-inner">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
          <span style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink-2)' }}>
            {t.rail.quizTitle(pack.name)}
            {renderReviewBadge()}
          </span>
          {renderCollapseBtn()}
        </div>

        <div className="sheet-header">
          <h1 className="sheet-part-title" style={{ fontSize: '34px' }}>
            Identification test
          </h1>
        </div>

        <p style={{ fontSize: '16px', color: 'var(--ink-2)', lineHeight: 1.5 }}>
          Numbers and callouts are hidden on the board during the quiz. Read the clue on the left,
          then click directly on the hardware component you think matches.
        </p>

        {/* Live region for screen reader feedback */}
        <div aria-live="polite" className="live-region-wrap">
          {activeFeedback && (
            <div
              className="quiz-feedback-box"
              data-status={activeFeedback.status}
            >
              <p style={{ fontWeight: 600, marginBottom: '6px' }}>
                {activeFeedback.status === 'correct' && 'Correct'}
                {activeFeedback.status === 'wrong' && 'Not quite'}
                {activeFeedback.status === 'skipped' && 'Skipped'}
              </p>
              <p>{activeFeedback.message}</p>

              <button
                type="button"
                className="primary-btn"
                style={{ marginTop: '14px' }}
                onClick={onNextQuizQuestion}
              >
                {t.rail.nextQuestionBtn}
              </button>
            </div>
          )}
        </div>

        {!activeFeedback && (
          <div className="fails-box" style={{ marginTop: '12px' }}>
            Rotate and zoom the 3D board to inspect the components closely. Take your time before
            clicking.
          </div>
        )}
      </div>
    </section>
  );
}
