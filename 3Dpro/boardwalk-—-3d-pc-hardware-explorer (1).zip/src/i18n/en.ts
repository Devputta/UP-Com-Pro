/**
 * Boardwalk — English Translation Bundle
 */

import { TranslationSchema } from './types.ts';

export const en: TranslationSchema = {
  header: {
    brandName: 'Boardwalk',
    workbenchSuffix: 'Workbench',
    packLabel: 'Pack:',
    modes: {
      explore: 'Explore',
      journey: 'Journey',
      quiz: 'Quiz',
      build: 'Build'
    },
    compareBtn: 'Compare',
    themeDark: 'Dark theme',
    themeLight: 'Light theme',
    languageLabel: 'Language',
    shareQuizBtn: 'Custom Quiz'
  },
  rail: {
    componentsTitle: (packName: string) => `${packName} components`,
    partsCount: (count: number) => `${count} parts in this system`,
    dataJourneyTitle: 'Data journey',
    stepNumber: (step: number) => `Step ${step}`,
    quizTitle: (packName: string) => `${packName} quiz`,
    quizSubtitleActive: 'Find the device or part in the 3D view',
    quizSubtitleFinished: 'Quiz finished',
    questionCounter: (current: number, total: number) => `Question ${current} of ${total}`,
    clueLabel: 'Clue',
    instructionClick: 'Click the matching component on the 3D board or in the list.',
    nextQuestionBtn: 'Next question',
    skipQuestionBtn: 'Skip question',
    seeResultsBtn: 'See results',
    collapseButton: 'Collapse panel',
    expandButton: 'Components'
  },
  sheet: {
    pickPartTitle: 'Pick a part',
    pickPartInstruction: 'Click anything on the 3D board, or choose from the list on the left to inspect its technical architecture and typical specifications.',
    partCounter: (current: number, total: number) => `Part ${current} of ${total}`,
    compareWithOthers: 'Compare PC hardware architectures',
    typicalNumbers: 'Typical numbers',
    whenItGoesWrong: 'When it goes wrong',
    personalNotes: 'Personal notes',
    notesPlaceholder: 'Record observations, socket pinouts, or class notes...',
    notesSaved: 'Saved in browser',
    notesSavedBrowser: 'Notes are saved in your browser',
    printNotesBtn: 'Print Study Notes',
    askAboutPart: 'Ask about this part',
    askPlaceholder: (partName: string) => `Ask a question about ${partName.toLowerCase()}...`,
    askButton: 'Ask question',
    consultingButton: 'Consulting...',
    aiDisclaimer: 'AI answer, check it before relying on it',
    aiAnswerQuestion: 'Q:',
    stepCounter: (current: number, total: number) => `Step ${current} of ${total}`,
    activeComponent: 'Active component',
    backStepBtn: 'Back',
    nextStepBtn: 'Next step',
    startAgainBtn: 'Start again',
    arrowKeyHint: 'Use the left and right arrow keys to step through the sequence.',
    sessionResults: 'Session results',
    quizComplete: 'Quiz complete',
    bestScore: (score: number, total: number) => `Best score: ${score} / ${total}`,
    allCorrect: 'All components identified correctly.',
    partialScore: (score: number, total: number) => `Identified ${score} of ${total} components correctly.`,
    answersBreakdown: 'Answers breakdown',
    retakeQuizBtn: 'Retake quiz',
    backToExploreBtn: 'Back to explore',
    collapseButton: 'Collapse panel',
    expandButton: 'Details'
  },
  build: {
    title: 'PC Build Workbench',
    lede: 'Drag each component from the tray to its correct socket on the motherboard. Incompatible pairings will be rejected with an explanation.',
    summaryTitle: 'Build complete',
    summaryLede: 'All primary motherboard components successfully installed and verified for architectural compatibility.',
    restartBtn: 'Start new build',
    inspectBtn: 'Inspect in 3D',
    trayTitle: 'Component Tray',
    boardTitle: 'Motherboard Sockets'
  },
  compare: {
    modalTitle: 'Hardware Architecture Compare',
    modalSubtitle: 'Direct side-by-side technical evaluation of common PC hardware standards.',
    keyNumbers: 'Key specifications',
    verdictTitle: 'Architecture summary',
    whenToChoose: 'When to choose which:',
    closeBtn: 'Close compare view'
  },
  customQuiz: {
    modalTitle: 'Custom Quiz & Shareable Link',
    modalSubtitle: 'Select up to 8 parts to generate a custom quiz link that opens directly without requiring a backend.',
    selectHint: 'Pick parts to test:',
    selectedCount: (count: number, max: number) => `Selected: ${count} of ${max} parts`,
    copyLinkBtn: 'Copy shareable link',
    copiedNotice: 'Link copied to clipboard',
    startCustomQuizBtn: 'Start this quiz now',
    closeBtn: 'Close',
    noPartsSelected: 'Please select at least 1 part to start a quiz.'
  },
  algorithms: {
    selectAlgorithm: 'Algorithm:',
    codePanelTitle: 'Algorithm execution',
    stepExplanationTitle: 'Step explanation',
    binarySearchTitle: 'Binary Search',
    bfsTitle: 'Breadth-First Search (BFS)',
    nextStep: 'Next step',
    prevStep: 'Back',
    stepCounter: (current: number, total: number) => `Step ${current} of ${total}`,
    resetAlgo: 'Restart algorithm'
  },
  meta: {
    reviewPendingNotice: 'Human review pending',
    needsReview: false
  }
};
