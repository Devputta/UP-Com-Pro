/**
 * Boardwalk — Hindi Translation Bundle (हिन्दी)
 *
 * All technical terms (CPU, RAM, SSD, GPU, Motherboard, PCIe, BIOS, DDR4, DDR5,
 * SATA, NVMe, Router, Switch, Firewall, DNS, Array, Linked List, Stack, Queue,
 * Binary Tree, Graph, Binary Search, BFS) are kept in English letters.
 *
 * Mark which translations still need a human review with `needsReview: true`.
 */

import { TranslationSchema } from './types.ts';

export const hi: TranslationSchema = {
  header: {
    brandName: 'Boardwalk',
    workbenchSuffix: 'Workbench',
    packLabel: 'Pack:',
    modes: {
      explore: 'Explore',
      journey: 'Journey',
      quiz: 'Quiz',
      build: 'Build'
    },
    compareBtn: 'Compare',
    themeDark: 'डार्क थीम',
    themeLight: 'लाइट थीम',
    languageLabel: 'भाषा',
    shareQuizBtn: 'कस्टम Quiz'
  },
  rail: {
    componentsTitle: (packName: string) => `${packName} के घटक`,
    partsCount: (count: number) => `इस सिस्टम में ${count} पार्ट्स`,
    dataJourneyTitle: 'Data Journey',
    stepNumber: (step: number) => `चरण ${step}`,
    quizTitle: (packName: string) => `${packName} Quiz`,
    quizSubtitleActive: '3D दृश्य में डिवाइस या पार्ट खोजें',
    quizSubtitleFinished: 'Quiz समाप्त हुई',
    questionCounter: (current: number, total: number) => `प्रश्न ${current} / ${total}`,
    clueLabel: 'संकेत (Clue)',
    instructionClick: '3D बोर्ड पर या सूची में सही कॉम्पोनेन्ट पर क्लिक करें।',
    nextQuestionBtn: 'अगला प्रश्न',
    skipQuestionBtn: 'प्रश्न छोड़ें',
    seeResultsBtn: 'परिणाम देखें',
    collapseButton: 'पैनल छिपाएं',
    expandButton: 'कॉम्पोनेन्ट्स'
  },
  sheet: {
    pickPartTitle: 'एक पार्ट चुनें',
    pickPartInstruction: 'इसके तकनीकी आर्किटेक्चर और विशिष्टताओं का अध्ययन करने के लिए 3D बोर्ड पर क्लिक करें या बाईं ओर की सूची से चुनें।',
    partCounter: (current: number, total: number) => `पार्ट ${current} / ${total}`,
    compareWithOthers: 'PC Hardware आर्किटेक्चर की तुलना करें',
    typicalNumbers: 'मानक विनिर्देश (Typical numbers)',
    whenItGoesWrong: 'समस्या आने पर (When it goes wrong)',
    personalNotes: 'व्यक्तिगत नोट्स',
    notesPlaceholder: 'अपने अवलोकन, सॉकेट पिनआउट्स या क्लास नोट्स यहाँ लिखें...',
    notesSaved: 'ब्राउज़र में सुरक्षित',
    notesSavedBrowser: 'नोट्स आपके ब्राउज़र में सुरक्षित रहते हैं',
    printNotesBtn: 'स्टडी नोट्स प्रिंट करें',
    askAboutPart: 'इस पार्ट के बारे में पूछें',
    askPlaceholder: (partName: string) => `${partName} के बारे में एक सवाल पूछें...`,
    askButton: 'प्रश्न पूछें',
    consultingButton: 'परामर्श जारी है...',
    aiDisclaimer: 'AI उत्तर, भरोसा करने से पहले इसकी जांच करें',
    aiAnswerQuestion: 'प्रश्न:',
    stepCounter: (current: number, total: number) => `चरण ${current} / ${total}`,
    activeComponent: 'सक्रिय कॉम्पोनेन्ट',
    backStepBtn: 'पीछे',
    nextStepBtn: 'अगला चरण',
    startAgainBtn: 'पुनः शुरू करें',
    arrowKeyHint: 'क्रम में आगे-पीछे जाने के लिए बाएँ और दाएँ तीर (Arrow keys) का उपयोग करें।',
    sessionResults: 'सत्र परिणाम',
    quizComplete: 'Quiz पूर्ण हुआ',
    bestScore: (score: number, total: number) => `सर्वोत्तम स्कोर: ${score} / ${total}`,
    allCorrect: 'सभी कॉम्पोनेन्ट्स की सही पहचान की गई।',
    partialScore: (score: number, total: number) => `${total} में से ${score} कॉम्पोनेन्ट्स की सही पहचान की गई।`,
    answersBreakdown: 'उत्तरों का विवरण',
    retakeQuizBtn: 'Quiz दोबारा दें',
    backToExploreBtn: 'वापस Explore पर जाएँ',
    collapseButton: 'पैनल छिपाएं',
    expandButton: 'विवरण'
  },
  build: {
    title: 'PC Build Workbench',
    lede: 'ट्रे से प्रत्येक कॉम्पोनेन्ट को Motherboard के सही सॉकेट पर ड्रैग करें। असंगत पार्ट्स को कारण सहित अस्वीकार किया जाएगा।',
    summaryTitle: 'Build पूर्ण हुआ',
    summaryLede: 'Motherboard के सभी मुख्य कॉम्पोनेन्ट्स सफलतापूर्वक लगाए गए और आर्किटेक्चरल संगतता जांची गई।',
    restartBtn: 'नया Build शुरू करें',
    inspectBtn: '3D में निरीक्षण करें',
    trayTitle: 'कॉम्पोनेन्ट ट्रे',
    boardTitle: 'Motherboard सॉकेट्स'
  },
  compare: {
    modalTitle: 'Hardware आर्किटेक्चर तुलना',
    modalSubtitle: 'सामान्य PC Hardware मानकों का प्रत्यक्ष साइड-बाय-साइड तकनीकी मूल्यांकन।',
    keyNumbers: 'मुख्य विनिर्देश',
    verdictTitle: 'आर्किटेक्चर निष्कर्ष',
    whenToChoose: 'किसे कब चुनें:',
    closeBtn: 'तुलना बंद करें'
  },
  customQuiz: {
    modalTitle: 'कस्टम Quiz और शेयर करने योग्य लिंक',
    modalSubtitle: 'सीधे खुलने वाली कस्टम Quiz लिंक जनरेट करने के लिए 8 पार्ट्स तक चुनें। इसके लिए किसी बैकएंड की आवश्यकता नहीं है।',
    selectHint: 'परीक्षण के लिए पार्ट्स चुनें:',
    selectedCount: (count: number, max: number) => `चयनित: ${max} में से ${count} पार्ट्स`,
    copyLinkBtn: 'शेयर लिंक कॉपी करें',
    copiedNotice: 'लिंक क्लिपबोर्ड पर कॉपी हो गया',
    startCustomQuizBtn: 'यह Quiz अभी शुरू करें',
    closeBtn: 'बंद करें',
    noPartsSelected: 'Quiz शुरू करने के लिए कृपया कम से कम 1 पार्ट चुनें।'
  },
  algorithms: {
    selectAlgorithm: 'Algorithm:',
    codePanelTitle: 'Algorithm निष्पादन कोड',
    stepExplanationTitle: 'चरण स्पष्टीकरण',
    binarySearchTitle: 'Binary Search',
    bfsTitle: 'Breadth-First Search (BFS)',
    nextStep: 'अगला चरण',
    prevStep: 'पीछे',
    stepCounter: (current: number, total: number) => `चरण ${current} / ${total}`,
    resetAlgo: 'Algorithm पुनः आरंभ करें'
  },
  meta: {
    reviewPendingNotice: 'मानव समीक्षा बाकी (Needs human review)',
    needsReview: true
  }
};
