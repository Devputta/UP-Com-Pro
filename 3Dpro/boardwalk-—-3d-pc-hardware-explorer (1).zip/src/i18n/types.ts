/**
 * Boardwalk — Internationalization (i18n) Type Definitions
 *
 * Defines the schema for all UI text, allowing per-language bundles (e.g. English, Hindi).
 * Supports the `needsReview` flag for marking newly translated strings that require human review.
 */

export type Language = 'en' | 'hi';

export interface TranslationSchema {
  header: {
    brandName: string;
    workbenchSuffix: string;
    packLabel: string;
    modes: {
      explore: string;
      journey: string;
      quiz: string;
      build: string;
    };
    compareBtn: string;
    themeDark: string;
    themeLight: string;
    languageLabel: string;
    shareQuizBtn: string;
  };
  rail: {
    componentsTitle: (packName: string) => string;
    partsCount: (count: number) => string;
    dataJourneyTitle: string;
    stepNumber: (step: number) => string;
    quizTitle: (packName: string) => string;
    quizSubtitleActive: string;
    quizSubtitleFinished: string;
    questionCounter: (current: number, total: number) => string;
    clueLabel: string;
    instructionClick: string;
    nextQuestionBtn: string;
    skipQuestionBtn: string;
    seeResultsBtn: string;
    collapseButton: string;
    expandButton: string;
  };
  sheet: {
    pickPartTitle: string;
    pickPartInstruction: string;
    partCounter: (current: number, total: number) => string;
    compareWithOthers: string;
    typicalNumbers: string;
    whenItGoesWrong: string;
    personalNotes: string;
    notesPlaceholder: string;
    notesSaved: string;
    notesSavedBrowser: string;
    printNotesBtn: string;
    askAboutPart: string;
    askPlaceholder: (partName: string) => string;
    askButton: string;
    consultingButton: string;
    aiDisclaimer: string;
    aiAnswerQuestion: string;
    stepCounter: (current: number, total: number) => string;
    activeComponent: string;
    backStepBtn: string;
    nextStepBtn: string;
    startAgainBtn: string;
    arrowKeyHint: string;
    sessionResults: string;
    quizComplete: string;
    bestScore: (score: number, total: number) => string;
    allCorrect: string;
    partialScore: (score: number, total: number) => string;
    answersBreakdown: string;
    retakeQuizBtn: string;
    backToExploreBtn: string;
    collapseButton: string;
    expandButton: string;
  };
  build: {
    title: string;
    lede: string;
    summaryTitle: string;
    summaryLede: string;
    restartBtn: string;
    inspectBtn: string;
    trayTitle: string;
    boardTitle: string;
  };
  compare: {
    modalTitle: string;
    modalSubtitle: string;
    keyNumbers: string;
    verdictTitle: string;
    whenToChoose: string;
    closeBtn: string;
  };
  customQuiz: {
    modalTitle: string;
    modalSubtitle: string;
    selectHint: string;
    selectedCount: (count: number, max: number) => string;
    copyLinkBtn: string;
    copiedNotice: string;
    startCustomQuizBtn: string;
    closeBtn: string;
    noPartsSelected: string;
  };
  algorithms: {
    selectAlgorithm: string;
    codePanelTitle: string;
    stepExplanationTitle: string;
    binarySearchTitle: string;
    bfsTitle: string;
    nextStep: string;
    prevStep: string;
    stepCounter: (current: number, total: number) => string;
    resetAlgo: string;
  };
  meta: {
    reviewPendingNotice: string;
    needsReview: boolean;
  };
}
