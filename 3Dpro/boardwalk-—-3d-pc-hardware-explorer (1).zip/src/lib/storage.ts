/**
 * Safe localStorage wrapper.
 * Every localStorage call is protected in a try/catch block so the app
 * functions seamlessly even if storage is disabled, quota is exceeded,
 * or running in private browsing modes.
 */

const NOTES_PREFIX = 'boardwalk_note_';
const BEST_SCORE_KEY = 'boardwalk_quiz_best';
const THEME_KEY = 'boardwalk_theme';

export function getPartNote(partId: string): string {
  try {
    return localStorage.getItem(NOTES_PREFIX + partId) || '';
  } catch {
    return '';
  }
}

export function setPartNote(partId: string, note: string): void {
  try {
    if (!note) {
      localStorage.removeItem(NOTES_PREFIX + partId);
    } else {
      localStorage.setItem(NOTES_PREFIX + partId, note);
    }
  } catch {
    // Storage quota exceeded or disabled; fail gracefully
  }
}

export interface BestScore {
  score: number;
  total: number;
}

export function getBestScore(): BestScore | null {
  try {
    const raw = localStorage.getItem(BEST_SCORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (typeof parsed?.score === 'number' && typeof parsed?.total === 'number') {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function setBestScore(score: number, total: number): void {
  try {
    const current = getBestScore();
    // Only update if better percentage or first score
    if (!current || score / total > current.score / current.total) {
      localStorage.setItem(BEST_SCORE_KEY, JSON.stringify({ score, total }));
    }
  } catch {
    // Graceful no-op
  }
}

export function getStoredTheme(): 'light' | 'dark' {
  try {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === 'light' || stored === 'dark') return stored;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  } catch {
    return 'light';
  }
}

export function setStoredTheme(theme: 'light' | 'dark'): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch {
    // Graceful no-op
  }
}
