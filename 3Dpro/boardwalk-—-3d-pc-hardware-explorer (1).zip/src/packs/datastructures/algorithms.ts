/**
 * Boardwalk — Data Structures Algorithm Traces
 *
 * Provides step-by-step educational walkthroughs for Binary Search and Breadth-First Search (BFS).
 * Each step specifies the active 3D model component to flash, the matching line of code,
 * and a single plain sentence explanation.
 */

export interface AlgorithmStep {
  stepNumber: number;
  title: string;
  activePartId: string;
  explanation: string; // Exactly one plain sentence
  highlightLine: number; // 1-indexed
  stateVariables: Record<string, string | number>;
}

export interface AlgorithmData {
  id: 'binary_search' | 'bfs';
  name: string;
  shortDescription: string;
  codeSnippet: string[];
  steps: AlgorithmStep[];
}

export const BINARY_SEARCH_ALGO: AlgorithmData = {
  id: 'binary_search',
  name: 'Binary Search',
  shortDescription: 'Divide-and-conquer search on sorted array in O(log N) time.',
  codeSnippet: [
    'function binarySearch(arr, target) {',
    '  let low = 0, high = arr.length - 1;',
    '  while (low <= high) {',
    '    const mid = Math.floor((low + high) / 2);',
    '    if (arr[mid] === target) return mid;',
    '    if (arr[mid] < target) low = mid + 1;',
    '    else high = mid - 1;',
    '  }',
    '  return -1;',
    '}'
  ],
  steps: [
    {
      stepNumber: 1,
      title: 'Initialize pointers',
      activePartId: 'array',
      explanation: 'Set search boundary from low index 0 to high index 7 covering the entire sorted array.',
      highlightLine: 2,
      stateVariables: { low: 0, high: 7, target: 42 }
    },
    {
      stepNumber: 2,
      title: 'Probe midpoint',
      activePartId: 'array',
      explanation: 'Calculate midpoint index 3 with value 27 and compare it against our target 42.',
      highlightLine: 4,
      stateVariables: { low: 0, high: 7, mid: 3, 'arr[mid]': 27, target: 42 }
    },
    {
      stepNumber: 3,
      title: 'Narrow right partition',
      activePartId: 'array',
      explanation: 'Because target 42 is greater than 27, eliminate the left half and advance low pointer to index 4.',
      highlightLine: 6,
      stateVariables: { low: 4, high: 7, target: 42 }
    },
    {
      stepNumber: 4,
      title: 'Probe second midpoint',
      activePartId: 'array',
      explanation: 'Calculate the new midpoint index 5 with value 55 and compare it against target 42.',
      highlightLine: 4,
      stateVariables: { low: 4, high: 7, mid: 5, 'arr[mid]': 55, target: 42 }
    },
    {
      stepNumber: 5,
      title: 'Narrow left partition',
      activePartId: 'array',
      explanation: 'Because target 42 is less than 55, eliminate the upper half and decrement high pointer to index 4.',
      highlightLine: 7,
      stateVariables: { low: 4, high: 4, target: 42 }
    },
    {
      stepNumber: 6,
      title: 'Target confirmed',
      activePartId: 'array',
      explanation: 'Midpoint index 4 holds value 42, matching the search target in 3 logarithmic steps.',
      highlightLine: 5,
      stateVariables: { mid: 4, 'arr[4]': 42, status: 'Found' }
    }
  ]
};

export const BFS_ALGO: AlgorithmData = {
  id: 'bfs',
  name: 'Breadth-First Search (BFS)',
  shortDescription: 'Level-by-level graph traversal utilizing a FIFO queue.',
  codeSnippet: [
    'function bfs(graph, start) {',
    '  const visited = new Set([start]);',
    '  const queue = [start];',
    '  while (queue.length > 0) {',
    '    const current = queue.shift();',
    '    for (const neighbor of graph[current]) {',
    '      if (!visited.has(neighbor)) {',
    '        visited.add(neighbor);',
    '        queue.push(neighbor);',
    '      }',
    '    }',
    '  }',
    '}'
  ],
  steps: [
    {
      stepNumber: 1,
      title: 'Initialize queue and visited set',
      activePartId: 'graph',
      explanation: 'Enqueue the root source vertex A and record it in the visited set to prevent cyclic loops.',
      highlightLine: 2,
      stateVariables: { current: 'None', queue: '[A]', visited: '{A}' }
    },
    {
      stepNumber: 2,
      title: 'Dequeue root vertex',
      activePartId: 'queue',
      explanation: 'Dequeue vertex A from the front of the queue to inspect its adjacent outgoing edges.',
      highlightLine: 5,
      stateVariables: { current: 'A', queue: '[]', visited: '{A}' }
    },
    {
      stepNumber: 3,
      title: 'Discover level 1 neighbors',
      activePartId: 'graph',
      explanation: 'Discover adjacent neighbor vertices B and C, mark both as visited, and enqueue them at the rear.',
      highlightLine: 9,
      stateVariables: { current: 'A', queue: '[B, C]', visited: '{A, B, C}' }
    },
    {
      stepNumber: 4,
      title: 'Dequeue vertex B',
      activePartId: 'queue',
      explanation: 'Dequeue vertex B from the front and discover its unvisited level 2 neighbor vertex D.',
      highlightLine: 5,
      stateVariables: { current: 'B', queue: '[C]', visited: '{A, B, C}' }
    },
    {
      stepNumber: 5,
      title: 'Enqueue vertex D',
      activePartId: 'queue',
      explanation: 'Enqueue neighbor vertex D into the queue while preserving chronological traversal order.',
      highlightLine: 9,
      stateVariables: { current: 'B', queue: '[C, D]', visited: '{A, B, C, D}' }
    },
    {
      stepNumber: 6,
      title: 'Dequeue vertex C',
      activePartId: 'graph',
      explanation: 'Dequeue vertex C to visit connected vertices E and F in systematic breadth-wise expansion.',
      highlightLine: 5,
      stateVariables: { current: 'C', queue: '[D, E, F]', visited: '{A, B, C, D, E, F}' }
    },
    {
      stepNumber: 7,
      title: 'Traversal complete',
      activePartId: 'graph',
      explanation: 'All reachable vertices have been explored in optimal shortest-path topological order.',
      highlightLine: 4,
      stateVariables: { status: 'Queue empty', totalExplored: 6 }
    }
  ]
};

export const ALGORITHMS: AlgorithmData[] = [BINARY_SEARCH_ALGO, BFS_ALGO];
