/**
 * Boardwalk — Data Structures Pack 3D Procedural Builder
 *
 * Procedurally generates 6 computer science data structures using pure Three.js geometry:
 * 1. Array (contiguous indexed memory cells with base-pointer brackets)
 * 2. Linked List (heap node containers with data and next-pointer arrow linkages)
 * 3. Stack (vertical LIFO hopper with stacked plates and TOP pointer)
 * 4. Queue (horizontal FIFO conduit with Front and Rear boundary gates)
 * 5. Binary Tree (hierarchical branching node tree with root and left/right children)
 * 6. Graph (network of 6 vertices interconnected by directed spatial edge tubes)
 */

import * as THREE from 'three';
import { BuiltPart, SceneBuildResult } from '../types.ts';

function createMaterial(
  color: THREE.ColorRepresentation,
  roughness = 0.45,
  metalness = 0.15,
  extra?: Partial<THREE.MeshStandardMaterialParameters>
): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness,
    ...extra
  });
}

function makeBox(
  w: number,
  h: number,
  d: number,
  material: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  castShadow = true,
  receiveShadow = true
): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = receiveShadow;
  return mesh;
}

function makeCylinder(
  rTop: number,
  rBot: number,
  h: number,
  segs: number,
  material: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  castShadow = true,
  receiveShadow = true
): THREE.Mesh {
  const geo = new THREE.CylinderGeometry(rTop, rBot, h, segs);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = receiveShadow;
  return mesh;
}

function makeSphere(
  radius: number,
  segs: number,
  material: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  castShadow = true,
  receiveShadow = true
): THREE.Mesh {
  const geo = new THREE.SphereGeometry(radius, segs, segs);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = receiveShadow;
  return mesh;
}

function makeArrowTube(
  start: THREE.Vector3,
  end: THREE.Vector3,
  tubeRadius: number,
  material: THREE.Material
): THREE.Group {
  const group = new THREE.Group();
  const dir = new THREE.Vector3().subVectors(end, start);
  const len = dir.length();
  const mid = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);

  const shaft = new THREE.Mesh(
    new THREE.CylinderGeometry(tubeRadius, tubeRadius, Math.max(0.01, len - 0.22), 12),
    material
  );
  shaft.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  shaft.position.copy(mid);
  group.add(shaft);

  // Arrowhead cone
  const cone = new THREE.Mesh(
    new THREE.ConeGeometry(tubeRadius * 2.6, 0.22, 12),
    material
  );
  cone.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  cone.position.copy(end.clone().addScaledVector(dir.clone().normalize(), -0.1));
  group.add(cone);

  return group;
}

export function buildDataStructuresScene(): SceneBuildResult {
  const parts: Record<string, BuiltPart> = {};

  // Palette: Educational workbench tokens
  const frameMat = createMaterial('#2b3338', 0.45, 0.35);
  const cellMat = createMaterial('#44525d', 0.5, 0.15);
  const probeMat = createMaterial('#f1c232', 0.3, 0.2, {
    emissive: new THREE.Color(0xf1c232),
    emissiveIntensity: 0.2
  });
  const dataBlueMat = createMaterial('#2f7cb3', 0.4, 0.1);
  const pointerMat = createMaterial('#9faeb5', 0.3, 0.6);
  const copperMat = createMaterial('#b87333', 0.35, 0.7);
  const vertexMat = createMaterial('#388e63', 0.35, 0.25);
  const edgeMat = createMaterial('#637785', 0.3, 0.5);

  // ==========================================================================
  // 1. ARRAY: Contiguous row of 8 cells with index markings [-3.2, 0, 1.4]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, cellMat, probeMat, pointerMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_array';

    const cx = -3.2;
    const cy = 0.25;
    const cz = 1.4;

    // Outer mounting tray
    const tray = makeBox(3.4, 0.12, 0.9, frameMat, cx, cy - 0.18, cz);
    group.add(tray);
    pickables.push(tray);

    // 8 contiguous memory slots
    const slotCount = 8;
    const slotW = 0.36;
    const spacing = 0.39;
    const startX = cx - ((slotCount - 1) * spacing) / 2;

    for (let i = 0; i < slotCount; i++) {
      const sx = startX + i * spacing;
      // Active element indicator (index 3 & 4 highlight)
      const isMid = i === 3 || i === 4;
      const mat = isMid ? probeMat : cellMat;
      const slot = makeBox(slotW, 0.32, 0.65, mat, sx, cy, cz);
      group.add(slot);
      pickables.push(slot);

      // Index label block above
      const indexBlock = makeBox(0.2, 0.05, 0.18, pointerMat, sx, cy + 0.18, cz - 0.2);
      group.add(indexBlock);

      // Data bit plate on top
      const dataPlate = makeBox(0.26, 0.04, 0.28, frameMat, sx, cy + 0.18, cz + 0.1);
      group.add(dataPlate);
    }

    parts.array = { id: 'array', group, materials: mats, pickableMeshes: pickables };
  }

  // ==========================================================================
  // 2. LINKED LIST: 4 Dynamic Heap Nodes with Pointer Links [3.2, 0, 1.4]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, dataBlueMat, pointerMat, copperMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_linked_list';

    const cx = 3.2;
    const cy = 0.25;
    const cz = 1.4;

    const nodeCount = 4;
    const spacing = 0.92;
    const startX = cx - ((nodeCount - 1) * spacing) / 2;

    for (let i = 0; i < nodeCount; i++) {
      const nx = startX + i * spacing;

      // Outer node enclosure
      const enclosure = makeBox(0.68, 0.36, 0.55, frameMat, nx, cy, cz);
      group.add(enclosure);
      pickables.push(enclosure);

      // Data compartment [Left]
      const dataComp = makeBox(0.3, 0.32, 0.48, dataBlueMat, nx - 0.15, cy + 0.03, cz);
      group.add(dataComp);

      // Next pointer compartment [Right]
      const ptrComp = makeBox(0.24, 0.32, 0.48, pointerMat, nx + 0.16, cy + 0.03, cz);
      group.add(ptrComp);

      // Pointer arrow to next node
      if (i < nodeCount - 1) {
        const arrow = makeArrowTube(
          new THREE.Vector3(nx + 0.28, cy + 0.05, cz),
          new THREE.Vector3(nx + spacing - 0.34, cy + 0.05, cz),
          0.025,
          copperMat
        );
        group.add(arrow);
      } else {
        // Ground / Null termination symbol
        const nullPost = makeCylinder(0.02, 0.02, 0.3, 8, copperMat, nx + 0.45, cy + 0.05, cz);
        nullPost.rotation.z = Math.PI / 2;
        group.add(nullPost);
        const nullBar = makeBox(0.04, 0.24, 0.04, copperMat, nx + 0.6, cy + 0.05, cz);
        group.add(nullBar);
      }
    }

    parts.linked_list = { id: 'linked_list', group, materials: mats, pickableMeshes: pickables };
  }

  // ==========================================================================
  // 3. STACK: Vertical LIFO Hopper with Stacked Plates [-3.4, 0, -1.5]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, dataBlueMat, probeMat, pointerMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_stack';

    const cx = -3.4;
    const cy = 0.1;
    const cz = -1.5;

    // Sturdy base plate
    const base = makeBox(1.5, 0.12, 1.2, frameMat, cx, cy, cz);
    group.add(base);
    pickables.push(base);

    // Left and Right hopper guide walls
    const leftWall = makeBox(0.1, 1.3, 0.9, frameMat, cx - 0.55, cy + 0.65, cz);
    const rightWall = makeBox(0.1, 1.3, 0.9, frameMat, cx + 0.55, cy + 0.65, cz);
    const backWall = makeBox(1.1, 1.3, 0.08, frameMat, cx, cy + 0.65, cz - 0.45);
    group.add(leftWall, rightWall, backWall);
    pickables.push(leftWall, rightWall);

    // 4 Stacked LIFO plates
    const plateCount = 4;
    const plateH = 0.2;
    for (let p = 0; p < plateCount; p++) {
      const py = cy + 0.16 + p * 0.24;
      const isTop = p === plateCount - 1;
      const mat = isTop ? probeMat : dataBlueMat;
      const plate = makeBox(0.92, plateH, 0.76, mat, cx, py, cz);
      group.add(plate);
      pickables.push(plate);
    }

    // TOP pointer arrow hovering above
    const topArrow = makeArrowTube(
      new THREE.Vector3(cx, cy + 1.6, cz),
      new THREE.Vector3(cx, cy + 1.2, cz),
      0.035,
      pointerMat
    );
    group.add(topArrow);

    parts.stack = { id: 'stack', group, materials: mats, pickableMeshes: pickables };
  }

  // ==========================================================================
  // 4. QUEUE: Horizontal FIFO Conduit with Front & Rear Pointers [0.0, 0, 1.7]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, cellMat, probeMat, pointerMat, copperMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_queue';

    const cx = 0.0;
    const cy = 0.25;
    const cz = 1.7;

    // Conveyor rail bottom
    const track = makeBox(2.8, 0.1, 0.9, frameMat, cx, cy - 0.16, cz);
    group.add(track);
    pickables.push(track);

    // Guide rails along top and bottom
    const topRail = makeBox(2.8, 0.08, 0.08, pointerMat, cx, cy + 0.18, cz - 0.4);
    const botRail = makeBox(2.8, 0.08, 0.08, pointerMat, cx, cy + 0.18, cz + 0.4);
    group.add(topRail, botRail);

    // 4 Queued packets
    const packetCount = 4;
    for (let q = 0; q < packetCount; q++) {
      const qx = cx - 0.75 + q * 0.5;
      const isFront = q === 0;
      const mat = isFront ? probeMat : cellMat;
      const packet = makeBox(0.38, 0.28, 0.65, mat, qx, cy, cz);
      group.add(packet);
      pickables.push(packet);
    }

    // Front (Dequeue) pointer arrow departing left
    const frontArrow = makeArrowTube(
      new THREE.Vector3(cx - 0.95, cy, cz),
      new THREE.Vector3(cx - 1.55, cy, cz),
      0.03,
      copperMat
    );
    group.add(frontArrow);

    // Rear (Enqueue) pointer arrow arriving right
    const rearArrow = makeArrowTube(
      new THREE.Vector3(cx + 1.55, cy, cz),
      new THREE.Vector3(cx + 0.95, cy, cz),
      0.03,
      copperMat
    );
    group.add(rearArrow);

    parts.queue = { id: 'queue', group, materials: mats, pickableMeshes: pickables };
  }

  // ==========================================================================
  // 5. BINARY TREE: Hierarchical Branching Node Hierarchy [0.0, 0, -1.5]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, vertexMat, pointerMat, probeMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_binary_tree';

    const cx = 0.0;
    const cz = -1.5;

    // Node locations
    // Level 0: Root
    const nRoot = new THREE.Vector3(cx, 1.45, cz);
    // Level 1: Left and Right
    const nL = new THREE.Vector3(cx - 1.25, 0.85, cz);
    const nR = new THREE.Vector3(cx + 1.25, 0.85, cz);
    // Level 2: Children
    const nLL = new THREE.Vector3(cx - 1.85, 0.26, cz);
    const nLR = new THREE.Vector3(cx - 0.65, 0.26, cz);
    const nRL = new THREE.Vector3(cx + 0.65, 0.26, cz);
    const nRR = new THREE.Vector3(cx + 1.85, 0.26, cz);

    const allNodes = [
      { pos: nRoot, isRoot: true },
      { pos: nL, isRoot: false },
      { pos: nR, isRoot: false },
      { pos: nLL, isRoot: false },
      { pos: nLR, isRoot: false },
      { pos: nRL, isRoot: false },
      { pos: nRR, isRoot: false }
    ];

    // Branch cylinders
    const branches = [
      [nRoot, nL],
      [nRoot, nR],
      [nL, nLL],
      [nL, nLR],
      [nR, nRL],
      [nR, nRR]
    ];

    branches.forEach(([from, to]) => {
      const dir = new THREE.Vector3().subVectors(to, from);
      const len = dir.length();
      const mid = new THREE.Vector3().addVectors(from, to).multiplyScalar(0.5);

      const branch = new THREE.Mesh(
        new THREE.CylinderGeometry(0.035, 0.035, len, 10),
        pointerMat
      );
      branch.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      branch.position.copy(mid);
      group.add(branch);
    });

    // Render nodes
    allNodes.forEach((n, idx) => {
      const mat = n.isRoot ? probeMat : vertexMat;
      const sphere = makeSphere(0.24, 16, mat, n.pos.x, n.pos.y, n.pos.z);
      group.add(sphere);
      pickables.push(sphere);

      // Metallic rim band
      const rim = makeCylinder(0.26, 0.26, 0.06, 16, frameMat, n.pos.x, n.pos.y, n.pos.z);
      group.add(rim);
    });

    parts.binary_tree = { id: 'binary_tree', group, materials: mats, pickableMeshes: pickables };
  }

  // ==========================================================================
  // 6. GRAPH: Network of 6 Vertices with Directed/Undirected Edges [3.4, 0, -1.5]
  // ==========================================================================
  {
    const mats: THREE.Material[] = [frameMat, vertexMat, edgeMat, probeMat];
    const pickables: THREE.Mesh[] = [];
    const group = new THREE.Group();
    group.name = 'part_graph';

    const cx = 3.4;
    const cz = -1.5;

    // 6 spatial vertices: A, B, C, D, E, F
    const vertices = [
      { id: 'A', pos: new THREE.Vector3(cx - 0.9, 0.9, cz + 0.4) },
      { id: 'B', pos: new THREE.Vector3(cx + 0.3, 1.25, cz + 0.6) },
      { id: 'C', pos: new THREE.Vector3(cx + 1.0, 0.85, cz - 0.2) },
      { id: 'D', pos: new THREE.Vector3(cx - 0.6, 0.32, cz - 0.5) },
      { id: 'E', pos: new THREE.Vector3(cx + 0.2, 0.35, cz - 0.7) },
      { id: 'F', pos: new THREE.Vector3(cx + 1.1, 0.32, cz + 0.5) }
    ];

    // Interconnecting graph edges
    const edges = [
      [0, 1], // A -> B
      [0, 2], // A -> C
      [1, 3], // B -> D
      [1, 5], // B -> F
      [2, 4], // C -> E
      [3, 4], // D -> E
      [4, 5]  // E -> F
    ];

    // Edge tubes
    edges.forEach(([u, v]) => {
      const from = vertices[u].pos;
      const to = vertices[v].pos;
      const dir = new THREE.Vector3().subVectors(to, from);
      const len = dir.length();
      const mid = new THREE.Vector3().addVectors(from, to).multiplyScalar(0.5);

      const edgeMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.03, 0.03, len, 8),
        edgeMat
      );
      edgeMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      edgeMesh.position.copy(mid);
      group.add(edgeMesh);
    });

    // Vertex node spheres
    vertices.forEach((v, idx) => {
      const isStart = idx === 0;
      const mat = isStart ? probeMat : vertexMat;
      const nodeMesh = makeSphere(0.22, 16, mat, v.pos.x, v.pos.y, v.pos.z);
      group.add(nodeMesh);
      pickables.push(nodeMesh);

      // Vertex collar
      const collar = makeCylinder(0.24, 0.24, 0.05, 14, frameMat, v.pos.x, v.pos.y, v.pos.z);
      group.add(collar);
    });

    parts.graph = { id: 'graph', group, materials: mats, pickableMeshes: pickables };
  }

  return { parts };
}
