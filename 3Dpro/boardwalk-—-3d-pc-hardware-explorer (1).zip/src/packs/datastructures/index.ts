/**
 * Boardwalk — Data Structures Pack Definition
 *
 * Encapsulates the 6 core computer science structures (Array, Linked List, Stack,
 * Queue, Binary Tree, Graph) with interactive algorithm execution traces.
 */

import * as THREE from 'three';
import { Pack } from '../types.ts';
import { ALGORITHMS } from './algorithms.ts';
import { buildDataStructuresScene } from './build.ts';
import { DATA_STRUCTURE_PARTS } from './parts.ts';

export const dataStructuresPack: Pack = {
  id: 'datastructures',
  name: 'Data Structures',
  title: 'Computer Science Data Structures',
  shortTitle: 'Data Structures',
  journeySubtitle: 'Algorithm step-by-step trace',
  parts: DATA_STRUCTURE_PARTS,
  journey: [
    {
      partId: 'array',
      stepNumber: 1,
      title: 'Contiguous Index Arithmetic',
      lede: 'Calculating physical memory addresses in O(1) time.',
      body: 'Arrays achieve constant-time direct indexing because every cell occupies consecutive bytes. Knowing the array base address and slot size allows immediate address lookup without following pointers.'
    },
    {
      partId: 'linked_list',
      stepNumber: 2,
      title: 'Pointer Linkage across the Heap',
      lede: 'Dynamically allocating nodes linked by memory references.',
      body: 'When memory cannot be allocated in a contiguous slab, linked list nodes scatter across the heap. Inserting or deleting at known boundaries is instant, but finding an element requires sequential pointer hopping.'
    },
    {
      partId: 'stack',
      stepNumber: 3,
      title: 'LIFO Call Stack Management',
      lede: 'Pushing and popping execution frames at a single boundary.',
      body: 'Stacks enforce strict Last-In First-Out discipline, making them ideal for tracking nested function calls, recursive descent, arithmetic syntax trees, and undo/redo operation histories.'
    },
    {
      partId: 'queue',
      stepNumber: 4,
      title: 'FIFO Scheduling Pipeline',
      lede: 'First-In First-Out buffered message dispatch.',
      body: 'Queues maintain chronological fairness. In event loops and task pipelines, tasks enqueue at the rear and dequeue from the front, ensuring older tasks are never starved.'
    },
    {
      partId: 'binary_tree',
      stepNumber: 5,
      title: 'Logarithmic Divide & Conquer',
      lede: 'Halving the candidate search space at each branch.',
      body: 'Binary Search Trees organize elements so the left child is smaller and right child is greater. Balanced trees guarantee O(log N) lookup by eliminating half the remaining candidate nodes at every step.'
    },
    {
      partId: 'graph',
      stepNumber: 6,
      title: 'Topological Traversal & Networks',
      lede: 'Exploring interconnected vertices via edges.',
      body: 'Graphs generalize relationships with no single root. Using Breadth-First Search (BFS) with a tracking queue discovers shortest paths, while Depth-First Search (DFS) traverses deeply into dependencies.'
    }
  ],
  build: buildDataStructuresScene,
  explode: {
    array: [-1.2, 0.4, 0.8],
    linked_list: [1.2, 0.4, 0.8],
    stack: [-1.4, 0.5, -0.9],
    queue: [0.0, 0.3, 1.2],
    binary_tree: [0.0, 0.6, -1.0],
    graph: [1.4, 0.5, -0.9]
  },
  home: {
    direction: [0, 1.35, 1.8],
    target: [0, 0.3, 0],
    distance: 7.2,
    fov: 42
  },
  dataFlowRoutes: [
    {
      id: 'queue_to_graph',
      label: 'BFS traversal frontier',
      curve: new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.0, 0.4, 1.7),
        new THREE.Vector3(1.6, 0.6, 0.2),
        new THREE.Vector3(3.4, 0.7, -1.5)
      ]),
      pulseCount: 7,
      startIndex: 0
    },
    {
      id: 'array_to_tree',
      label: 'Sorted array to BST',
      curve: new THREE.CatmullRomCurve3([
        new THREE.Vector3(-3.2, 0.4, 1.4),
        new THREE.Vector3(-1.6, 0.8, -0.2),
        new THREE.Vector3(0.0, 1.45, -1.5)
      ]),
      pulseCount: 7,
      startIndex: 7
    }
  ]
};

export { ALGORITHMS } from './algorithms.ts';
