/**
 * Boardwalk — Data Structures Pack Catalog
 *
 * Defines the 6 core computer science data structures:
 * Array, Linked List, Stack, Queue, Binary Tree, and Graph.
 *
 * Each part includes complete technical documentation, typical Big-O numbers,
 * real failure modes (buffer overflows, dangling pointers, recursion exhaustion),
 * and educational quiz clues.
 */

import { PartData } from '../types.ts';

export const DATA_STRUCTURE_PARTS: PartData[] = [
  {
    id: 'array',
    number: 1,
    name: 'Array',
    summary: 'Contiguous block of fixed-size memory slots accessed in O(1) time by numerical index.',
    body: [
      'An array stores elements of identical type in consecutive physical memory addresses. Knowing the base address and element byte width allows the CPU to calculate any slot address instantly using index arithmetic.',
      'Because the memory block is fixed upon allocation, resizing requires allocating a new memory range and copying all elements over in O(N) time. Insertions or deletions in the middle require shifting all subsequent elements.'
    ],
    specs: [
      { label: 'Index Access', value: 'O(1) constant time' },
      { label: 'Linear Search', value: 'O(N) un-sorted' },
      { label: 'Binary Search', value: 'O(log N) sorted' },
      { label: 'Insertion/Delete', value: 'O(N) shift cost' }
    ],
    fails: 'IndexOutOfBoundsException and buffer overrun vulnerabilities when addressing memory beyond the allocated array bounds.',
    clue: 'A contiguous block of indexed memory cells offering constant-time direct element lookup via base-plus-offset calculation.'
  },
  {
    id: 'linked_list',
    number: 2,
    name: 'Linked List',
    summary: 'Linear chain of heap nodes where each entry stores a payload and an explicit pointer to its successor.',
    body: [
      'Unlike contiguous arrays, linked list nodes reside dynamically throughout heap memory. Each node encapsulates its data along with a pointer referencing the memory address of the subsequent node.',
      'Prepending a node to the head or splicing after a known reference is an instant O(1) pointer assignment with zero element shifting. However, finding an arbitrary item requires sequentially following pointer references in O(N) time.'
    ],
    specs: [
      { label: 'Head Insert/Delete', value: 'O(1) constant' },
      { label: 'Arbitrary Lookup', value: 'O(N) pointer walk' },
      { label: 'Per-Node Overhead', value: '8 bytes pointer on 64-bit' },
      { label: 'Cache Locality', value: 'Dispersed across heap' }
    ],
    fails: 'Dangling pointers, memory leaks caused by losing the head pointer, and null-pointer dereference crashes on list traversal.',
    clue: 'A sequential chain of dynamic heap nodes linked together by explicit next-memory address pointers.'
  },
  {
    id: 'stack',
    number: 3,
    name: 'Stack',
    summary: 'Last-In, First-Out (LIFO) container restricted to push, pop, and peek operations at a single top boundary.',
    body: [
      'A stack enforces a strict Last-In, First-Out access discipline. Items are pushed onto the top and popped from the top in O(1) time, preventing arbitrary access to intermediate elements.',
      'Stacks form the backbone of hardware execution call stacks, recursive function stack frames, browser history back-stacks, and expression syntax parsing.'
    ],
    specs: [
      { label: 'Push & Pop', value: 'O(1) constant time' },
      { label: 'Peek / Top', value: 'O(1) inspection' },
      { label: 'Access Order', value: 'LIFO discipline' },
      { label: 'Primary Role', value: 'Call stack, undo/redo, DFS' }
    ],
    fails: 'Stack overflow error when unconstrained recursion or unbounded push operations exceed thread stack allocation limits.',
    clue: 'A vertical LIFO container where elements can only be pushed and popped from the uppermost open boundary.'
  },
  {
    id: 'queue',
    number: 4,
    name: 'Queue',
    summary: 'First-In, First-Out (FIFO) pipeline where elements enqueue at the rear and dequeue from the front.',
    body: [
      'A queue guarantees fair, chronological order of arrival. New elements join the tail via Enqueue, while the oldest pending item departs from the head via Dequeue in O(1) time.',
      'Queues orchestrate asynchronous event loops, operating system CPU runqueues, printer spoolers, and breadth-first search frontier management.'
    ],
    specs: [
      { label: 'Enqueue & Dequeue', value: 'O(1) constant' },
      { label: 'Access Order', value: 'FIFO discipline' },
      { label: 'Boundary Pointers', value: 'Front (head), Rear (tail)' },
      { label: 'Primary Role', value: 'Event dispatch, BFS, IPC' }
    ],
    fails: 'Queue starvation when producer throughput outpaces consumers, leading to buffer memory exhaustion or packet drop.',
    clue: 'A sequential FIFO conduit that serves the oldest arrival first from the front while appending newcomers to the rear.'
  },
  {
    id: 'binary_tree',
    number: 5,
    name: 'Binary Tree',
    summary: 'Hierarchical node structure where each parent node branches downward to at most two child nodes.',
    body: [
      'In a Binary Search Tree (BST), every node satisfies the ordering invariant: all keys in its left subtree are strictly smaller, and all keys in its right subtree are strictly greater. This halves the candidate search space at each descent.',
      'Self-balancing variants (such as AVL and Red-Black trees) guarantee O(log N) logarithmic depth for lookup, insertion, and deletion by performing tree rotations during mutations.'
    ],
    specs: [
      { label: 'Balanced Lookup', value: 'O(log N) logarithmic' },
      { label: 'Unbalanced Lookup', value: 'O(N) degenerate case' },
      { label: 'Branching Degree', value: 'At most 2 per node' },
      { label: 'Height (Balanced)', value: 'Floor(log2 N)' }
    ],
    fails: 'Pathological tree skew into a degenerate O(N) linked list when elements are inserted in monotonic sorted order without balancing.',
    clue: 'A hierarchical branching structure with a single root node where every parent node has at most two descendents.'
  },
  {
    id: 'graph',
    number: 6,
    name: 'Graph',
    summary: 'Non-linear network composed of vertices (nodes) interconnected by directed or undirected edges.',
    body: [
      'Graphs model complex many-to-many topologies without root or hierarchical restrictions. Real-world systems like internet routing meshes, social friendship graphs, and dependency graphs map directly to graph structures.',
      'Vertices and edges are stored as adjacency lists or adjacency matrices. Algorithms explore the graph via Breadth-First Search (BFS) for shortest paths or Depth-First Search (DFS) for topological sorting.'
    ],
    specs: [
      { label: 'Topology', value: 'Vertices V and Edges E' },
      { label: 'Adjacency Storage', value: 'O(V + E) list / O(V²) matrix' },
      { label: 'Traversal Cost', value: 'O(V + E) for BFS / DFS' },
      { label: 'Edge Types', value: 'Directed, undirected, weighted' }
    ],
    fails: 'Infinite traversal loops when cycling through cyclic graphs without an explicit visited node tracking set.',
    clue: 'A generalized network of interconnected vertices linked by arbitrary directed or undirected edges.'
  }
];
