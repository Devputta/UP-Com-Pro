/**
 * Boardwalk — PC Hardware Pack
 */

import { Pack } from '../types.ts';
import { buildHardwarePack } from './build.ts';
import {
  createHardwareDataFlowRoutes,
  HARDWARE_ANCHORS,
  HARDWARE_EXPLODE_VECTORS,
  HARDWARE_HOME,
  HARDWARE_SUBASSEMBLY_LIFTS
} from './layout.ts';
import { HARDWARE_JOURNEY_STEPS, HARDWARE_PART_LIST } from './parts.ts';

export const hardwarePack: Pack = {
  id: 'hardware',
  name: 'PC Hardware',
  title: 'PC Hardware',
  shortTitle: 'Hardware',
  journeySubtitle: 'Opening a video file',
  parts: HARDWARE_PART_LIST,
  journey: HARDWARE_JOURNEY_STEPS,
  build: buildHardwarePack,
  explode: HARDWARE_EXPLODE_VECTORS,
  subassemblyLifts: HARDWARE_SUBASSEMBLY_LIFTS,
  anchors: HARDWARE_ANCHORS,
  home: HARDWARE_HOME,
  dataFlowRoutes: createHardwareDataFlowRoutes()
};
