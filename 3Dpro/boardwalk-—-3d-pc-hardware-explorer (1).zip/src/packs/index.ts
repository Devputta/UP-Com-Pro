/**
 * Boardwalk — Pack Registry
 *
 * Manages available learning packs and persists the user's active pack selection.
 */

import { dataStructuresPack } from './datastructures/index.ts';
import { hardwarePack } from './hardware/index.ts';
import { networkingPack } from './networking/index.ts';
import { Pack } from './types.ts';

export * from './types.ts';
export { dataStructuresPack } from './datastructures/index.ts';
export { hardwarePack } from './hardware/index.ts';
export { networkingPack } from './networking/index.ts';

export const PACKS: Pack[] = [hardwarePack, networkingPack, dataStructuresPack];

const PACK_STORAGE_KEY = 'boardwalk_active_pack';

export function getStoredPackId(): string {
  try {
    const saved = localStorage.getItem(PACK_STORAGE_KEY);
    if (saved && PACKS.some((p) => p.id === saved)) {
      return saved;
    }
    return hardwarePack.id;
  } catch {
    return hardwarePack.id;
  }
}

export function setStoredPackId(packId: string): void {
  try {
    localStorage.setItem(PACK_STORAGE_KEY, packId);
  } catch {
    // Graceful fallback
  }
}

export function getPackById(id: string): Pack {
  return PACKS.find((p) => p.id === id) || hardwarePack;
}
