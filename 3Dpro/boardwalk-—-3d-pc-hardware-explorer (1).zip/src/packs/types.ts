/**
 * Boardwalk — Pack System Types
 *
 * Defines the contract for interchangeable learning packs (e.g., PC Hardware, Networking).
 * Every pack supplies its catalog of parts, 3D procedural builder, explode layout,
 * and guided dataflow journey.
 */

import * as THREE from 'three';

export interface PartSpec {
  label: string;
  value: string;
}

export interface PartData {
  id: string;
  number: number;
  name: string;
  summary: string;
  body: [string, string];
  specs: [PartSpec, PartSpec, PartSpec, PartSpec];
  fails: string;
  clue: string;
}

export interface JourneyStep {
  partId: string;
  stepNumber: number;
  title: string;
  lede: string;
  body: string;
}

export interface BuiltPart {
  id: string;
  group: THREE.Group;
  materials: THREE.Material[];
  pickableMeshes: THREE.Mesh[];
  subAssemblies?: Record<string, THREE.Group>;
}

export interface SceneBuildResult {
  parts: Record<string, BuiltPart>;
  surfaceMountMesh?: THREE.InstancedMesh;
}

export interface DataFlowRoute {
  id: string;
  label: string;
  curve: THREE.CatmullRomCurve3;
  pulseCount: number;
  startIndex: number;
}

export interface Pack {
  id: string;
  name: string;
  title: string;
  shortTitle: string;
  journeySubtitle?: string;
  parts: PartData[];
  journey: JourneyStep[];
  build(): SceneBuildResult;
  explode: Record<string, [number, number, number]>;
  subassemblyLifts?: Record<string, [number, number, number]>;
  anchors?: Partial<Record<string, [number, number, number]>>;
  home: {
    direction: [number, number, number];
    target: [number, number, number];
    distance: number;
    fov?: number;
  };
  dataFlowRoutes?: DataFlowRoute[];
}
