import React, { useState, useMemo } from 'react';
import {
  GitCompare,
  ArrowLeftRight,
  PlusCircle,
  MinusCircle,
  FileEdit,
  CheckCircle,
  BookOpen,
  Filter,
  Download,
  AlertTriangle,
  Lightbulb,
  BookMarked,
  PieChart,
  HelpCircle,
  FileText,
  Layers,
  Info,
  FileDown,
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import {
  DocumentEntity,
  DocumentChunk,
  ComparisonResult,
  DiffChangeType,
  ComparisonMode,
  ConceptMatch,
  DefinitionComparisonItem,
  TopicItem,
} from '../types/doculens';
import { compareDocuments } from '../services/comparisonEngine';

interface CompareViewProps {
  documents: DocumentEntity[];
  chunks: DocumentChunk[];
  initialLeftDocId?: string;
  initialRightDocId?: string;
  onNavigateToReader: (docId: string, pageNumber: number, highlightQuery?: string) => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  documents,
  chunks,
  initialLeftDocId,
  initialRightDocId,
  onNavigateToReader,
}) => {
  const readyDocs = documents.filter((d) => d.status === 'ready');

  // Choose sensible defaults if available
  const defaultLeft =
    initialLeftDocId ||
    readyDocs.find((d) => d.id.includes('computing-foundations'))?.id ||
    readyDocs[1]?.id ||
    readyDocs[0]?.id ||
    '';

  const defaultRight =
    initialRightDocId ||
    readyDocs.find((d) => d.id.includes('computing-architectures'))?.id ||
    readyDocs.find((d) => d.id !== defaultLeft)?.id ||
    '';

  const [leftDocId, setLeftDocId] = useState<string>(defaultLeft);
  const [rightDocId, setRightDocId] = useState<string>(defaultRight);
  const [activeMode, setActiveMode] = useState<ComparisonMode>('concept-comparison');
  const [diffFilter, setDiffFilter] = useState<DiffChangeType | 'all'>('all');
  const [conceptFilter, setConceptFilter] = useState<string>('all');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const leftDoc = readyDocs.find((d) => d.id === leftDocId);
  const rightDoc = readyDocs.find((d) => d.id === rightDocId);

  // Swap Document A and Document B
  const handleSwap = () => {
    const temp = leftDocId;
    setLeftDocId(rightDocId);
    setRightDocId(temp);
  };

  // Compute full comparison result
  const comparisonResult: ComparisonResult | null = useMemo(() => {
    if (!leftDoc || !rightDoc || leftDoc.id === rightDoc.id) return null;

    const leftChunks = chunks.filter((c) => c.documentId === leftDoc.id);
    const rightChunks = chunks.filter((c) => c.documentId === rightDoc.id);

    return compareDocuments(leftDoc, rightDoc, leftChunks, rightChunks, { mode: activeMode });
  }, [leftDoc, rightDoc, chunks, activeMode]);

  // Filtered changes for Content Differences mode
  const filteredChanges = useMemo(() => {
    if (!comparisonResult) return [];
    if (diffFilter === 'all') return comparisonResult.changes;
    return comparisonResult.changes.filter((c) => c.type === diffFilter);
  }, [comparisonResult, diffFilter]);

  // Filtered concepts
  const filteredConcepts = useMemo(() => {
    if (!comparisonResult?.conceptMatches) return [];
    if (conceptFilter === 'all') return comparisonResult.conceptMatches;
    return comparisonResult.conceptMatches.filter((c) => c.relationshipType === conceptFilter);
  }, [comparisonResult, conceptFilter]);

  // Export comparison report as Markdown
  const handleExportMarkdown = () => {
    if (!comparisonResult || !leftDoc || !rightDoc) return;

    let md = `# DocuLens Document Intelligence Comparison Report\n\n`;
    md += `**Generated:** ${new Date(comparisonResult.createdAt).toLocaleString()}\n`;
    md += `**Reference Document (A):** ${leftDoc.originalName} (${leftDoc.pageCount} pages, ${leftDoc.chunkCount} chunks)\n`;
    md += `**Comparison Document (B):** ${rightDoc.originalName} (${rightDoc.pageCount} pages, ${rightDoc.chunkCount} chunks)\n\n`;

    md += `## 1. Executive Summary\n`;
    md += `- **Shared Concepts Identified:** ${comparisonResult.conceptMatches?.length || 0}\n`;
    md += `- **Defined Terms Compared:** ${comparisonResult.definitionComparisons?.length || 0}\n`;
    md += `- **Topic Overlap Jaccard Index:** ${comparisonResult.topicOverlap?.overlapPercentage || 0}%\n`;
    md += `- **Clause Additions:** ${comparisonResult.statistics.added} | **Removals:** ${comparisonResult.statistics.removed} | **Modifications:** ${comparisonResult.statistics.modified}\n\n`;

    if (comparisonResult.conceptMatches && comparisonResult.conceptMatches.length > 0) {
      md += `## 2. Concept Comparison (Cross-Vocabulary Alignment)\n\n`;
      for (const cpt of comparisonResult.conceptMatches) {
        md += `### ${cpt.conceptTitle} (${cpt.confidenceLabel})\n`;
        md += `- **Relationship Type:** ${cpt.relationshipType.replace('_', ' ')}\n`;
        md += `- **Document A Excerpt (p.${cpt.leftPage}):** "${cpt.leftExcerpt}"\n`;
        md += `- **Document B Excerpt (p.${cpt.rightPage}):** "${cpt.rightExcerpt}"\n`;
        md += `- **Nuance & Distinction:** ${cpt.nuanceNotes}\n\n`;
      }
    }

    if (comparisonResult.definitionComparisons && comparisonResult.definitionComparisons.length > 0) {
      md += `## 3. Definition & Rule Comparison\n\n`;
      for (const def of comparisonResult.definitionComparisons) {
        md += `### ${def.term} [Alignment: ${def.alignment.replace('_', ' ')}]\n`;
        if (def.leftDefinition) md += `- **Doc A (p.${def.leftPage}):** "${def.leftDefinition}"\n`;
        if (def.rightDefinition) md += `- **Doc B (p.${def.rightPage}):** "${def.rightDefinition}"\n`;
        if (def.keyDifferences) md += `- **Differences:** ${def.keyDifferences}\n`;
        md += `\n`;
      }
    }

    if (comparisonResult.topicOverlap) {
      md += `## 4. Topic Overlap & Subject Matrix\n`;
      md += `Calculation Method: ${comparisonResult.topicOverlap.calculationMethod}\n\n`;
      md += `### Shared Topics\n`;
      for (const t of comparisonResult.topicOverlap.sharedTopics) {
        md += `- **${t.topicName}:** Doc A p.${t.leftPage} & Doc B p.${t.rightPage}\n`;
      }
      md += `\n### Unique to Document A\n`;
      for (const t of comparisonResult.topicOverlap.uniqueToLeft) {
        md += `- **${t.topicName}** (Doc A p.${t.leftPage})\n`;
      }
      md += `\n### Unique to Document B\n`;
      for (const t of comparisonResult.topicOverlap.uniqueToRight) {
        md += `- **${t.topicName}** (Doc B p.${t.rightPage})\n`;
      }
    }

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `DocuLens_Comparison_${leftDoc.id}_vs_${rightDoc.id}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setExportNotice('Comparison report downloaded as Markdown.');
    setTimeout(() => setExportNotice(null), 4000);
  };

  // Export comparison report as a well-formatted PDF
  const handleExportPDF = () => {
    if (!comparisonResult || !leftDoc || !rightDoc) return;

    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4',
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 40;
      const contentWidth = pageWidth - margin * 2;
      let y = margin;

      const checkPageBreak = (neededHeight: number) => {
        if (y + neededHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(140, 140, 140);
          doc.text('DocuLens Intelligence Report — Document Comparison', margin, y);
          doc.text(`Page ${doc.getNumberOfPages()}`, pageWidth - margin - 35, y);
          y += 18;
          doc.setDrawColor(220, 220, 220);
          doc.line(margin, y, pageWidth - margin, y);
          y += 20;
        }
      };

      // Header Banner
      doc.setFont('times', 'bold');
      doc.setFontSize(18);
      doc.setTextColor(36, 37, 32);
      doc.text('DocuLens Document Intelligence Report', margin, y);
      y += 18;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(110, 110, 110);
      doc.text(
        `Generated: ${new Date(comparisonResult.createdAt).toLocaleString()} | Local-First Document Analysis`,
        margin,
        y
      );
      y += 14;

      doc.setDrawColor(184, 75, 47);
      doc.setLineWidth(2);
      doc.line(margin, y, pageWidth - margin, y);
      y += 18;

      // Metadata summary box
      doc.setFillColor(244, 241, 233);
      doc.roundedRect(margin, y, contentWidth, 58, 4, 4, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(184, 75, 47);
      doc.text('DOCUMENT A (Reference):', margin + 12, y + 17);
      doc.setTextColor(36, 37, 32);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `${leftDoc.originalName} (${leftDoc.pageCount} pages, ${leftDoc.chunkCount} chunks)`,
        margin + 160,
        y + 17
      );

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(184, 75, 47);
      doc.text('DOCUMENT B (Comparison):', margin + 12, y + 34);
      doc.setTextColor(36, 37, 32);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `${rightDoc.originalName} (${rightDoc.pageCount} pages, ${rightDoc.chunkCount} chunks)`,
        margin + 160,
        y + 34
      );

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.text(`Active Mode: ${activeMode.toUpperCase()} | SHA Verified Provenance`, margin + 12, y + 49);
      y += 72;

      // 1. Executive Summary
      checkPageBreak(90);
      doc.setFont('times', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(36, 37, 32);
      doc.text('1. Executive Summary & Comparison Metrics', margin, y);
      y += 16;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(60, 60, 60);
      const metrics = [
        `• Shared Concepts Mapped: ${comparisonResult.conceptMatches?.length || 0}`,
        `• Defined Terms Analyzed: ${comparisonResult.definitionComparisons?.length || 0}`,
        `• Topic Overlap Score (Jaccard Index): ${comparisonResult.topicOverlap?.overlapPercentage || 0}%`,
        `• Clause Level Variations: ${comparisonResult.statistics.added} additions, ${comparisonResult.statistics.modified} modifications, ${comparisonResult.statistics.removed} removals`,
      ];
      for (const m of metrics) {
        doc.text(m, margin + 10, y);
        y += 14;
      }
      y += 10;

      // 2. Content Differences
      if (comparisonResult.changes.length > 0) {
        checkPageBreak(70);
        doc.setFont('times', 'bold');
        doc.setFontSize(12);
        doc.setTextColor(36, 37, 32);
        doc.text(`2. Content Differences (${comparisonResult.changes.length} Clauses)`, margin, y);
        y += 16;

        for (const change of comparisonResult.changes.slice(0, 18)) {
          checkPageBreak(55);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          if (change.type === 'addition') doc.setTextColor(34, 120, 60);
          else if (change.type === 'removal') doc.setTextColor(180, 40, 40);
          else if (change.type === 'modification') doc.setTextColor(184, 75, 47);
          else doc.setTextColor(90, 90, 90);

          doc.text(`[${change.type.toUpperCase()}] ${change.summary || 'Clause Variation'}`, margin + 10, y);
          y += 11;

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(70, 70, 70);
          if (change.leftText) {
            const linesA = doc.splitTextToSize(
              `Doc A (p.${change.leftPage || 1}): "${change.leftText.slice(0, 130)}"`,
              contentWidth - 25
            );
            doc.text(linesA, margin + 15, y);
            y += linesA.length * 9.5 + 2;
          }
          if (change.rightText) {
            const linesB = doc.splitTextToSize(
              `Doc B (p.${change.rightPage || 1}): "${change.rightText.slice(0, 130)}"`,
              contentWidth - 25
            );
            doc.text(linesB, margin + 15, y);
            y += linesB.length * 9.5 + 4;
          }
          y += 4;
        }
      }

      // 3. Concept Comparison
      if (comparisonResult.conceptMatches && comparisonResult.conceptMatches.length > 0) {
        checkPageBreak(70);
        doc.setFont('times', 'bold');
        doc.setFontSize(12);
        doc.setTextColor(36, 37, 32);
        doc.text('3. Concept Comparison (Cross-Terminology Alignments)', margin, y);
        y += 16;

        for (const cpt of comparisonResult.conceptMatches) {
          checkPageBreak(75);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(184, 75, 47);
          doc.text(
            `• ${cpt.conceptTitle} (${cpt.confidenceLabel}) — ${cpt.relationshipType.replace('_', ' ')}`,
            margin + 10,
            y
          );
          y += 12;

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(70, 70, 70);
          const excerptA = doc.splitTextToSize(
            `Doc A (p.${cpt.leftPage}): "${cpt.leftExcerpt.slice(0, 140)}"`,
            contentWidth - 25
          );
          doc.text(excerptA, margin + 15, y);
          y += excerptA.length * 9.5 + 2;

          const excerptB = doc.splitTextToSize(
            `Doc B (p.${cpt.rightPage}): "${cpt.rightExcerpt.slice(0, 140)}"`,
            contentWidth - 25
          );
          doc.text(excerptB, margin + 15, y);
          y += excerptB.length * 9.5 + 2;

          const nuance = doc.splitTextToSize(`Distinction: ${cpt.nuanceNotes}`, contentWidth - 25);
          doc.setTextColor(110, 110, 110);
          doc.text(nuance, margin + 15, y);
          y += nuance.length * 9.5 + 6;
        }
      }

      // 4. Definition Comparison
      if (comparisonResult.definitionComparisons && comparisonResult.definitionComparisons.length > 0) {
        checkPageBreak(70);
        doc.setFont('times', 'bold');
        doc.setFontSize(12);
        doc.setTextColor(36, 37, 32);
        doc.text('4. Definition & Rule Comparison', margin, y);
        y += 16;

        for (const def of comparisonResult.definitionComparisons) {
          checkPageBreak(60);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(36, 37, 32);
          doc.text(`• ${def.term} [Alignment: ${def.alignment.toUpperCase()}]`, margin + 10, y);
          y += 12;

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(70, 70, 70);
          if (def.leftDefinition) {
            const defA = doc.splitTextToSize(`Doc A (p.${def.leftPage}): ${def.leftDefinition}`, contentWidth - 25);
            doc.text(defA, margin + 15, y);
            y += defA.length * 9.5 + 2;
          }
          if (def.rightDefinition) {
            const defB = doc.splitTextToSize(`Doc B (p.${def.rightPage}): ${def.rightDefinition}`, contentWidth - 25);
            doc.text(defB, margin + 15, y);
            y += defB.length * 9.5 + 2;
          }
          if (def.keyDifferences) {
            const diff = doc.splitTextToSize(`Differences: ${def.keyDifferences}`, contentWidth - 25);
            doc.setTextColor(150, 60, 40);
            doc.text(diff, margin + 15, y);
            y += diff.length * 9.5 + 4;
          }
          y += 4;
        }
      }

      // 5. Topic Overlap
      if (comparisonResult.topicOverlap) {
        checkPageBreak(70);
        doc.setFont('times', 'bold');
        doc.setFontSize(12);
        doc.setTextColor(36, 37, 32);
        doc.text('5. Topic Overlap Matrix', margin, y);
        y += 16;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        doc.text(`Method: ${comparisonResult.topicOverlap.calculationMethod}`, margin + 10, y);
        y += 13;

        if (comparisonResult.topicOverlap.sharedTopics.length > 0) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(36, 37, 32);
          doc.text('Shared Topics in Both Documents:', margin + 10, y);
          y += 12;
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(70, 70, 70);
          for (const t of comparisonResult.topicOverlap.sharedTopics) {
            checkPageBreak(20);
            doc.text(`- ${t.topicName} (Doc A p.${t.leftPage} | Doc B p.${t.rightPage})`, margin + 15, y);
            y += 11;
          }
          y += 4;
        }
      }

      // Page numbering footer
      const totalPages = doc.getNumberOfPages();
      for (let p = 1; p <= totalPages; p++) {
        doc.setPage(p);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(160, 160, 160);
        doc.text(
          `DocuLens Intelligence Report · Page ${p} of ${totalPages} · Confidential & Traceable`,
          margin,
          pageHeight - 20
        );
      }

      doc.save(`DocuLens_Comparison_Report_${leftDoc.id}_vs_${rightDoc.id}.pdf`);
      setExportNotice('Comparison report downloaded as PDF.');
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err: any) {
      console.error('PDF report generation error:', err);
      setExportNotice('Failed to generate PDF report: ' + (err?.message || 'unknown error'));
      setTimeout(() => setExportNotice(null), 5000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="border-b border-[#E0D9CC] pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
            Intelligent Document Comparison Workspace
          </h1>
          <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
            Compare two documents discussing the same subject across different vocabularies.
            Inspect content diffs, cross-terminology concept mappings, side-by-side definitions,
            and subject overlap matrices.
          </p>
        </div>

        {comparisonResult && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleExportPDF}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#F5F2EB] border border-[#B84B2F]/40 hover:border-[#B84B2F] rounded text-xs font-semibold text-[#B84B2F] transition-colors shadow-2xs"
              title="Download formatted PDF comparison report"
            >
              <FileDown className="w-3.5 h-3.5 text-[#B84B2F]" />
              <span>Export PDF Report</span>
            </button>
            <button
              onClick={handleExportMarkdown}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#F5F2EB] border border-[#E0D9CC] rounded text-xs font-medium text-[#20211D] transition-colors shadow-2xs"
              title="Download Markdown summary report"
            >
              <Download className="w-3.5 h-3.5 text-[#8E9085]" />
              <span>Export Markdown</span>
            </button>
          </div>
        )}
      </div>

      {exportNotice && (
        <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded text-xs">
          {exportNotice}
        </div>
      )}

      {/* Document Selection Toolbar */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
            Select Two Documents to Compare:
          </span>
          <span className="text-[11px] text-[#8E9085]">
            {readyDocs.length} ready documents in library
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-11 gap-3 items-center">
          {/* Document A Selector (Reference) */}
          <div className="md:col-span-5 p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono text-[#B84B2F] font-bold uppercase tracking-wider">
                Document A — Reference Document:
              </span>
              {leftDoc && (
                <span className="text-[10px] font-mono text-[#8E9085]">
                  {leftDoc.pageCount}p · {leftDoc.chunkCount} chunks
                </span>
              )}
            </div>

            <select
              value={leftDocId}
              onChange={(e) => setLeftDocId(e.target.value)}
              aria-label="Document A — Reference Document"
              className="w-full text-xs font-serif font-semibold bg-[#FAF8F5] border border-[#E0D9CC] rounded px-3 py-2 text-[#20211D] focus:outline-none cursor-pointer"
            >
              {readyDocs.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName} ({d.pageCount}p)
                </option>
              ))}
            </select>

            {leftDoc?.summary && (
              <p className="text-[11px] text-[#5C5E55] line-clamp-2 italic font-serif">
                "{leftDoc.summary}"
              </p>
            )}
          </div>

          {/* Swap Action Button */}
          <div className="md:col-span-1 flex justify-center">
            <button
              onClick={handleSwap}
              title="Swap Document A and Document B"
              aria-label="Swap Document A and Document B"
              className="p-2.5 rounded-full bg-[#FAF8F5] border border-[#E0D9CC] hover:border-[#B84B2F] text-[#5C5E55] hover:text-[#B84B2F] shadow-2xs transition-colors"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          {/* Document B Selector (Comparison) */}
          <div className="md:col-span-5 p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono text-[#5C5E55] font-bold uppercase tracking-wider">
                Document B — Comparison Document:
              </span>
              {rightDoc && (
                <span className="text-[10px] font-mono text-[#8E9085]">
                  {rightDoc.pageCount}p · {rightDoc.chunkCount} chunks
                </span>
              )}
            </div>

            <select
              value={rightDocId}
              onChange={(e) => setRightDocId(e.target.value)}
              aria-label="Document B — Comparison Document"
              className="w-full text-xs font-serif font-semibold bg-[#FAF8F5] border border-[#E0D9CC] rounded px-3 py-2 text-[#20211D] focus:outline-none cursor-pointer"
            >
              {readyDocs.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName} ({d.pageCount}p)
                </option>
              ))}
            </select>

            {rightDoc?.summary && (
              <p className="text-[11px] text-[#5C5E55] line-clamp-2 italic font-serif">
                "{rightDoc.summary}"
              </p>
            )}
          </div>
        </div>

        {/* Warning if same document selected */}
        {leftDocId === rightDocId && (
          <div className="text-xs text-amber-800 bg-amber-50 p-3 rounded border border-amber-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              Please select two distinct documents above to execute a cross-document comparison.
            </span>
          </div>
        )}
      </div>

      {/* Comparison Mode Selector Tabs */}
      {comparisonResult && (
        <div className="border-b border-[#E0D9CC]">
          <div className="flex items-center gap-2 overflow-x-auto pb-px" role="tablist">
            {[
              {
                id: 'concept-comparison' as ComparisonMode,
                label: 'Concept Comparison',
                icon: Lightbulb,
                badge: comparisonResult.conceptMatches?.length || 0,
                desc: 'Passages discussing the same subject with different words',
              },
              {
                id: 'definition-comparison' as ComparisonMode,
                label: 'Definition Comparison',
                icon: BookMarked,
                badge: comparisonResult.definitionComparisons?.length || 0,
                desc: 'Compare extracted term definitions and algorithmic rules',
              },
              {
                id: 'topic-overlap' as ComparisonMode,
                label: 'Topic Overlap',
                icon: PieChart,
                badge: `${comparisonResult.topicOverlap?.overlapPercentage || 0}%`,
                desc: 'Shared subjects vs unique coverage breakdown',
              },
              {
                id: 'content-diff' as ComparisonMode,
                label: 'Content Differences',
                icon: GitCompare,
                badge: comparisonResult.changes.length,
                desc: 'Clause additions, removals, and modifications',
              },
            ].map((mode) => {
              const Icon = mode.icon;
              const isActive = activeMode === mode.id;
              return (
                <button
                  key={mode.id}
                  onClick={() => setActiveMode(mode.id)}
                  role="tab"
                  aria-selected={isActive}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-t-lg border-b-2 transition-colors whitespace-nowrap ${
                    isActive
                      ? 'border-[#B84B2F] bg-[#FAF8F5] text-[#B84B2F] font-semibold'
                      : 'border-transparent text-[#5C5E55] hover:text-[#20211D] hover:bg-[#F5F2EB]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#B84B2F]' : 'text-[#8E9085]'}`} />
                  <span>{mode.label}</span>
                  <span
                    className={`font-mono text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-[#B84B2F]/15 text-[#B84B2F]' : 'bg-[#EAE5D9] text-[#5C5E55]'
                    }`}
                  >
                    {mode.badge}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty / Unselected State */}
      {!comparisonResult && (
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-12 text-center text-[#5C5E55] space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#F5F2EB] border border-[#E0D9CC] p-3 flex items-center justify-center shadow-xs">
            <img
              src="/doculens-mark-transparent.png"
              alt="DocuLens Compare"
              className="w-full h-full object-contain"
            />
          </div>
          <p className="font-serif text-lg font-medium text-[#20211D]">
            Select Two Documents to Initiate Comparison
          </p>
          <p className="text-xs max-w-md mx-auto text-[#5C5E55] leading-relaxed">
            Select Reference Document A and Comparison Document B above to explore concept
            alignments, differing terminology, rule definitions, and structural changes.
          </p>
        </div>
      )}

      {/* MODE 1: CONCEPT COMPARISON WORKSPACE */}
      {comparisonResult && activeMode === 'concept-comparison' && (
        <div className="space-y-4">
          <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-[#B84B2F]" />
              <span className="font-medium text-[#20211D]">
                Cross-Vocabulary Concept Matches ({comparisonResult.conceptMatches?.length || 0} found)
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[#8E9085]">Filter Relationship:</span>
              <select
                value={conceptFilter}
                onChange={(e) => setConceptFilter(e.target.value)}
                className="bg-[#F5F2EB] border border-[#E0D9CC] rounded px-2 py-1 text-xs text-[#20211D] focus:outline-none"
              >
                <option value="all">All Relationships</option>
                <option value="synonymous_terminology">Synonymous Terminology</option>
                <option value="overlapping_definition">Overlapping Definition</option>
                <option value="differing_perspective">Differing Perspective</option>
                <option value="possible_relationship">Possible Relationship</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredConcepts.length === 0 ? (
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55] space-y-2">
                <Info className="w-6 h-6 mx-auto text-[#8E9085]" />
                <p className="font-serif">No concepts match the selected filter.</p>
              </div>
            ) : (
              filteredConcepts.map((cpt) => {
                const isSynonym = cpt.relationshipType === 'synonymous_terminology';
                const isPerspective = cpt.relationshipType === 'differing_perspective';
                const isOverlap = cpt.relationshipType === 'overlapping_definition';

                return (
                  <div
                    key={cpt.id}
                    className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-4 shadow-2xs hover:border-[#C8BFB0] transition-colors"
                  >
                    {/* Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EAE5D9] pb-3 text-xs">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-serif font-bold text-sm text-[#20211D]">
                          {cpt.conceptTitle}
                        </span>
                        {cpt.category && (
                          <span className="font-mono text-[10px] bg-[#F5F2EB] border border-[#E0D9CC] text-[#5C5E55] px-1.5 py-0.5 rounded">
                            {cpt.category}
                          </span>
                        )}
                        <span
                          className={`font-mono text-[10px] px-2 py-0.5 rounded font-semibold ${
                            cpt.confidenceLabel === 'High Confidence'
                              ? 'bg-emerald-100 text-emerald-800'
                              : cpt.confidenceLabel === 'Moderate Confidence'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-stone-200 text-stone-700'
                          }`}
                        >
                          {cpt.confidenceLabel} ({Math.round(cpt.confidence * 100)}%)
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[11px] font-medium px-2 py-0.5 rounded border ${
                            isSynonym
                              ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                              : isPerspective
                              ? 'border-[#B84B2F]/30 bg-[#B84B2F]/10 text-[#B84B2F]'
                              : isOverlap
                              ? 'border-blue-300 bg-blue-50 text-blue-800'
                              : 'border-[#E0D9CC] bg-[#F5F2EB] text-[#5C5E55]'
                          }`}
                        >
                          {cpt.relationshipType.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {/* Side-by-side Evidence Passages */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-serif leading-relaxed">
                      {/* Document A Passage */}
                      <div className="p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-mono text-[#5C5E55] border-b border-[#E0D9CC] pb-1.5">
                          <span className="font-semibold text-[#B84B2F] truncate max-w-[200px]">
                            Doc A: {leftDoc?.originalName}
                          </span>
                          <button
                            onClick={() =>
                              onNavigateToReader(leftDoc!.id, cpt.leftPage, cpt.conceptTitle)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#20211D] hover:text-[#B84B2F]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Page {cpt.leftPage}</span>
                          </button>
                        </div>
                        <p className="text-[#20211D]">"{cpt.leftExcerpt}"</p>
                      </div>

                      {/* Document B Passage */}
                      <div className="p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-mono text-[#5C5E55] border-b border-[#E0D9CC] pb-1.5">
                          <span className="font-semibold text-[#20211D] truncate max-w-[200px]">
                            Doc B: {rightDoc?.originalName}
                          </span>
                          <button
                            onClick={() =>
                              onNavigateToReader(rightDoc!.id, cpt.rightPage, cpt.conceptTitle)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#20211D] hover:text-[#B84B2F]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Page {cpt.rightPage}</span>
                          </button>
                        </div>
                        <p className="text-[#20211D]">"{cpt.rightExcerpt}"</p>
                      </div>
                    </div>

                    {/* Nuance & Distinction Commentary */}
                    <div className="p-3 bg-[#EAE5D9]/60 rounded border border-[#E0D9CC] text-xs space-y-1">
                      <div className="text-[11px] font-semibold text-[#20211D] uppercase tracking-wider flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-[#B84B2F]" />
                        <span>Semantic Nuance & Preserved Distinctions:</span>
                      </div>
                      <p className="text-[#5C5E55] font-sans leading-relaxed">{cpt.nuanceNotes}</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* MODE 2: DEFINITION COMPARISON WORKSPACE */}
      {comparisonResult && activeMode === 'definition-comparison' && (
        <div className="space-y-4">
          <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <BookMarked className="w-4 h-4 text-[#B84B2F]" />
              <span className="font-medium text-[#20211D]">
                Side-by-Side Term Definitions & Criteria ({comparisonResult.definitionComparisons?.length || 0} terms)
              </span>
            </div>
            <span className="text-[11px] text-[#8E9085]">
              Extracted directly from source text
            </span>
          </div>

          <div className="space-y-4">
            {(!comparisonResult.definitionComparisons ||
              comparisonResult.definitionComparisons.length === 0) && (
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55]">
                <p className="font-serif">No explicit definitions found in these documents.</p>
              </div>
            )}

            {comparisonResult.definitionComparisons?.map((def) => {
              const isConsistent = def.alignment === 'consistent';
              const isDifferingScope = def.alignment === 'differing_scope';
              const isConflicting = def.alignment === 'conflicting';
              const isOnlyA = def.alignment === 'only_in_doc_a';
              const isOnlyB = def.alignment === 'only_in_doc_b';

              return (
                <div
                  key={def.id}
                  className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-4 shadow-2xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EAE5D9] pb-3 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-serif font-bold text-base text-[#20211D]">
                        {def.term}
                      </span>
                    </div>

                    <div>
                      <span
                        className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded border uppercase ${
                          isConsistent
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                            : isDifferingScope
                            ? 'bg-amber-50 border-amber-300 text-amber-800'
                            : isConflicting
                            ? 'bg-red-50 border-red-300 text-red-800'
                            : 'bg-stone-100 border-stone-300 text-stone-700'
                        }`}
                      >
                        {def.alignment.replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>

                  {/* Side-by-Side Definitions */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-serif leading-relaxed">
                    {/* Left Def */}
                    <div className="p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
                      <div className="flex items-center justify-between text-[11px] font-mono text-[#5C5E55] border-b border-[#E0D9CC] pb-1.5">
                        <span className="font-semibold text-[#B84B2F]">Doc A Definition</span>
                        {def.leftPage && (
                          <button
                            onClick={() =>
                              onNavigateToReader(leftDoc!.id, def.leftPage!, def.term)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#20211D] hover:text-[#B84B2F]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Page {def.leftPage}</span>
                          </button>
                        )}
                      </div>
                      {def.leftDefinition ? (
                        <p className="text-[#20211D]">"{def.leftDefinition}"</p>
                      ) : (
                        <p className="text-[#8E9085] italic font-sans">[Not defined in Document A]</p>
                      )}
                    </div>

                    {/* Right Def */}
                    <div className="p-3.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded-lg space-y-2">
                      <div className="flex items-center justify-between text-[11px] font-mono text-[#5C5E55] border-b border-[#E0D9CC] pb-1.5">
                        <span className="font-semibold text-[#20211D]">Doc B Definition</span>
                        {def.rightPage && (
                          <button
                            onClick={() =>
                              onNavigateToReader(rightDoc!.id, def.rightPage!, def.term)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#20211D] hover:text-[#B84B2F]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Page {def.rightPage}</span>
                          </button>
                        )}
                      </div>
                      {def.rightDefinition ? (
                        <p className="text-[#20211D]">"{def.rightDefinition}"</p>
                      ) : (
                        <p className="text-[#8E9085] italic font-sans">[Not defined in Document B]</p>
                      )}
                    </div>
                  </div>

                  {/* Key Similarities & Differences */}
                  {(def.keySimilarities || def.keyDifferences) && (
                    <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-1.5 text-xs">
                      {def.keySimilarities && (
                        <p className="text-[#5C5E55]">
                          <strong className="text-[#20211D]">Key Similarities:</strong>{' '}
                          {def.keySimilarities}
                        </p>
                      )}
                      {def.keyDifferences && (
                        <p className="text-[#B84B2F]">
                          <strong className="text-[#B84B2F]">Meaningful Distinctions:</strong>{' '}
                          {def.keyDifferences}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODE 3: TOPIC OVERLAP WORKSPACE */}
      {comparisonResult && activeMode === 'topic-overlap' && (
        <div className="space-y-6">
          {/* Overlap Index Bar */}
          {comparisonResult.topicOverlap && (
            <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-3 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="font-serif font-bold text-sm text-[#20211D]">
                    Topic Overlap Index: {comparisonResult.topicOverlap.overlapPercentage}%
                  </h3>
                  <p className="text-xs text-[#5C5E55] mt-0.5">
                    {comparisonResult.topicOverlap.calculationMethod}
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xl font-bold text-[#B84B2F]">
                    {comparisonResult.topicOverlap.jaccardSimilarity}
                  </span>
                  <span className="text-[11px] text-[#8E9085] block font-mono">
                    Jaccard Similarity
                  </span>
                </div>
              </div>

              {/* Progress visual */}
              <div className="w-full bg-[#E0D9CC] h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-[#B84B2F] h-full transition-all duration-500"
                  style={{ width: `${comparisonResult.topicOverlap.overlapPercentage}%` }}
                />
              </div>

              <p className="text-[11px] text-[#8E9085] italic font-sans border-t border-[#EAE5D9] pt-2">
                Note on limitations: {comparisonResult.topicOverlap.limitations}
              </p>
            </div>
          )}

          {/* Three Column Matrix: Shared vs Unique A vs Unique B */}
          {comparisonResult.topicOverlap && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Shared Topics */}
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-[#E0D9CC] pb-2 text-xs">
                  <span className="font-semibold text-emerald-800 uppercase font-mono">
                    Shared Subjects ({comparisonResult.topicOverlap.sharedTopics.length})
                  </span>
                  <CheckCircle className="w-4 h-4 text-emerald-700" />
                </div>

                <div className="space-y-2">
                  {comparisonResult.topicOverlap.sharedTopics.length === 0 ? (
                    <p className="text-xs text-[#8E9085] text-center py-4">No shared topics identified.</p>
                  ) : (
                    comparisonResult.topicOverlap.sharedTopics.map((top) => (
                      <div
                        key={top.id}
                        className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-xs space-y-1.5"
                      >
                        <span className="font-serif font-bold text-[#20211D] block">
                          {top.topicName}
                        </span>
                        <p className="text-[#5C5E55] text-[11px] font-sans">{top.contextSummary}</p>
                        <div className="flex items-center gap-2 pt-1 border-t border-[#E0D9CC]">
                          {top.leftPage && (
                            <button
                              onClick={() =>
                                onNavigateToReader(leftDoc!.id, top.leftPage!, top.topicName)
                              }
                              className="text-[10px] text-[#B84B2F] font-mono hover:underline"
                            >
                              Doc A p.{top.leftPage}
                            </button>
                          )}
                          <span className="text-[#8E9085]">·</span>
                          {top.rightPage && (
                            <button
                              onClick={() =>
                                onNavigateToReader(rightDoc!.id, top.rightPage!, top.topicName)
                              }
                              className="text-[10px] text-[#20211D] font-mono hover:underline"
                            >
                              Doc B p.{top.rightPage}
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Unique to Doc A */}
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-[#E0D9CC] pb-2 text-xs">
                  <span className="font-semibold text-[#B84B2F] uppercase font-mono">
                    Only in Doc A ({comparisonResult.topicOverlap.uniqueToLeft.length})
                  </span>
                  <MinusCircle className="w-4 h-4 text-[#B84B2F]" />
                </div>

                <div className="space-y-2">
                  {comparisonResult.topicOverlap.uniqueToLeft.length === 0 ? (
                    <p className="text-xs text-[#8E9085] text-center py-4">No unique topics in Doc A.</p>
                  ) : (
                    comparisonResult.topicOverlap.uniqueToLeft.map((top) => (
                      <div
                        key={top.id}
                        className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-xs space-y-1.5"
                      >
                        <span className="font-serif font-bold text-[#20211D] block">
                          {top.topicName}
                        </span>
                        <p className="text-[#5C5E55] text-[11px] font-sans">{top.contextSummary}</p>
                        {top.leftPage && (
                          <button
                            onClick={() =>
                              onNavigateToReader(leftDoc!.id, top.leftPage!, top.topicName)
                            }
                            className="text-[10px] text-[#B84B2F] font-mono hover:underline block pt-1 border-t border-[#E0D9CC]"
                          >
                            Inspect in Doc A (Page {top.leftPage})
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Unique to Doc B */}
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-[#E0D9CC] pb-2 text-xs">
                  <span className="font-semibold text-emerald-800 uppercase font-mono">
                    Only in Doc B ({comparisonResult.topicOverlap.uniqueToRight.length})
                  </span>
                  <PlusCircle className="w-4 h-4 text-emerald-700" />
                </div>

                <div className="space-y-2">
                  {comparisonResult.topicOverlap.uniqueToRight.length === 0 ? (
                    <p className="text-xs text-[#8E9085] text-center py-4">No unique topics in Doc B.</p>
                  ) : (
                    comparisonResult.topicOverlap.uniqueToRight.map((top) => (
                      <div
                        key={top.id}
                        className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-xs space-y-1.5"
                      >
                        <span className="font-serif font-bold text-[#20211D] block">
                          {top.topicName}
                        </span>
                        <p className="text-[#5C5E55] text-[11px] font-sans">{top.contextSummary}</p>
                        {top.rightPage && (
                          <button
                            onClick={() =>
                              onNavigateToReader(rightDoc!.id, top.rightPage!, top.topicName)
                            }
                            className="text-[10px] text-emerald-800 font-mono hover:underline block pt-1 border-t border-[#E0D9CC]"
                          >
                            Inspect in Doc B (Page {top.rightPage})
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODE 4: CONTENT DIFFERENCES (REVISION DIFF) */}
      {comparisonResult && activeMode === 'content-diff' && (
        <div className="space-y-4">
          {/* Metrics summary cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <PlusCircle className="w-3.5 h-3.5 text-emerald-700" />
                <span>Additions (Doc B)</span>
              </span>
              <div className="text-xl font-mono font-bold text-emerald-800">
                +{comparisonResult.statistics.added}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <MinusCircle className="w-3.5 h-3.5 text-red-700" />
                <span>Removals (Doc A)</span>
              </span>
              <div className="text-xl font-mono font-bold text-red-800">
                -{comparisonResult.statistics.removed}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <FileEdit className="w-3.5 h-3.5 text-[#B84B2F]" />
                <span>Modifications</span>
              </span>
              <div className="text-xl font-mono font-bold text-[#B84B2F]">
                ~{comparisonResult.statistics.modified}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5 text-[#8E9085]" />
                <span>Unchanged</span>
              </span>
              <div className="text-xl font-mono font-bold text-[#5C5E55]">
                ={comparisonResult.statistics.identical}
              </div>
            </div>
          </div>

          {/* Filter segment tabs */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs pb-1">
            <div className="flex items-center gap-1 text-[#5C5E55] mr-2">
              <Filter className="w-3.5 h-3.5" />
              <span>Filter:</span>
            </div>
            {(['all', 'modification', 'addition', 'removal', 'unchanged'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setDiffFilter(type)}
                className={`px-3 py-1.5 rounded border capitalize transition-colors ${
                  diffFilter === type
                    ? 'border-[#B84B2F] bg-[#FAF8F5] text-[#B84B2F] font-semibold'
                    : 'border-[#E0D9CC] bg-[#F5F2EB] text-[#5C5E55] hover:text-[#20211D]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Change Entries */}
          <div className="space-y-4">
            {filteredChanges.length === 0 ? (
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55]">
                <p className="font-serif">No changes match the selected filter.</p>
              </div>
            ) : (
              filteredChanges.map((change) => {
                const isAdd = change.type === 'addition';
                const isRem = change.type === 'removal';
                const isMod = change.type === 'modification';

                return (
                  <div
                    key={change.id}
                    className={`border rounded-lg p-5 space-y-3 transition-colors ${
                      isAdd
                        ? 'border-emerald-300 bg-emerald-50/30'
                        : isRem
                        ? 'border-red-300 bg-red-50/30'
                        : isMod
                        ? 'border-[#C8BFB0] bg-[#FAF8F5]'
                        : 'border-[#E0D9CC] bg-[#FAF8F5]'
                    }`}
                  >
                    {/* Header info */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        {isAdd && (
                          <span className="font-mono text-emerald-800 font-bold uppercase">
                            [+ Addition]
                          </span>
                        )}
                        {isRem && (
                          <span className="font-mono text-red-800 font-bold uppercase">
                            [- Removal]
                          </span>
                        )}
                        {isMod && (
                          <span className="font-mono text-[#B84B2F] font-bold uppercase">
                            [~ Modification]
                          </span>
                        )}
                        {!isAdd && !isRem && !isMod && (
                          <span className="font-mono text-[#8E9085] uppercase">
                            [= Unchanged]
                          </span>
                        )}

                        <span className="text-[#8E9085]">·</span>
                        <span className="font-medium text-[#20211D]">{change.summary}</span>
                      </div>

                      {/* Jump buttons */}
                      <div className="flex items-center gap-3">
                        {change.leftPage && leftDoc && (
                          <button
                            onClick={() =>
                              onNavigateToReader(leftDoc.id, change.leftPage!, change.summary)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#5C5E55] hover:text-[#20211D]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Doc A p.{change.leftPage}</span>
                          </button>
                        )}
                        {change.rightPage && rightDoc && (
                          <button
                            onClick={() =>
                              onNavigateToReader(rightDoc.id, change.rightPage!, change.summary)
                            }
                            className="flex items-center gap-1 text-[11px] text-[#5C5E55] hover:text-[#20211D]"
                          >
                            <BookOpen className="w-3 h-3 text-[#B84B2F]" />
                            <span>Doc B p.{change.rightPage}</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Side-by-side / Comparison content */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-serif leading-relaxed">
                      {/* Left document text */}
                      <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1">
                        <div className="text-[10px] font-mono text-[#8E9085] flex justify-between">
                          <span>{leftDoc?.originalName}</span>
                          {change.leftPage && <span>Page {change.leftPage}</span>}
                        </div>
                        {change.leftText ? (
                          <p className={`text-[#20211D] ${isRem ? 'line-through text-red-800/80' : ''}`}>
                            {change.leftText}
                          </p>
                        ) : (
                          <p className="text-[#8E9085] italic font-sans">[Clause absent in baseline]</p>
                        )}
                      </div>

                      {/* Right document text */}
                      <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1">
                        <div className="text-[10px] font-mono text-[#8E9085] flex justify-between">
                          <span>{rightDoc?.originalName}</span>
                          {change.rightPage && <span>Page {change.rightPage}</span>}
                        </div>
                        {change.rightText ? (
                          <p className={`text-[#20211D] ${isAdd ? 'text-emerald-900 font-medium' : ''}`}>
                            {change.rightText}
                          </p>
                        ) : (
                          <p className="text-[#8E9085] italic font-sans">[Clause deleted in revision]</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
