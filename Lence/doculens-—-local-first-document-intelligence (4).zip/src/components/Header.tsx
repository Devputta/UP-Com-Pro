import React, { useState } from 'react';
import {
  FileText,
  BookOpen,
  Search,
  MessageSquare,
  Table as TableIcon,
  GitCompare,
  Settings,
  Menu,
  X,
  HelpCircle,
  Wifi,
  WifiOff,
  Shield,
  Layers,
} from 'lucide-react';
import { DocumentEntity } from '../types/doculens';

export type ActiveTab =
  | 'library'
  | 'reader'
  | 'search'
  | 'inquiry'
  | 'tables'
  | 'compare'
  | 'workspace';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id?: string) => void;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  documents,
  selectedDocId,
  onSelectDoc,
  isOnline,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const navItems = [
    { id: 'library' as ActiveTab, label: 'Library', icon: FileText },
    { id: 'reader' as ActiveTab, label: 'Reader', icon: BookOpen },
    { id: 'search' as ActiveTab, label: 'Search', icon: Search },
    { id: 'inquiry' as ActiveTab, label: 'Ask Documents', icon: MessageSquare },
    { id: 'tables' as ActiveTab, label: 'Tables', icon: TableIcon },
    { id: 'compare' as ActiveTab, label: 'Compare', icon: GitCompare },
  ];

  const handleTabClick = (tab: ActiveTab) => {
    onSelectTab(tab);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <header className="border-b border-[#E0D9CC] bg-[#FAF8F5] text-[#20211D] sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Left: Logo and DocuLens Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => handleTabClick('library')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
              title="DocuLens Home"
            >
              <div className="w-9 h-9 rounded border border-[#E0D9CC] bg-[#F5F2EB] p-1 flex items-center justify-center shrink-0 shadow-xs group-hover:border-[#B84B2F] transition-colors">
                <img
                  src="/doculens-mark-transparent.png"
                  alt="DocuLens Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-serif font-bold tracking-wide text-lg text-[#20211D]">
                    DocuLens
                  </span>
                  <span className="text-[10px] font-mono uppercase px-1 py-0.2 rounded bg-[#EAE5D9] text-[#5C5E55] tracking-widest hidden sm:inline">
                    v1.0
                  </span>
                </div>
                <span className="text-[10px] font-mono text-[#8E9085] tracking-wider uppercase hidden md:inline">
                  Document Intelligence
                </span>
              </div>
            </button>
          </div>

          {/* Middle: Clean Desktop Navigation */}
          <nav
            className="hidden md:flex items-center gap-1 lg:gap-1.5"
            aria-label="Primary Navigation"
          >
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabClick(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                    isActive
                      ? 'bg-[#EAE5D9] text-[#B84B2F] font-semibold shadow-2xs'
                      : 'text-[#5C5E55] hover:text-[#20211D] hover:bg-[#F5F2EB]'
                  }`}
                >
                  <Icon
                    className={`w-3.5 h-3.5 ${
                      isActive ? 'text-[#B84B2F]' : 'text-[#8E9085]'
                    }`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right: Useful Actions Only (Settings, Help, Local Status) */}
          <div className="flex items-center gap-2 text-xs">

            {/* Help / Info Dialog trigger */}
            <button
              onClick={() => setIsHelpOpen(true)}
              title="Help, Shortcuts & Architecture"
              aria-label="Help and Architecture Details"
              className="p-1.5 text-[#5C5E55] hover:text-[#20211D] hover:bg-[#F5F2EB] rounded border border-[#E0D9CC] transition-colors"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Settings / Workspace */}
            <button
              onClick={() => handleTabClick('workspace')}
              title="Settings & Storage Workspace"
              aria-label="Settings Workspace"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border transition-colors ${
                activeTab === 'workspace'
                  ? 'border-[#B84B2F] text-[#B84B2F] bg-[#EAE5D9]'
                  : 'border-[#E0D9CC] text-[#5C5E55] hover:text-[#20211D] hover:bg-[#F5F2EB]'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Settings</span>
            </button>

            {/* Discreet Online / Offline Status Dot */}
            <div
              className="flex items-center justify-center p-1.5 rounded"
              title={
                isOnline
                  ? 'Local core active (online). All indexing and processing run strictly on-device.'
                  : 'Offline mode active. Full search, parsing, tables, and comparison remain functional.'
              }
            >
              {isOnline ? (
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-[#B84B2F]" />
              )}
            </div>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="md:hidden p-1.5 text-[#20211D] hover:bg-[#F5F2EB] rounded border border-[#E0D9CC]"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-[#B84B2F]" />
              ) : (
                <Menu className="w-5 h-5 text-[#20211D]" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-[#E0D9CC] bg-[#FAF8F5] px-4 py-3 space-y-3 shadow-lg">
            {/* Nav Links */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabClick(item.id)}
                    className={`flex items-center gap-2 p-2.5 rounded text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-[#EAE5D9] text-[#B84B2F] font-semibold border border-[#B84B2F]/30'
                        : 'bg-[#F5F2EB] text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#B84B2F]' : 'text-[#8E9085]'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-[#E0D9CC] flex items-center justify-between text-[11px] text-[#5C5E55]">
              <span className="flex items-center gap-1.5">
                <Shield className="w-3 h-3 text-[#5C5E55]" />
                <span>Local-first · IndexedDB</span>
              </span>
              <span>{isOnline ? 'Network Connected' : 'Offline Mode'}</span>
            </div>
          </div>
        )}
      </header>

      {/* Help & Architecture Modal */}
      {isHelpOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="help-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-2xs"
        >
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-xl max-w-xl w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-[#E0D9CC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded bg-[#F5F2EB] border border-[#E0D9CC] p-1 flex items-center justify-center">
                  <img
                    src="/doculens-mark-transparent.png"
                    alt="DocuLens"
                    className="w-full h-full object-contain"
                  />
                </div>
                <h2 id="help-title" className="font-serif font-bold text-base text-[#20211D]">
                  DocuLens Guide & Quick Reference
                </h2>
              </div>
              <button
                onClick={() => setIsHelpOpen(false)}
                className="text-[#8E9085] hover:text-[#20211D] p-1"
                aria-label="Close help modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#5C5E55] leading-relaxed">
              <div className="p-3 bg-[#F5F2EB] rounded border border-[#E0D9CC] space-y-1">
                <span className="font-semibold text-[#20211D]">Local-First Privacy Architecture</span>
                <p>
                  All document uploads, text extraction, page parsing, table detection, and lexical
                  searches are executed 100% inside your browser via IndexedDB. Documents are never
                  uploaded to external servers without explicit disclosure.
                </p>
              </div>

              <div className="space-y-1.5">
                <span className="font-semibold text-[#20211D] uppercase text-[11px] tracking-wider">
                  Workspace Destinations
                </span>
                <ul className="list-disc list-inside space-y-1 pl-1">
                  <li>
                    <strong className="text-[#20211D]">Library:</strong> Ingest PDFs, inspect page/element
                    counts, and delete documents.
                  </li>
                  <li>
                    <strong className="text-[#20211D]">Reader:</strong> Visual page canvas with element
                    provenance inspection and marginalia annotations.
                  </li>
                  <li>
                    <strong className="text-[#20211D]">Search:</strong> Deterministic BM25 lexical search with
                    exact phrase bonuses and multi-term highlight jumps.
                  </li>
                  <li>
                    <strong className="text-[#20211D]">Ask Documents:</strong> Evidence-grounded inquiries with
                    backend citation verification.
                  </li>
                  <li>
                    <strong className="text-[#20211D]">Tables:</strong> Extracted document tables with
                    formula-injection-safe CSV exports.
                  </li>
                  <li>
                    <strong className="text-[#20211D]">Compare:</strong> Intelligent comparison across content
                    diffs, shared concepts, definitions, and topic overlap.
                  </li>
                </ul>
              </div>

              <div className="space-y-1.5 border-t border-[#E0D9CC] pt-2">
                <span className="font-semibold text-[#20211D] uppercase text-[11px] tracking-wider">
                  Keyboard Shortcuts in Reader
                </span>
                <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
                  <div className="p-1.5 bg-[#F5F2EB] rounded border border-[#E0D9CC]">
                    <span className="text-[#B84B2F]">← Left Arrow:</span> Previous page
                  </div>
                  <div className="p-1.5 bg-[#F5F2EB] rounded border border-[#E0D9CC]">
                    <span className="text-[#B84B2F]">→ Right Arrow:</span> Next page
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-[#E0D9CC] flex justify-end">
              <button
                onClick={() => setIsHelpOpen(false)}
                className="bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] px-4 py-1.5 rounded text-xs font-medium transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
