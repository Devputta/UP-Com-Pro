import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Bookmark,
  Plus,
  Trash2,
  Maximize2,
  Minimize2,
  Crosshair,
  Printer,
  FileWarning,
  Search,
  X,
  Highlighter,
  FileText,
} from 'lucide-react';
import {
  DocumentEntity,
  DocumentElement,
  MarginaliaNote,
} from '../types/doculens';
import { highlightTextSegments } from '../services/lexicalSearch';

interface ReaderViewProps {
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id: string) => void;
  elements: DocumentElement[];
  notes: MarginaliaNote[];
  onAddNote: (note: {
    documentId: string;
    pageNumber: number;
    selectedText: string;
    noteText: string;
  }) => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
  targetPage?: number;
  highlightQuery?: string;
  targetElementId?: string;
  onClearHighlight?: () => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  documents,
  selectedDocId,
  onSelectDoc,
  elements,
  notes,
  onAddNote,
  onDeleteNote,
  targetPage,
  highlightQuery: initialHighlightQuery,
  targetElementId,
  onClearHighlight,
}) => {
  const currentDoc = documents.find((d) => d.id === selectedDocId) || documents[0];
  const [currentPage, setCurrentPage] = useState<number>(targetPage || 1);
  const [pageInput, setPageInput] = useState<string>(String(targetPage || 1));
  const [selectedElement, setSelectedElement] = useState<DocumentElement | null>(null);
  const [newNoteText, setNewNoteText] = useState('');
  const [selectedTextForNote, setSelectedTextForNote] = useState('');
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);

  // In-Reader Search & Term Highlighting State
  const [activeHighlightQuery, setActiveHighlightQuery] = useState<string>(
    initialHighlightQuery || ''
  );
  const [isSearchToolbarOpen, setIsSearchToolbarOpen] = useState(
    Boolean(initialHighlightQuery)
  );
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);

  const canvasRef = useRef<HTMLDivElement>(null);
  const firstMatchRef = useRef<HTMLDivElement>(null);

  // Sync highlight query from external navigation (e.g. from Search or Citation click)
  useEffect(() => {
    if (initialHighlightQuery !== undefined) {
      setActiveHighlightQuery(initialHighlightQuery);
      if (initialHighlightQuery) {
        setIsSearchToolbarOpen(true);
      }
    }
  }, [initialHighlightQuery]);

  // Filter elements for the current document
  const docElements = currentDoc ? elements.filter((e) => e.documentId === currentDoc.id) : [];
  const totalPages = currentDoc
    ? Math.max(1, currentDoc.pageCount, ...docElements.map((e) => e.pageNumber))
    : 1;

  // Sync targetPage prop when it changes (e.g. from Search or Citation click)
  useEffect(() => {
    if (targetPage && targetPage >= 1 && targetPage <= totalPages) {
      setCurrentPage(targetPage);
      setPageInput(String(targetPage));
      setSelectedElement(null);
    }
  }, [targetPage, totalPages]);

  // Select target element if specified
  useEffect(() => {
    if (targetElementId) {
      const matchEl = docElements.find((e) => e.id === targetElementId);
      if (matchEl) {
        setSelectedElement(matchEl);
        if (matchEl.pageNumber !== currentPage) {
          setCurrentPage(matchEl.pageNumber);
          setPageInput(String(matchEl.pageNumber));
        }
      }
    }
  }, [targetElementId, docElements, currentPage]);

  // Keep page within bounds when document changes
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
      setPageInput(String(totalPages));
    }
  }, [totalPages, currentPage]);

  // Keyboard navigation: Left Arrow (prev), Right Arrow (next)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (e.key === 'ArrowLeft') {
        if (currentPage > 1) {
          setCurrentPage((p) => {
            const next = p - 1;
            setPageInput(String(next));
            return next;
          });
          setSelectedElement(null);
        }
      } else if (e.key === 'ArrowRight') {
        if (currentPage < totalPages) {
          setCurrentPage((p) => {
            const next = p + 1;
            setPageInput(String(next));
            return next;
          });
          setSelectedElement(null);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, totalPages]);

  // Count total matches on the current page
  const pageElements = docElements.filter((e) => e.pageNumber === currentPage);
  const pageNotes = notes.filter((n) => n.documentId === currentDoc?.id && n.pageNumber === currentPage);

  const pageMatchesCount = React.useMemo(() => {
    if (!activeHighlightQuery.trim()) return 0;
    let count = 0;
    for (const el of pageElements) {
      const segs = highlightTextSegments(el.content, activeHighlightQuery);
      count += segs.filter((s) => s.isMatch).length;
    }
    return count;
  }, [pageElements, activeHighlightQuery]);

  // Auto-scroll to first match when highlight query changes or page loads
  useEffect(() => {
    if (pageMatchesCount > 0 && firstMatchRef.current) {
      firstMatchRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [currentPage, activeHighlightQuery, pageMatchesCount]);

  if (!currentDoc) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center text-[#5C5E55] space-y-3">
        <div className="w-16 h-16 mx-auto rounded-full bg-[#FAF8F5] border border-[#E0D9CC] p-3 flex items-center justify-center shadow-xs">
          <img
            src="/doculens-mark-transparent.png"
            alt="DocuLens Emblem"
            className="w-full h-full object-contain"
          />
        </div>
        <p className="font-serif text-lg font-medium text-[#20211D]">
          No documents loaded for reading
        </p>
        <p className="text-xs max-w-sm mx-auto text-[#5C5E55] leading-relaxed">
          Please select or upload a document in the Library view to inspect page layout, element
          provenance, and add marginalia notes.
        </p>
      </div>
    );
  }

  const handlePrevPage = () => {
    if (currentPage > 1) {
      const prev = currentPage - 1;
      setCurrentPage(prev);
      setPageInput(String(prev));
      setSelectedElement(null);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      const next = currentPage + 1;
      setCurrentPage(next);
      setPageInput(String(next));
      setSelectedElement(null);
    }
  };

  const handlePageJumpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(pageInput, 10);
    if (!isNaN(parsed) && parsed >= 1 && parsed <= totalPages) {
      setCurrentPage(parsed);
      setSelectedElement(null);
    } else {
      setPageInput(String(currentPage));
    }
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    await onAddNote({
      documentId: currentDoc.id,
      pageNumber: currentPage,
      selectedText: selectedTextForNote.trim() || `Page ${currentPage} observation`,
      noteText: newNoteText.trim(),
    });
    setNewNoteText('');
    setSelectedTextForNote('');
  };

  const clearHighlighting = () => {
    setActiveHighlightQuery('');
    if (onClearHighlight) onClearHighlight();
  };

  /**
   * Helper to render text with search highlighting
   */
  const renderHighlightedContent = (text: string, isFirstEl: boolean) => {
    if (!activeHighlightQuery.trim()) {
      return <span>{text}</span>;
    }

    const segments = highlightTextSegments(text, activeHighlightQuery);
    let isFirstMatchAssigned = false;

    return (
      <>
        {segments.map((seg, i) => {
          if (seg.isMatch) {
            const assignRef = isFirstEl && !isFirstMatchAssigned;
            if (assignRef) isFirstMatchAssigned = true;

            return (
              <mark
                key={i}
                ref={assignRef ? (firstMatchRef as any) : undefined}
                className="bg-[#B84B2F]/25 text-[#B84B2F] font-semibold px-0.5 rounded underline decoration-[#B84B2F]/50 transition-colors"
                title={`Match for "${activeHighlightQuery}"`}
              >
                {seg.text}
              </mark>
            );
          }
          return <span key={i}>{seg.text}</span>;
        })}
      </>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-4">
      {/* Top Reading Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-[#E0D9CC] bg-[#FAF8F5] p-3 rounded-lg shadow-2xs">
        {/* Document Switcher */}
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-[#8E9085] shrink-0" />
          <select
            id="reader-doc-select"
            aria-label="Select document to read"
            value={currentDoc.id}
            onChange={(e) => {
              onSelectDoc(e.target.value);
              setCurrentPage(1);
              setPageInput('1');
              setSelectedElement(null);
            }}
            className="text-xs font-serif font-medium bg-[#F5F2EB] border border-[#E0D9CC] hover:border-[#B84B2F] rounded px-2.5 py-1 text-[#20211D] max-w-xs truncate cursor-pointer focus:outline-none focus:border-[#B84B2F]"
          >
            {documents.map((d) => (
              <option key={d.id} value={d.id}>
                {d.originalName} ({d.pageCount}p)
              </option>
            ))}
          </select>
        </div>

        {/* Page Stepper, Search Toggle & Provenance Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            aria-label="Previous Page (Left Arrow)"
            title="Previous Page (←)"
            className="p-1 text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded disabled:opacity-30 disabled:cursor-not-allowed bg-[#F5F2EB]"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Direct page jump form */}
          <form onSubmit={handlePageJumpSubmit} className="flex items-center gap-1.5 text-xs text-[#20211D]">
            <span className="text-[#8E9085]">Page</span>
            <input
              type="text"
              inputMode="numeric"
              value={pageInput}
              onChange={(e) => setPageInput(e.target.value)}
              onBlur={() => {
                const p = parseInt(pageInput, 10);
                if (!isNaN(p) && p >= 1 && p <= totalPages) {
                  setCurrentPage(p);
                } else {
                  setPageInput(String(currentPage));
                }
              }}
              className="w-12 text-center font-mono font-medium bg-[#F5F2EB] border border-[#E0D9CC] focus:border-[#B84B2F] rounded py-0.5 px-1 text-xs text-[#20211D] focus:outline-none"
              aria-label="Go to page"
            />
            <span className="text-[#8E9085]">of {totalPages}</span>
          </form>

          <button
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
            aria-label="Next Page (Right Arrow)"
            title="Next Page (→)"
            className="p-1 text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded disabled:opacity-30 disabled:cursor-not-allowed bg-[#F5F2EB]"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-[#E0D9CC] mx-1" />

          {/* Toggle In-Page Search Toolbar */}
          <button
            onClick={() => setIsSearchToolbarOpen(!isSearchToolbarOpen)}
            title="Find & Highlight on Page"
            aria-label="Toggle Page Search Highlighting"
            className={`p-1.5 border rounded text-xs flex items-center gap-1 transition-colors ${
              isSearchToolbarOpen || activeHighlightQuery
                ? 'border-[#B84B2F] text-[#B84B2F] bg-[#FAF8F5]'
                : 'border-[#E0D9CC] text-[#5C5E55] bg-[#F5F2EB]'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Highlight</span>
          </button>

          {/* Print button */}
          <button
            onClick={() => window.print()}
            title="Print Page View"
            aria-label="Print Page View"
            className="p-1.5 text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded bg-[#F5F2EB]"
          >
            <Printer className="w-3.5 h-3.5" />
          </button>

          {/* Toggle Inspector */}
          <button
            onClick={() => setIsInspectorOpen(!isInspectorOpen)}
            title="Toggle Element Provenance Sidebar"
            aria-label="Toggle Element Provenance Sidebar"
            className={`p-1.5 border rounded text-xs flex items-center gap-1 ${
              isInspectorOpen
                ? 'border-[#B84B2F] text-[#B84B2F] bg-[#FAF8F5]'
                : 'border-[#E0D9CC] text-[#5C5E55] bg-[#F5F2EB]'
            }`}
          >
            {isInspectorOpen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">Provenance</span>
          </button>
        </div>
      </div>

      {/* In-Reader Search & Highlight Toolbar */}
      {isSearchToolbarOpen && (
        <div className="border border-[#E0D9CC] bg-[#F5F2EB] p-3 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-1">
            <Highlighter className="w-4 h-4 text-[#B84B2F] shrink-0" />
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                value={activeHighlightQuery}
                onChange={(e) => setActiveHighlightQuery(e.target.value)}
                placeholder="Type word, phrase, or code to highlight on this page..."
                className="w-full bg-[#FAF8F5] border border-[#E0D9CC] focus:border-[#B84B2F] rounded px-3 py-1.5 text-xs text-[#20211D] placeholder-[#8E9085] focus:outline-none"
              />
              {activeHighlightQuery && (
                <button
                  type="button"
                  onClick={clearHighlighting}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E9085] hover:text-[#20211D]"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {activeHighlightQuery.trim() ? (
              <span className="font-mono text-[11px] text-[#5C5E55] bg-[#FAF8F5] px-2 py-1 rounded border border-[#E0D9CC]">
                {pageMatchesCount} match{pageMatchesCount === 1 ? '' : 'es'} on Page {currentPage}
              </span>
            ) : (
              <span className="text-[11px] text-[#8E9085]">Live on-page highlight</span>
            )}

            {activeHighlightQuery && (
              <button
                onClick={clearHighlighting}
                className="text-[11px] text-[#8E9085] hover:text-[#B84B2F] px-2 py-1 underline"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* Scanned Image Document Alert Banner */}
      {currentDoc.isScanned && (
        <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg text-xs flex items-center gap-2.5">
          <FileWarning className="w-4 h-4 text-amber-700 shrink-0" />
          <span>
            <strong>Scanned Document Notice:</strong> This PDF contains scanned image pages without
            an embedded OCR text layer. Text-based lexical search and automatic element citations
            are limited.
          </span>
        </div>
      )}

      {/* Main Reading Workspace Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Document Canvas (Page Surface) */}
        <div
          ref={canvasRef}
          className={`${
            isInspectorOpen ? 'lg:col-span-8' : 'lg:col-span-12'
          } border border-[#D5CEBF] bg-[#FAF8F5] rounded-lg shadow-xs min-h-[680px] p-8 sm:p-12 space-y-6 relative transition-all`}
        >
          {/* Page Header Watermark / Provenance Kicker */}
          <div className="flex items-center justify-between text-[11px] text-[#8E9085] border-b border-[#E0D9CC] pb-3 mb-6 font-mono">
            <span>DOCULENS PROVENANCE SURFACE</span>
            <span className="truncate max-w-sm">
              {currentDoc.originalName} — PAGE {currentPage}
            </span>
          </div>

          {pageElements.length === 0 ? (
            <div className="text-center py-20 text-[#8E9085] space-y-2">
              <p className="font-serif text-base text-[#20211D]">No text elements on page {currentPage}</p>
              <p className="text-xs max-w-sm mx-auto">
                This page may contain graphical diagrams, empty space, or unscanned image scans.
              </p>
            </div>
          ) : (
            <div className="space-y-4 font-serif text-[#20211D] leading-relaxed">
              {pageElements.map((el, elIdx) => {
                const isSelected = selectedElement?.id === el.id;
                const hasMatch =
                  activeHighlightQuery.trim() &&
                  el.content.toLowerCase().includes(activeHighlightQuery.toLowerCase());

                const baseClass = `relative group cursor-pointer transition-colors p-2.5 rounded ${
                  isSelected
                    ? 'bg-[#B84B2F]/10 border-l-3 border-[#B84B2F]'
                    : hasMatch
                    ? 'bg-amber-50/70 border-l-3 border-amber-500 hover:bg-amber-100/50'
                    : 'hover:bg-[#F5F2EB] border-l-3 border-transparent'
                }`;

                if (el.type === 'heading-1') {
                  return (
                    <div
                      key={el.id}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                      }}
                      className={baseClass}
                    >
                      <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#20211D]">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h1>
                      <span className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 font-mono text-[10px] text-[#8E9085]">
                        h1 · {el.sourceElementId}
                      </span>
                    </div>
                  );
                }

                if (el.type === 'heading-2') {
                  return (
                    <div
                      key={el.id}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                      }}
                      className={baseClass}
                    >
                      <h2 className="text-lg font-semibold text-[#20211D] mt-2">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h2>
                      <span className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 font-mono text-[10px] text-[#8E9085]">
                        h2 · {el.sourceElementId}
                      </span>
                    </div>
                  );
                }

                if (el.type === 'heading-3') {
                  return (
                    <div
                      key={el.id}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                      }}
                      className={baseClass}
                    >
                      <h3 className="text-base font-semibold text-[#20211D]">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h3>
                      <span className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 font-mono text-[10px] text-[#8E9085]">
                        h3 · {el.sourceElementId}
                      </span>
                    </div>
                  );
                }

                if (el.type === 'footnote') {
                  return (
                    <div
                      key={el.id}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                      }}
                      className={`${baseClass} pt-4 border-t border-[#E0D9CC] text-xs text-[#5C5E55] italic`}
                    >
                      <p>{renderHighlightedContent(el.content, elIdx === 0)}</p>
                      <span className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 font-mono text-[10px] text-[#8E9085]">
                        fn · {el.sourceElementId}
                      </span>
                    </div>
                  );
                }

                if (el.type === 'callout') {
                  return (
                    <div
                      key={el.id}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                      }}
                      className={`${baseClass} p-3 bg-amber-50/50 border border-amber-200 text-xs text-amber-900 rounded font-sans`}
                    >
                      <p>{renderHighlightedContent(el.content, elIdx === 0)}</p>
                    </div>
                  );
                }

                return (
                  <div
                    key={el.id}
                    onClick={() => {
                      setSelectedElement(el);
                      setSelectedTextForNote(el.content);
                    }}
                    className={baseClass}
                  >
                    <p className="text-sm sm:text-base text-[#383933]">
                      {renderHighlightedContent(el.content, elIdx === 0)}
                    </p>
                    <span className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 font-mono text-[10px] text-[#8E9085]">
                      p · {el.sourceElementId}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Page Footer Footprint */}
          <div className="flex items-center justify-between text-[11px] text-[#8E9085] border-t border-[#E0D9CC] pt-4 mt-8 font-mono">
            <span>SHA: {currentDoc.sha256.slice(0, 16)}...</span>
            <span>— {currentPage} of {totalPages} —</span>
            <span>{currentDoc.parserName}</span>
          </div>
        </div>

        {/* Sidebar: Element Provenance & Marginalia */}
        {isInspectorOpen && (
          <div className="lg:col-span-4 space-y-6">
            {/* Element Provenance Card */}
            <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-3 shadow-2xs">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
                <Crosshair className="w-3.5 h-3.5 text-[#B84B2F]" />
                <span>Provenance Inspector</span>
              </div>

              {selectedElement ? (
                <div className="space-y-2 text-xs">
                  <div className="p-2.5 bg-[#F5F2EB] rounded border border-[#E0D9CC] font-mono space-y-1">
                    <div className="flex justify-between">
                      <span className="text-[#5C5E55]">Element ID:</span>
                      <span className="font-semibold text-[#20211D]">{selectedElement.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#5C5E55]">Source ID:</span>
                      <span className="text-[#20211D]">{selectedElement.sourceElementId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#5C5E55]">Type:</span>
                      <span className="text-[#B84B2F] font-semibold">{selectedElement.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#5C5E55]">Page Number:</span>
                      <span className="text-[#20211D]">{selectedElement.pageNumber}</span>
                    </div>
                    {selectedElement.bbox && (
                      <div className="flex justify-between">
                        <span className="text-[#5C5E55]">Bounding Box:</span>
                        <span className="text-[#20211D]">
                          [{selectedElement.bbox.join(', ')}]
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-1">
                    <span className="text-[11px] text-[#5C5E55] font-medium">Selected Passage:</span>
                    <p className="mt-1 p-2 bg-[#F5F2EB] rounded text-xs text-[#20211D] italic max-h-32 overflow-y-auto font-serif">
                      "{selectedElement.content}"
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-xs text-[#8E9085]">
                  <p>Click any paragraph or heading on the page canvas to inspect element provenance.</p>
                </div>
              )}
            </div>

            {/* Marginalia & Researcher Notes */}
            <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-4 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
                  <Bookmark className="w-3.5 h-3.5 text-[#B84B2F]" />
                  <span>Marginalia Notes (p.{currentPage})</span>
                </div>
                <span className="text-xs text-[#8E9085] font-mono">{pageNotes.length} notes</span>
              </div>

              {/* Note creator */}
              <form onSubmit={handleCreateNote} className="space-y-2">
                <textarea
                  value={newNoteText}
                  onChange={(e) => setNewNoteText(e.target.value)}
                  placeholder="Annotate this page with research or audit notes..."
                  rows={2}
                  className="w-full text-xs p-2.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-[#20211D] placeholder-[#8E9085] focus:outline-none focus:border-[#B84B2F]"
                />
                <button
                  type="submit"
                  disabled={!newNoteText.trim()}
                  className="w-full flex items-center justify-center gap-1.5 bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] text-xs font-medium py-1.5 px-3 rounded transition-colors disabled:opacity-40"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Attach Marginalia Note</span>
                </button>
              </form>

              {/* Existing page notes */}
              <div className="space-y-2 pt-2 max-h-60 overflow-y-auto">
                {pageNotes.length === 0 ? (
                  <p className="text-xs text-[#8E9085] text-center py-2">
                    No annotations on this page yet.
                  </p>
                ) : (
                  pageNotes.map((note) => (
                    <div
                      key={note.id}
                      className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1.5 relative group"
                    >
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-[11px] font-mono text-[#8E9085]">
                          {new Date(note.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <button
                          onClick={() => onDeleteNote(note.id)}
                          className="opacity-0 group-hover:opacity-100 text-[#8E9085] hover:text-red-700 transition-opacity"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="text-xs text-[#20211D] leading-relaxed font-sans">{note.noteText}</p>
                      {note.selectedText && (
                        <p className="text-[10px] text-[#5C5E55] italic truncate border-t border-[#E0D9CC] pt-1">
                          Ref: "{note.selectedText}"
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
