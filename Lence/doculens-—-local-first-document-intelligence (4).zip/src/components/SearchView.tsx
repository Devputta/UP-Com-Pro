import React, { useState, useMemo } from 'react';
import {
  Search,
  BookOpen,
  ArrowRight,
  Sparkles,
  Filter,
  AlertCircle,
  X,
  SlidersHorizontal,
  FileText,
} from 'lucide-react';
import {
  DocumentChunk,
  DocumentEntity,
  SearchResult,
  SearchNoResultsAdvice,
} from '../types/doculens';
import { searchChunks, analyzeNoResults, highlightTextSegments } from '../services/lexicalSearch';

interface SearchViewProps {
  documents: DocumentEntity[];
  chunks: DocumentChunk[];
  selectedDocId?: string;
  onSelectDoc: (id?: string) => void;
  onNavigateToReader: (docId: string, pageNumber: number, highlightQuery?: string) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  documents,
  chunks,
  selectedDocId,
  onSelectDoc,
  onNavigateToReader,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [sortBy, setSortBy] = useState<'relevance' | 'page'>('relevance');

  const sampleQueries = [
    '648 billion',
    'interconnection delays',
    'Child-Pugh Class A',
    '12-lead electrocardiogram',
    'step-by-step procedure',
    'retention memory',
    'dynamic line rating',
    'stored-program',
  ];

  const noResultsAdvice = useMemo<SearchNoResultsAdvice | null>(() => {
    if (hasSearched && results.length === 0 && query.trim()) {
      return analyzeNoResults(query, chunks, documents, selectedDocId);
    }
    return null;
  }, [hasSearched, results.length, query, chunks, documents, selectedDocId]);

  const handleSearch = (e?: React.FormEvent, customQuery?: string) => {
    if (e) e.preventDefault();
    const q = customQuery !== undefined ? customQuery : query;
    if (!q.trim()) {
      setResults([]);
      setHasSearched(false);
      return;
    }
    setHasSearched(true);
    const searchRes = searchChunks(q, chunks, documents, selectedDocId);
    setResults(searchRes);
  };

  const executeSample = (q: string) => {
    setQuery(q);
    handleSearch(undefined, q);
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setHasSearched(false);
  };

  // Sorted results
  const displayedResults = useMemo(() => {
    if (sortBy === 'page') {
      return [...results].sort((a, b) => {
        if (a.document.id !== b.document.id) {
          return a.document.originalName.localeCompare(b.document.originalName);
        }
        return a.chunk.pageStart - b.chunk.pageStart;
      });
    }
    return results; // Default BM25 score descending
  }, [results, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="border-b border-[#E0D9CC] pb-4">
        <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
          Lexical Search Engine
        </h1>
        <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
          Deterministic local full-text search with exact phrase bonus, multi-term coordination,
          and contextual highlighting. Jump directly to matching document pages with active highlights.
        </p>
      </div>

      {/* Search Input Bar */}
      <form onSubmit={(e) => handleSearch(e)} className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#8E9085] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                if (e.target.value.trim().length > 1) {
                  const instant = searchChunks(e.target.value, chunks, documents, selectedDocId);
                  setResults(instant);
                  setHasSearched(true);
                } else if (!e.target.value.trim()) {
                  setResults([]);
                  setHasSearched(false);
                }
              }}
              placeholder="Search phrases, numbers, terms, or sections (e.g. '648 billion', 'step-by-step', 'Child-Pugh')..."
              className="w-full bg-[#FAF8F5] border border-[#E0D9CC] focus:border-[#B84B2F] rounded-lg pl-10 pr-9 py-2.5 text-xs sm:text-sm text-[#20211D] placeholder-[#8E9085] focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={clearSearch}
                aria-label="Clear search input"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8E9085] hover:text-[#20211D]"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedDocId || ''}
              onChange={(e) => {
                const newId = e.target.value || undefined;
                onSelectDoc(newId);
                if (query.trim()) {
                  const res = searchChunks(query, chunks, documents, newId);
                  setResults(res);
                }
              }}
              aria-label="Filter search by document"
              className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg px-3 py-2.5 text-xs text-[#20211D] focus:outline-none max-w-[190px] truncate"
            >
              <option value="">All Documents ({documents.length})</option>
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName}
                </option>
              ))}
            </select>

            <button
              type="submit"
              className="bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] px-5 py-2.5 rounded-lg text-xs font-medium transition-colors"
            >
              Search
            </button>
          </div>
        </div>

        {/* Suggested Query Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap text-xs text-[#5C5E55]">
          <span className="font-medium text-[#8E9085]">Suggested tests:</span>
          {sampleQueries.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => executeSample(q)}
              className="px-2 py-0.5 rounded border border-[#E0D9CC] bg-[#FAF8F5] hover:border-[#B84B2F] hover:text-[#B84B2F] transition-colors text-[11px]"
            >
              {q}
            </button>
          ))}
        </div>
      </form>

      {/* Results Header / Controls */}
      {hasSearched && results.length > 0 && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E0D9CC] pb-2 text-xs text-[#5C5E55]">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[#20211D]">
              Found {results.length} matching passage{results.length === 1 ? '' : 's'} for "{query}"
            </span>
          </div>

          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#8E9085]" />
            <span className="text-[#8E9085]">Sort by:</span>
            <button
              onClick={() => setSortBy('relevance')}
              className={`px-2 py-0.5 rounded border text-[11px] ${
                sortBy === 'relevance'
                  ? 'bg-[#EAE5D9] text-[#B84B2F] border-[#B84B2F]/40 font-semibold'
                  : 'bg-[#FAF8F5] border-[#E0D9CC] text-[#5C5E55]'
              }`}
            >
              BM25 Relevance
            </button>
            <button
              onClick={() => setSortBy('page')}
              className={`px-2 py-0.5 rounded border text-[11px] ${
                sortBy === 'page'
                  ? 'bg-[#EAE5D9] text-[#B84B2F] border-[#B84B2F]/40 font-semibold'
                  : 'bg-[#FAF8F5] border-[#E0D9CC] text-[#5C5E55]'
              }`}
            >
              Page Order
            </button>
          </div>
        </div>
      )}

      {/* Empty / Zero state */}
      {!hasSearched && (
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55] space-y-3">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#F5F2EB] border border-[#E0D9CC] p-2.5 flex items-center justify-center shadow-xs">
            <img
              src="/doculens-mark-transparent.png"
              alt="DocuLens Search"
              className="w-full h-full object-contain"
            />
          </div>
          <p className="font-serif text-base font-medium text-[#20211D]">
            Evidence-Based Lexical Search
          </p>
          <p className="text-xs max-w-md mx-auto text-[#5C5E55] leading-relaxed">
            Query exact terms, numbers, or phrases across all indexed documents. Results display
            term highlights and provide one-click jump to Reader with active highlight overlays.
          </p>
        </div>
      )}

      {/* No Results Handling */}
      {hasSearched && results.length === 0 && (
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-8 sm:p-10 space-y-4">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-[#F5F2EB] border border-[#E0D9CC] p-2 flex items-center justify-center shrink-0">
              <AlertCircle className="w-6 h-6 text-[#B84B2F]" />
            </div>
            <div className="text-center sm:text-left space-y-2 flex-1">
              <h3 className="font-serif text-base font-semibold text-[#20211D]">
                No matching passages found for "{query}"
              </h3>
              <p className="text-xs text-[#5C5E55] leading-relaxed max-w-2xl">
                {noResultsAdvice?.message ||
                  'Lexical retrieval requires exact tokens, numbers, or phrases present in the stored document chunks.'}
              </p>

              {/* Scope Relaxation Option */}
              {noResultsAdvice?.reason === 'scoped_out' && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectDoc(undefined);
                      const res = searchChunks(query, chunks, documents, undefined);
                      setResults(res);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] rounded text-xs font-medium transition-colors"
                  >
                    <Filter className="w-3.5 h-3.5" />
                    <span>
                      Search across All Documents ({noResultsAdvice.scopeRelaxationDocCount} have matches)
                    </span>
                  </button>
                </div>
              )}

              {/* Suggested Vocabulary / Spelling */}
              {noResultsAdvice?.suggestedTerms && noResultsAdvice.suggestedTerms.length > 0 && (
                <div className="pt-3 border-t border-[#E0D9CC] space-y-1.5">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#5C5E55] flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-[#B84B2F]" />
                    <span>Similar terms indexed in documents:</span>
                  </span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {noResultsAdvice.suggestedTerms.map((term) => (
                      <button
                        key={term}
                        type="button"
                        onClick={() => executeSample(term)}
                        className="px-2.5 py-1 rounded border border-[#E0D9CC] bg-[#F5F2EB] hover:border-[#B84B2F] hover:text-[#B84B2F] text-xs font-mono transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Available Section Titles */}
              {noResultsAdvice?.availableSectionTitles &&
                noResultsAdvice.availableSectionTitles.length > 0 && (
                  <div className="pt-2 space-y-1.5">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8E9085]">
                      Document Sections You Can Search:
                    </span>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {noResultsAdvice.availableSectionTitles.map((sec) => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => executeSample(sec)}
                          className="px-2 py-0.5 rounded border border-[#E0D9CC] bg-[#FAF8F5] hover:border-[#5C5E55] text-[11px] text-[#5C5E55] truncate max-w-xs transition-colors"
                        >
                          § {sec}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
            </div>
          </div>
        </div>
      )}

      {/* Results Listing with Multi-Term Highlighting */}
      <div className="space-y-4">
        {displayedResults.map((res, idx) => {
          // Build snippet highlighting: if highlightSegments exist, render directly
          const segments =
            res.highlightSegments && res.highlightSegments.length > 0
              ? res.highlightSegments
              : highlightTextSegments(res.chunk.text, [query, ...res.matchedTerms], query);

          return (
            <div
              key={`${res.chunk.id}-${idx}`}
              className="border border-[#E0D9CC] bg-[#FAF8F5] hover:border-[#C8BFB0] rounded-lg p-5 space-y-3 transition-colors shadow-2xs"
            >
              {/* Header / Provenance */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-[#8E9085]" />
                    <span className="font-serif font-semibold text-[#20211D]">
                      {res.document.originalName}
                    </span>
                  </div>
                  <span className="text-[#8E9085]">·</span>
                  <span className="font-mono text-[#B84B2F] font-semibold bg-[#B84B2F]/10 px-1.5 py-0.5 rounded">
                    Page {res.chunk.pageStart}
                  </span>
                  {res.chunk.sectionPath.length > 0 && (
                    <>
                      <span className="text-[#8E9085]">·</span>
                      <span className="text-[#5C5E55] truncate max-w-xs font-mono text-[11px]">
                        § {res.chunk.sectionPath.join(' / ')}
                      </span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono text-[11px] text-[#8E9085]">
                    BM25: {Math.round(res.score)}
                  </span>
                  <button
                    onClick={() => onNavigateToReader(res.document.id, res.chunk.pageStart, query)}
                    className="flex items-center gap-1 text-xs text-[#20211D] hover:text-[#B84B2F] font-semibold bg-[#F5F2EB] hover:bg-[#EAE5D9] px-2.5 py-1 rounded border border-[#E0D9CC] transition-colors"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-[#B84B2F]" />
                    <span>Inspect in Reader</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Snippet with Rich Multi-Term Highlight */}
              <div className="p-3.5 bg-[#F5F2EB] rounded border border-[#E0D9CC] font-serif text-xs sm:text-sm text-[#20211D] leading-relaxed">
                {segments.map((seg, sIdx) => {
                  if (seg.isMatch) {
                    return (
                      <mark
                        key={sIdx}
                        className={`font-semibold px-0.5 rounded transition-colors ${
                          seg.isPrimary
                            ? 'bg-[#B84B2F]/25 text-[#B84B2F] underline decoration-[#B84B2F]/50'
                            : 'bg-amber-200/60 text-[#20211D]'
                        }`}
                        title={seg.term ? `Matched term: "${seg.term}"` : undefined}
                      >
                        {seg.text}
                      </mark>
                    );
                  }
                  return <span key={sIdx}>{seg.text}</span>;
                })}
              </div>

              {/* Chunk footer with term tags */}
              <div className="flex items-center justify-between text-[11px] text-[#8E9085] font-mono flex-wrap gap-2 pt-1 border-t border-[#EAE5D9]">
                <span>Chunk ID: {res.chunk.id}</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span>Matched:</span>
                  {res.matchedTerms.map((t, tIdx) => (
                    <span
                      key={tIdx}
                      className="px-1.5 py-0.5 rounded bg-[#FAF8F5] border border-[#E0D9CC] text-[#5C5E55] text-[10px]"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
