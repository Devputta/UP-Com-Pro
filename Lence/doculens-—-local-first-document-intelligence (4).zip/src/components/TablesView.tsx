import React, { useState, useMemo } from 'react';
import {
  Table as TableIcon,
  Download,
  Search,
  ArrowUpDown,
  ShieldCheck,
  BarChart2,
  FileSpreadsheet,
} from 'lucide-react';
import { DocumentTable, DocumentEntity } from '../types/doculens';
import { downloadCSVFile, analyzeColumn } from '../services/tableExport';

interface TablesViewProps {
  tables: DocumentTable[];
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id?: string) => void;
  onNavigateToReader: (docId: string, pageNumber: number) => void;
}

export const TablesView: React.FC<TablesViewProps> = ({
  tables,
  documents,
  selectedDocId,
  onSelectDoc,
  onNavigateToReader,
}) => {
  const filteredTables = selectedDocId
    ? tables.filter((t) => t.documentId === selectedDocId)
    : tables;

  const [activeTableId, setActiveTableId] = useState<string>(
    filteredTables[0]?.id || ''
  );
  const [filterQuery, setFilterQuery] = useState('');
  const [sortColIndex, setSortColIndex] = useState<number | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Sync active table if selection changes
  const activeTable =
    filteredTables.find((t) => t.id === activeTableId) || filteredTables[0];

  const currentDoc = documents.find((d) => d.id === activeTable?.documentId);

  // Sorting and filtering
  const processedRows = useMemo(() => {
    if (!activeTable) return [];
    let rows = [...activeTable.rows];

    if (filterQuery.trim()) {
      const q = filterQuery.toLowerCase();
      rows = rows.filter((row) =>
        row.some((cell) => cell.toLowerCase().includes(q))
      );
    }

    if (sortColIndex !== null) {
      rows.sort((a, b) => {
        const valA = a[sortColIndex] || '';
        const valB = b[sortColIndex] || '';

        const numA = parseFloat(valA.replace(/[^0-9.-]/g, ''));
        const numB = parseFloat(valB.replace(/[^0-9.-]/g, ''));

        if (!isNaN(numA) && !isNaN(numB)) {
          return sortDirection === 'asc' ? numA - numB : numB - numA;
        }
        return sortDirection === 'asc'
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      });
    }

    return rows;
  }, [activeTable, filterQuery, sortColIndex, sortDirection]);

  // Analyze active table columns for numerical stats
  const columnStats = useMemo(() => {
    if (!activeTable) return [];
    return activeTable.headers.map((header, idx) => {
      const columnValues = activeTable.rows.map((r) => r[idx] || '');
      return {
        header,
        ...analyzeColumn(columnValues),
      };
    });
  }, [activeTable]);

  const handleHeaderClick = (colIdx: number) => {
    if (sortColIndex === colIdx) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColIndex(colIdx);
      setSortDirection('asc');
    }
  };

  const handleDownloadJSON = (table: DocumentTable) => {
    const data = table.rows.map((row) => {
      const obj: Record<string, string> = {};
      table.headers.forEach((h, i) => {
        obj[h] = row[i] || '';
      });
      return obj;
    });
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${table.title || 'table_export'}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E0D9CC] pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
            Table Extraction & Safe CSV Studio
          </h1>
          <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
            Normalized data grids extracted from document tables. Exports are fortified against
            formula injection attacks (escaping '=', '+', '-', '@' triggers) to ensure safe
            spreadsheet imports.
          </p>
        </div>

        {/* Scope selector */}
        <div className="flex items-center gap-2">
          <label htmlFor="tables-doc-scope-select" className="text-xs text-[#5C5E55]">Document Scope:</label>
          <select
            id="tables-doc-scope-select"
            value={selectedDocId || ''}
            onChange={(e) => onSelectDoc(e.target.value || undefined)}
            className="text-xs bg-[#FAF8F5] border border-[#E0D9CC] rounded px-2.5 py-1.5 text-[#20211D]"
          >
            <option value="">All Documents ({tables.length} tables)</option>
            {documents.map((d) => (
              <option key={d.id} value={d.id}>
                {d.originalName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filteredTables.length === 0 ? (
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-12 text-center text-[#5C5E55] space-y-3 shadow-2xs">
          <div className="w-12 h-12 mx-auto rounded-full bg-[#F5F2EB] border border-[#E0D9CC] flex items-center justify-center">
            <TableIcon className="w-6 h-6 text-[#8E9085]" />
          </div>
          {currentDoc?.isScanned ? (
            <div className="space-y-1 max-w-md mx-auto">
              <p className="font-serif text-base font-semibold text-[#20211D]">
                Scanned Document Limitation
              </p>
              <p className="text-xs text-[#5C5E55] leading-relaxed">
                "{currentDoc.originalName}" contains scanned image pages without an embedded OCR
                text layer. Automatic table extraction requires extractable text coordinates.
              </p>
            </div>
          ) : currentDoc?.status === 'failed' ? (
            <div className="space-y-1 max-w-md mx-auto">
              <p className="font-serif text-base font-semibold text-rose-800">
                Table Extraction Failed
              </p>
              <p className="text-xs text-[#5C5E55] leading-relaxed">
                The document failed ingestion processing: {currentDoc.errorMessage || 'Corrupted PDF structure'}.
              </p>
            </div>
          ) : (
            <div className="space-y-1 max-w-md mx-auto">
              <p className="font-serif text-base font-semibold text-[#20211D]">
                No Tabular Grids Detected
              </p>
              <p className="text-xs text-[#5C5E55] leading-relaxed">
                {selectedDocId
                  ? `No table-like column structures were detected in "${currentDoc?.originalName || 'the selected document'}". Ordinary paragraphs and lists are preserved in the Reader.`
                  : 'No tables were detected across your document library. Upload a document with data tables or explore the curated benchmark suite in the Library.'}
              </p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Table Tab Selector (Buttons) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {filteredTables.map((t) => {
              const isActive = activeTable?.id === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    setActiveTableId(t.id);
                    setFilterQuery('');
                    setSortColIndex(null);
                  }}
                  className={`px-3 py-1.5 text-xs font-serif rounded border text-left whitespace-nowrap transition-colors flex items-center gap-2 ${
                    isActive
                      ? 'border-[#B84B2F] bg-[#FAF8F5] text-[#B84B2F] font-semibold shadow-2xs'
                      : 'border-[#E0D9CC] bg-[#F5F2EB] text-[#5C5E55] hover:text-[#20211D]'
                  }`}
                >
                  <span>{t.title || `Table p.${t.pageNumber}`}</span>
                  <span className="font-mono text-[10px] px-1 rounded bg-[#EAE5D9] text-[#5C5E55]">
                    {t.rows.length}r × {t.headers.length}c
                  </span>
                </button>
              );
            })}
          </div>

          {activeTable && (
            <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-5 shadow-2xs">
              {/* Active Table Header & Actions */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E0D9CC] pb-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="font-serif text-lg font-semibold text-[#20211D]">
                      {activeTable.title || 'Extracted Table'}
                    </h2>
                    {activeTable.confidence && (
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase tracking-wider font-semibold ${
                          activeTable.confidence === 'high'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : activeTable.confidence === 'medium'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : 'bg-rose-50 text-rose-800 border-rose-300'
                        }`}
                      >
                        {activeTable.confidence} confidence
                      </span>
                    )}
                    {activeTable.extractionMethod && (
                      <span className="text-[10px] font-mono text-[#8E9085] px-1.5 py-0.5 rounded bg-[#F5F2EB] border border-[#E0D9CC]">
                        {activeTable.extractionMethod}
                      </span>
                    )}
                  </div>

                  <div className="text-xs text-[#5C5E55] flex items-center gap-2 mt-1.5 flex-wrap">
                    <span>Source: {currentDoc?.originalName || 'Document'}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[#B84B2F]">Page {activeTable.pageNumber}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {activeTable.headers.length} columns × {activeTable.rows.length} rows
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[10px] text-[#8E9085]">
                      Provenance: {activeTable.sourceElementId}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {currentDoc && (
                    <button
                      onClick={() => onNavigateToReader(currentDoc.id, activeTable.pageNumber)}
                      className="text-xs text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded px-2.5 py-1.5 bg-[#F5F2EB] transition-colors"
                      title="Inspect table in context on document page"
                    >
                      Inspect in Reader (p.{activeTable.pageNumber})
                    </button>
                  )}

                  <button
                    onClick={() => handleDownloadJSON(activeTable)}
                    className="flex items-center gap-1.5 text-xs font-medium text-[#20211D] border border-[#E0D9CC] hover:bg-[#F5F2EB] rounded px-3 py-1.5 bg-[#FAF8F5] transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>JSON</span>
                  </button>

                  <button
                    onClick={() => downloadCSVFile(activeTable)}
                    className="flex items-center gap-1.5 text-xs font-medium text-[#F5F2EB] bg-[#20211D] hover:bg-[#383933] rounded px-3.5 py-1.5 transition-colors"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-[#B84B2F]" />
                    <span>Export Safe CSV</span>
                  </button>
                </div>
              </div>

              {/* Table Warnings if present */}
              {activeTable.warnings && activeTable.warnings.length > 0 && (
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded text-xs text-amber-900 space-y-1">
                  <span className="font-semibold block">Extraction Structure Notes:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-800">
                    {activeTable.warnings.map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Security Formula Injection Notice */}
              <div className="p-2.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-[11px] text-[#5C5E55] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>
                  <strong>Formula Injection Defense Active:</strong> Cells prefixed with '=', '+',
                  '-', or '@' will be prepended with a single quote in CSV downloads to safeguard
                  against malicious spreadsheet macro execution.
                </span>
              </div>

              {/* Search filter within table */}
              <div className="flex items-center justify-between gap-3">
                <div className="relative max-w-xs w-full">
                  <Search className="w-3.5 h-3.5 text-[#8E9085] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={filterQuery}
                    onChange={(e) => setFilterQuery(e.target.value)}
                    placeholder="Filter rows by text or value..."
                    className="w-full text-xs bg-[#F5F2EB] border border-[#E0D9CC] focus:border-[#B84B2F] rounded pl-8 pr-3 py-1.5 text-[#20211D] placeholder-[#8E9085] focus:outline-none"
                  />
                </div>

                <span className="text-xs text-[#8E9085] font-mono">
                  Showing {processedRows.length} of {activeTable.rows.length} rows
                </span>
              </div>

              {/* Data Grid Table */}
              <div className="overflow-x-auto border border-[#E0D9CC] rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#F5F2EB] border-b border-[#E0D9CC] text-[#20211D]">
                      {activeTable.headers.map((h, colIdx) => {
                        const isSorted = sortColIndex === colIdx;
                        return (
                          <th
                            key={colIdx}
                            onClick={() => handleHeaderClick(colIdx)}
                            className="p-3 font-semibold font-serif cursor-pointer hover:bg-[#EAE4D7] transition-colors select-none whitespace-nowrap"
                          >
                            <div className="flex items-center gap-1.5">
                              <span>{h}</span>
                              <ArrowUpDown
                                className={`w-3 h-3 ${
                                  isSorted ? 'text-[#B84B2F]' : 'text-[#8E9085]'
                                }`}
                              />
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E0D9CC] bg-[#FAF8F5]">
                    {processedRows.length === 0 ? (
                      <tr>
                        <td
                          colSpan={activeTable.headers.length}
                          className="p-6 text-center text-xs text-[#8E9085]"
                        >
                          No rows match the filter query.
                        </td>
                      </tr>
                    ) : (
                      processedRows.map((row, rIdx) => (
                        <tr
                          key={rIdx}
                          className="hover:bg-[#F5F2EB] transition-colors font-mono"
                        >
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="p-3 text-[#20211D] whitespace-nowrap">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Numerical Column Analytics */}
              {columnStats.some((c) => c.isNumeric) && (
                <div className="pt-2 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
                    <BarChart2 className="w-3.5 h-3.5 text-[#B84B2F]" />
                    <span>Numeric Column Statistics:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {columnStats
                      .filter((c) => c.isNumeric)
                      .map((stat, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded text-xs space-y-1 font-mono"
                        >
                          <div className="font-serif font-semibold text-[#20211D] truncate">
                            {stat.header}
                          </div>
                          <div className="text-[11px] text-[#5C5E55] flex justify-between">
                            <span>Count: {stat.count}</span>
                            <span>Avg: {stat.average}</span>
                          </div>
                          <div className="text-[11px] text-[#5C5E55] flex justify-between">
                            <span>Min: {stat.min}</span>
                            <span>Max: {stat.max}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
