import React, { useState, useMemo } from 'react';
import {
  Table as TableIcon,
  Download,
  Search,
  ArrowUpDown,
  ShieldCheck,
  BarChart2,
  FileSpreadsheet,
} from 'lucide-react';
import { DocumentTable, DocumentEntity } from '../types/doculens';
import { downloadCSVFile, downloadJSONFile, analyzeColumn } from '../services/tableExport';

interface TablesViewProps {
  tables: DocumentTable[];
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id?: string) => void;
  onNavigateToReader: (docId: string, pageNumber: number) => void;
}

export const TablesView: React.FC<TablesViewProps> = ({
  tables,
  documents,
  selectedDocId,
  onSelectDoc,
  onNavigateToReader,
}) => {
  const filteredTables = selectedDocId
    ? tables.filter((t) => t.documentId === selectedDocId)
    : tables;

  const [activeTableId, setActiveTableId] = useState<string>(
    filteredTables[0]?.id || ''
  );
  const [filterQuery, setFilterQuery] = useState('');
  const [sortColIndex, setSortColIndex] = useState<number | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Sync active table if selection changes
  const activeTable =
    filteredTables.find((t) => t.id === activeTableId) || filteredTables[0];

  const currentDoc = documents.find((d) => d.id === activeTable?.documentId);

  // Sorting and filtering
  const processedRows = useMemo(() => {
    if (!activeTable) return [];
    let rows = [...activeTable.rows];

    if (filterQuery.trim()) {
      const q = filterQuery.toLowerCase();
      rows = rows.filter((row) =>
        row.some((cell) => cell.toLowerCase().includes(q))
      );
    }

    if (sortColIndex !== null) {
      rows.sort((a, b) => {
        const valA = a[sortColIndex] || '';
        const valB = b[sortColIndex] || '';

        const numA = parseFloat(valA.replace(/[^0-9.-]/g, ''));
        const numB = parseFloat(valB.replace(/[^0-9.-]/g, ''));

        if (!isNaN(numA) && !isNaN(numB)) {
          return sortDirection === 'asc' ? numA - numB : numB - numA;
        }
        return sortDirection === 'asc'
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      });
    }

    return rows;
  }, [activeTable, filterQuery, sortColIndex, sortDirection]);

  // Analyze active table columns for numerical stats
  const columnStats = useMemo(() => {
    if (!activeTable) return [];
    return activeTable.headers.map((header, idx) => {
      const columnValues = activeTable.rows.map((r) => r[idx] || '');
      return {
        header,
        ...analyzeColumn(columnValues),
      };
    });
  }, [activeTable]);

  const handleHeaderClick = (colIdx: number) => {
    if (sortColIndex === colIdx) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColIndex(colIdx);
      setSortDirection('asc');
    }
  };

  const handleDownloadJSON = (table: DocumentTable) => {
    const data = table.rows.map((row) => {
      const obj: Record<string, string> = {};
      table.headers.forEach((h, i) => {
        obj[h] = row[i] || '';
      });
      return obj;
    });
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${table.title || 'table_export'}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-paper-border pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-ink">
            Table Extraction & Safe CSV Studio
          </h1>
          <p className="text-[13px] text-ink-muted mt-1.5 max-w-2xl leading-relaxed">
            Normalized data grids extracted from document tables. Exports are fortified against
            formula injection attacks (escaping '=', '+', '-', '@' triggers) to ensure safe
            spreadsheet imports.
          </p>
        </div>

        {/* Right side controls: Document Scope selector + Aligned Export Buttons */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <label htmlFor="tables-doc-scope-select" className="text-[13px] text-ink-muted whitespace-nowrap">
              Scope:
            </label>
            <select
              id="tables-doc-scope-select"
              value={selectedDocId || ''}
              onChange={(e) => onSelectDoc(e.target.value || undefined)}
              className="text-[13px] bg-paper-light border border-paper-border hover:border-accent rounded-md px-3 py-2 min-h-[36px] text-ink focus:border-accent transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              <option value="" className="bg-paper-light text-ink">All Documents ({tables.length} tables)</option>
              {documents.map((d) => (
                <option key={d.id} value={d.id} className="bg-paper-light text-ink">
                  {d.originalName}
                </option>
              ))}
            </select>
          </div>

          {/* Consistent, Aligned Export Button Group */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => activeTable && downloadCSVFile(activeTable, currentDoc?.originalName || 'document')}
              disabled={!activeTable || activeTable.rows.length === 0}
              className="flex items-center gap-2 px-3.5 py-2 min-h-[36px] bg-paper hover:bg-paper-dim border border-accent-border hover:border-accent rounded-md text-[13px] font-semibold text-accent transition-all duration-150 shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-paper disabled:hover:border-accent-border"
              title={!activeTable ? 'No table selected to export' : 'Export sanitized CSV file with formula-injection protection'}
            >
              <FileSpreadsheet className="w-4 h-4 text-accent" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => activeTable && downloadJSONFile(activeTable, currentDoc?.originalName || 'document')}
              disabled={!activeTable || activeTable.rows.length === 0}
              className="flex items-center gap-2 px-3.5 py-2 min-h-[36px] bg-paper hover:bg-paper-dim border border-paper-border hover:border-ink-muted rounded-md text-[13px] font-medium text-ink transition-all duration-150 shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-paper disabled:hover:border-paper-border"
              title={!activeTable ? 'No table selected to export' : 'Export structured JSON with metadata'}
            >
              <Download className="w-4 h-4 text-ink-faint" />
              <span>JSON</span>
            </button>
          </div>
        </div>
      </div>

      {filteredTables.length === 0 ? (
        <div className="border border-paper-border bg-paper-light rounded-lg p-8 sm:p-12 text-center text-ink-muted space-y-4 shadow-xs">
          <div className="w-14 h-14 mx-auto rounded-full bg-paper border border-paper-border flex items-center justify-center">
            <TableIcon className="w-6 h-6 text-ink-faint" />
          </div>
          {currentDoc?.isScanned ? (
            <div className="space-y-1.5 max-w-md mx-auto">
              <p className="font-serif text-lg font-semibold text-ink">
                Scanned Document Limitation
              </p>
              <p className="text-[13px] text-ink-muted leading-relaxed">
                "{currentDoc.originalName}" contains scanned image pages without an embedded OCR
                text layer. Automatic table extraction requires extractable text coordinates.
              </p>
            </div>
          ) : currentDoc?.status === 'failed' ? (
            <div className="space-y-1.5 max-w-md mx-auto">
              <p className="font-serif text-lg font-semibold text-rose-400">
                Table Extraction Failed
              </p>
              <p className="text-[13px] text-ink-muted leading-relaxed">
                The document failed ingestion processing: {currentDoc.errorMessage || 'Corrupted PDF structure'}.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5 max-w-md mx-auto">
              <p className="font-serif text-lg font-semibold text-ink">
                No Tabular Grids Detected
              </p>
              <p className="text-[13px] text-ink-muted leading-relaxed">
                {selectedDocId
                  ? `No table-like column structures were detected in "${currentDoc?.originalName || 'the selected document'}". Ordinary paragraphs and lists are preserved in the Reader.`
                  : 'No tables were detected across your document library. Upload a document with data tables or explore the curated benchmark suite in the Library.'}
              </p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Table Tab Selector (Buttons) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {filteredTables.map((t) => {
              const isActive = activeTable?.id === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    setActiveTableId(t.id);
                    setFilterQuery('');
                    setSortColIndex(null);
                  }}
                  className={`px-3 py-2 min-h-[36px] text-[13px] font-sans rounded-md border text-left whitespace-nowrap transition-all duration-150 flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
                    isActive
                      ? 'border-accent bg-accent-subtle text-accent font-semibold shadow-xs'
                      : 'border-paper-border bg-paper text-ink-muted hover:text-ink hover:bg-paper-dim'
                  }`}
                >
                  <span className="font-medium">{t.title || `Table p.${t.pageNumber}`}</span>
                  <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-paper-dim text-ink-muted">
                    {t.rows.length}r × {t.headers.length}c
                  </span>
                </button>
              );
            })}
          </div>

          {activeTable && (
            <div className="border border-paper-border bg-paper-light rounded-lg p-5 space-y-5 shadow-xs">
              {/* Active Table Header & Actions */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-paper-border pb-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="font-serif text-lg font-semibold text-ink">
                      {activeTable.title || 'Extracted Table'}
                    </h2>
                    {activeTable.confidence && (
                      <span
                        className={`text-xs font-mono px-2 py-0.5 rounded border uppercase tracking-wider font-semibold ${
                          activeTable.confidence === 'high'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : activeTable.confidence === 'medium'
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                        }`}
                      >
                        {activeTable.confidence} confidence
                      </span>
                    )}
                    {activeTable.extractionMethod && (
                      <span className="text-xs font-mono text-ink-faint px-2 py-0.5 rounded bg-paper border border-paper-border">
                        {activeTable.extractionMethod}
                      </span>
                    )}
                  </div>

                  <div className="text-[13px] text-ink-muted flex items-center gap-2 mt-1.5 flex-wrap">
                    <span>Source: {currentDoc?.originalName || 'Document'}</span>
                    <span aria-hidden="true" className="text-ink-faint">·</span>
                    <span className="font-mono text-accent">Page {activeTable.pageNumber}</span>
                    <span aria-hidden="true" className="text-ink-faint">·</span>
                    <span>
                      {activeTable.headers.length} columns × {activeTable.rows.length} rows
                    </span>
                    <span aria-hidden="true" className="text-ink-faint">·</span>
                    <span className="font-mono text-xs text-ink-faint">
                      Provenance: {activeTable.sourceElementId}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {currentDoc && (
                    <button
                      onClick={() => onNavigateToReader(currentDoc.id, activeTable.pageNumber)}
                      className="text-[13px] text-ink-muted hover:text-ink border border-paper-border hover:bg-paper-dim rounded-md px-3 py-2 min-h-[36px] bg-paper transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                      title="Inspect table in context on document page"
                    >
                      Inspect in Reader (p.{activeTable.pageNumber})
                    </button>
                  )}

                  <button
                    onClick={() => downloadJSONFile(activeTable, currentDoc?.originalName || 'document')}
                    className="flex items-center gap-1.5 text-[13px] font-medium text-ink border border-paper-border hover:bg-paper-dim rounded-md px-3.5 py-2 min-h-[36px] bg-paper transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    title="Download table in JSON format with metadata"
                  >
                    <Download className="w-4 h-4 text-ink-faint" />
                    <span>JSON</span>
                  </button>

                  <button
                    onClick={() => downloadCSVFile(activeTable, currentDoc?.originalName || 'document')}
                    className="flex items-center gap-2 text-[13px] font-semibold text-accent bg-paper hover:bg-paper-dim border border-accent-border hover:border-accent rounded-md px-3.5 py-2 min-h-[36px] transition-all duration-150 shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    title="Export sanitized CSV with formula injection defense"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-accent" />
                    <span>Export CSV</span>
                  </button>
                </div>
              </div>

              {/* Table Warnings if present */}
              {activeTable.warnings && activeTable.warnings.length > 0 && (
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-md text-[13px] text-amber-300 space-y-1">
                  <span className="font-semibold block text-amber-200">Extraction Structure Notes:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-xs text-amber-300">
                    {activeTable.warnings.map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Security Formula Injection Notice */}
              <div className="p-3 bg-paper border border-paper-border rounded-md text-xs text-ink-muted flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong className="text-ink">Formula Injection Defense Active:</strong> Cells prefixed with '=', '+',
                  '-', or '@' will be prepended with a single quote in CSV downloads to safeguard
                  against malicious spreadsheet macro execution.
                </span>
              </div>

              {/* Search filter within table */}
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="relative max-w-xs w-full">
                  <Search className="w-4 h-4 text-ink-faint absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={filterQuery}
                    onChange={(e) => setFilterQuery(e.target.value)}
                    placeholder="Filter rows by text or value..."
                    className="w-full text-[13px] bg-paper border border-paper-border focus:border-accent rounded-md pl-9 pr-3 py-2 min-h-[36px] text-ink placeholder:text-ink-faint transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  />
                </div>

                <span className="text-xs text-ink-faint font-mono">
                  Showing {processedRows.length} of {activeTable.rows.length} rows
                </span>
              </div>

              {/* Data Grid Table */}
              <div className="overflow-x-auto border border-paper-border rounded-lg">
                <table className="w-full text-left text-[13px] border-collapse font-sans">
                  <thead>
                    <tr className="bg-paper border-b border-paper-border text-ink">
                      {activeTable.headers.map((h, colIdx) => {
                        const isSorted = sortColIndex === colIdx;
                        return (
                          <th
                            key={colIdx}
                            onClick={() => handleHeaderClick(colIdx)}
                            className="p-3.5 font-semibold font-sans cursor-pointer hover:bg-paper-dim transition-colors select-none whitespace-nowrap"
                          >
                            <div className="flex items-center gap-2">
                              <span>{h}</span>
                              <ArrowUpDown
                                className={`w-3.5 h-3.5 ${
                                  isSorted ? 'text-accent' : 'text-ink-faint'
                                }`}
                              />
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-paper-border bg-paper-light">
                    {processedRows.length === 0 ? (
                      <tr>
                        <td
                          colSpan={activeTable.headers.length}
                          className="p-8 text-center text-[13px] text-ink-faint"
                        >
                          No rows match the filter query.
                        </td>
                      </tr>
                    ) : (
                      processedRows.map((row, rIdx) => (
                        <tr
                          key={rIdx}
                          className="hover:bg-paper-dim transition-colors font-mono text-xs"
                        >
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="p-3 text-ink whitespace-nowrap">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Numerical Column Analytics */}
              {columnStats.some((c) => c.isNumeric) && (
                <div className="pt-2 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-ink-muted">
                    <BarChart2 className="w-3.5 h-3.5 text-accent" />
                    <span>Numeric Column Statistics:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {columnStats
                      .filter((c) => c.isNumeric)
                      .map((stat, idx) => (
                        <div
                          key={idx}
                          className="p-3.5 bg-paper border border-paper-border rounded-md text-xs space-y-1.5 font-mono"
                        >
                          <div className="font-sans font-semibold text-ink truncate text-[13px]">
                            {stat.header}
                          </div>
                          <div className="text-xs text-ink-muted flex justify-between">
                            <span>Count: {stat.count}</span>
                            <span>Avg: {stat.average}</span>
                          </div>
                          <div className="text-xs text-ink-muted flex justify-between">
                            <span>Min: {stat.min}</span>
                            <span>Max: {stat.max}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
