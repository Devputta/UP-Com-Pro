/**
 * DocuLens Table Extraction & CSV Security Sanitizer
 * Implements strict Formula Injection Mitigation (RFC-4180 & OWASP CSV Injection Guidelines)
 * Escapes '=', '+', '-', '@', '\t', '\r', '%', '|' to prevent spreadsheet macro execution
 * and formula exploits across Microsoft Excel, Google Sheets, and LibreOffice Calc.
 */

import { DocumentTable } from '../types/doculens';
import {
  BRAND_NAME,
  BRAND_TAGLINE,
  BRAND_REPOSITORY,
  formatExportDateTime,
  generateExportFilename,
  generateJSONMetadata,
} from '../utils/exportBranding';

// Dangerous characters per OWASP CSV Injection guidelines that trigger formula evaluation
const DANGEROUS_FORMULA_PREFIXES = ['=', '+', '-', '@', '\t', '\r', '%', '|'];

/**
 * Sanitizes a single cell value against CSV formula injection.
 * Escapes malicious spreadsheet formula execution while preserving valid numbers.
 */
export function sanitizeCSVCell(value: string | number | undefined | null): string {
  if (value === null || value === undefined) return '';

  if (typeof value === 'number') {
    if (!isNaN(value) && isFinite(value)) {
      return String(value);
    }
    return '';
  }

  const rawStr = String(value);
  const trimmed = rawStr.trim();
  if (trimmed === '') return '';

  // Check if it's a legitimate number (e.g. "-12.5", "+4.2", "390", "342.0", "0")
  const isPureNumber = /^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(trimmed);
  if (isPureNumber) {
    return trimmed;
  }

  const firstChar = trimmed.charAt(0);
  const rawFirstChar = rawStr.charAt(0);
  const isFormulaRisk =
    DANGEROUS_FORMULA_PREFIXES.includes(firstChar) ||
    DANGEROUS_FORMULA_PREFIXES.includes(rawFirstChar);

  let sanitized = trimmed;
  if (isFormulaRisk) {
    // Prepend single quote (') to force spreadsheet software to treat the cell as raw string text
    sanitized = `'${trimmed}`;
  }

  // RFC-4180 CSV escaping:
  // If the cell contains quotes, commas, newlines, or carriage returns:
  // double up internal quotes and wrap the whole cell in double quotes.
  if (
    sanitized.includes('"') ||
    sanitized.includes(',') ||
    sanitized.includes('\n') ||
    sanitized.includes('\r')
  ) {
    return `"${sanitized.replace(/"/g, '""')}"`;
  }

  return sanitized;
}

export interface CSVExportOptions {
  docName?: string;
  date?: Date;
  includeMetadataHeader?: boolean;
}

/**
 * Converts a DocumentTable to a secure CSV string compliant with RFC-4180.
 * Writes metadata as '# key: value' comment lines at the top while preserving
 * strict Formula Injection Mitigation.
 */
export function exportTableToCSV(
  table: DocumentTable,
  options?: CSVExportOptions
): string {
  const lines: string[] = [];

  // Metadata comments at top (RFC-4180 compliant comments)
  lines.push(`# Application: ${BRAND_NAME}`);
  lines.push(`# Tagline: ${BRAND_TAGLINE}`);
  lines.push(`# Contributor: Devputta (${BRAND_REPOSITORY})`);
  if (options?.docName) {
    const cleanDoc = options.docName.replace(/[\r\n]+/g, ' ').trim();
    lines.push(`# Document: ${cleanDoc}`);
  }
  lines.push(`# Page: ${table.pageNumber}`);
  const genDate = formatExportDateTime(options?.date || new Date(), true);
  lines.push(`# Generated: ${genDate}`);

  // Title comment if present, sanitized to prevent injection or header splitting
  if (table.title) {
    const cleanTitle = table.title
      .replace(/[\r\n]+/g, ' ')
      .replace(/^([=+\-@%|])/g, "'$1")
      .trim();
    lines.push(`# ${cleanTitle}`);
  }

  // Header row
  const headerLine = table.headers.map((h) => sanitizeCSVCell(h)).join(',');
  lines.push(headerLine);

  // Data rows
  for (const row of table.rows) {
    const rowLine = row.map((cell) => sanitizeCSVCell(cell)).join(',');
    lines.push(rowLine);
  }

  return lines.join('\r\n');
}

/**
 * Converts a DocumentTable to structured JSON with metadata object.
 */
export function exportTableToJSON(
  table: DocumentTable,
  options?: { docName?: string; date?: Date }
): { meta: ReturnType<typeof generateJSONMetadata>; data: Record<string, string>[] } {
  const data = table.rows.map((row) => {
    const obj: Record<string, string> = {};
    table.headers.forEach((h, i) => {
      obj[h] = row[i] || '';
    });
    return obj;
  });

  const meta = generateJSONMetadata(table.title || `Table p.${table.pageNumber}`, {
    docA: options?.docName || 'Document',
    docB: table.title || `Table_p${table.pageNumber}`,
    pageNumber: table.pageNumber,
    confidence: table.confidence,
    extractionMethod: table.extractionMethod,
    rowCount: table.rows.length,
    columnCount: table.headers.length,
    date: options?.date || new Date(),
  });

  return { meta, data };
}

/**
 * Computes numeric stats for a column if numerical.
 */
export function analyzeColumn(values: string[]): {
  isNumeric: boolean;
  count: number;
  min?: number;
  max?: number;
  average?: number;
  sum?: number;
} {
  const numericValues = values
    .map((v) => parseFloat(v.replace(/[^0-9.-]/g, '')))
    .filter((n) => !isNaN(n));

  if (numericValues.length >= values.length * 0.6 && numericValues.length > 0) {
    const sum = numericValues.reduce((acc, val) => acc + val, 0);
    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const average = sum / numericValues.length;

    return {
      isNumeric: true,
      count: values.length,
      min: Math.round(min * 100) / 100,
      max: Math.round(max * 100) / 100,
      average: Math.round(average * 100) / 100,
      sum: Math.round(sum * 100) / 100,
    };
  }

  return {
    isNumeric: false,
    count: values.length,
  };
}

/**
 * Triggers safe client-side CSV download with standardized filename:
 * doculens_<type>_<docA>_vs_<docB>_YYYY-MM-DD_HHmm.csv
 */
export function downloadCSVFile(
  table: DocumentTable,
  docName: string = 'document',
  filenamePrefix = 'table'
): void {
  const csvContent = exportTableToCSV(table, { docName });
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);

  const filename = generateExportFilename(
    'table',
    docName,
    table.title || filenamePrefix || `p${table.pageNumber}`,
    'csv'
  );
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Triggers client-side JSON download with standardized filename:
 * doculens_<type>_<docA>_vs_<docB>_YYYY-MM-DD_HHmm.json
 */
export function downloadJSONFile(
  table: DocumentTable,
  docName: string = 'document',
  filenamePrefix = 'table'
): void {
  const jsonContent = exportTableToJSON(table, { docName });
  const blob = new Blob([JSON.stringify(jsonContent, null, 2)], {
    type: 'application/json;charset=utf-8;',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);

  const filename = generateExportFilename(
    'table',
    docName,
    table.title || filenamePrefix || `p${table.pageNumber}`,
    'json'
  );
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
