# DocuLens — Local-First Document Intelligence

DocuLens is a minimalist, local-first document intelligence workbench for PDF ingestion, evidence-based lexical search, citation-verified inquiry answering, structured table extraction, and document revision comparison.

Built with an editorial aesthetic, DocuLens prioritizes document provenance, verifiable citations, privacy, and zero-loss local storage.

---

## Architecture Overview

DocuLens operates on a **split-boundary, local-first architecture**:

```
┌─────────────────────────────────────────────────────────────┐
│                      Client Browser                         │
│  ┌───────────────────┐    ┌───────────────────────────────┐ │
│  │   PDF.js Parser   │───▶│ IndexedDB (doculens_store_v1) │ │
│  │  Signature Check  │    │ - Documents, Chunks, Elements │ │
│  │  Page/Size Limits │    │ - Extracted Tables, Notes     │ │
│  └───────────────────┘    └───────────────────────────────┘ │
│            │                             │                  │
│            ▼                             ▼                  │
│  ┌───────────────────┐    ┌───────────────────────────────┐ │
│  │  Lexical Search   │    │  Deterministic Offline Engine │ │
│  │  BM25-style Rank  │◀───│  Local Citation Extraction    │ │
│  └───────────────────┘    └───────────────────────────────┘ │
└──────────────────────────────────────┬──────────────────────┘
                                       │ (Optional: Question + Excerpts only)
                                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    Stateless Proxy Server                   │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Express Proxy (2MB Body Cap, 25 req/min, 25s Timeout)  │ │
│  │ Secret Isolation: GEMINI_API_KEY never leaks to client │ │
│  │ Strict Citation Verification & Delimiter Escaping     │ │
│  └───────────────────────────┬────────────────────────────┘ │
└──────────────────────────────┼──────────────────────────────┘
                               ▼
                Google Gemini API (gemini-2.5-flash)
```

1. **Client Sandbox (Browser)**:
   - All PDF parsing, binary signature validation, text extraction, page layout reconstruction, and lexical indexing run 100% within the browser.
   - All documents, chunks, extracted tables, and notes are persisted exclusively in client-side IndexedDB (`doculens_local_store_v1`).
   - Browser Same-Origin Policy (SOP) strictly isolates stored documents from other sites and origins.

2. **Stateless Proxy Server (`server.ts`)**:
   - Acts as a secured proxy between the client and Google Gemini (`gemini-2.5-flash`).
   - Keeps `GEMINI_API_KEY` strictly on the server; never exposed to the client bundle or network responses.
   - Enforces strict request body limits (2 MB), sliding-window rate limiting (25 requests/min per IP), and 25-second request timeouts.
   - Sanitizes all errors to ensure internal stack traces, system paths, or environment variables are never leaked.
   - Full PDF files are **never** transmitted to the server or any external API.

3. **Deterministic Offline Fallback**:
   - If the server is offline or no `GEMINI_API_KEY` is configured, DocuLens automatically falls back to an on-device deterministic synthesis engine.
   - Questions are answered by ranking passages, synthesizing extracted findings, and validating citations directly against the local document chunk store.

---

## Core Capabilities

- **Strict PDF Ingestion & Validation**:
  - Validates `%PDF-` magic binary file header signatures.
  - Enforces maximum file size (25 MB) and maximum page count (200 pages).
  - Handles encrypted/password-protected PDFs, corrupted files, and zero-text documents gracefully with clear human-readable error messages.
  - Detects duplicate files by title, size, and page count with non-destructive notifications.
- **Lexical Search & Passage Retrieval**:
  - Token-level search with exact phrase matching, term frequency weighting, page location metadata, and match count indicators.
  - Helpful suggestions and empty states when no documents match query terms.
- **Verified Question Answering**:
  - Distinguishes direct quotations, extracted facts, summaries, and synthetic interpretations.
  - Every citation is validated against stored chunk text, document ID, and page number.
  - Fabricated citation IDs, hallucinated page numbers, and inaccurate quotes are rejected and marked unverified.
  - Explicitly states when document evidence is insufficient to answer the inquiry.
- **Table Extraction & Safe CSV Export**:
  - Heuristic table detection based on line spacing and tabular layout alignment.
  - Full CSV export adhering to RFC-4180 with defense against CSV Formula Injection (sanitizing `=`, `+`, `-`, `@`, `\t`, `\r`, `%`, `|`).
- **Intelligent 4-Mode Document Comparison Workspace**:
  - **Concept Comparison**: Matches subjects across differing authorial terminologies (e.g. stored-program computers vs digital processing engines, algorithms as step-by-step procedures vs deterministic computational instructions).
  - **Definition Comparison**: Extracts and contrasts side-by-side term definitions, regulatory rules, and clinical inclusion criteria with scope divergence analysis.
  - **Topic Overlap Matrix**: Analyzes shared subjects and document-unique topics with a documented Jaccard similarity index and explicit limitation notes.
  - **Content Differences (Revision Diff)**: Side-by-side clause additions, removals, and modifications with verified page numbers.
  - Quick swap action, document metadata headers, and Markdown comparison report export.
- **Evidence-Based Lexical Search & Dynamic In-Reader Highlighting**:
  - Token-level search with exact phrase bonus, term frequency weighting, page location metadata, and match count indicators.
  - Rich multi-term highlights identifying primary and secondary matching terms.
  - In-Reader "Find & Highlight" toolbar with live occurrence counts, auto-scroll to matches, and element provenance inspection.
- **Controlled First-Use & Confirmed Deletion**:
  - Curated benchmark suite includes clinical protocols, energy audits, and computer architecture documents demonstrating cross-terminology comparison.
  - No sample documents are auto-injected without explicit user action ("Load Curated Benchmark Suite").
  - Deleted documents are permanently removed along with all associated chunks, tables, and notes.
  - Sample documents are never auto-restored after user deletion.
  - Settings panel includes an orphan cleanup utility (`cleanupOrphanedRecords`) for recovering from interrupted operations.

---

## Supported File Types & Limitations

### Supported:
- Standard digital PDF documents (`.pdf`) containing selectable text layers.
- Maximum file size: **25 MB**.
- Maximum page count: **200 pages**.
- Formats: PDF 1.0 through 2.0 specifications supported by PDF.js.

### Honest Limitations:
- **No Optical Character Recognition (OCR)**: Scanned image-only PDFs without digital text layers will report zero extractable text. Scanned images are not processed via OCR.
- **Single-User Local Sandbox**: Storage is bound to the local browser profile. There is no user authentication, account management, multi-tenant isolation, or cloud synchronization.
- **No Native At-Rest Encryption**: IndexedDB data is stored unencrypted in the browser profile directory, protected by the operating system's user account permissions and storage volume encryption (e.g., FileVault, BitLocker).
- **No Cloud Backup**: Clearing browser data, using private/incognito mode, or resetting site storage permanently deletes all local documents. Export your data before clearing site data.

---

## Privacy & Security Model

- **What stays on your machine**:
  - 100% of uploaded PDF files, layout elements, full text chunks, extracted tables, and marginalia notes.
  - Search indexes and document comparisons run entirely within your browser memory.
- **What is sent to the server / external AI**:
  - Only when remote AI is enabled: The specific question string and the top-ranked extracted excerpt passages (typically < 10KB total).
  - Raw PDF files are **never** uploaded or sent to external servers.
- **Prompt Injection Defense**:
  - Extracted document text is encapsulated within `<untrusted_document_context>` delimiters.
  - System commands, delimiter tags, and prompt injection patterns are stripped and neutralized before passing to the model.
  - Document text is never permitted to override instructions or trigger tool execution.
- **Spreadsheet Security**:
  - CSV exports neutralize formula execution vectors for Microsoft Excel, Apple Numbers, and Google Sheets.

For vulnerability disclosure and detailed threat models, see [SECURITY.md](SECURITY.md).

---

## Getting Started

### Prerequisites
- Node.js `v18.0.0` or higher
- npm `v9.0.0` or higher

### Installation

```bash
# Clone the repository
git clone https://github.com/your-org/doculens.git
cd doculens

# Install dependencies cleanly
npm install
```

### Environment Configuration

Copy the example environment file:
```bash
cp .env.example .env
```

Configure your environment variables in `.env`:
```env
# Optional: Google Gemini API Key for remote AI synthesis.
# If omitted, DocuLens runs in 100% offline deterministic mode.
GEMINI_API_KEY="your-gemini-api-key"

# Optional: Port configuration (default: 3000)
PORT=3000
```

### Running Locally

```bash
# Start development server with hot module reload
npm run dev

# Or build and run production server
npm run build
npm start
```

Open `http://localhost:3000` in your browser.

---

## Testing & Quality Assurance

The codebase includes an automated test suite covering document management, inquiry reliability, citation provenance, prompt injection mitigation, CSV sanitization, and server security boundaries:

```bash
# Run all unit and integration tests
npm test

# Run TypeScript type checks
npm run lint

# Compile production build
npm run build
```

---

## Troubleshooting

| Issue | Cause | Solution |
| :--- | :--- | :--- |
| **"Invalid PDF structure or header missing"** | File is not a valid PDF or is corrupted. | Verify the file opens in a standard PDF viewer before uploading. |
| **"File size exceeds 25 MB limit"** | File exceeds parser limit. | Compress or split the document into smaller chapters. |
| **"PDF is encrypted with a password"** | Document has encryption or DRM enabled. | Remove password protection in Adobe Acrobat or Preview before upload. |
| **"No extractable text found"** | The PDF is a pure image scan without text layers. | DocuLens does not perform OCR. Run OCR preprocessing before upload. |
| **"AI Service Unavailable / Offline Mode"** | `GEMINI_API_KEY` is not set or server rate limit reached. | DocuLens automatically falls back to local deterministic synthesis. To use AI, set `GEMINI_API_KEY` in `.env`. |
| **Orphaned records or storage bloat** | Browser was closed abruptly during file deletion. | Open **Settings** in the application and click **"Purge Orphaned Records"**. |

---

## License

This project is licensed under the Apache License, Version 2.0. See the [LICENSE](LICENSE) file for details.
