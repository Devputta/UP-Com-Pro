# QRForge

A fast, private QR code generator that runs entirely in your web browser. No tracking, no backend database, and no data leaves your device.

- **Source code**: [https://github.com/Devputta/QRForge](https://github.com/Devputta/QRForge)

## Preview

```
+-----------------------------------------------------------+
|  [QRForge]     Generator    Batch export    Library       |
|                                                           |
|  Website  Maps  Wi-Fi  Contact  WhatsApp  Text  Calendar  |
|  [ Destination URL: https://example.com/page            ] |
|                                                           |
|  Colors: [Foreground #000] [Background #fff]              |
|                                     +------------------+  |
|                                     |  [QR CODE HERE]  |  |
|                                     |  [Scan verified] |  |
|                                     +------------------+  |
|                                     [ Download PNG ]      |
|                                     [ Download SVG ]      |
|                                     [ Export PDF ]        |
+-----------------------------------------------------------+
```

## Features

- **Scan verified**: Decodes the rendered QR code with jsQR in real-time to verify that phone cameras will read the exact intended content.
- **Export formats**: High-resolution PNG (512px, 1024px, 2048px), vector SVG for crisp signage, and print-ready PDF at custom physical dimensions (cm).
- **Custom styling**: High-contrast color pairings, dot patterns (square, rounded, dots), corner markers (square, rounded, circle), error correction levels (L, M, Q, H), quiet borders, and centered icons or custom logos with scannability warnings.
- **Batch CSV export**: Generate dozens of QR codes at once with a ZIP package and index manifest.
- **Saved library with JSON backup**: Save designs locally in your browser, duplicate, re-edit, and export or import your entire library as a verified JSON file.
- **Offline and private**: Works offline with self-hosted fonts. No telemetry, no third-party scripts.
- **Form auto-recovery**: Automatically preserves your active draft in session storage so you never lose work on accidental reload.
- **Light & dark themes**: Automatically follows your system preference with a quick manual toggle.

## Static codes note

All QR codes created with QRForge are **static QR codes**. The encoded data is directly written into the matrix pattern:
- **No redirects or middleman servers**: Scanners open your direct link or information without passing through an external URL shortener.
- **Permanent and immutable**: Once printed, the destination cannot be modified or expired by a third party.
- **No scan tracking or analytics**: Because there is no intermediary server, scans cannot be tracked, logged, or monetized.

## Supported QR types

- **Website**: Web addresses with optional UTM builder (source, medium, campaign).
- **Google Maps**: Search queries, turn-by-turn directions with travel modes, or direct map links.
- **Wi-Fi networks**: WPA/WPA2/WPA3 or open networks with one-tap connection (passwords are never saved to disk).
- **Contact card (vCard 3.0)**: Standard digital business cards with full RFC 2426 escaping.
- **WhatsApp**: Direct chat links with international phone numbers and prefilled messages.
- **Plain text**: Direct text display for notes, serial numbers, codes, and instructions.
- **Calendar event (iCalendar)**: Add appointments, meetings, or conferences directly to Google Calendar, Apple Calendar, and Outlook.
- **Social profiles**: Quick links for LinkedIn, X (Twitter), GitHub, YouTube, and Instagram.
- **Email & Phone/SMS**: Pre-addressed emails and phone call or SMS triggers.
- **Files**: Share links for PDFs, presentations, and documents hosted on your cloud storage.

## Install and run

Requires Node.js 18 or later.

```bash
# Install dependencies
npm install

# Start local development server
npm run dev

# Run automated tests
npm test

# Run linter
npm run lint

# Build for production
npm run build
```

## Privacy note

QRForge has no tracking scripts, analytics cookies, or backend servers. Every QR code matrix is calculated and drawn directly in your browser. All fonts are self-hosted. Your links, contact details, and Wi-Fi credentials never leave your computer.
