/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  BarChart3,
  HelpCircle,
  Maximize2,
  Minimize2,
  Moon,
  Play,
  RotateCcw,
  Sun,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Announcer } from './components/Announcer';
import { CanvasBoard } from './components/CanvasBoard';
import { ControlsGuideModal } from './components/ControlsGuideModal';
import { GameOverModal } from './components/GameOverModal';
import { HoldPanel } from './components/HoldPanel';
import { MobileControls } from './components/MobileControls';
import { NextQueuePanel } from './components/NextQueuePanel';
import { PauseModal } from './components/PauseModal';
import { ScorePanel } from './components/ScorePanel';
import { StatsModal } from './components/StatsModal';
import { sound } from './game/audio';
import { GameEngine } from './game/gameEngine';
import { BoardSize, ThemeMode } from './game/types';
import { useControls } from './game/useControls';
import { loadPersistentData, savePersistentData } from './lib/storage';

export default function App() {
  const initialData = useMemo(() => loadPersistentData(), []);

  // Persistent settings state
  const [soundEnabled, setSoundEnabled] = useState(initialData.settings.soundEnabled);
  const [ghostEnabled, setGhostEnabled] = useState(initialData.settings.ghostPieceEnabled);
  const [theme, setTheme] = useState<ThemeMode>(initialData.settings.theme);
  const [boardSize, setBoardSize] = useState<BoardSize>(initialData.settings.boardSize);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Modals state
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isControlsOpen, setIsControlsOpen] = useState(false);
  const [announcement, setAnnouncement] = useState('');
  const [stateTick, setStateTick] = useState(0);

  const prevHighScoreRef = useRef(initialData.stats.highScore);

  const triggerUpdate = useCallback(() => {
    setStateTick((t) => t + 1);
  }, []);

  // Initialize engine once
  const engineRef = useRef<GameEngine | null>(null);
  if (!engineRef.current) {
    sound.setSoundEnabled(initialData.settings.soundEnabled);
    sound.setVolume(initialData.settings.volume);

    engineRef.current = new GameEngine(
      initialData.stats,
      initialData.settings,
      {
        onMove: () => sound.playMove(),
        onRotate: () => sound.playRotate(),
        onSoftDrop: () => sound.playSoftDrop(),
        onHardDrop: () => sound.playHardDrop(),
        onHold: () => sound.playHold(),
        onLock: () => sound.playLock(),
        onLineClear: (ev) => sound.playLineClear(ev.isTetris),
        onLevelUp: () => sound.playLevelUp(),
        onGameOver: () => sound.playGameOver(),
        onAnnounce: (msg) => setAnnouncement(msg),
        onStateChange: triggerUpdate,
      }
    );
  }

  const engine = engineRef.current;

  // Sync settings with storage
  useEffect(() => {
    sound.setSoundEnabled(soundEnabled);
    engine.settings.soundEnabled = soundEnabled;
    engine.settings.ghostPieceEnabled = ghostEnabled;
    engine.settings.theme = theme;
    engine.settings.boardSize = boardSize;

    savePersistentData({
      stats: engine.stats,
      settings: engine.settings,
    });
  }, [soundEnabled, ghostEnabled, theme, boardSize, engine]);

  // Track fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = async () => {
    sound.playButtonClick();
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen not supported or blocked in iframe
    }
  };

  // Save stats on game over or changes
  useEffect(() => {
    if (engine.status === 'GAME_OVER') {
      savePersistentData({
        stats: engine.stats,
        settings: engine.settings,
      });
    }
  }, [stateTick, engine]);

  // Bind keyboard controls
  useControls({
    engine,
    enabled: !isStatsOpen && !isControlsOpen,
  });

  // Game Loop using requestAnimationFrame
  useEffect(() => {
    let lastTime = performance.now();
    let frameId: number;

    const gameLoop = (currentTime: number) => {
      const delta = Math.min(100, currentTime - lastTime);
      lastTime = currentTime;

      if (engine.status === 'PLAYING') {
        engine.update(delta);
      }

      frameId = requestAnimationFrame(gameLoop);
    };

    frameId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(frameId);
  }, [engine]);

  const handleStartGame = () => {
    sound.playButtonClick();
    prevHighScoreRef.current = engine.stats.highScore;
    engine.startGame();
  };

  const handleResumeGame = () => {
    sound.playButtonClick();
    engine.resumeGame();
  };

  const handleToggleSound = () => {
    sound.playButtonClick();
    setSoundEnabled((prev) => !prev);
  };

  const handleToggleTheme = () => {
    sound.playButtonClick();
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleToggleGhost = () => {
    sound.playButtonClick();
    setGhostEnabled((prev) => !prev);
  };

  const cycleBoardSize = () => {
    sound.playButtonClick();
    setBoardSize((curr) => {
      if (curr === 'compact') return 'normal';
      if (curr === 'normal') return 'large';
      return 'compact';
    });
  };

  const isNewHighScore =
    engine.status === 'GAME_OVER' &&
    engine.score > prevHighScoreRef.current &&
    engine.score > 0;

  const isLight = theme === 'light';

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 selection:bg-cyan-500 selection:text-white ${
        isLight ? 'bg-slate-100 text-slate-900' : 'bg-slate-950 text-slate-100'
      }`}
    >
      <Announcer message={announcement} />

      {/* Top Bar Contract: Zone 1 (Wordmark), Zone 2 (Nav links), Zone 3 (Actions) */}
      <header
        className={`flex items-center justify-between px-3 sm:px-6 py-2.5 border-b sticky top-0 z-40 backdrop-blur-md transition-colors ${
          isLight
            ? 'border-slate-200 bg-white/90 text-slate-800'
            : 'border-slate-800 bg-slate-950/90 text-slate-100'
        }`}
      >
        {/* Zone 1: Single text wordmark */}
        <a href="/" className="text-xl font-black tracking-tight flex items-center gap-1.5 shrink-0">
          <span className="text-cyan-500">BLOCK</span>FALL
        </a>

        {/* Zone 2: Clean unboxed nav controls & Quick board sizing */}
        <nav className="flex items-center gap-2 sm:gap-4 text-xs font-medium text-slate-400">
          {/* Board Size Toggle button */}
          <button
            type="button"
            onClick={cycleBoardSize}
            title="Toggle Board Size (Compact / Normal / Large)"
            className={`px-2 py-1 rounded-md text-[11px] font-mono border transition-colors flex items-center gap-1 ${
              isLight
                ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Size:</span>
            <span className="font-bold text-cyan-500 capitalize">{boardSize}</span>
          </button>

          <span aria-hidden="true" className={isLight ? 'text-slate-300' : 'text-slate-700'}>
            ·
          </span>

          <button
            type="button"
            onClick={() => {
              sound.playButtonClick();
              setIsControlsOpen(true);
            }}
            className={`flex items-center gap-1 transition-colors ${
              isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5 text-cyan-500" />
            <span className="hidden sm:inline">Guide</span>
          </button>

          <span aria-hidden="true" className={isLight ? 'text-slate-300' : 'text-slate-700'}>
            ·
          </span>

          <button
            type="button"
            onClick={() => {
              sound.playButtonClick();
              setIsStatsOpen(true);
            }}
            className={`flex items-center gap-1 transition-colors ${
              isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-indigo-500" />
            <span className="hidden sm:inline">Stats</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Light / Dark Mode Toggle */}
          <button
            type="button"
            onClick={handleToggleTheme}
            aria-label={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            className={`p-2 rounded-lg border transition-colors ${
              isLight
                ? 'bg-white border-slate-200 text-amber-500 hover:bg-slate-50'
                : 'bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-800'
            }`}
          >
            {isLight ? <Moon className="w-4 h-4 text-slate-700" /> : <Sun className="w-4 h-4 text-amber-400" />}
          </button>

          {/* Fullscreen Toggle */}
          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
            className={`p-2 rounded-lg border transition-colors ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={handleToggleSound}
            aria-label={soundEnabled ? 'Mute sound' : 'Unmute sound'}
            className={`p-2 rounded-lg border transition-colors ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-500" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {/* Play / Restart button */}
          {engine.status === 'IDLE' ? (
            <button
              type="button"
              onClick={handleStartGame}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold uppercase tracking-wider transition-colors shadow-xs"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>PLAY</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleStartGame}
              aria-label="Restart Game"
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                isLight
                  ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300 shadow-xs'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Restart</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Game Arena */}
      <main className="flex-1 flex flex-col items-center justify-center p-2 sm:p-4 max-w-5xl mx-auto w-full">
        <div className="w-full flex flex-col items-center">
          {/* Mobile Top Score Bar (Compact on mobile) */}
          <div
            className={`w-full max-w-sm grid grid-cols-4 gap-2 mb-2 lg:hidden text-center rounded-xl p-2 text-xs border transition-colors ${
              isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-900/90 border-slate-800'
            }`}
          >
            <div>
              <span className="text-[9px] uppercase tracking-wider text-slate-500 block">SCORE</span>
              <span
                className={`font-mono font-bold tabular-nums ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}
              >
                {engine.score}
              </span>
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-wider text-amber-500 block">BEST</span>
              <span className="font-mono font-bold text-amber-500 tabular-nums">
                {Math.max(engine.score, engine.stats.highScore)}
              </span>
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-wider text-cyan-600 block">LVL</span>
              <span className="font-mono font-bold text-cyan-600 tabular-nums">{engine.level}</span>
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-wider text-emerald-600 block">LINES</span>
              <span className="font-mono font-bold text-emerald-600 tabular-nums">{engine.lines}</span>
            </div>
          </div>

          {/* Desktop & Tablet Tri-Column Layout */}
          <div className="flex items-start justify-center gap-4 sm:gap-6 w-full">
            {/* Left Side Panel (Hold & Score on desktop) */}
            <div className="hidden lg:flex flex-col gap-4 w-44 shrink-0">
              <HoldPanel heldPiece={engine.heldPiece} canHold={engine.canHold} theme={theme} />
              <ScorePanel
                score={engine.score}
                highScore={engine.stats.highScore}
                level={engine.level}
                lines={engine.lines}
                theme={theme}
              />
            </div>

            {/* Center: The Game Board */}
            <div className="relative flex flex-col items-center">
              {/* Mobile Hold & Next compact strip */}
              <div className="flex items-center justify-between w-full max-w-[320px] mb-2 lg:hidden px-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-slate-500 uppercase">HOLD</span>
                  <div className="scale-75 origin-left">
                    <HoldPanel heldPiece={engine.heldPiece} canHold={engine.canHold} theme={theme} />
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <div className="scale-75 origin-right">
                    <NextQueuePanel queue={engine.nextQueue} theme={theme} />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-500 uppercase">NEXT</span>
                </div>
              </div>

              {/* Direct Tap Instructions Reminder for Mobile & Mouse */}
              <div className="mb-1 text-[11px] text-slate-500 dark:text-slate-400 text-center select-none hidden sm:block">
                <span>Tap left/right side of board to move · Tap top or right-click to rotate</span>
              </div>

              {/* Canvas Board Component */}
              <CanvasBoard
                engine={engine}
                showGhost={ghostEnabled}
                theme={theme}
                boardSize={boardSize}
              />

              {/* Start Screen Overlay when status is IDLE */}
              {engine.status === 'IDLE' && (
                <div
                  className={`absolute inset-0 z-20 flex flex-col items-center justify-center p-6 backdrop-blur-xs rounded-xl text-center border transition-colors ${
                    isLight
                      ? 'bg-white/90 border-slate-200 text-slate-900 shadow-xl'
                      : 'bg-slate-950/85 border-slate-800 text-white'
                  }`}
                >
                  <h1 className="text-3xl sm:text-4xl font-black tracking-tight mb-2">
                    <span className="text-cyan-500">BLOCK</span>FALL
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mb-6 leading-relaxed">
                    Falling-block arcade puzzle with 7-bag randomizer, SRS wall kicks, and touch controls.
                  </p>

                  <button
                    type="button"
                    onClick={handleStartGame}
                    className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide transition-all shadow-lg shadow-cyan-900/30 active:scale-95 cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>START GAME</span>
                  </button>

                  <div className="mt-5 flex flex-wrap justify-center items-center gap-2 text-xs text-slate-500 font-mono">
                    <span>Tap left/right or use arrows</span>
                    <span>·</span>
                    <span>Space to drop</span>
                  </div>
                </div>
              )}
            </div>

            {/* Right Side Panel (Next Queue on desktop) */}
            <div className="hidden lg:flex flex-col gap-4 w-44 shrink-0">
              <NextQueuePanel queue={engine.nextQueue} theme={theme} />

              {/* Quick hotkey reminder card */}
              <div
                className={`p-3 rounded-xl border text-[11px] space-y-1 font-mono transition-colors ${
                  isLight
                    ? 'bg-white border-slate-200 text-slate-600 shadow-xs'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex justify-between">
                  <span>Tap Left/Right</span>
                  <span className="text-cyan-600 dark:text-cyan-400">Move</span>
                </div>
                <div className="flex justify-between">
                  <span>Right-Click</span>
                  <span className="text-indigo-600 dark:text-indigo-400">Rotate</span>
                </div>
                <div className="flex justify-between">
                  <span>Keys</span>
                  <span className="text-slate-700 dark:text-slate-300">Arrows/WASD</span>
                </div>
                <div className="flex justify-between">
                  <span>Hard Drop</span>
                  <span className="text-slate-700 dark:text-slate-300">Space</span>
                </div>
                <div className="flex justify-between">
                  <span>Hold</span>
                  <span className="text-slate-700 dark:text-slate-300">C / Shift</span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Touch Controls */}
          <div className="w-full mt-2 lg:hidden">
            <MobileControls engine={engine} status={engine.status} theme={theme} />
          </div>
        </div>
      </main>

      {/* Modals */}
      {engine.status === 'PAUSED' && (
        <PauseModal
          engine={engine}
          onResume={handleResumeGame}
          onRestart={handleStartGame}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          ghostEnabled={ghostEnabled}
          onToggleGhost={handleToggleGhost}
          boardSize={boardSize}
          onSetBoardSize={(s) => setBoardSize(s)}
          theme={theme}
        />
      )}

      {engine.status === 'GAME_OVER' && (
        <GameOverModal
          score={engine.score}
          lines={engine.lines}
          level={engine.level}
          highScore={engine.stats.highScore}
          isNewHighScore={isNewHighScore}
          onPlayAgain={handleStartGame}
          onOpenStats={() => setIsStatsOpen(true)}
          theme={theme}
        />
      )}

      {isStatsOpen && (
        <StatsModal
          stats={engine.stats}
          onClose={() => setIsStatsOpen(false)}
          theme={theme}
        />
      )}

      {isControlsOpen && (
        <ControlsGuideModal
          onClose={() => setIsControlsOpen(false)}
          theme={theme}
        />
      )}
    </div>
  );
}
