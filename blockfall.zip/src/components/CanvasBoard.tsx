import React, { useEffect, useRef, useState } from 'react';
import { BOARD_HEIGHT, BOARD_WIDTH, HIDDEN_ROWS, PIECE_COLORS, TOTAL_ROWS } from '../game/constants';
import { TETROMINO_SHAPES } from '../game/pieces';
import { GameEngine } from '../game/gameEngine';
import { BoardSize, TetrominoType, ThemeMode } from '../game/types';

interface CanvasBoardProps {
  engine: GameEngine;
  showGhost: boolean;
  theme: ThemeMode;
  boardSize: BoardSize;
}

export const CanvasBoard: React.FC<CanvasBoardProps> = ({
  engine,
  showGhost,
  theme,
  boardSize,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Touch & click tracking for board side taps and gestures
  const touchStartPos = useRef<{ x: number; y: number; time: number } | null>(null);
  const [activeZone, setActiveZone] = useState<'left' | 'right' | 'rotate' | 'drop' | null>(null);

  // Render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const cellSize = width / BOARD_WIDTH;

      const isLight = theme === 'light';

      // Clear entire board canvas
      ctx.fillStyle = isLight ? '#F8FAFC' : '#090D16';
      ctx.fillRect(0, 0, width, height);

      // Draw subtle grid lines
      ctx.strokeStyle = isLight ? 'rgba(15, 23, 42, 0.08)' : 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;

      for (let c = 1; c < BOARD_WIDTH; c++) {
        const x = Math.floor(c * cellSize);
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      for (let r = 1; r < BOARD_HEIGHT; r++) {
        const y = Math.floor(r * cellSize);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Helper function to draw an arcade 3D shaded block
      const drawBlock = (col: number, visibleRow: number, type: TetrominoType, alpha = 1.0) => {
        const x = col * cellSize;
        const y = visibleRow * cellSize;
        const pad = Math.max(1, Math.floor(cellSize * 0.04));
        const bSize = cellSize - pad * 2;
        const colors = PIECE_COLORS[type];

        ctx.save();
        ctx.globalAlpha = alpha;

        // Base color
        ctx.fillStyle = colors.main;
        ctx.fillRect(x + pad, y + pad, bSize, bSize);

        // Highlight bevel (top & left)
        const bevel = Math.max(2, Math.floor(cellSize * 0.12));
        ctx.fillStyle = colors.light;
        ctx.beginPath();
        ctx.moveTo(x + pad, y + pad);
        ctx.lineTo(x + pad + bSize, y + pad);
        ctx.lineTo(x + pad + bSize - bevel, y + pad + bevel);
        ctx.lineTo(x + pad + bevel, y + pad + bevel);
        ctx.lineTo(x + pad + bevel, y + pad + bSize - bevel);
        ctx.lineTo(x + pad, y + pad + bSize);
        ctx.closePath();
        ctx.fill();

        // Shadow bevel (bottom & right)
        ctx.fillStyle = colors.dark;
        ctx.beginPath();
        ctx.moveTo(x + pad + bSize, y + pad);
        ctx.lineTo(x + pad + bSize, y + pad + bSize);
        ctx.lineTo(x + pad, y + pad + bSize);
        ctx.lineTo(x + pad + bevel, y + pad + bSize - bevel);
        ctx.lineTo(x + pad + bSize - bevel, y + pad + bSize - bevel);
        ctx.lineTo(x + pad + bSize - bevel, y + pad + bevel);
        ctx.closePath();
        ctx.fill();

        // Center jewel accent
        ctx.fillStyle = colors.main;
        ctx.fillRect(x + pad + bevel, y + pad + bevel, bSize - bevel * 2, bSize - bevel * 2);

        // Thin dark border for crisp light mode contrast
        if (isLight) {
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)';
          ctx.lineWidth = 1;
          ctx.strokeRect(x + pad + 0.5, y + pad + 0.5, bSize - 1, bSize - 1);
        }

        ctx.restore();
      };

      // Draw locked board blocks
      for (let r = HIDDEN_ROWS; r < TOTAL_ROWS; r++) {
        const visibleRow = r - HIDDEN_ROWS;
        const isClearingRow = engine.clearingRows.includes(r);

        for (let c = 0; c < BOARD_WIDTH; c++) {
          const cell = engine.board[r][c];
          if (cell !== null) {
            if (isClearingRow) {
              // Flash bright white/cyan on clearing line
              const x = c * cellSize;
              const y = visibleRow * cellSize;
              ctx.fillStyle = isLight ? '#0284C7' : '#FFFFFF';
              ctx.fillRect(x + 1, y + 1, cellSize - 2, cellSize - 2);
            } else {
              drawBlock(c, visibleRow, cell);
            }
          }
        }
      }

      // Draw ghost piece (preview landing position)
      if (showGhost && engine.ghostPiece && engine.activePiece && engine.status === 'PLAYING') {
        const ghost = engine.ghostPiece;
        const shape = TETROMINO_SHAPES[ghost.type][ghost.rotation];

        for (let r = 0; r < shape.length; r++) {
          for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c] !== 0) {
              const boardY = ghost.y + r;
              const boardX = ghost.x + c;
              if (boardY >= HIDDEN_ROWS && boardY < TOTAL_ROWS && boardX >= 0 && boardX < BOARD_WIDTH) {
                const visibleRow = boardY - HIDDEN_ROWS;
                const x = boardX * cellSize;
                const y = visibleRow * cellSize;
                const colors = PIECE_COLORS[ghost.type];

                ctx.save();
                ctx.strokeStyle = isLight ? colors.dark : colors.light;
                ctx.lineWidth = 1.5;
                ctx.fillStyle = isLight ? 'rgba(0, 0, 0, 0.06)' : colors.glow;
                ctx.fillRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
                ctx.strokeRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
                ctx.restore();
              }
            }
          }
        }
      }

      // Draw active piece
      if (engine.activePiece && engine.status === 'PLAYING') {
        const active = engine.activePiece;
        const shape = TETROMINO_SHAPES[active.type][active.rotation];

        for (let r = 0; r < shape.length; r++) {
          for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c] !== 0) {
              const boardY = active.y + r;
              const boardX = active.x + c;
              if (boardY >= HIDDEN_ROWS && boardY < TOTAL_ROWS && boardX >= 0 && boardX < BOARD_WIDTH) {
                const visibleRow = boardY - HIDDEN_ROWS;
                drawBlock(boardX, visibleRow, active.type);
              }
            }
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [engine, showGhost, theme]);

  // Handle direct pointer taps / clicks on left/right/center of board
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (engine.status !== 'PLAYING') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    touchStartPos.current = { x, y, time: performance.now() };

    // Primary click / tap behavior
    if (e.button === 0) {
      const relX = x / rect.width;
      const relY = y / rect.height;

      if (relX < 0.38) {
        engine.moveLeft();
        setActiveZone('left');
      } else if (relX > 0.62) {
        engine.moveRight();
        setActiveZone('right');
      } else if (relY < 0.65) {
        engine.rotateClockwise();
        setActiveZone('rotate');
      } else {
        engine.softDropStep();
        setActiveZone('drop');
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setActiveZone(null);
    if (!touchStartPos.current || engine.status !== 'PLAYING') return;

    const rect = e.currentTarget.getBoundingClientRect();
    const endX = e.clientX - rect.left;
    const endY = e.clientY - rect.top;
    const dx = endX - touchStartPos.current.x;
    const dy = endY - touchStartPos.current.y;
    const dt = performance.now() - touchStartPos.current.time;

    // Detect fast downward swipe for hard drop
    if (dy > 65 && Math.abs(dx) < 40 && dt < 300) {
      engine.hardDrop();
    }
    touchStartPos.current = null;
  };

  // Right-click on board -> Rotate clockwise (and prevent context menu)
  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (engine.status === 'PLAYING') {
      engine.rotateClockwise();
      setActiveZone('rotate');
      setTimeout(() => setActiveZone(null), 150);
    }
  };

  // Responsive board max-width based on selected size
  const sizeClasses = {
    compact: 'max-w-[240px] sm:max-w-[270px]',
    normal: 'max-w-[300px] sm:max-w-[340px]',
    large: 'max-w-[360px] sm:max-w-[430px]',
  }[boardSize];

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onContextMenu={handleContextMenu}
      className={`relative mx-auto rounded-xl overflow-hidden border-2 transition-all select-none touch-none cursor-pointer ${
        theme === 'light'
          ? 'border-slate-300 bg-white shadow-xl shadow-slate-200'
          : 'border-slate-800 bg-slate-950 shadow-2xl shadow-cyan-950/20'
      } ${sizeClasses}`}
      title="Click left/right to move, click top to rotate, or right-click to rotate!"
    >
      <canvas
        ref={canvasRef}
        width={300}
        height={600}
        className="block aspect-[1/2] w-full h-auto touch-none select-none"
        aria-label="BlockFall 10 by 20 game board. Click or tap left or right side to move, center to rotate, or right click to rotate."
        role="img"
      />

      {/* Subtle touch zone feedback flash indicators */}
      {activeZone === 'left' && (
        <div className="absolute inset-y-0 left-0 w-[38%] bg-cyan-500/15 pointer-events-none transition-opacity" />
      )}
      {activeZone === 'right' && (
        <div className="absolute inset-y-0 right-0 w-[38%] bg-cyan-500/15 pointer-events-none transition-opacity" />
      )}
      {activeZone === 'rotate' && (
        <div className="absolute inset-x-0 top-0 h-[65%] bg-indigo-500/15 pointer-events-none transition-opacity" />
      )}
      {activeZone === 'drop' && (
        <div className="absolute inset-x-0 bottom-0 h-[35%] bg-amber-500/15 pointer-events-none transition-opacity" />
      )}
    </div>
  );
};
