import React from 'react';
import { X, Keyboard, Smartphone, MousePointer } from 'lucide-react';
import { ThemeMode } from '../game/types';

interface ControlsGuideModalProps {
  onClose: () => void;
  theme?: ThemeMode;
}

export const ControlsGuideModal: React.FC<ControlsGuideModalProps> = ({ onClose, theme = 'dark' }) => {
  const isLight = theme === 'light';

  const keyboardControls = [
    { key: '← / A', action: 'Move Left' },
    { key: '→ / D', action: 'Move Right' },
    { key: '↓ / S', action: 'Soft Drop' },
    { key: '↑ / W / X', action: 'Rotate Clockwise' },
    { key: 'Z', action: 'Rotate Counter-Clockwise' },
    { key: 'Space', action: 'Hard Drop (instant)' },
    { key: 'C / Shift', action: 'Hold Piece' },
    { key: 'P / Esc', action: 'Pause / Resume' },
    { key: 'R', action: 'Restart Game' },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="controls-guide-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
    >
      <div
        className={`w-full max-w-md rounded-xl border p-6 shadow-2xl transition-colors ${
          isLight
            ? 'bg-white border-slate-300 text-slate-800'
            : 'bg-slate-900 border-slate-700/80 text-slate-100'
        }`}
      >
        <div
          className={`flex items-center justify-between pb-3 mb-4 border-b ${
            isLight ? 'border-slate-200' : 'border-slate-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Keyboard className="w-5 h-5 text-cyan-500" />
            <h2
              id="controls-guide-title"
              className={`text-lg font-bold uppercase tracking-tight ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}
            >
              Controls & Touch Guide
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close controls guide"
            className={`p-1 rounded-lg transition-colors ${
              isLight
                ? 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Direct Board Tap & Mouse Gestures */}
        <div className="mb-4">
          <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
            <MousePointer className="w-3.5 h-3.5" />
            <span>Direct Board Touch & Clicks</span>
          </div>
          <div
            className={`p-3 rounded-xl border text-xs space-y-1.5 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <div className="flex justify-between items-center py-0.5">
              <span>Tap Right Side of Board:</span>
              <span className="font-semibold text-cyan-600 dark:text-cyan-300">Move Right</span>
            </div>
            <div className="flex justify-between items-center py-0.5">
              <span>Tap Left Side of Board:</span>
              <span className="font-semibold text-cyan-600 dark:text-cyan-300">Move Left</span>
            </div>
            <div className="flex justify-between items-center py-0.5">
              <span>Right-Click / Tap Top:</span>
              <span className="font-semibold text-indigo-600 dark:text-indigo-300">Rotate CW</span>
            </div>
            <div className="flex justify-between items-center py-0.5">
              <span>Swipe Down / Tap Bottom:</span>
              <span className="font-semibold text-amber-600 dark:text-amber-300">Drop</span>
            </div>
          </div>
        </div>

        {/* Keyboard layout */}
        <div className="mb-4">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-2">
            Keyboard Shortcuts
          </span>
          <div
            className={`space-y-1.5 p-3 rounded-xl border text-xs ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            {keyboardControls.map((c, i) => (
              <div
                key={i}
                className={`flex items-center justify-between py-1 border-b last:border-none ${
                  isLight ? 'border-slate-200' : 'border-slate-900/60'
                }`}
              >
                <span className={isLight ? 'text-slate-700' : 'text-slate-300'}>{c.action}</span>
                <kbd
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border ${
                    isLight
                      ? 'bg-white border-slate-300 text-slate-800 shadow-xs'
                      : 'bg-slate-800 border-slate-700 text-cyan-300'
                  }`}
                >
                  {c.key}
                </kbd>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile controls note */}
        <div className="mb-5">
          <div className="flex items-center gap-1.5 mb-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
            <Smartphone className="w-3.5 h-3.5" />
            <span>On-Screen Touch Buttons</span>
          </div>
          <p
            className={`text-xs p-3 rounded-xl border leading-relaxed ${
              isLight
                ? 'bg-slate-50 border-slate-200 text-slate-600'
                : 'bg-slate-950/60 border-slate-800 text-slate-300'
            }`}
          >
            Dedicated D-pad and action buttons appear below the board on mobile screens. Hold Left or Right arrows for continuous motion, or tap directly on either side of the board!
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition-colors"
        >
          Got It
        </button>
      </div>
    </div>
  );
};
