import React from 'react';
import { RotateCcw, BarChart3, Trophy } from 'lucide-react';
import { ThemeMode } from '../game/types';

interface GameOverModalProps {
  score: number;
  lines: number;
  level: number;
  highScore: number;
  isNewHighScore: boolean;
  onPlayAgain: () => void;
  onOpenStats: () => void;
  theme?: ThemeMode;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  lines,
  level,
  highScore,
  isNewHighScore,
  onPlayAgain,
  onOpenStats,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="game-over-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm"
    >
      <div
        className={`w-full max-w-sm rounded-xl border p-6 shadow-2xl text-center transition-colors ${
          isLight
            ? 'bg-white border-slate-300 text-slate-800'
            : 'bg-slate-900 border-slate-700/80 text-slate-100'
        }`}
      >
        <h2 id="game-over-title" className="text-2xl font-bold tracking-tight text-red-500 uppercase mb-1">
          Game Over
        </h2>
        <p className={`text-xs mb-6 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          Better luck on the next drop!
        </p>

        {isNewHighScore && (
          <div className="mb-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-semibold">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span>NEW HIGH SCORE!</span>
          </div>
        )}

        <div
          className={`rounded-xl p-4 mb-6 border flex flex-col gap-3 ${
            isLight
              ? 'bg-slate-50 border-slate-200'
              : 'bg-slate-950/60 border-slate-800'
          }`}
        >
          <div>
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider block mb-0.5 ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              FINAL SCORE
            </span>
            <span
              className={`text-3xl font-mono font-bold tabular-nums tracking-tight ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}
            >
              {score.toLocaleString()}
            </span>
          </div>

          <div
            className={`grid grid-cols-2 gap-2 pt-2 border-t ${
              isLight ? 'border-slate-200' : 'border-slate-800/80'
            }`}
          >
            <div>
              <span
                className={`text-[10px] font-semibold uppercase tracking-wider block ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                LINES
              </span>
              <span
                className={`text-lg font-mono font-bold tabular-nums ${
                  isLight ? 'text-emerald-700' : 'text-emerald-400'
                }`}
              >
                {lines}
              </span>
            </div>
            <div>
              <span
                className={`text-[10px] font-semibold uppercase tracking-wider block ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                LEVEL
              </span>
              <span
                className={`text-lg font-mono font-bold tabular-nums ${
                  isLight ? 'text-cyan-700' : 'text-cyan-400'
                }`}
              >
                {level}
              </span>
            </div>
          </div>

          <div
            className={`pt-2 border-t flex items-center justify-between text-xs ${
              isLight ? 'border-slate-200 text-slate-500' : 'border-slate-800/80 text-slate-400'
            }`}
          >
            <span>All-time Best:</span>
            <span className="font-mono font-semibold text-amber-500 tabular-nums">
              {Math.max(score, highScore).toLocaleString()}
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onPlayAgain}
            className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:bg-cyan-700 text-white font-semibold transition-colors shadow-sm"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again</span>
          </button>

          <button
            type="button"
            onClick={onOpenStats}
            className={`flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl border font-medium transition-colors text-sm ${
              isLight
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>View Statistics</span>
          </button>
        </div>
      </div>
    </div>
  );
};
