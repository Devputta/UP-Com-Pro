import React from 'react';
import { TetrominoType, ThemeMode } from '../game/types';
import { PiecePreview } from './PiecePreview';

interface HoldPanelProps {
  heldPiece: TetrominoType | null;
  canHold: boolean;
  theme?: ThemeMode;
}

export const HoldPanel: React.FC<HoldPanelProps> = ({ heldPiece, canHold, theme = 'dark' }) => {
  const isLight = theme === 'light';

  return (
    <div
      className={`flex flex-col items-center p-3 rounded-xl border transition-colors ${
        isLight
          ? 'bg-white border-slate-200 text-slate-800 shadow-sm'
          : 'bg-slate-900/90 border-slate-800 text-slate-200 shadow-sm'
      }`}
    >
      <div className="flex items-center justify-between w-full mb-2">
        <span className={`text-xs font-semibold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          HOLD
        </span>
        <span className={`text-[10px] font-mono hidden sm:inline ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
          [C]
        </span>
      </div>
      <PiecePreview
        type={heldPiece}
        size={76}
        dimmed={!canHold && heldPiece !== null}
        theme={theme}
      />
      <span
        className={`mt-2 text-[10px] font-mono font-medium tracking-tight ${
          canHold
            ? isLight ? 'text-emerald-600' : 'text-emerald-400'
            : isLight ? 'text-slate-400' : 'text-slate-500'
        }`}
      >
        {canHold ? 'READY' : 'LOCKED'}
      </span>
    </div>
  );
};
