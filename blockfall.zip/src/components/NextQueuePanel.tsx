import React from 'react';
import { TetrominoType, ThemeMode } from '../game/types';
import { PiecePreview } from './PiecePreview';

interface NextQueuePanelProps {
  queue: TetrominoType[];
  theme?: ThemeMode;
}

export const NextQueuePanel: React.FC<NextQueuePanelProps> = ({ queue, theme = 'dark' }) => {
  const displayPieces = queue.slice(0, 3);
  const isLight = theme === 'light';

  return (
    <div
      className={`flex flex-col items-center p-3 rounded-xl border transition-colors ${
        isLight
          ? 'bg-white border-slate-200 text-slate-800 shadow-sm'
          : 'bg-slate-900/90 border-slate-800 text-slate-200 shadow-sm'
      }`}
    >
      <div className="flex items-center justify-between w-full mb-2">
        <span className={`text-xs font-semibold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          NEXT
        </span>
        <span className={`text-[10px] font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
          QUEUE
        </span>
      </div>
      <div className="flex flex-col gap-2">
        {displayPieces.map((type, idx) => (
          <PiecePreview
            key={idx}
            type={type}
            size={idx === 0 ? 76 : 60}
            theme={theme}
          />
        ))}
      </div>
    </div>
  );
};
