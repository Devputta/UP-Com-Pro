import React from 'react';
import { ThemeMode } from '../game/types';

interface ScorePanelProps {
  score: number;
  highScore: number;
  level: number;
  lines: number;
  theme?: ThemeMode;
}

export const ScorePanel: React.FC<ScorePanelProps> = ({
  score,
  highScore,
  level,
  lines,
  theme = 'dark',
}) => {
  const isLight = theme === 'light';

  return (
    <div
      className={`flex flex-col gap-2 p-3 rounded-xl border transition-colors ${
        isLight
          ? 'bg-white border-slate-200 text-slate-800 shadow-sm'
          : 'bg-slate-900/90 border-slate-800 text-slate-200 shadow-sm'
      }`}
    >
      <div>
        <div className={`text-[10px] font-semibold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          SCORE
        </div>
        <div className={`text-xl sm:text-2xl font-mono font-bold tracking-tight tabular-nums ${isLight ? 'text-slate-900' : 'text-white'}`}>
          {score.toLocaleString()}
        </div>
      </div>

      <div className={`pt-1 border-t ${isLight ? 'border-slate-100' : 'border-slate-800/80'}`}>
        <div className={`text-[10px] font-semibold uppercase tracking-wider ${isLight ? 'text-amber-700' : 'text-amber-400/90'}`}>
          HIGH SCORE
        </div>
        <div className={`text-base sm:text-lg font-mono font-semibold tracking-tight tabular-nums ${isLight ? 'text-amber-600' : 'text-amber-300'}`}>
          {Math.max(score, highScore).toLocaleString()}
        </div>
      </div>

      <div className={`grid grid-cols-2 gap-2 pt-1 border-t ${isLight ? 'border-slate-100' : 'border-slate-800/80'}`}>
        <div>
          <div className={`text-[10px] font-semibold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            LEVEL
          </div>
          <div className={`text-base sm:text-lg font-mono font-bold tabular-nums ${isLight ? 'text-cyan-700' : 'text-cyan-400'}`}>
            {level}
          </div>
        </div>
        <div>
          <div className={`text-[10px] font-semibold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            LINES
          </div>
          <div className={`text-base sm:text-lg font-mono font-bold tabular-nums ${isLight ? 'text-emerald-700' : 'text-emerald-400'}`}>
            {lines}
          </div>
        </div>
      </div>
    </div>
  );
};
