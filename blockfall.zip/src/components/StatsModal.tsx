import React from 'react';
import { X } from 'lucide-react';
import { GameStats, TetrominoType, ThemeMode } from '../game/types';
import { PiecePreview } from './PiecePreview';
import { TETROMINO_TYPES } from '../game/pieces';

interface StatsModalProps {
  stats: GameStats;
  onClose: () => void;
  theme?: ThemeMode;
}

export const StatsModal: React.FC<StatsModalProps> = ({ stats, onClose, theme = 'dark' }) => {
  const totalPieces = Object.values(stats.pieceCounts).reduce((a, b) => a + b, 0);
  const isLight = theme === 'light';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="stats-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
    >
      <div
        className={`w-full max-w-md rounded-xl border p-6 shadow-2xl transition-colors ${
          isLight
            ? 'bg-white border-slate-300 text-slate-800'
            : 'bg-slate-900 border-slate-700/80 text-slate-100'
        }`}
      >
        <div
          className={`flex items-center justify-between pb-3 mb-4 border-b ${
            isLight ? 'border-slate-200' : 'border-slate-800'
          }`}
        >
          <h2
            id="stats-title"
            className={`text-lg font-bold uppercase tracking-tight ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}
          >
            Statistics & Records
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close statistics"
            className={`p-1 rounded-lg transition-colors ${
              isLight
                ? 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Overview cards */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          <div
            className={`p-3 rounded-xl border ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider block ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              High Score
            </span>
            <span className="text-lg font-mono font-bold text-amber-500 tabular-nums">
              {stats.highScore.toLocaleString()}
            </span>
          </div>

          <div
            className={`p-3 rounded-xl border ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider block ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              Games Played
            </span>
            <span
              className={`text-lg font-mono font-bold tabular-nums ${
                isLight ? 'text-cyan-700' : 'text-cyan-400'
              }`}
            >
              {stats.gamesPlayed.toLocaleString()}
            </span>
          </div>

          <div
            className={`p-3 rounded-xl border ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider block ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              Best Lines
            </span>
            <span
              className={`text-lg font-mono font-bold tabular-nums ${
                isLight ? 'text-emerald-700' : 'text-emerald-400'
              }`}
            >
              {stats.bestLines.toLocaleString()}
            </span>
          </div>

          <div
            className={`p-3 rounded-xl border ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            <span
              className={`text-[10px] font-semibold uppercase tracking-wider block ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              Total Lines Cleared
            </span>
            <span
              className={`text-lg font-mono font-bold tabular-nums ${
                isLight ? 'text-indigo-700' : 'text-indigo-400'
              }`}
            >
              {stats.totalLines.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Piece distribution */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2">
            <span
              className={`text-xs font-semibold uppercase tracking-wider ${
                isLight ? 'text-slate-500' : 'text-slate-400'
              }`}
            >
              Piece Distribution
            </span>
            <span
              className={`text-xs font-mono tabular-nums ${
                isLight ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Total: {totalPieces}
            </span>
          </div>

          <div
            className={`grid grid-cols-7 gap-1.5 p-2 rounded-xl border ${
              isLight
                ? 'bg-slate-50 border-slate-200'
                : 'bg-slate-950/60 border-slate-800'
            }`}
          >
            {TETROMINO_TYPES.map((type: TetrominoType) => {
              const count = stats.pieceCounts[type] || 0;
              const pct = totalPieces > 0 ? Math.round((count / totalPieces) * 100) : 0;
              return (
                <div key={type} className="flex flex-col items-center">
                  <div className="scale-75 origin-center">
                    <PiecePreview type={type} size={42} theme={theme} />
                  </div>
                  <span
                    className={`text-[11px] font-mono font-bold mt-1 tabular-nums ${
                      isLight ? 'text-slate-800' : 'text-slate-200'
                    }`}
                  >
                    {count}
                  </span>
                  <span
                    className={`text-[9px] font-mono tabular-nums ${
                      isLight ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {pct}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className={`w-full py-2.5 px-4 rounded-xl font-medium transition-colors border ${
            isLight
              ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
          }`}
        >
          Close
        </button>
      </div>
    </div>
  );
};
