import { STORAGE_KEY } from '../game/constants';
import { GameSettings, GameStats, TetrominoType } from '../game/types';

export interface PersistentData {
  stats: GameStats;
  settings: GameSettings;
}

const DEFAULT_PIECE_COUNTS: Record<TetrominoType, number> = {
  I: 0,
  J: 0,
  L: 0,
  O: 0,
  S: 0,
  T: 0,
  Z: 0,
};

const DEFAULT_STATS: GameStats = {
  highScore: 0,
  bestLines: 0,
  bestLevel: 1,
  gamesPlayed: 0,
  totalLines: 0,
  pieceCounts: { ...DEFAULT_PIECE_COUNTS },
};

const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  volume: 0.6,
  ghostPieceEnabled: true,
  theme: 'dark',
  boardSize: 'normal',
};

export function loadPersistentData(): PersistentData {
  if (typeof window === 'undefined') {
    return { stats: DEFAULT_STATS, settings: DEFAULT_SETTINGS };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return { stats: DEFAULT_STATS, settings: DEFAULT_SETTINGS };
    }

    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') {
      return { stats: DEFAULT_STATS, settings: DEFAULT_SETTINGS };
    }

    // Safely extract and validate stats
    const stats: GameStats = {
      highScore: typeof parsed.stats?.highScore === 'number' && !isNaN(parsed.stats.highScore) ? Math.max(0, parsed.stats.highScore) : 0,
      bestLines: typeof parsed.stats?.bestLines === 'number' && !isNaN(parsed.stats.bestLines) ? Math.max(0, parsed.stats.bestLines) : 0,
      bestLevel: typeof parsed.stats?.bestLevel === 'number' && !isNaN(parsed.stats.bestLevel) ? Math.max(1, parsed.stats.bestLevel) : 1,
      gamesPlayed: typeof parsed.stats?.gamesPlayed === 'number' && !isNaN(parsed.stats.gamesPlayed) ? Math.max(0, parsed.stats.gamesPlayed) : 0,
      totalLines: typeof parsed.stats?.totalLines === 'number' && !isNaN(parsed.stats.totalLines) ? Math.max(0, parsed.stats.totalLines) : 0,
      pieceCounts: {
        I: Number(parsed.stats?.pieceCounts?.I) || 0,
        J: Number(parsed.stats?.pieceCounts?.J) || 0,
        L: Number(parsed.stats?.pieceCounts?.L) || 0,
        O: Number(parsed.stats?.pieceCounts?.O) || 0,
        S: Number(parsed.stats?.pieceCounts?.S) || 0,
        T: Number(parsed.stats?.pieceCounts?.T) || 0,
        Z: Number(parsed.stats?.pieceCounts?.Z) || 0,
      },
    };

    // Safely extract and validate settings
    const settings: GameSettings = {
      soundEnabled: typeof parsed.settings?.soundEnabled === 'boolean' ? parsed.settings.soundEnabled : true,
      volume: typeof parsed.settings?.volume === 'number' && !isNaN(parsed.settings.volume)
        ? Math.max(0, Math.min(1, parsed.settings.volume))
        : 0.6,
      ghostPieceEnabled: typeof parsed.settings?.ghostPieceEnabled === 'boolean' ? parsed.settings.ghostPieceEnabled : true,
      theme: parsed.settings?.theme === 'light' ? 'light' : 'dark',
      boardSize: ['compact', 'normal', 'large'].includes(parsed.settings?.boardSize)
        ? parsed.settings.boardSize
        : 'normal',
    };

    return { stats, settings };
  } catch {
    // If corrupt or parsing error, fallback safely
    return { stats: DEFAULT_STATS, settings: DEFAULT_SETTINGS };
  }
}

export function savePersistentData(data: PersistentData): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Gracefully handle storage quota or private browsing errors
  }
}
