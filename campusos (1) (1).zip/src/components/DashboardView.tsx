import { UserProfile, CampusEvent, Notice, Ticket, SubjectAttendanceSummary } from '../types/index.js';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  AlertCircle, 
  CheckCircle2, 
  QrCode, 
  ArrowRight, 
  Bell,
  BookOpen
} from 'lucide-react';

interface DashboardViewProps {
  currentUser: UserProfile;
  events: CampusEvent[];
  notices: Notice[];
  myTickets: Ticket[];
  attendance: SubjectAttendanceSummary[];
  onNavigateTab: (tab: string) => void;
  onViewTicket: (ticket: Ticket) => void;
}

export function DashboardView({
  currentUser,
  events,
  notices,
  myTickets,
  attendance,
  onNavigateTab,
  onViewTicket
}: DashboardViewProps) {
  // Today's scheduled classes (VI Sem CSE Monday / Tuesday sample)
  const todayClasses = [
    { time: '09:00 AM - 10:00 AM', code: '22CS61', name: 'Distributed Systems & Cloud Computing', room: 'LH-302', faculty: 'Dr. Arvind Venkat' },
    { time: '10:15 AM - 11:15 AM', code: '22CS62', name: 'Compiler Design & Automata Theory', room: 'LH-302', faculty: 'Prof. Sandhya Rao' },
    { time: '11:30 AM - 01:30 PM', code: '22CSL67', name: 'Cloud Computing & DevOps Lab', room: 'Lab-4', faculty: 'Dr. Arvind Venkat & Lab Staff' }
  ];

  const shortageSubject = attendance.find(s => s.percentage < 75);
  const activeTickets = myTickets.filter(t => t.status === 'ISSUED');
  const recentNotices = notices.slice(0, 3);

  return (
    <div className="space-y-6 text-slate-800">
      {/* Student Welcome Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">
              Student Information Portal · Academic Year 2026–27
            </span>
            <h1 className="text-xl font-bold text-slate-900 mt-1">
              Welcome back, {currentUser.full_name}
            </h1>
            <div className="text-xs text-slate-600 mt-1 flex flex-wrap items-center gap-3">
              {currentUser.student_id && (
                <span className="font-mono font-medium">USN / Roll: {currentUser.student_id}</span>
              )}
              <span>·</span>
              <span>{currentUser.department_name}</span>
              <span>·</span>
              <span>Semester {currentUser.semester || 6} (Section A)</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 block">Current Academic Status</span>
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded mt-1">
              <CheckCircle2 className="h-3.5 w-3.5" /> Enrolled & Active
            </span>
          </div>
        </div>
      </div>

      {/* Attendance Shortage Warning (Real Institutional Format as specified in Rule 9) */}
      {shortageSubject && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-xs text-amber-900">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-4 w-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h2 className="font-bold text-amber-950">Attendance Shortage Notice</h2>
              <p className="text-amber-900 leading-relaxed">
                Your attendance in <strong>{shortageSubject.subject_code} {shortageSubject.subject_name}</strong> is currently <strong>{shortageSubject.percentage.toFixed(1)}%</strong>, which is below the mandatory 75% institutional requirement for semester-end examination eligibility.
              </p>
              <p className="text-amber-800">
                Please ensure attendance in upcoming lecture and tutorial sessions, or submit an approved medical/on-duty leave request to the department office.
              </p>
              <div className="pt-2 flex items-center gap-3">
                <button
                  onClick={() => onNavigateTab('attendance')}
                  className="font-semibold text-blue-900 hover:underline"
                >
                  View Attendance Record →
                </button>
                <button
                  onClick={() => onNavigateTab('leave')}
                  className="font-semibold text-blue-900 hover:underline"
                >
                  Apply for Leave →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Two column grid for Classes & Attendance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Classes */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Today's Class Schedule</h2>
              <span className="text-[11px] text-slate-500">Monday, VI Semester Schedule</span>
            </div>
            <button
              onClick={() => onNavigateTab('schedule')}
              className="text-xs font-semibold text-blue-900 hover:underline flex items-center gap-1"
            >
              Full Timetable <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {todayClasses.map((cls, idx) => (
              <div key={idx} className="py-2.5 flex items-start justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold text-blue-900">{cls.code}</span>
                    <span className="text-slate-400">·</span>
                    <span className="font-medium text-slate-900">{cls.name}</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Faculty: {cls.faculty}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="font-mono font-medium text-slate-700 block">{cls.time}</span>
                  <span className="text-[11px] text-slate-500 block">Room: {cls.room}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Academic Attendance Summary Table */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Attendance Summary</h2>
              <span className="text-[11px] text-slate-500">Minimum 75% required for examination eligibility</span>
            </div>
            <button
              onClick={() => onNavigateTab('attendance')}
              className="text-xs font-semibold text-blue-900 hover:underline flex items-center gap-1"
            >
              View Details <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 text-slate-500 font-semibold">
                <tr>
                  <th className="py-2 px-1">Subject</th>
                  <th className="py-2 px-2 text-center">Classes</th>
                  <th className="py-2 px-2 text-center">%</th>
                  <th className="py-2 px-1 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {attendance.slice(0, 4).map((sub) => {
                  const isShort = sub.percentage < 75;
                  return (
                    <tr key={sub.subject_code}>
                      <td className="py-2 px-1 font-medium text-slate-900 truncate max-w-[160px]">
                        {sub.subject_code} - {sub.subject_name}
                      </td>
                      <td className="py-2 px-2 text-center font-mono text-slate-600">
                        {sub.attended_classes}/{sub.total_classes}
                      </td>
                      <td className="py-2 px-2 text-center font-mono font-bold">
                        <span className={isShort ? 'text-red-700' : 'text-slate-900'}>
                          {sub.percentage.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-2 px-1 text-right">
                        {isShort ? (
                          <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 px-1.5 py-0.5 rounded">
                            Shortage
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                            Eligible
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Two column grid for Events & Notices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Registered Events */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Upcoming Registered Events & Passes</h2>
              <span className="text-[11px] text-slate-500">Present your validated QR ticket at entrance gates</span>
            </div>
            <button
              onClick={() => onNavigateTab('events')}
              className="text-xs font-semibold text-blue-900 hover:underline flex items-center gap-1"
            >
              Browse Events <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-3">
            {activeTickets.length > 0 ? (
              activeTickets.map(ticket => (
                <div key={ticket.id} className="border border-slate-200 rounded-md p-3.5 flex items-center justify-between gap-3 text-xs bg-slate-50/50">
                  <div className="space-y-1">
                    <span className="font-bold text-slate-900 block">{ticket.event_title}</span>
                    <div className="text-slate-500 text-[11px] flex items-center gap-3">
                      <span>{new Date(ticket.event_start_at).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      <span>·</span>
                      <span>{ticket.event_location}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-600 block">
                      Ticket ID: {ticket.public_ticket_id}
                    </span>
                  </div>

                  <button
                    onClick={() => onViewTicket(ticket)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 transition-colors shrink-0"
                  >
                    <QrCode className="h-3.5 w-3.5" />
                    Open Pass
                  </button>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-xs text-slate-500">
                No active event passes issued. Register for campus workshops or hackathons to obtain passes.
              </div>
            )}
          </div>
        </div>

        {/* Recent Official Notices */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Important Notices & Circulars</h2>
              <span className="text-[11px] text-slate-500">Department and university announcements</span>
            </div>
            <button
              onClick={() => onNavigateTab('notices')}
              className="text-xs font-semibold text-blue-900 hover:underline flex items-center gap-1"
            >
              All Circulars <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {recentNotices.map(notice => (
              <div key={notice.id} className="py-2.5 space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{notice.title}</span>
                  <span className="text-[11px] text-slate-500">
                    {new Date(notice.published_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                <p className="text-slate-600 text-[11px] line-clamp-2 leading-relaxed">
                  {notice.body}
                </p>
                <div className="text-[10px] text-slate-400">
                  Issued by: {notice.author_name}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
