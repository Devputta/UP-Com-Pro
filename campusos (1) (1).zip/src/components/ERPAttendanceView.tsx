import { useEffect, useState } from 'react';
import { SubjectAttendanceSummary, AttendanceRecord, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { CheckCircle2, AlertCircle, Save, CheckSquare, ArrowRight } from 'lucide-react';

interface ERPAttendanceViewProps {
  currentUser: UserProfile;
}

export function ERPAttendanceView({ currentUser }: ERPAttendanceViewProps) {
  const [attendanceList, setAttendanceList] = useState<SubjectAttendanceSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'RECORD' | 'REGISTER'>(
    currentUser.role === 'STUDENT' ? 'RECORD' : 'REGISTER'
  );

  // Faculty Roll Call Register
  const [selectedSubject, setSelectedSubject] = useState('22CS61');
  const [sessionDate, setSessionDate] = useState(new Date().toISOString().split('T')[0]);
  const [sessionTime, setSessionTime] = useState('09:00 AM - 10:00 AM');
  const [studentRolls, setStudentRolls] = useState<Array<{
    student_id: string;
    student_name: string;
    student_usn: string;
    status: 'PRESENT' | 'ABSENT' | 'LATE';
  }>>([
    { student_id: 'usr-student-1', student_name: 'Rahul Sharma', student_usn: '1CS22CS089', status: 'PRESENT' },
    { student_id: 'usr-student-2', student_name: 'Ananya Deshmukh', student_usn: '1EC23EC014', status: 'PRESENT' },
    { student_id: 'usr-student-3', student_name: 'Aditya Kulkarni', student_usn: '1CS22CS012', status: 'PRESENT' },
    { student_id: 'usr-student-4', student_name: 'Bhavana Hegde', student_usn: '1CS22CS025', status: 'ABSENT' },
    { student_id: 'usr-student-5', student_name: 'Chirag Reddy', student_usn: '1CS22CS044', status: 'PRESENT' },
    { student_id: 'usr-student-6', student_name: 'Deepika Iyer', student_usn: '1CS22CS058', status: 'PRESENT' }
  ]);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isStaff = currentUser.role !== 'STUDENT';

  useEffect(() => {
    async function loadAttendance() {
      setLoading(true);
      try {
        const res = await api.getStudentAttendance(currentUser.id);
        setAttendanceList(res.attendance);
      } catch (err) {
        console.error('Failed to load attendance:', err);
      } finally {
        setLoading(false);
      }
    }
    loadAttendance();
  }, [currentUser.id]);

  const handleToggleStatus = (studentId: string, status: 'PRESENT' | 'ABSENT' | 'LATE') => {
    setStudentRolls(prev => prev.map(s => s.student_id === studentId ? { ...s, status } : s));
  };

  const handleSaveRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSaveSuccess(null);
    try {
      const recordsToSave = studentRolls.map(s => ({
        subject_code: selectedSubject,
        subject_name: 'Distributed Systems & Cloud Computing',
        student_id: s.student_id,
        student_name: s.student_name,
        student_usn: s.student_usn,
        date: sessionDate,
        session_time: sessionTime,
        status: s.status,
        marked_by: currentUser.full_name
      }));

      await api.markAttendance(recordsToSave);
      setSaveSuccess(`Session roll call attendance recorded for ${studentRolls.length} students on ${sessionDate}.`);
      setTimeout(() => setSaveSuccess(null), 5000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Calculations
  const totalHeld = attendanceList.reduce((acc, curr) => acc + curr.total_classes, 0);
  const totalAttended = attendanceList.reduce((acc, curr) => acc + curr.attended_classes, 0);
  const aggregatePercentage = totalHeld > 0 ? ((totalAttended / totalHeld) * 100).toFixed(1) : '0';
  const shortageSubjects = attendanceList.filter(s => s.percentage < 75);

  return (
    <div className="space-y-6 text-slate-800">
      {/* Title & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Student Attendance</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Academic Year 2026–27 · Semester {currentUser.semester || 6} · Official Attendance Record
          </p>
        </div>

        {isStaff && (
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-md border border-slate-200">
            <button
              onClick={() => setActiveTab('RECORD')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'RECORD'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Academic Record
            </button>
            <button
              onClick={() => setActiveTab('REGISTER')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'REGISTER'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mark Class Roll Call
            </button>
          </div>
        )}
      </div>

      {saveSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-md p-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{saveSuccess}</span>
        </div>
      )}

      {activeTab === 'RECORD' && (
        <div className="space-y-5">
          {/* Summary Strip (Institutional Format) */}
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
              <div className="sm:pr-4 space-y-1">
                <span className="text-slate-500 uppercase tracking-wider text-[11px] block">Overall Attendance</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-slate-900">{aggregatePercentage}%</span>
                  <span className="text-slate-500 font-mono">({totalAttended} / {totalHeld} classes)</span>
                </div>
              </div>

              <div className="sm:px-4 pt-3 sm:pt-0 space-y-1">
                <span className="text-slate-500 uppercase tracking-wider text-[11px] block">University Minimum Rule</span>
                <div className="text-sm font-semibold text-slate-800">
                  75.0% Mandatory Requirement
                </div>
                <span className="text-[11px] text-slate-500 block">Exemption allowed up to 65% with approved medical certificate</span>
              </div>

              <div className="sm:pl-4 pt-3 sm:pt-0 space-y-1">
                <span className="text-slate-500 uppercase tracking-wider text-[11px] block">Current Examination Status</span>
                <div>
                  {Number(aggregatePercentage) >= 75 ? (
                    <span className="inline-flex items-center gap-1.5 font-bold text-emerald-700 text-sm">
                      <CheckCircle2 className="h-4 w-4" /> Eligible for Hall Ticket
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 font-bold text-red-700 text-sm">
                      <AlertCircle className="h-4 w-4" /> Shortage Status
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Shortage Warning Notification (Rule 9: Informative rather than dramatic) */}
          {shortageSubjects.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-md p-4 text-xs text-amber-900 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-amber-950">
                <AlertCircle className="h-4 w-4 text-amber-700 shrink-0" />
                <span>Attendance shortage</span>
              </div>
              <p className="leading-relaxed text-amber-900">
                Your attendance in <strong>{shortageSubjects.map(s => `${s.subject_code} ${s.subject_name} (${s.percentage.toFixed(1)}%)`).join(', ')}</strong> is currently below the required 75%.
              </p>
              <p className="text-amber-800 text-[11px]">
                Please attend upcoming classes or submit an approved leave/on-duty request if applicable.
              </p>
            </div>
          )}

          {/* Academic Attendance Table (Clean Institutional Table as specified in Rule 8) */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="py-2.5 px-4">Subject Code</th>
                    <th className="py-2.5 px-4">Subject Title</th>
                    <th className="py-2.5 px-4">Instructor</th>
                    <th className="py-2.5 px-3 text-center">Classes Held</th>
                    <th className="py-2.5 px-3 text-center">Attended</th>
                    <th className="py-2.5 px-3 text-center">Percentage</th>
                    <th className="py-2.5 px-4 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {attendanceList.map((item) => {
                    const isShort = item.percentage < 75;
                    return (
                      <tr key={item.subject_code} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 px-4 font-mono font-semibold text-blue-900">
                          {item.subject_code}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-900">
                          {item.subject_name}
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {item.faculty_name}
                        </td>
                        <td className="py-3 px-3 text-center font-mono text-slate-600">
                          {item.total_classes}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-semibold text-slate-900">
                          {item.attended_classes}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold">
                          <span className={isShort ? 'text-red-700' : 'text-slate-900'}>
                            {item.percentage.toFixed(1)}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          {isShort ? (
                            <span className="text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                              Shortage
                            </span>
                          ) : (
                            <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                              Eligible
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Staff Session Roll Call Register */}
      {activeTab === 'REGISTER' && isStaff && (
        <form onSubmit={handleSaveRegister} className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4 space-y-3">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Class Session Parameters
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Subject</label>
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                >
                  <option value="22CS61">22CS61 - Distributed Systems & Cloud Computing</option>
                  <option value="22CS62">22CS62 - Compiler Design & Automata Theory</option>
                  <option value="22CS63">22CS63 - Information & Network Security</option>
                  <option value="22CSL67">22CSL67 - Cloud Computing & DevOps Lab</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Session Date</label>
                <input
                  type="date"
                  value={sessionDate}
                  onChange={(e) => setSessionDate(e.target.value)}
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Period / Slot</label>
                <input
                  type="text"
                  value={sessionTime}
                  onChange={(e) => setSessionTime(e.target.value)}
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-4">USN / Roll No</th>
                  <th className="py-2.5 px-4">Student Name</th>
                  <th className="py-2.5 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {studentRolls.map(student => (
                  <tr key={student.student_id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-4 font-mono font-medium text-slate-900">
                      {student.student_usn}
                    </td>
                    <td className="py-2.5 px-4 text-slate-800">
                      {student.student_name}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <div className="inline-flex rounded-md border border-slate-200 p-0.5 bg-slate-50">
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(student.student_id, 'PRESENT')}
                          className={`px-3 py-1 text-xs font-semibold rounded ${
                            student.status === 'PRESENT'
                              ? 'bg-emerald-700 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Present
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(student.student_id, 'ABSENT')}
                          className={`px-3 py-1 text-xs font-semibold rounded ${
                            student.status === 'ABSENT'
                              ? 'bg-red-700 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Absent
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(student.student_id, 'LATE')}
                          className={`px-3 py-1 text-xs font-semibold rounded ${
                            student.status === 'LATE'
                              ? 'bg-amber-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Late
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-900 text-white text-xs font-semibold rounded-md shadow-xs hover:bg-blue-800 disabled:opacity-50 transition-colors"
            >
              <Save className="h-4 w-4" />
              {isSubmitting ? 'Recording...' : 'Submit Session Attendance'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
