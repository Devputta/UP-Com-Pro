import { useEffect, useState } from 'react';
import { LeaveApplication, LeaveType, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { Plus, CheckCircle2, Clock, Calendar, MessageSquare, AlertCircle } from 'lucide-react';

interface ERPLeaveViewProps {
  currentUser: UserProfile;
}

export function ERPLeaveView({ currentUser }: ERPLeaveViewProps) {
  const [leaves, setLeaves] = useState<LeaveApplication[]>([]);
  const [loading, setLoading] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [selectedLeave, setSelectedLeave] = useState<LeaveApplication | null>(null);
  const [reviewComments, setReviewComments] = useState('');
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Form State
  const [leaveType, setLeaveType] = useState<LeaveType>('MEDICAL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isStaff = currentUser.role !== 'STUDENT';

  const fetchLeaves = async () => {
    setLoading(true);
    try {
      const res = await api.getLeaveApplications();
      setLeaves(res.leaves);
    } catch (err) {
      console.error('Failed to load leaves:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaves();
  }, [currentUser.id]);

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setActionSuccess(null);
    try {
      const start = new Date(startDate).getTime();
      const end = new Date(endDate).getTime();
      const diffDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);

      await api.applyLeave({
        leave_type: leaveType,
        start_date: startDate,
        end_date: endDate,
        total_days: diffDays,
        reason
      });

      setShowApplyModal(false);
      setStartDate('');
      setEndDate('');
      setReason('');
      setActionSuccess('Leave application submitted to the department head for review.');
      setTimeout(() => setActionSuccess(null), 5000);
      fetchLeaves();
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReview = async (status: 'APPROVED' | 'REJECTED') => {
    if (!selectedLeave) return;
    try {
      await api.reviewLeave(selectedLeave.id, status, reviewComments);
      setSelectedLeave(null);
      setReviewComments('');
      setActionSuccess(`Leave application ${status.toLowerCase()}.`);
      setTimeout(() => setActionSuccess(null), 5000);
      fetchLeaves();
    } catch (err: any) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Student Leave Management</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Submit absence applications for medical recuperation, approved on-duty activities, or personal leaves.
          </p>
        </div>

        <button
          onClick={() => setShowApplyModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 text-white rounded text-xs font-semibold hover:bg-blue-800 transition-colors shrink-0"
        >
          <Plus className="h-4 w-4" />
          Apply for Leave
        </button>
      </div>

      {actionSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-md p-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Table of Leave Applications */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-4">Application ID</th>
                <th className="py-2.5 px-4">Student</th>
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4">Dates</th>
                <th className="py-2.5 px-4">Days</th>
                <th className="py-2.5 px-4">Reason</th>
                <th className="py-2.5 px-4">Status</th>
                {isStaff && <th className="py-2.5 px-4 text-right">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {leaves.map((item) => {
                const isApproved = item.status === 'APPROVED';
                const isPending = item.status === 'PENDING';
                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">
                      {item.id}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{item.student_name}</div>
                      <div className="font-mono text-[11px] text-slate-500">{item.student_usn || '—'}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-700">
                      {item.leave_type.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {item.start_date} to {item.end_date}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium">
                      {item.total_days}
                    </td>
                    <td className="py-3 px-4 text-slate-700 max-w-xs truncate" title={item.reason}>
                      {item.reason}
                    </td>
                    <td className="py-3 px-4">
                      {isApproved ? (
                        <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                          Approved
                        </span>
                      ) : isPending ? (
                        <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                          Pending
                        </span>
                      ) : (
                        <span className="text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                          Rejected
                        </span>
                      )}
                    </td>
                    {isStaff && (
                      <td className="py-3 px-4 text-right">
                        {isPending && (
                          <button
                            onClick={() => setSelectedLeave(item)}
                            className="text-xs text-blue-900 font-semibold hover:underline"
                          >
                            Review
                          </button>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>

          {leaves.length === 0 && !loading && (
            <div className="py-8 text-center text-xs text-slate-500">
              No leave records found.
            </div>
          )}
        </div>
      </div>

      {/* Apply Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Submit Leave Application</h2>
              <button onClick={() => setShowApplyModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleApply} className="p-5 space-y-3.5">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Leave Category</label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                >
                  <option value="MEDICAL">Medical Leave (Doctor Certified)</option>
                  <option value="ON_DUTY">On-Duty Leave (Collegiate Representation / Hackathon)</option>
                  <option value="PERSONAL">Personal / Family Emergency</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Reason & Remarks</label>
                <textarea
                  rows={3}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Detail the cause of absence for department review."
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-blue-900 text-white rounded font-semibold hover:bg-blue-800 disabled:opacity-50"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {selectedLeave && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Review Leave Application</h2>
              <button onClick={() => setSelectedLeave(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <div className="p-5 space-y-3">
              <div className="bg-slate-50 p-3 rounded border border-slate-200 space-y-1">
                <div className="font-bold text-slate-900">{selectedLeave.student_name} ({selectedLeave.student_usn})</div>
                <div className="text-slate-600">Period: {selectedLeave.start_date} to {selectedLeave.end_date} ({selectedLeave.total_days} days)</div>
                <div className="text-slate-800 italic mt-1">"{selectedLeave.reason}"</div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Approval Comments</label>
                <textarea
                  rows={2}
                  value={reviewComments}
                  onChange={(e) => setReviewComments(e.target.value)}
                  placeholder="Optional review remarks"
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  onClick={() => handleReview('REJECTED')}
                  className="px-3 py-1.5 bg-red-700 text-white rounded font-semibold hover:bg-red-800"
                >
                  Reject
                </button>
                <button
                  onClick={() => handleReview('APPROVED')}
                  className="px-4 py-1.5 bg-emerald-700 text-white rounded font-semibold hover:bg-emerald-800"
                >
                  Approve
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
