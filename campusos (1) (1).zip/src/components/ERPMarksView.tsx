import { useEffect, useState } from 'react';
import { InternalMarksRecord, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { Printer, CheckCircle2 } from 'lucide-react';

interface ERPMarksViewProps {
  currentUser: UserProfile;
}

export function ERPMarksView({ currentUser }: ERPMarksViewProps) {
  const [marks, setMarks] = useState<InternalMarksRecord[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadMarks() {
      setLoading(true);
      try {
        const res = await api.getInternalMarks(currentUser.id);
        setMarks(res.marks);
      } catch (err) {
        console.error('Failed to load marks:', err);
      } finally {
        setLoading(false);
      }
    }
    loadMarks();
  }, [currentUser.id]);

  const totalScored = marks.reduce((acc, curr) => acc + curr.total_internal, 0);
  const totalPossible = marks.reduce((acc, curr) => acc + curr.max_marks, 0);
  const percentage = totalPossible > 0 ? ((totalScored / totalPossible) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Continuous Internal Evaluation (CIE) Marks</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Academic Year 2026–27 · Semester {currentUser.semester || 6} · Department of {currentUser.department_name}
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-300 rounded text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 transition-colors shrink-0 print:hidden"
        >
          <Printer className="h-4 w-4" />
          Print Statement
        </button>
      </div>

      {/* Summary Record Strip */}
      <div className="bg-white border border-slate-200 rounded-lg p-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
          <div className="sm:pr-4 space-y-1">
            <span className="text-slate-500 uppercase tracking-wider text-[11px] block">Cumulative CIE Score</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900">{percentage}%</span>
              <span className="text-slate-500 font-mono">({totalScored} / {totalPossible} marks)</span>
            </div>
          </div>

          <div className="sm:px-4 pt-3 sm:pt-0 space-y-1">
            <span className="text-slate-500 uppercase tracking-wider text-[11px] block">Internal Result Status</span>
            <span className="inline-flex items-center gap-1 text-sm font-bold text-emerald-700">
              <CheckCircle2 className="h-4 w-4" /> Cleared (All {marks.length} Subjects)
            </span>
            <span className="text-[11px] text-slate-500 block">Eligible for Semester End Examination (SEE)</span>
          </div>

          <div className="sm:pl-4 pt-3 sm:pt-0 space-y-1">
            <span className="text-slate-500 uppercase tracking-wider text-[11px] block">Provisional Assessment Grade</span>
            <div className="text-sm font-bold text-blue-900">
              {Number(percentage) >= 90 ? 'Grade O (Outstanding)' : Number(percentage) >= 80 ? 'Grade A+ (Excellent)' : 'Grade A (Very Good)'}
            </div>
          </div>
        </div>
      </div>

      {/* Marks Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-4">Subject Code</th>
                <th className="py-2.5 px-4">Subject Title</th>
                <th className="py-2.5 px-3 text-center">Test 1 (/30)</th>
                <th className="py-2.5 px-3 text-center">Test 2 (/30)</th>
                <th className="py-2.5 px-3 text-center">Assignment (/20)</th>
                <th className="py-2.5 px-3 text-center font-bold">Total Internal (/50)</th>
                <th className="py-2.5 px-3 text-center">%</th>
                <th className="py-2.5 px-4 text-right">Grade Point</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {marks.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-bold text-blue-900 font-mono">
                    {row.subject_code}
                  </td>
                  <td className="py-3 px-4 font-sans font-medium text-slate-900">
                    {row.subject_name}
                  </td>
                  <td className="py-3 px-3 text-center text-slate-700">
                    {row.test1_marks}
                  </td>
                  <td className="py-3 px-3 text-center text-slate-700">
                    {row.test2_marks}
                  </td>
                  <td className="py-3 px-3 text-center text-slate-700">
                    {row.assignment_marks}
                  </td>
                  <td className="py-3 px-3 text-center font-bold text-slate-900 text-sm">
                    {row.total_internal}
                  </td>
                  <td className="py-3 px-3 text-center font-bold text-slate-900">
                    {row.percentage}%
                  </td>
                  <td className="py-3 px-4 text-right font-sans font-semibold text-slate-800">
                    {row.grade_point}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-200 pt-3">
        <span>Verified by Head of Department & Continuous Internal Assessment Cell.</span>
        <span className="font-mono">Office Record ID: CIE-2026-6S-CSE</span>
      </div>
    </div>
  );
}
