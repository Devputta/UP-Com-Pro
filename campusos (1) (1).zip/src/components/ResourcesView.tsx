import { useEffect, useState } from 'react';
import { AcademicResource, Department, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { Download, Plus, Search, X, FileText, CheckCircle2 } from 'lucide-react';

interface ResourcesViewProps {
  departments: Department[];
  currentUser: UserProfile;
}

export function ResourcesView({ departments, currentUser }: ResourcesViewProps) {
  const [resources, setResources] = useState<AcademicResource[]>([]);
  const [selectedDeptId, setSelectedDeptId] = useState<string>(currentUser.department_id || 'dept-cse');
  const [selectedSemester, setSelectedSemester] = useState<number>(currentUser.semester || 6);
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newType, setNewType] = useState<AcademicResource['resource_type']>('LECTURE_NOTES');
  const [newSubjectCode, setNewSubjectCode] = useState('22CS61');
  const [newFileName, setNewFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canUpload = ['FACULTY', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);

  const fetchResources = async () => {
    setLoading(true);
    try {
      const res = await api.getResources(selectedDeptId, selectedSemester);
      setResources(res.resources);
    } catch (err) {
      console.error('Failed to load resources:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResources();
  }, [selectedDeptId, selectedSemester]);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await api.createResource({
        title: newTitle,
        description: newDesc,
        resource_type: newType,
        department_id: selectedDeptId,
        semester: selectedSemester,
        subject_code: newSubjectCode,
        file_name: newFileName || `${newSubjectCode}_Document.pdf`,
        file_size: '3.4 MB'
      });
      setShowUploadModal(false);
      setNewTitle('');
      setNewDesc('');
      setNewFileName('');
      fetchResources();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = (resource: AcademicResource) => {
    setDownloadSuccess(`Downloaded "${resource.file_name}"`);
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  const filteredResources = resources.filter(res => {
    if (selectedType !== 'ALL' && res.resource_type !== selectedType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = res.title.toLowerCase().includes(q);
      const matchCode = res.subject_code.toLowerCase().includes(q);
      const matchDesc = res.description.toLowerCase().includes(q);
      const matchAuthor = res.uploaded_by.toLowerCase().includes(q);
      if (!matchTitle && !matchCode && !matchDesc && !matchAuthor) return false;
    }
    return true;
  });

  const types = [
    { label: 'All', value: 'ALL' },
    { label: 'Syllabus & Schemes', value: 'SYLLABUS' },
    { label: 'Lecture Notes', value: 'LECTURE_NOTES' },
    { label: 'Lab Manuals', value: 'LAB_MANUAL' },
    { label: 'Exam Prep & Q-Papers', value: 'EXAM_PREP' }
  ];

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Course Resources & Syllabus</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Official department curriculum schemes, laboratory manuals, and professor lecture notes.
          </p>
        </div>

        {canUpload && (
          <button
            onClick={() => setShowUploadModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 text-white rounded text-xs font-semibold hover:bg-blue-800 transition-colors shrink-0"
          >
            <Plus className="h-4 w-4" />
            Upload Document
          </button>
        )}
      </div>

      {downloadSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-md p-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 sm:p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by subject code (e.g. 22CS61), title, or instructor..."
              className="w-full pl-9 pr-8 py-1.5 border border-slate-300 rounded text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-900"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={selectedDeptId}
              onChange={(e) => setSelectedDeptId(e.target.value)}
              className="border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-blue-900"
            >
              {departments.map(d => (
                <option key={d.id} value={d.id}>{d.code}</option>
              ))}
            </select>

            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(Number(e.target.value))}
              className="border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-blue-900"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                <option key={s} value={s}>Sem {s}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Categories */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {types.map(t => (
              <button
                key={t.value}
                onClick={() => setSelectedType(t.value)}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  selectedType === t.value
                    ? 'bg-blue-900 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <span className="text-slate-500 text-[11px] hidden sm:inline">
            {filteredResources.length} documents available
          </span>
        </div>
      </div>

      {/* Table of Resources */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-4">Subject Code</th>
                <th className="py-2.5 px-4">Document Title</th>
                <th className="py-2.5 px-4">Type</th>
                <th className="py-2.5 px-4">Uploaded By</th>
                <th className="py-2.5 px-4">Size</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredResources.map((res) => (
                <tr key={res.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-blue-900">
                    {res.subject_code}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{res.title}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{res.description}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-700 font-medium">
                    {res.resource_type.replace('_', ' ')}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {res.uploaded_by}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-500">
                    {res.file_size}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleDownload(res)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-semibold text-xs transition-colors"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredResources.length === 0 && !loading && (
            <div className="py-10 text-center text-xs text-slate-500">
              No course documents found for the selected filter.
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Upload Course Material</h2>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleUpload} className="p-5 space-y-3.5">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Unit 3: Log Replication and Consensus Notes"
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Subject Code *</label>
                <input
                  type="text"
                  required
                  value={newSubjectCode}
                  onChange={(e) => setNewSubjectCode(e.target.value)}
                  placeholder="e.g. 22CS61"
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 font-mono focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Resource Category</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                >
                  <option value="SYLLABUS">Syllabus & Scheme</option>
                  <option value="LECTURE_NOTES">Lecture Slides / Notes</option>
                  <option value="LAB_MANUAL">Laboratory Manual</option>
                  <option value="EXAM_PREP">Exam Prep & Model Papers</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Brief Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Topics covered."
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-blue-900 text-white rounded font-semibold hover:bg-blue-800 disabled:opacity-50"
                >
                  {isSubmitting ? 'Uploading...' : 'Publish Document'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
