import { useEffect, useState } from 'react';
import { AcademicScheduleItem, Department, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { Clock, MapPin, User } from 'lucide-react';

interface ScheduleViewProps {
  departments: Department[];
  currentUser: UserProfile;
}

export function ScheduleView({ departments, currentUser }: ScheduleViewProps) {
  const [selectedDeptId, setSelectedDeptId] = useState<string>(currentUser.department_id || 'dept-cse');
  const [selectedSemester, setSelectedSemester] = useState<number>(currentUser.semester || 6);
  const [selectedDay, setSelectedDay] = useState<string>('Monday');
  const [scheduleItems, setScheduleItems] = useState<AcademicScheduleItem[]>([]);
  const [loading, setLoading] = useState(false);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  useEffect(() => {
    async function loadSchedule() {
      setLoading(true);
      try {
        const res = await api.getSchedule(selectedDeptId, selectedSemester);
        setScheduleItems(res.schedule);
      } catch (err) {
        console.error('Failed to load academic schedule:', err);
      } finally {
        setLoading(false);
      }
    }
    loadSchedule();
  }, [selectedDeptId, selectedSemester]);

  const currentDayItems = scheduleItems.filter(s => s.day_of_week === selectedDay);

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Class Timetable & Schedule</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Academic Year 2026–27 · Lecture periods, laboratory slots, and room allocations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDeptId}
            onChange={(e) => setSelectedDeptId(e.target.value)}
            className="border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-blue-900"
          >
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
            ))}
          </select>

          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(Number(e.target.value))}
            className="border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-blue-900"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8].map(sem => (
              <option key={sem} value={sem}>Semester {sem}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Day Selector */}
      <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 pb-2 text-xs">
        {days.map(d => (
          <button
            key={d}
            onClick={() => setSelectedDay(d)}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              selectedDay === d
                ? 'bg-blue-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Schedule Items Table / Cards */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-4">Period / Time</th>
                <th className="py-2.5 px-4">Subject Code</th>
                <th className="py-2.5 px-4">Subject Title</th>
                <th className="py-2.5 px-4">Room / Lab</th>
                <th className="py-2.5 px-4">Faculty In-Charge</th>
                <th className="py-2.5 px-4 text-center">Section</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {currentDayItems.map((item, idx) => (
                <tr key={item.id || idx} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-mono font-medium text-slate-900 whitespace-nowrap">
                    {item.start_time} - {item.end_time}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-blue-900">
                    {item.subject_code}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-900">
                    {item.subject_name}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700">
                    {item.room_no}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {item.faculty_name}
                  </td>
                  <td className="py-3 px-4 text-center font-semibold text-slate-700">
                    {item.section}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {currentDayItems.length === 0 && !loading && (
            <div className="py-10 text-center text-xs text-slate-500">
              No classes scheduled on {selectedDay}.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
