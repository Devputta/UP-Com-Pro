import { UserProfile, UserRole } from '../types/index.js';
import { 
  LayoutDashboard, 
  CheckSquare, 
  Calendar, 
  BarChart2, 
  BookOpen, 
  Ticket, 
  FileText, 
  LifeBuoy, 
  Bell, 
  Camera, 
  ShieldCheck,
  Building2,
  X
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  currentUser: UserProfile;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  ticketCount: number;
}

export function Sidebar({
  activeTab,
  onTabChange,
  currentUser,
  isOpenMobile,
  onCloseMobile,
  ticketCount
}: SidebarProps) {
  const isStaff = currentUser.role !== 'STUDENT';
  const isOrganizerOrAdmin = ['ORGANIZER', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);
  const isAdmin = ['DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);

  interface NavItem {
    id: string;
    label: string;
    icon: any;
    badge?: number;
  }

  interface NavSection {
    title: string | null;
    items: NavItem[];
  }

  const navSections: NavSection[] = [
    {
      title: null,
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }
      ]
    },
    {
      title: 'Academics',
      items: [
        { id: 'attendance', label: 'Attendance', icon: CheckSquare },
        { id: 'schedule', label: 'Class Timetable', icon: Calendar },
        { id: 'marks', label: 'CIE Marks', icon: BarChart2 },
        { id: 'resources', label: 'Course Resources', icon: BookOpen }
      ]
    },
    {
      title: 'Student Services',
      items: [
        { id: 'events', label: 'Events & Registration', icon: Calendar },
        { id: 'tickets', label: 'My Tickets & Passes', icon: Ticket, badge: ticketCount > 0 ? ticketCount : undefined },
        { id: 'leave', label: 'Leave Applications', icon: FileText },
        { id: 'services', label: 'Service Requests', icon: LifeBuoy }
      ]
    },
    {
      title: 'Communication',
      items: [
        { id: 'notices', label: 'Notices & Circulars', icon: Bell }
      ]
    },
    ...(isStaff || isOrganizerOrAdmin ? [
      {
        title: 'Staff / Administration',
        items: [
          ...(isStaff ? [{ id: 'register', label: 'Roll Call Register', icon: CheckSquare }] : []),
          ...(isOrganizerOrAdmin ? [{ id: 'desk', label: 'Gate QR Scanner', icon: Camera }] : []),
          ...(isAdmin ? [{ id: 'admin', label: 'Audit & Governance', icon: ShieldCheck }] : [])
        ]
      }
    ] : [])
  ];

  const handleSelect = (id: string) => {
    onTabChange(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 z-40 bg-slate-900/50 md:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 md:static ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="h-14 border-b border-slate-200 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded bg-blue-900 flex items-center justify-center text-white font-bold text-sm">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <span className="font-bold text-sm text-slate-900 leading-none block">CampusOS</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Student Information System</span>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="md:hidden text-slate-400 hover:text-slate-600 p-1"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5 text-xs">
          {navSections.map((sec, idx) => (
            <div key={idx} className="space-y-1">
              {sec.title && (
                <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  {sec.title}
                </div>
              )}
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelect(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-md font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-900 text-white font-semibold shadow-xs'
                        : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                        isActive ? 'bg-blue-800 text-white' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User affiliation footer */}
        <div className="border-t border-slate-200 p-3 bg-slate-50 text-[11px] text-slate-600">
          <div className="font-semibold text-slate-900 truncate">{currentUser.full_name}</div>
          <div className="text-slate-500 truncate">{currentUser.department_name}</div>
          {currentUser.student_id && (
            <div className="font-mono text-slate-500 mt-0.5">Roll: {currentUser.student_id}</div>
          )}
        </div>
      </aside>
    </>
  );
}
