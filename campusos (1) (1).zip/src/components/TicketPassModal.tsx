import { useEffect, useState } from 'react';
import { Ticket } from '../types/index.js';
import { generateTicketQrDataUrl } from '../lib/qr.js';
import { X, Printer, ShieldCheck, CheckCircle2, Clock, MapPin, Calendar, Building2 } from 'lucide-react';

interface TicketPassModalProps {
  ticket: Ticket;
  onClose: () => void;
}

export function TicketPassModal({ ticket, onClose }: TicketPassModalProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    let active = true;
    generateTicketQrDataUrl(ticket.public_ticket_id).then(url => {
      if (active) setQrDataUrl(url);
    });
    return () => { active = false; };
  }, [ticket.public_ticket_id]);

  const handlePrint = () => {
    window.print();
  };

  const isCheckedIn = ticket.status === 'CHECKED_IN';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
      <div className="flex max-h-[92vh] w-full max-w-md flex-col rounded-lg border border-slate-300 bg-white text-slate-800 shadow-xl overflow-hidden print:max-w-none print:border-none print:shadow-none">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-blue-900" />
            <span className="text-xs font-semibold tracking-wide text-slate-900 uppercase">Official Campus Digital Pass</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 rounded px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 transition-colors"
              title="Print Pass"
            >
              <Printer className="h-3.5 w-3.5" />
              Print Pass
            </button>
            <button
              onClick={onClose}
              className="rounded p-1 text-slate-400 hover:text-slate-600 transition-colors"
              title="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Pass Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 print:p-8">
          {/* Institution Header */}
          <div className="text-center pb-3 border-b border-slate-200">
            <div className="text-[10px] font-bold uppercase tracking-widest text-blue-900 mb-0.5">
              CampusOS Digital Entry Credential
            </div>
            <h1 className="text-base font-bold text-slate-900 tracking-tight">
              University College of Engineering
            </h1>
            <p className="text-xs text-slate-500">
              Department of {ticket.department_name}
            </p>
          </div>

          {/* Event Details */}
          <div className="rounded border border-slate-200 bg-slate-50 p-3.5 space-y-2">
            <div className="text-sm font-bold text-slate-900 leading-snug">
              {ticket.event_title}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Calendar className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span>{new Date(ticket.event_start_at).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span>{new Date(ticket.event_start_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="flex items-center gap-2 sm:col-span-2">
                <MapPin className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                <span className="truncate">{ticket.event_location}</span>
              </div>
            </div>
          </div>

          {/* QR Code Presentation Area */}
          <div className="flex flex-col items-center justify-center p-4 bg-white rounded-lg border border-slate-200 shadow-xs">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="Ticket QR Code"
                className="h-44 w-44 object-contain"
              />
            ) : (
              <div className="h-44 w-44 flex items-center justify-center bg-slate-50 rounded text-slate-400 text-xs">
                Generating QR...
              </div>
            )}

            <div className="mt-2 text-center">
              <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-500 block">
                Verification Reference ID
              </span>
              <span className="font-mono text-sm font-bold text-slate-900 tracking-wider">
                {ticket.public_ticket_id}
              </span>
            </div>
          </div>

          {/* Status Badge Banner */}
          <div className="flex items-center justify-between p-2.5 rounded border border-slate-200 bg-slate-50 text-xs">
            <span className="text-slate-600 font-medium">Entrance Status:</span>
            {isCheckedIn ? (
              <span className="flex items-center gap-1.5 font-semibold text-emerald-700">
                <CheckCircle2 className="h-4 w-4" />
                Checked In ({ticket.checked_in_at ? new Date(ticket.checked_in_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Verified'})
              </span>
            ) : (
              <span className="flex items-center gap-1.5 font-semibold text-blue-900">
                <ShieldCheck className="h-4 w-4" />
                Confirmed & Ready for Entry
              </span>
            )}
          </div>

          {/* Attendee Info Table */}
          <div className="space-y-1.5 text-xs border-t border-slate-200 pt-3">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Student Name:</span>
              <span className="font-semibold text-slate-900">{ticket.student_name}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">USN / Roll Number:</span>
              <span className="font-mono text-slate-900">{ticket.student_usn || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Department:</span>
              <span className="text-slate-900">{ticket.department_name}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Issued On:</span>
              <span className="text-slate-700">{new Date(ticket.issued_at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
            </div>
          </div>

          {/* Gate instructions */}
          <p className="text-[11px] text-slate-500 leading-relaxed text-center">
            Security Notice: Present this QR credential at the campus event entrance scanner. Duplicate presentations are flagged automatically.
          </p>
        </div>
      </div>
    </div>
  );
}
