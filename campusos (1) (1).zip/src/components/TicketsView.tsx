import { useState } from 'react';
import { Ticket, EventRegistration } from '../types/index.js';
import { api } from '../lib/api.js';
import { QrCode, CheckCircle2, AlertCircle, Calendar, Clock, MapPin, Printer } from 'lucide-react';

interface TicketsViewProps {
  tickets: Ticket[];
  registrations: EventRegistration[];
  onViewTicket: (ticket: Ticket) => void;
  onRefresh: () => void;
}

export function TicketsView({
  tickets,
  registrations,
  onViewTicket,
  onRefresh
}: TicketsViewProps) {
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [confirmCancelId, setConfirmCancelId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const activeTickets = tickets.filter(t => t.status !== 'VOID');

  const handleCancelRegistration = async (registrationId: string) => {
    setCancellingId(registrationId);
    setMessage(null);
    try {
      const res = await api.cancelRegistration(registrationId);
      if (res.success) {
        setMessage({ type: 'success', text: 'Registration cancelled and entry pass voided.' });
        setConfirmCancelId(null);
        onRefresh();
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to cancel registration.' });
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">My Registered Event Passes</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Official digital passes issued for campus events. Present the QR code on screen or printed at entrance security.
          </p>
        </div>
      </div>

      {message && (
        <div
          className={`flex items-center gap-2 rounded-md border p-3 text-xs ${
            message.type === 'success'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
              : 'border-red-200 bg-red-50 text-red-900'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          ) : (
            <AlertCircle className="h-4 w-4 text-red-700 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Tickets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activeTickets.map(ticket => {
          const isCheckedIn = ticket.status === 'CHECKED_IN';

          return (
            <div
              key={ticket.id}
              className="bg-white border border-slate-200 rounded-lg p-4 flex flex-col justify-between shadow-2xs hover:border-slate-300 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <span className="font-mono text-xs font-bold text-blue-900">
                    {ticket.public_ticket_id}
                  </span>

                  {isCheckedIn ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded">
                      <CheckCircle2 className="h-3 w-3" /> Checked In
                    </span>
                  ) : (
                    <span className="text-[11px] font-semibold text-blue-900 bg-blue-50 border border-blue-200 px-1.5 py-0.2 rounded">
                      Valid Pass
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {ticket.event_title}
                  </h3>
                  <div className="mt-2 space-y-1 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span>{new Date(ticket.event_start_at).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0 ml-1" />
                      <span>{new Date(ticket.event_start_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{ticket.event_location}</span>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded border border-slate-100 space-y-0.5">
                  <div>Attendee: <strong className="text-slate-800">{ticket.student_name}</strong></div>
                  <div>Roll No: <span className="font-mono text-slate-700">{ticket.student_usn || '—'}</span></div>
                  <div>Department: <span className="text-slate-700">{ticket.department_name}</span></div>
                  {isCheckedIn && ticket.checked_in_at && (
                    <div className="text-emerald-700 font-medium pt-1 border-t border-slate-200">
                      Admitted: {new Date(ticket.checked_in_at).toLocaleTimeString()}
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                <button
                  onClick={() => onViewTicket(ticket)}
                  className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 transition-colors shadow-xs"
                >
                  <QrCode className="h-3.5 w-3.5" />
                  View & Print QR Pass
                </button>

                {!isCheckedIn && (
                  <div>
                    {confirmCancelId === ticket.registration_id ? (
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => handleCancelRegistration(ticket.registration_id)}
                          disabled={cancellingId === ticket.registration_id}
                          className="flex-1 py-1 rounded bg-red-700 text-white text-[11px] font-semibold hover:bg-red-800"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setConfirmCancelId(null)}
                          className="px-3 py-1 rounded border border-slate-300 text-slate-600 text-[11px]"
                        >
                          Keep
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmCancelId(ticket.registration_id)}
                        className="w-full text-center text-[11px] text-slate-500 hover:text-red-700 py-0.5"
                      >
                        Cancel Registration
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {activeTickets.length === 0 && (
        <div className="py-12 text-center text-xs text-slate-500 bg-white border border-slate-200 rounded-lg">
          No registered event passes. Browse upcoming events to register and receive entry passes.
        </div>
      )}
    </div>
  );
}
