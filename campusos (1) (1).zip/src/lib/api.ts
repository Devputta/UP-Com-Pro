import {
  UserProfile,
  Department,
  Notice,
  CampusEvent,
  EventRegistration,
  Ticket,
  AcademicScheduleItem,
  AcademicResource,
  CampusServiceRequest,
  AuditLog,
  CheckInResponse,
  SubjectAttendanceSummary,
  AttendanceRecord,
  LeaveApplication,
  InternalMarksRecord,
  CourseSubject,
  PasswordResetRequest
} from '../types/index.js';

class ApiClient {
  private activeUserId: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.activeUserId = localStorage.getItem('campus_os_user_id');
    }
  }

  setActiveUser(userId: string | null) {
    this.activeUserId = userId;
    if (typeof window !== 'undefined') {
      if (userId) {
        localStorage.setItem('campus_os_user_id', userId);
      } else {
        localStorage.removeItem('campus_os_user_id');
      }
    }
  }

  getActiveUserId(): string | null {
    if (this.activeUserId) return this.activeUserId;
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('campus_os_user_id');
      if (saved) {
        this.activeUserId = saved;
        return saved;
      }
    }
    return null;
  }

  private async fetchJson<T>(url: string, options: RequestInit = {}): Promise<T> {
    const headers = new Headers(options.headers || {});
    const uid = this.getActiveUserId();
    if (uid) {
      headers.set('x-user-id', uid);
    }
    if (options.body && typeof options.body === 'string' && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }

    const response = await fetch(url, { ...options, headers });
    const data = await response.json();

    if (!response.ok) {
      const msg = data?.error?.message || data?.message || `Request failed with status ${response.status}`;
      const err = new Error(msg);
      (err as any).data = data;
      (err as any).status = response.status;
      throw err;
    }
    return data;
  }

  // Auth
  async login(credentials: { email?: string; password?: string; userId?: string }): Promise<{ success: boolean; user: UserProfile }> {
    const res = await this.fetchJson<{ success: boolean; user: UserProfile }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
    if (res.user) {
      this.setActiveUser(res.user.id);
    }
    return res;
  }

  async logout(): Promise<{ success: boolean }> {
    try {
      await this.fetchJson<{ success: boolean }>('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors on logout
    }
    this.setActiveUser(null);
    return { success: true };
  }

  async getMe(): Promise<{ user: UserProfile | null }> {
    const uid = this.getActiveUserId();
    if (!uid) {
      return { user: null };
    }
    return this.fetchJson<{ user: UserProfile | null }>('/api/me');
  }

  async getAllUsers(): Promise<{ users: UserProfile[] }> {
    return this.fetchJson<{ users: UserProfile[] }>('/api/auth/users');
  }

  async switchUser(userId: string): Promise<{ user: UserProfile }> {
    this.setActiveUser(userId);
    return this.fetchJson<{ user: UserProfile }>('/api/auth/switch-user', {
      method: 'POST',
      body: JSON.stringify({ userId })
    });
  }

  async forgotPassword(data: {
    full_name: string;
    email: string;
    student_id_or_staff_id?: string;
    department_name: string;
    semester?: number;
    role: 'STUDENT' | 'FACULTY' | 'ADMIN';
    reason?: string;
  }): Promise<{ success: boolean; request: PasswordResetRequest; message: string }> {
    return this.fetchJson('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async changePassword(data: {
    currentPassword: string;
    newPassword: string;
  }): Promise<{ success: boolean; message: string }> {
    return this.fetchJson('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async getPasswordRequests(): Promise<{ requests: PasswordResetRequest[] }> {
    return this.fetchJson<{ requests: PasswordResetRequest[] }>('/api/admin/password-requests');
  }

  async dispatchPassword(requestId: string): Promise<{
    success: boolean;
    generated_password: string;
    request: PasswordResetRequest;
    targetUser?: UserProfile;
    message: string;
  }> {
    return this.fetchJson(`/api/admin/password-requests/${requestId}/dispatch`, {
      method: 'POST'
    });
  }

  // Departments
  async getDepartments(): Promise<{ departments: Department[] }> {
    return this.fetchJson<{ departments: Department[] }>('/api/departments');
  }

  // Notices
  async getNotices(): Promise<{ notices: Notice[] }> {
    return this.fetchJson<{ notices: Notice[] }>('/api/notices');
  }

  async createNotice(data: Partial<Notice>): Promise<{ notice: Notice }> {
    return this.fetchJson<{ notice: Notice }>('/api/notices', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Events
  async getEvents(): Promise<{ events: CampusEvent[] }> {
    return this.fetchJson<{ events: CampusEvent[] }>('/api/events');
  }

  async getEvent(id: string): Promise<{ event: CampusEvent }> {
    return this.fetchJson<{ event: CampusEvent }>(`/api/events/${id}`);
  }

  async createEvent(data: Partial<CampusEvent>): Promise<{ event: CampusEvent }> {
    return this.fetchJson<{ event: CampusEvent }>('/api/events', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async publishEvent(id: string): Promise<{ event: CampusEvent }> {
    return this.fetchJson<{ event: CampusEvent }>(`/api/events/${id}/publish`, {
      method: 'POST'
    });
  }

  async closeEvent(id: string): Promise<{ event: CampusEvent }> {
    return this.fetchJson<{ event: CampusEvent }>(`/api/events/${id}/close`, {
      method: 'POST'
    });
  }

  // Registrations & Tickets
  async registerForEvent(eventId: string): Promise<{ success: boolean; registration: EventRegistration; ticket: Ticket }> {
    return this.fetchJson<{ success: boolean; registration: EventRegistration; ticket: Ticket }>(
      `/api/events/${eventId}/register`,
      { method: 'POST' }
    );
  }

  async cancelRegistration(regId: string): Promise<{ success: boolean }> {
    return this.fetchJson<{ success: boolean }>(`/api/registrations/${regId}/cancel`, {
      method: 'POST'
    });
  }

  async getMyRegistrations(): Promise<{ registrations: EventRegistration[] }> {
    return this.fetchJson<{ registrations: EventRegistration[] }>('/api/my-registrations');
  }

  async getMyTickets(): Promise<{ tickets: Ticket[] }> {
    return this.fetchJson<{ tickets: Ticket[] }>('/api/my-tickets');
  }

  async lookupTicket(ticketId: string): Promise<{ ticket: Ticket }> {
    return this.fetchJson<{ ticket: Ticket }>(`/api/tickets/lookup?id=${encodeURIComponent(ticketId)}`);
  }

  // Check-In (Atomic verification)
  async performCheckIn(ticketId: string, eventId: string, deviceRef?: string): Promise<CheckInResponse> {
    const headers = new Headers();
    headers.set('Content-Type', 'application/json');
    const uid = this.getActiveUserId();
    if (uid) {
      headers.set('x-user-id', uid);
    }

    const res = await fetch('/api/checkins', {
      method: 'POST',
      headers,
      body: JSON.stringify({ ticketId, eventId, deviceRef })
    });

    const data: CheckInResponse = await res.json();
    return data;
  }

  // Attendees & CSV Export
  async getAttendees(eventId: string): Promise<{
    event_id: string;
    event_title: string;
    total_registered: number;
    total_checked_in: number;
    capacity: number;
    attendees: Array<{
      registration_id: string;
      student_id: string;
      student_name: string;
      student_usn?: string;
      student_email: string;
      department_name: string;
      year?: number;
      semester?: number;
      registration_status: string;
      registered_at: string;
      checked_in_at?: string;
      public_ticket_id?: string;
      ticket_status?: string;
    }>;
  }> {
    return this.fetchJson(`/api/events/${eventId}/attendees`);
  }

  getAttendanceExportUrl(eventId: string): string {
    return `/api/events/${eventId}/attendance/export`;
  }

  // Academic Schedule
  async getSchedule(departmentId?: string, semester?: number): Promise<{ schedule: AcademicScheduleItem[] }> {
    const query = new URLSearchParams();
    if (departmentId) query.set('department_id', departmentId);
    if (semester) query.set('semester', String(semester));
    return this.fetchJson<{ schedule: AcademicScheduleItem[] }>(`/api/academic/schedule?${query.toString()}`);
  }

  // Academic Resources
  async getResources(departmentId?: string, semester?: number): Promise<{ resources: AcademicResource[] }> {
    const query = new URLSearchParams();
    if (departmentId) query.set('department_id', departmentId);
    if (semester) query.set('semester', String(semester));
    return this.fetchJson<{ resources: AcademicResource[] }>(`/api/academic/resources?${query.toString()}`);
  }

  async createResource(data: Partial<AcademicResource>): Promise<{ resource: AcademicResource }> {
    return this.fetchJson<{ resource: AcademicResource }>('/api/academic/resources', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Service Requests
  async getServiceRequests(): Promise<{ requests: CampusServiceRequest[] }> {
    return this.fetchJson<{ requests: CampusServiceRequest[] }>('/api/services/requests');
  }

  async createServiceRequest(data: Partial<CampusServiceRequest>): Promise<{ request: CampusServiceRequest }> {
    return this.fetchJson<{ request: CampusServiceRequest }>('/api/services/requests', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async updateServiceRequest(id: string, updates: Partial<CampusServiceRequest>): Promise<{ request: CampusServiceRequest }> {
    return this.fetchJson<{ request: CampusServiceRequest }>(`/api/services/requests/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates)
    });
  }

  // Admin & Audit
  async getAuditLogs(): Promise<{ logs: AuditLog[] }> {
    return this.fetchJson<{ logs: AuditLog[] }>('/api/audit-logs');
  }

  async getReportsOverview(): Promise<{
    metrics: {
      total_events: number;
      active_events: number;
      total_registrations: number;
      total_checkins: number;
      attendance_rate: number;
      registered_students: number;
    };
    department_summary: Array<{
      code: string;
      name: string;
      student_count: number;
      faculty_count: number;
    }>;
  }> {
    return this.fetchJson('/api/reports/overview');
  }

  // --- College ERP Methods (Ansarimajid/College-ERP Inspired) ---

  // 1. Attendance
  async getStudentAttendance(studentId?: string): Promise<{ attendance: SubjectAttendanceSummary[] }> {
    const q = studentId ? `?student_id=${encodeURIComponent(studentId)}` : '';
    return this.fetchJson<{ attendance: SubjectAttendanceSummary[] }>(`/api/erp/attendance${q}`);
  }

  async markAttendance(records: Omit<AttendanceRecord, 'id'>[]): Promise<{ success: boolean; count: number }> {
    return this.fetchJson<{ success: boolean; count: number }>('/api/erp/attendance/mark', {
      method: 'POST',
      body: JSON.stringify({ records })
    });
  }

  // 2. Leave Management
  async getLeaveApplications(): Promise<{ leaves: LeaveApplication[] }> {
    return this.fetchJson<{ leaves: LeaveApplication[] }>('/api/erp/leave');
  }

  async applyLeave(data: {
    leave_type: 'MEDICAL' | 'ON_DUTY' | 'PERSONAL';
    start_date: string;
    end_date: string;
    total_days: number;
    reason: string;
  }): Promise<{ leave: LeaveApplication }> {
    return this.fetchJson<{ leave: LeaveApplication }>('/api/erp/leave/apply', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async reviewLeave(leaveId: string, status: 'APPROVED' | 'REJECTED', comments: string): Promise<{ leave: LeaveApplication }> {
    return this.fetchJson<{ leave: LeaveApplication }>(`/api/erp/leave/${leaveId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status, comments })
    });
  }

  // 3. Internal Assessment Marks
  async getInternalMarks(studentId?: string): Promise<{ marks: InternalMarksRecord[] }> {
    const q = studentId ? `?student_id=${encodeURIComponent(studentId)}` : '';
    return this.fetchJson<{ marks: InternalMarksRecord[] }>(`/api/erp/marks${q}`);
  }

  // 4. Subjects
  async getSubjects(departmentId?: string, semester?: number): Promise<{ subjects: CourseSubject[] }> {
    const q = new URLSearchParams();
    if (departmentId) q.set('department_id', departmentId);
    if (semester) q.set('semester', String(semester));
    return this.fetchJson<{ subjects: CourseSubject[] }>(`/api/erp/subjects?${q.toString()}`);
  }
}

export const api = new ApiClient();
