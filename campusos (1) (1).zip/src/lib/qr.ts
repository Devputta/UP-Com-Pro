import QRCode from 'qrcode';

export async function generateTicketQrDataUrl(publicTicketId: string): Promise<string> {
  try {
    return await QRCode.toDataURL(publicTicketId, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 260,
      color: {
        dark: '#0F172A',
        light: '#FFFFFF'
      }
    });
  } catch (err) {
    console.error('Error generating QR code:', err);
    return '';
  }
}

export async function generateTicketQrSvg(publicTicketId: string): Promise<string> {
  try {
    return await QRCode.toString(publicTicketId, {
      type: 'svg',
      errorCorrectionLevel: 'M',
      margin: 1,
      width: 220,
      color: {
        dark: '#0F172A',
        light: '#FFFFFF'
      }
    });
  } catch (err) {
    console.error('Error generating QR SVG:', err);
    return '';
  }
}
