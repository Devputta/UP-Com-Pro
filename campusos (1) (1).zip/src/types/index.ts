export type UserRole = 
  | 'STUDENT'
  | 'FACULTY'
  | 'ORGANIZER'
  | 'DEPARTMENT_ADMIN'
  | 'COLLEGE_ADMIN'
  | 'SUPER_ADMIN';

export interface UserProfile {
  id: string;
  auth_user_id: string;
  full_name: string;
  email: string;
  phone?: string;
  student_id?: string; // e.g. USN / Roll No
  department_id: string;
  department_name: string;
  year?: number;
  semester?: number;
  role: UserRole;
  status: 'ACTIVE' | 'SUSPENDED';
  password?: string;
  assigned_event_ids?: string[]; // For organizers
  created_at: string;
  updated_at: string;
}

export interface PasswordResetRequest {
  id: string;
  full_name: string;
  email: string;
  student_id_or_staff_id?: string;
  department_id?: string;
  department_name: string;
  semester?: number;
  role: 'STUDENT' | 'FACULTY' | 'ADMIN';
  reason?: string;
  requested_at: string;
  status: 'PENDING' | 'DISPATCHED';
  generated_password?: string;
  dispatched_at?: string;
  dispatched_by?: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  status: 'ACTIVE' | 'INACTIVE';
  head_of_department?: string;
  student_count: number;
  faculty_count: number;
}

export type NoticeAudience = 'ALL' | 'STUDENTS' | 'FACULTY' | 'DEPARTMENT';
export type NoticePriority = 'NORMAL' | 'URGENT' | 'ACADEMIC';

export interface Notice {
  id: string;
  title: string;
  body: string;
  audience: NoticeAudience;
  department_id?: string;
  department_name?: string;
  priority: NoticePriority;
  published_at: string;
  expires_at?: string;
  created_by: string;
  author_name: string;
  pinned?: boolean;
}

export type EventStatus = 
  | 'DRAFT'
  | 'REVIEW'
  | 'PUBLISHED'
  | 'REGISTRATION_OPEN'
  | 'REGISTRATION_CLOSED'
  | 'COMPLETED'
  | 'ARCHIVED';

export type EventCategory = 
  | 'WORKSHOP'
  | 'HACKATHON'
  | 'SYMPOSIUM'
  | 'CULTURAL'
  | 'GUEST_LECTURE'
  | 'SPORTS';

export interface CampusEvent {
  id: string;
  title: string;
  description: string;
  location: string;
  category: EventCategory;
  start_at: string;
  end_at: string;
  registration_open_at: string;
  registration_close_at: string;
  capacity: number;
  registered_count: number;
  checked_in_count: number;
  status: EventStatus;
  organizer_id: string;
  organizer_name: string;
  department_id?: string;
  department_name?: string;
  banner_color?: string;
  created_at: string;
  updated_at: string;
}

export type RegistrationStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'CHECKED_IN';

export interface EventRegistration {
  id: string;
  event_id: string;
  event_title: string;
  event_location: string;
  event_start_at: string;
  student_id: string;
  student_name: string;
  student_email: string;
  student_usn?: string;
  department_name: string;
  year?: number;
  semester?: number;
  status: RegistrationStatus;
  registered_at: string;
  cancelled_at?: string;
  checked_in_at?: string;
  checked_in_by?: string;
}

export interface Ticket {
  id: string;
  registration_id: string;
  event_id: string;
  event_title: string;
  event_location: string;
  event_start_at: string;
  student_id: string;
  student_name: string;
  student_email: string;
  student_usn?: string;
  department_name: string;
  public_ticket_id: string; // Opaque signed/random token, e.g. TKT-2026-X8F9-2A4B
  status: 'ISSUED' | 'CHECKED_IN' | 'VOID';
  issued_at: string;
  checked_in_at?: string;
  checked_in_by_name?: string;
}

export interface CheckInRecord {
  id: string;
  ticket_id: string;
  public_ticket_id: string;
  event_id: string;
  registration_id: string;
  student_name: string;
  student_usn?: string;
  department_name: string;
  checked_in_by: string;
  checked_in_by_name: string;
  checked_in_at: string;
  scanner_device_reference: string;
}

export interface AcademicScheduleItem {
  id: string;
  department_id: string;
  department_name: string;
  semester: number;
  section: string;
  day_of_week: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  start_time: string; // e.g. "09:00 AM"
  end_time: string;   // e.g. "10:00 AM"
  subject_code: string;
  subject_name: string;
  faculty_name: string;
  room_no: string;
}

export interface AcademicResource {
  id: string;
  title: string;
  description: string;
  resource_type: 'SYLLABUS' | 'LECTURE_NOTES' | 'LAB_MANUAL' | 'EXAM_PREP';
  department_id: string;
  department_name: string;
  semester: number;
  subject_code: string;
  file_name: string;
  file_size: string;
  uploaded_by: string;
  uploaded_at: string;
  download_url: string;
}

export interface CampusServiceRequest {
  id: string;
  student_id: string;
  student_name: string;
  student_email: string;
  department_name: string;
  category: 'ACADEMIC_QUERY' | 'INFRASTRUCTURE' | 'HOSTEL_MESS' | 'DOCUMENT_REQUEST' | 'LAB_EQUIPMENT';
  subject: string;
  description: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'REJECTED';
  assigned_to?: string;
  resolution_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  actor_user_id: string;
  actor_name: string;
  actor_role: UserRole;
  action: string;
  entity_type: string;
  entity_id: string;
  metadata?: Record<string, unknown>;
  ip_reference?: string;
  created_at: string;
}

export interface EmailEvent {
  id: string;
  recipient_email: string;
  recipient_name: string;
  template: 'REGISTRATION_CONFIRMED' | 'TICKET_ISSUED' | 'EVENT_CANCELLED' | 'SERVICE_UPDATE' | 'PASSWORD_RESET';
  subject: string;
  related_entity_id: string;
  status: 'SENT' | 'PENDING' | 'FAILED';
  created_at: string;
}

export interface CheckInResponse {
  success: boolean;
  code: 'SUCCESS' | 'ALREADY_CHECKED_IN' | 'INVALID_TICKET' | 'EVENT_MISMATCH' | 'UNAUTHORIZED' | 'REGISTRATION_NOT_CONFIRMED';
  message: string;
  ticket?: Ticket;
  attendee?: {
    name: string;
    student_id?: string;
    department: string;
    year?: number;
    email: string;
    checked_in_at: string;
    checked_in_by_name: string;
  };
}

// --- College ERP Types (Ansarimajid/College-ERP Inspired) ---

export interface AttendanceRecord {
  id: string;
  subject_code: string;
  subject_name: string;
  student_id: string;
  student_name: string;
  student_usn?: string;
  date: string;
  session_time: string;
  status: 'PRESENT' | 'ABSENT' | 'LATE';
  marked_by: string;
}

export interface SubjectAttendanceSummary {
  subject_code: string;
  subject_name: string;
  faculty_name: string;
  total_classes: number;
  attended_classes: number;
  percentage: number;
  status: 'ELIGIBLE' | 'SHORTAGE_WARNING';
  min_required_percentage: number;
}

export type LeaveType = 'MEDICAL' | 'ON_DUTY' | 'PERSONAL';
export type LeaveStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface LeaveApplication {
  id: string;
  student_id: string;
  student_name: string;
  student_usn?: string;
  department_name: string;
  leave_type: LeaveType;
  start_date: string;
  end_date: string;
  total_days: number;
  reason: string;
  status: LeaveStatus;
  reviewed_by?: string;
  review_comments?: string;
  created_at: string;
  updated_at: string;
}

export interface InternalMarksRecord {
  id: string;
  student_id: string;
  student_name: string;
  student_usn?: string;
  semester: number;
  subject_code: string;
  subject_name: string;
  test1_marks: number;     // out of 30
  test2_marks: number;     // out of 30
  assignment_marks: number;// out of 20
  lab_marks?: number;      // out of 20
  total_internal: number;  // out of 50 or 100
  max_marks: number;
  percentage: number;
  grade_point: string;
}

export interface CourseSubject {
  id: string;
  code: string;
  name: string;
  department_id: string;
  semester: number;
  credits: number;
  faculty_id: string;
  faculty_name: string;
  type: 'THEORY' | 'PRACTICAL';
}

