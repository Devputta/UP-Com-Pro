import React, { useState } from 'react';
import {
  Copy,
  Check,
  LogOut,
  AlertTriangle,
  Sparkles,
  Hash,
  User,
} from 'lucide-react';
import { ChannelInfo } from '../types/chat';

interface ChannelSetupProps {
  channelInfo: ChannelInfo | null;
  onJoin: (code: string, passphrase?: string, name?: string) => Promise<void>;
  onLeave: () => void;
  isLoading: boolean;
  defaultName?: string;
  myUserName?: string;
}

export const ChannelSetup: React.FC<ChannelSetupProps> = ({
  channelInfo,
  onJoin,
  onLeave,
  isLoading,
  defaultName = 'You',
  myUserName,
}) => {
  const [code, setCode] = useState('234');
  const [name, setName] = useState(myUserName || defaultName);
  const [copied, setCopied] = useState(false);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const generateRandomCode = () => {
    const random = Math.floor(100 + Math.random() * 900).toString();
    setCode(random);
    setValidationError(null);
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = code.replace(/\D/g, '').slice(0, 6);
    if (clean.length < 3) {
      setValidationError('PIN must be 3 to 6 numerical digits.');
      return;
    }
    setValidationError(null);
    onJoin(clean, undefined, name.trim() || 'You');
  };

  const handleCopy = () => {
    if (!channelInfo) return;
    const url = new URL(window.location.href);
    url.searchParams.set('channel', channelInfo.code);
    navigator.clipboard.writeText(url.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConfirmLeave = () => {
    setShowLeaveConfirm(false);
    onLeave();
  };

  // State: Connected to an active channel -> WhatsApp-style conversation bar
  if (channelInfo) {
    const isOnline = Boolean(channelInfo.peerPresent);
    const peerDisplayName = channelInfo.peerName || 'Partner';

    return (
      <div className="bg-[#151B22] dark:bg-[#151B22] bg-white border border-[#27323F] dark:border-[#27323F] border-slate-200 rounded-xl px-3 sm:px-4 py-2 shadow-lg transition-colors shrink-0 text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800">
        <div className="flex items-center justify-between gap-2.5">
          {/* Avatar + name + online/offline status */}
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Compact Avatar with status indicator */}
            <div className="relative shrink-0">
              <div
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-mono font-bold text-xs sm:text-sm text-[#0F1419] shadow-sm ${
                  isOnline
                    ? 'bg-[#F5A524]'
                    : 'bg-[#9BA3AF] dark:bg-[#9BA3AF] bg-slate-300'
                }`}
              >
                {peerDisplayName.charAt(0).toUpperCase()}
              </div>
              {/* Online / Offline status indicator */}
              <span
                className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-[#151B22] dark:ring-[#151B22] ring-white ${
                  isOnline ? 'bg-[#10B981]' : 'bg-[#6E7681] dark:bg-[#6E7681] bg-slate-400'
                }`}
                title={isOnline ? 'Online' : 'Waiting for partner'}
              />
            </div>

            {/* Conversation Name & Online Status */}
            <div className="min-w-0 flex flex-col justify-center">
              <div className="flex items-center gap-1.5">
                <span className="font-sans text-xs sm:text-sm font-semibold text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-900 truncate leading-tight">
                  {peerDisplayName}
                </span>
                {/* Clickable channel PIN badge */}
                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono font-medium text-[#F5A524] dark:text-[#F5A524] text-amber-700 bg-[#0F1419] dark:bg-[#0F1419] bg-slate-100 border border-[#27323F] dark:border-[#27323F] border-slate-300 hover:border-[#F5A524] transition-colors cursor-pointer shrink-0"
                  title="Click to copy invite link"
                >
                  <span className="text-[9px] text-[#9BA3AF] mr-0.5 uppercase">PIN</span>
                  <span>{channelInfo.code}</span>
                  {copied ? (
                    <Check className="w-2.5 h-2.5 text-[#10B981] ml-0.5" />
                  ) : (
                    <Copy className="w-2.5 h-2.5 text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-500 ml-0.5" />
                  )}
                </button>
              </div>

              {/* Status line: Online or waiting */}
              <div className="flex items-center gap-1.5 text-[11px] font-sans leading-tight mt-0.5">
                {isOnline ? (
                  <span className="text-[#10B981] font-medium flex items-center gap-1">
                    online · keys synced
                  </span>
                ) : (
                  <span className="text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-500">
                    waiting for partner to connect
                  </span>
                )}
                <span className="text-[#27323F] dark:text-[#27323F] text-slate-300">·</span>
                <span className="text-[10px] text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-500 font-mono hidden xs:inline">
                  You: {myUserName || 'You'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Action Controls: Share & Leave */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-medium bg-[#0F1419] dark:bg-[#0F1419] bg-slate-100 hover:bg-[#1B222A] dark:hover:bg-[#1B222A] hover:bg-slate-200 text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800 border border-[#27323F] dark:border-[#27323F] border-slate-300 hover:border-[#F5A524] rounded-md transition-colors cursor-pointer shadow-xs"
              title="Copy channel invite link"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#10B981]" />
                  <span className="text-[#10B981] font-semibold text-[11px]">
                    Copied!
                  </span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-500" />
                  <span className="text-[11px] hidden sm:inline">Copy link</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setShowLeaveConfirm(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-medium text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-600 hover:text-[#EF4444] hover:bg-[#1B222A] dark:hover:bg-[#1B222A] hover:bg-slate-100 border border-[#27323F] dark:border-[#27323F] border-slate-300 rounded-md transition-colors cursor-pointer"
              title="Leave channel"
            >
              <LogOut className="w-3 h-3" />
              <span className="text-[11px] hidden sm:inline">Leave</span>
            </button>
          </div>
        </div>

        {/* Leave Channel Confirmation */}
        {showLeaveConfirm && (
          <div className="mt-2 pt-2 border-t border-[#27323F] dark:border-[#27323F] border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#0F1419] dark:bg-[#0F1419] bg-slate-50 p-2 rounded-lg border border-[#27323F] dark:border-[#27323F] border-slate-200 text-xs">
            <div className="flex items-center gap-2 text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800">
              <AlertTriangle className="w-3.5 h-3.5 text-[#F5A524] shrink-0" />
              <span className="text-[11px] font-sans">
                Leave channel {channelInfo.code}? Keys will be wiped from RAM and the chat will vanish.
              </span>
            </div>
            <div className="flex items-center gap-1.5 self-end sm:self-auto font-mono">
              <button
                type="button"
                onClick={() => setShowLeaveConfirm(false)}
                className="px-2 py-0.5 text-[11px] text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-600 hover:text-[#E8E6E1] bg-[#151B22] dark:bg-[#151B22] bg-white border border-[#27323F] dark:border-[#27323F] border-slate-300 rounded"
              >
                Stay here
              </button>
              <button
                type="button"
                onClick={handleConfirmLeave}
                className="px-2 py-0.5 text-[11px] font-semibold text-white bg-[#EF4444] hover:bg-[#DC2626] rounded shadow-xs cursor-pointer"
              >
                Drop session
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // State: Pre-join -> Compact bar with clean numeric PIN input and small name input
  return (
    <div className="bg-[#151B22] dark:bg-[#151B22] bg-white border border-[#27323F] dark:border-[#27323F] border-slate-200 rounded-xl px-3 py-2 sm:px-3.5 sm:py-2.5 shadow-lg transition-colors shrink-0 text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800">
      <form onSubmit={handleJoinSubmit} className="space-y-1.5">
        <div className="flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
          {/* Small Channel Code & Small Name section */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-1 min-w-0">
            {/* PIN input */}
            <div className="relative shrink-0 w-28 sm:w-32">
              <button
                type="button"
                onClick={generateRandomCode}
                title="Roll a random PIN"
                className="absolute inset-y-0 left-0 pl-2 pr-1 flex items-center text-[#F5A524] dark:text-[#F5A524] text-amber-600 hover:text-[#E09418] cursor-pointer transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
              </button>
              <input
                id="channel-input"
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={code}
                onChange={(e) => {
                  setCode(e.target.value.replace(/\D/g, '').slice(0, 6));
                  setValidationError(null);
                }}
                placeholder="PIN (234)"
                className="w-full pl-7 pr-1.5 py-1 bg-[#0F1419] dark:bg-[#0F1419] bg-white border border-[#27323F] dark:border-[#27323F] border-slate-300 rounded-md text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800 font-mono text-xs tracking-wider font-semibold focus:outline-none focus:border-[#F5A524] transition-colors shadow-inner"
                title="Enter 3-6 digit channel PIN"
              />
            </div>

            {/* Clickable Quick Random Symbol button */}
            <button
              type="button"
              onClick={generateRandomCode}
              className="p-1 text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-600 hover:text-[#F5A524] dark:hover:text-[#F5A524] hover:bg-[#1B222A] dark:hover:bg-[#1B222A] hover:bg-slate-100 rounded border border-[#27323F] dark:border-[#27323F] border-slate-300 transition-colors cursor-pointer shrink-0"
              title="Roll random PIN"
              aria-label="Random PIN"
            >
              <Sparkles className="w-3.5 h-3.5" />
            </button>

            {/* Handle / Name Section */}
            <div className="relative shrink-0 w-24 sm:w-32">
              <div className="absolute inset-y-0 left-0 pl-1.5 flex items-center pointer-events-none text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-400">
                <User className="w-3 h-3" />
              </div>
              <input
                id="name-input"
                type="text"
                value={name}
                maxLength={20}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your handle"
                className="w-full pl-5 pr-1.5 py-1 text-xs bg-[#0F1419] dark:bg-[#0F1419] bg-white border border-[#27323F] dark:border-[#27323F] border-slate-300 rounded-md text-[#E8E6E1] dark:text-[#E8E6E1] text-slate-800 focus:outline-none focus:border-[#F5A524] font-sans font-medium"
                title="Your display handle"
              />
            </div>

            {/* Status indicator: Standby */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px] font-mono text-[#9BA3AF] dark:text-[#9BA3AF] text-slate-500 truncate pl-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#6E7681] dark:bg-[#6E7681] bg-slate-400 shrink-0" />
              <span className="truncate">standby</span>
            </div>
          </div>

          {/* Join Channel Button */}
          <div className="flex items-center gap-1.5 shrink-0 ml-auto">
            <button
              type="submit"
              disabled={isLoading || code.length < 3}
              className="px-3.5 py-1 text-xs font-mono font-bold text-[#0F1419] bg-[#F5A524] hover:bg-[#E09418] disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
            >
              {isLoading ? 'Connecting…' : 'Connect'}
            </button>
          </div>
        </div>

        {validationError && (
          <p className="text-[11px] font-mono text-[#EF4444] font-medium mt-0.5">
            {validationError}
          </p>
        )}
      </form>
    </div>
  );
};
