import React, { useState, useMemo } from 'react';
import {
  GitCompare,
  PlusCircle,
  MinusCircle,
  FileEdit,
  CheckCircle,
  ArrowRight,
  BookOpen,
  Filter,
} from 'lucide-react';
import {
  DocumentEntity,
  DocumentChunk,
  ComparisonResult,
  DiffChangeType,
} from '../types/doculens';
import { compareDocuments } from '../services/comparisonEngine';

interface CompareViewProps {
  documents: DocumentEntity[];
  chunks: DocumentChunk[];
  initialLeftDocId?: string;
  initialRightDocId?: string;
  onNavigateToReader: (docId: string, pageNumber: number) => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  documents,
  chunks,
  initialLeftDocId,
  initialRightDocId,
  onNavigateToReader,
}) => {
  const readyDocs = documents.filter((d) => d.status === 'ready');

  const [leftDocId, setLeftDocId] = useState<string>(
    initialLeftDocId || readyDocs[1]?.id || readyDocs[0]?.id || ''
  );
  const [rightDocId, setRightDocId] = useState<string>(
    initialRightDocId || readyDocs[2]?.id || readyDocs[1]?.id || readyDocs[0]?.id || ''
  );
  const [filterType, setFilterType] = useState<DiffChangeType | 'all'>('all');

  const leftDoc = readyDocs.find((d) => d.id === leftDocId);
  const rightDoc = readyDocs.find((d) => d.id === rightDocId);

  // Compute comparison
  const comparisonResult: ComparisonResult | null = useMemo(() => {
    if (!leftDoc || !rightDoc || leftDoc.id === rightDoc.id) return null;

    const leftChunks = chunks.filter((c) => c.documentId === leftDoc.id);
    const rightChunks = chunks.filter((c) => c.documentId === rightDoc.id);

    return compareDocuments(leftDoc, rightDoc, leftChunks, rightChunks);
  }, [leftDoc, rightDoc, chunks]);

  const filteredChanges = useMemo(() => {
    if (!comparisonResult) return [];
    if (filterType === 'all') return comparisonResult.changes;
    return comparisonResult.changes.filter((c) => c.type === filterType);
  }, [comparisonResult, filterType]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="border-b border-[#E0D9CC] pb-4">
        <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
          Document Revision Comparison
        </h1>
        <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
          Perform side-by-side semantic and structural diffs between two document revisions.
          Detect additions, deletions, and modified clauses with verified page citations from both
          sources.
        </p>
      </div>

      {/* Document Selection Toolbar */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 space-y-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
          Select Documents for Revision Diff:
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
          {/* Left / Baseline */}
          <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1.5">
            <span className="text-[11px] font-mono text-[#5C5E55]">BASELINE REVISION (A):</span>
            <select
              value={leftDocId}
              onChange={(e) => setLeftDocId(e.target.value)}
              aria-label="Baseline Revision A"
              className="w-full text-xs font-serif font-semibold bg-[#FAF8F5] border border-[#E0D9CC] rounded px-3 py-2 text-[#20211D] focus:outline-none"
            >
              {readyDocs.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName} ({d.pageCount}p)
                </option>
              ))}
            </select>
          </div>

          {/* Right / Target */}
          <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1.5">
            <span className="text-[11px] font-mono text-[#5C5E55]">REVISED REVISION (B):</span>
            <select
              value={rightDocId}
              onChange={(e) => setRightDocId(e.target.value)}
              aria-label="Revised Revision B"
              className="w-full text-xs font-serif font-semibold bg-[#FAF8F5] border border-[#E0D9CC] rounded px-3 py-2 text-[#20211D] focus:outline-none"
            >
              {readyDocs.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName} ({d.pageCount}p)
                </option>
              ))}
            </select>
          </div>
        </div>

        {leftDocId === rightDocId && (
          <p className="text-xs text-amber-800 bg-amber-50 p-2.5 rounded border border-amber-200">
            Please select two distinct documents to execute a comparison.
          </p>
        )}
      </div>

      {!comparisonResult && (
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-12 text-center text-[#5C5E55] space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#F5F2EB] border border-[#E0D9CC] p-3 flex items-center justify-center shadow-xs">
            <img
              src="/doculens-mark-transparent.png"
              alt="DocuLens Revision Compare"
              className="w-full h-full object-contain"
            />
          </div>
          <p className="font-serif text-lg font-medium text-[#20211D]">
            Select Two Distinct Document Revisions
          </p>
          <p className="text-xs max-w-md mx-auto text-[#5C5E55] leading-relaxed">
            Select a baseline document (Revision A) and an amended document (Revision B) above to
            compute side-by-side semantic differences, clause modifications, and exact page citations.
          </p>
        </div>
      )}

      {/* Comparison Metrics & Filters */}
      {comparisonResult && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <PlusCircle className="w-3.5 h-3.5 text-emerald-700" />
                <span>Additions</span>
              </span>
              <div className="text-xl font-mono font-bold text-emerald-800">
                +{comparisonResult.statistics.added}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <MinusCircle className="w-3.5 h-3.5 text-red-700" />
                <span>Removals</span>
              </span>
              <div className="text-xl font-mono font-bold text-red-800">
                -{comparisonResult.statistics.removed}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <FileEdit className="w-3.5 h-3.5 text-[#B84B2F]" />
                <span>Modifications</span>
              </span>
              <div className="text-xl font-mono font-bold text-[#B84B2F]">
                ~{comparisonResult.statistics.modified}
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded text-xs space-y-1">
              <span className="text-[11px] text-[#5C5E55] flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5 text-[#8E9085]" />
                <span>Unchanged</span>
              </span>
              <div className="text-xl font-mono font-bold text-[#5C5E55]">
                ={comparisonResult.statistics.identical}
              </div>
            </div>
          </div>

          {/* Filter segment tabs */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs pb-1">
            <div className="flex items-center gap-1 text-[#5C5E55] mr-2">
              <Filter className="w-3.5 h-3.5" />
              <span>Filter:</span>
            </div>
            {(['all', 'modification', 'addition', 'removal', 'unchanged'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1.5 rounded border capitalize transition-colors ${
                  filterType === type
                    ? 'border-[#B84B2F] bg-[#FAF8F5] text-[#B84B2F] font-semibold'
                    : 'border-[#E0D9CC] bg-[#F5F2EB] text-[#5C5E55] hover:text-[#20211D]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Change Entries */}
          <div className="space-y-4">
            {filteredChanges.length === 0 ? (
              <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55]">
                <p className="font-serif">No changes match the selected filter.</p>
              </div>
            ) : (
              filteredChanges.map((change) => {
                const isAdd = change.type === 'addition';
                const isRem = change.type === 'removal';
                const isMod = change.type === 'modification';

                return (
                  <div
                    key={change.id}
                    className={`border rounded-lg p-5 space-y-3 transition-colors ${
                      isAdd
                        ? 'border-emerald-300 bg-emerald-50/30'
                        : isRem
                        ? 'border-red-300 bg-red-50/30'
                        : isMod
                        ? 'border-[#C8BFB0] bg-[#FAF8F5]'
                        : 'border-[#E0D9CC] bg-[#FAF8F5]'
                    }`}
                  >
                    {/* Header info */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        {isAdd && (
                          <span className="font-mono text-emerald-800 font-bold uppercase">
                            [+ Addition]
                          </span>
                        )}
                        {isRem && (
                          <span className="font-mono text-red-800 font-bold uppercase">
                            [- Removal]
                          </span>
                        )}
                        {isMod && (
                          <span className="font-mono text-[#B84B2F] font-bold uppercase">
                            [~ Modification]
                          </span>
                        )}
                        {!isAdd && !isRem && !isMod && (
                          <span className="font-mono text-[#8E9085] uppercase">
                            [= Unchanged]
                          </span>
                        )}

                        <span className="text-[#8E9085]">·</span>
                        <span className="font-medium text-[#20211D]">{change.summary}</span>
                      </div>

                      {/* Jump buttons */}
                      <div className="flex items-center gap-3">
                        {change.leftPage && leftDoc && (
                          <button
                            onClick={() => onNavigateToReader(leftDoc.id, change.leftPage!)}
                            className="flex items-center gap-1 text-[11px] text-[#5C5E55] hover:text-[#20211D]"
                          >
                            <BookOpen className="w-3 h-3" />
                            <span>Rev A p.{change.leftPage}</span>
                          </button>
                        )}
                        {change.rightPage && rightDoc && (
                          <button
                            onClick={() => onNavigateToReader(rightDoc.id, change.rightPage!)}
                            className="flex items-center gap-1 text-[11px] text-[#5C5E55] hover:text-[#20211D]"
                          >
                            <BookOpen className="w-3 h-3" />
                            <span>Rev B p.{change.rightPage}</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Side-by-side / Comparison content */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-serif leading-relaxed">
                      {/* Left document text */}
                      <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1">
                        <div className="text-[10px] font-mono text-[#8E9085] flex justify-between">
                          <span>{leftDoc?.originalName}</span>
                          {change.leftPage && <span>Page {change.leftPage}</span>}
                        </div>
                        {change.leftText ? (
                          <p className={`text-[#20211D] ${isRem ? 'line-through text-red-800/80' : ''}`}>
                            {change.leftText}
                          </p>
                        ) : (
                          <p className="text-[#8E9085] italic">[Clause absent in baseline]</p>
                        )}
                      </div>

                      {/* Right document text */}
                      <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-1">
                        <div className="text-[10px] font-mono text-[#8E9085] flex justify-between">
                          <span>{rightDoc?.originalName}</span>
                          {change.rightPage && <span>Page {change.rightPage}</span>}
                        </div>
                        {change.rightText ? (
                          <p className={`text-[#20211D] ${isAdd ? 'text-emerald-900 font-medium' : ''}`}>
                            {change.rightText}
                          </p>
                        ) : (
                          <p className="text-[#8E9085] italic">[Clause deleted in revision]</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
