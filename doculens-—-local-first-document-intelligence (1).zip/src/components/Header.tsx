import React from 'react';
import {
  FileText,
  BookOpen,
  Search,
  MessageSquare,
  Table as TableIcon,
  GitCompare,
  Settings,
  Wifi,
  WifiOff,
  ShieldCheck,
} from 'lucide-react';
import { DocumentEntity } from '../types/doculens';

export type ActiveTab =
  | 'library'
  | 'reader'
  | 'search'
  | 'inquiry'
  | 'tables'
  | 'compare'
  | 'workspace';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id?: string) => void;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  documents,
  selectedDocId,
  onSelectDoc,
  isOnline,
}) => {
  const tabs = [
    { id: 'library' as ActiveTab, label: 'Library', icon: FileText },
    { id: 'reader' as ActiveTab, label: 'Reader', icon: BookOpen },
    { id: 'search' as ActiveTab, label: 'Search', icon: Search },
    { id: 'inquiry' as ActiveTab, label: 'Ask Documents', icon: MessageSquare },
    { id: 'tables' as ActiveTab, label: 'Tables & CSV', icon: TableIcon },
    { id: 'compare' as ActiveTab, label: 'Compare', icon: GitCompare },
    { id: 'workspace' as ActiveTab, label: 'Settings', icon: Settings },
  ];

  return (
    <header className="border-b border-[#E0D9CC] bg-[#FAF8F5] text-[#20211D]">
      {/* Brand & Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded border border-[#E0D9CC] bg-[#F5F2EB] p-1 flex items-center justify-center shrink-0 overflow-hidden shadow-xs">
            <img
              src="/doculens-mark-transparent.png"
              alt="DocuLens Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif font-semibold tracking-wider text-lg uppercase text-[#20211D]">
                DocuLens
              </span>
              <span className="text-xs font-mono text-[#5C5E55] border-l border-[#E0D9CC] pl-2 hidden sm:inline">
                DOCUMENT INTELLIGENCE
              </span>
            </div>
            <div className="text-[11px] text-[#5C5E55] flex items-center gap-2">
              <span>Public document workbench</span>
              <span aria-hidden="true">·</span>
              <span>Local-first & private</span>
              <span aria-hidden="true">·</span>
              <span>Verifiable citations</span>
            </div>
          </div>
        </div>

        {/* Status Indicators & Document Selector */}
        <div className="flex items-center flex-wrap gap-3 text-xs">
          {/* Document Scope Filter */}
          <div className="flex items-center gap-1.5 bg-[#F5F2EB] border border-[#E0D9CC] rounded px-2.5 py-1">
            <span className="text-[#5C5E55] font-medium">Scope:</span>
            <select
              value={selectedDocId || ''}
              onChange={(e) => onSelectDoc(e.target.value || undefined)}
              aria-label="Active document scope filter"
              className="bg-transparent border-none text-[#20211D] font-medium focus:outline-none cursor-pointer text-xs max-w-[180px] sm:max-w-[240px] truncate"
            >
              <option value="">All Documents ({documents.length})</option>
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.originalName} ({d.pageCount}p)
                </option>
              ))}
            </select>
          </div>

          {/* Offline / Online Status */}
          <div
            className="flex items-center gap-1.5 text-xs text-[#5C5E55] bg-[#F5F2EB] border border-[#E0D9CC] rounded px-2 py-1"
            title={
              isOnline
                ? 'Device is online. All PDF processing and indexing remain 100% on-device.'
                : 'Device is offline. All search, parsing, tables, and comparison functions remain fully operational.'
            }
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-700" />
                <span className="text-[#20211D]">Local Core</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-[#B84B2F]" />
                <span className="text-[#B84B2F] font-medium">Offline Mode</span>
              </>
            )}
          </div>

          {/* Privacy badge */}
          <div
            className="hidden lg:flex items-center gap-1 text-[11px] text-[#5C5E55]"
            title="Private on-device runtime"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#5C5E55]" />
            <span>IndexedDB Secured</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs - Clean Segmented / Editorial Menu */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <nav
          className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1"
          aria-label="Workspace views"
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-t border-b-2 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-[#B84B2F] text-[#B84B2F] bg-[#F5F2EB]'
                    : 'border-transparent text-[#5C5E55] hover:text-[#20211D] hover:bg-[#F5F2EB]/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#B84B2F]' : 'text-[#5C5E55]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
