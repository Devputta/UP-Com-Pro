import React, { useState, useRef, useMemo } from 'react';
import {
  Upload,
  FileText,
  Trash2,
  BookOpen,
  Table,
  GitCompare,
  Copy,
  Check,
  AlertCircle,
  CheckCircle2,
  Clock,
  Sparkles,
  Search,
  ArrowUpDown,
  X,
  FileWarning,
} from 'lucide-react';
import { DocumentEntity, UploadProgress } from '../types/doculens';

export interface DuplicateNotice {
  existingDoc: DocumentEntity;
  uploadedName: string;
  file?: File;
}

export type LibrarySortOption =
  | 'newest'
  | 'oldest'
  | 'name-asc'
  | 'name-desc'
  | 'size-desc'
  | 'pages-desc';

interface LibraryViewProps {
  documents: DocumentEntity[];
  onUploadFile: (file: File) => Promise<void>;
  onLoadSampleData: () => Promise<void>;
  onDeleteDocument: (id: string) => Promise<void>;
  onSelectDocumentForReader: (id: string) => void;
  onSelectDocumentForTables: (id: string) => void;
  onSelectDocumentForCompare: (id: string) => void;
  isProcessing: boolean;
  uploadProgress: UploadProgress | null;
  uploadError: string | null;
  uploadSuccess: string | null;
  deleteSuccess: string | null;
  duplicateNotice: DuplicateNotice | null;
  onClearDuplicateNotice: () => void;
  onReplaceDuplicate?: (existingId: string, file: File) => Promise<void>;
  onDismissUploadError: () => void;
  onDismissUploadSuccess: () => void;
  onDismissDeleteSuccess: () => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  documents,
  onUploadFile,
  onLoadSampleData,
  onDeleteDocument,
  onSelectDocumentForReader,
  onSelectDocumentForTables,
  onSelectDocumentForCompare,
  isProcessing,
  uploadProgress,
  uploadError,
  uploadSuccess,
  deleteSuccess,
  duplicateNotice,
  onClearDuplicateNotice,
  onReplaceDuplicate,
  onDismissUploadError,
  onDismissUploadSuccess,
  onDismissDeleteSuccess,
}) => {
  const [dragOver, setDragOver] = useState(false);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);
  const [confirmDeleteDoc, setConfirmDeleteDoc] = useState<DocumentEntity | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<LibrarySortOption>('newest');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      await onUploadFile(file);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      await onUploadFile(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // Filter and sort documents
  const filteredAndSortedDocs = useMemo(() => {
    let result = [...documents];

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (doc) =>
          doc.originalName.toLowerCase().includes(q) ||
          doc.sha256.toLowerCase().includes(q) ||
          (doc.summary && doc.summary.toLowerCase().includes(q))
      );
    }

    // Sort
    result.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return b.createdAt - a.createdAt;
        case 'oldest':
          return a.createdAt - b.createdAt;
        case 'name-asc':
          return a.originalName.localeCompare(b.originalName);
        case 'name-desc':
          return b.originalName.localeCompare(a.originalName);
        case 'size-desc':
          return b.sizeBytes - a.sizeBytes;
        case 'pages-desc':
          return b.pageCount - a.pageCount;
        default:
          return b.createdAt - a.createdAt;
      }
    });

    return result;
  }, [documents, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E0D9CC] pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
            Document Library
          </h1>
          <p className="text-xs text-[#5C5E55] mt-1 max-w-xl">
            Ingest PDFs, inspect cryptographic integrity (SHA-256), and extract element-level
            provenance. All files are parsed and retained locally in your browser storage.
          </p>
        </div>

        {documents.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={onLoadSampleData}
              disabled={isProcessing}
              className="text-xs text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] hover:border-[#C8BFB0] bg-[#FAF8F5] px-3 py-1.5 rounded transition-colors disabled:opacity-50 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#B84B2F]" />
              <span>Reload Benchmark Suite</span>
            </button>
          </div>
        )}
      </div>

      {/* Upload & Benchmark Zone */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Upload Dropzone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => !isProcessing && fileInputRef.current?.click()}
          className={`md:col-span-2 border-2 border-dashed rounded-lg p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-[#FAF8F5] relative ${
            dragOver
              ? 'border-[#B84B2F] bg-[#FAF8F5]'
              : isProcessing
              ? 'border-[#B84B2F]/40 cursor-wait'
              : 'border-[#D0C8B8] hover:border-[#B84B2F]/60'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.txt,.md"
            disabled={isProcessing}
            className="hidden"
            aria-label="Upload document file"
          />

          {!isProcessing ? (
            <>
              <div className="w-12 h-12 rounded-full bg-[#F5F2EB] border border-[#E0D9CC] flex items-center justify-center text-[#B84B2F] mb-3">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-[#20211D]">
                Drop PDF file here, or{' '}
                <span className="text-[#B84B2F] underline underline-offset-2">browse files</span>
              </p>
              <div className="text-xs text-[#5C5E55] mt-2 flex items-center gap-2 flex-wrap justify-center">
                <span>Standard %PDF- files</span>
                <span aria-hidden="true">·</span>
                <span>Up to 25 MB</span>
                <span aria-hidden="true">·</span>
                <span>Max 500 pages</span>
                <span aria-hidden="true">·</span>
                <span>Processed 100% on device</span>
              </div>
            </>
          ) : (
            <div className="w-full max-w-md space-y-3 py-2">
              <div className="flex items-center justify-center gap-2.5 text-xs text-[#B84B2F]">
                <img
                  src="/doculens-mark-transparent.png"
                  alt="DocuLens"
                  className="w-5 h-5 object-contain animate-pulse shrink-0"
                />
                <Clock className="w-4 h-4 animate-spin shrink-0" />
                <span className="font-medium font-serif text-sm">
                  {uploadProgress?.message || 'Processing document...'}
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-[#E0D9CC] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#B84B2F] h-full transition-all duration-300 ease-out"
                  style={{ width: `${uploadProgress?.percent || 20}%` }}
                />
              </div>

              <div className="flex justify-between items-center text-[11px] text-[#5C5E55] font-mono">
                <span className="capitalize">{uploadProgress?.stage || 'Parsing'}</span>
                <span>{uploadProgress?.percent || 20}%</span>
              </div>
            </div>
          )}
        </div>

        {/* Curated Benchmark Card */}
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-[#B84B2F] font-serif font-medium text-sm mb-2">
              <img
                src="/doculens-mark-transparent.png"
                alt="DocuLens Logo"
                className="w-4 h-4 object-contain"
              />
              <Sparkles className="w-3.5 h-3.5" />
              <span>Curated Benchmarks (Demo)</span>
            </div>
            <p className="text-xs text-[#5C5E55] leading-relaxed">
              Experience the full workspace instantly without locating a file on your device. Loads
              audited clean energy reports and multi-revision clinical protocols for testing diffs.
            </p>
            <ul className="text-xs text-[#5C5E55] mt-3 space-y-1.5 list-disc pl-4 font-serif">
              <li>Renewable Energy Transition Audit 2025</li>
              <li>Clinical Protocol B-709 (Revision 2.0)</li>
              <li>Clinical Protocol B-709 (Revision 3.0 Diff)</li>
            </ul>
          </div>

          <button
            onClick={onLoadSampleData}
            disabled={isProcessing}
            className="mt-4 w-full bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] text-xs font-medium py-2 px-3 rounded transition-colors text-center disabled:opacity-50"
          >
            Load Benchmark Documents
          </button>
        </div>
      </div>

      {/* Notifications: Failure, Success, Deletion, Duplicate */}
      {uploadError && (
        <div className="p-3.5 bg-red-50 border border-red-200 text-red-900 text-xs rounded-lg flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
            <div>
              <span className="font-semibold block text-red-950 mb-0.5">Upload Failed</span>
              <p className="leading-relaxed">{uploadError}</p>
            </div>
          </div>
          <button
            onClick={onDismissUploadError}
            className="text-red-700 hover:text-red-900 p-1"
            title="Dismiss error"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {uploadSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-lg flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-700 mt-0.5" />
            <div>
              <span className="font-semibold block text-emerald-950 mb-0.5">Document Ingested</span>
              <p className="leading-relaxed">{uploadSuccess}</p>
            </div>
          </div>
          <button
            onClick={onDismissUploadSuccess}
            className="text-emerald-700 hover:text-emerald-900 p-1"
            title="Dismiss message"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {deleteSuccess && (
        <div className="p-3.5 bg-[#FAF8F5] border border-[#E0D9CC] text-[#20211D] text-xs rounded-lg flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <Trash2 className="w-4 h-4 shrink-0 text-[#8E9085] mt-0.5" />
            <div>
              <span className="font-semibold block text-[#20211D] mb-0.5">Record Deleted</span>
              <p className="leading-relaxed text-[#5C5E55]">{deleteSuccess}</p>
            </div>
          </div>
          <button
            onClick={onDismissDeleteSuccess}
            className="text-[#8E9085] hover:text-[#20211D] p-1"
            title="Dismiss"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Duplicate Document Notice */}
      {duplicateNotice && (
        <div className="p-4 bg-amber-50 border border-amber-300 text-amber-950 text-xs rounded-lg space-y-3 shadow-xs">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <FileWarning className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-semibold block text-amber-900">
                  Duplicate Document Detected
                </span>
                <p className="leading-relaxed text-amber-800">
                  The uploaded file <strong>"{duplicateNotice.uploadedName}"</strong> has an identical
                  cryptographic fingerprint (SHA-256) to an existing record already stored in your
                  library: <strong>"{duplicateNotice.existingDoc.originalName}"</strong>.
                </p>
                <div className="font-mono text-[11px] text-amber-900 pt-1">
                  SHA-256: {duplicateNotice.existingDoc.sha256}
                </div>
              </div>
            </div>
            <button
              onClick={onClearDuplicateNotice}
              className="text-amber-700 hover:text-amber-950 p-1"
              title="Close notice"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-2 pt-1 border-t border-amber-200">
            <button
              onClick={() => {
                onSelectDocumentForReader(duplicateNotice.existingDoc.id);
                onClearDuplicateNotice();
              }}
              className="bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Open Existing in Reader</span>
            </button>

            {onReplaceDuplicate && duplicateNotice.file && (
              <button
                onClick={() =>
                  onReplaceDuplicate(duplicateNotice.existingDoc.id, duplicateNotice.file!)
                }
                className="bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 px-3 py-1.5 rounded text-xs font-medium"
              >
                Replace Existing Record
              </button>
            )}

            <button
              onClick={onClearDuplicateNotice}
              className="text-xs text-amber-800 hover:text-amber-950 px-2 py-1"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Library Records & Controls */}
      <div className="space-y-3">
        {/* Search, Sort, and Metrics Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-[#5C5E55]">
              Stored Documents ({documents.length})
            </h2>
            <span className="text-xs text-[#8E9085]">
              · {formatBytes(documents.reduce((acc, d) => acc + d.sizeBytes, 0))} Total
            </span>
          </div>

          {documents.length > 0 && (
            <div className="flex items-center gap-2.5 flex-wrap">
              {/* Search filter */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#8E9085] absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter by name, hash, or text..."
                  className="bg-[#FAF8F5] border border-[#E0D9CC] focus:border-[#B84B2F] rounded pl-8 pr-7 py-1 text-xs text-[#20211D] placeholder-[#8E9085] focus:outline-none w-48 sm:w-60"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[#8E9085] hover:text-[#20211D]"
                    title="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Sort selector */}
              <div className="flex items-center gap-1 bg-[#FAF8F5] border border-[#E0D9CC] rounded px-2 py-1 text-xs text-[#5C5E55]">
                <ArrowUpDown className="w-3 h-3 text-[#8E9085]" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as LibrarySortOption)}
                  className="bg-transparent border-none text-xs text-[#20211D] focus:outline-none cursor-pointer"
                  aria-label="Sort documents"
                >
                  <option value="newest">Newest Added</option>
                  <option value="oldest">Oldest Added</option>
                  <option value="name-asc">Name (A - Z)</option>
                  <option value="name-desc">Name (Z - A)</option>
                  <option value="size-desc">Size (Largest)</option>
                  <option value="pages-desc">Pages (Most)</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Empty States */}
        {documents.length === 0 ? (
          /* First-use empty state: sample documents are NEVER loaded automatically */
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-12 text-center text-[#5C5E55] space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-[#F5F2EB] border border-[#E0D9CC] p-3 flex items-center justify-center shadow-xs">
              <img
                src="/doculens-mark-transparent.png"
                alt="DocuLens Emblem"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="space-y-1">
              <p className="font-serif text-lg font-medium text-[#20211D]">
                Your Local Document Library is Empty
              </p>
              <p className="text-xs max-w-md mx-auto text-[#5C5E55] leading-relaxed">
                DocuLens operates 100% on your device with zero cloud tracking. Ingest your own PDF
                documents above, or explore the tool using our pre-structured benchmark documents.
              </p>
            </div>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] text-xs font-medium py-2 px-4 rounded transition-colors flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload a PDF File</span>
              </button>
              <button
                onClick={onLoadSampleData}
                disabled={isProcessing}
                className="bg-[#FAF8F5] hover:bg-[#F5F2EB] text-[#20211D] border border-[#E0D9CC] text-xs font-medium py-2 px-4 rounded transition-colors disabled:opacity-50 flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#B84B2F]" />
                <span>Load Benchmark Suite (Demo)</span>
              </button>
            </div>
          </div>
        ) : filteredAndSortedDocs.length === 0 ? (
          /* No search matches state */
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55] space-y-3">
            <Search className="w-8 h-8 mx-auto text-[#8E9085]" />
            <p className="font-serif text-base text-[#20211D]">
              No documents matched "{searchQuery}"
            </p>
            <p className="text-xs max-w-sm mx-auto text-[#5C5E55]">
              No records match your search filter. Try searching for a different keyword or clear the
              filter to view all stored records.
            </p>
            <div className="pt-1">
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs font-medium text-[#B84B2F] hover:underline"
              >
                Clear Search Filter
              </button>
            </div>
          </div>
        ) : (
          /* Document Records List */
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg overflow-hidden divide-y divide-[#E0D9CC]">
            {filteredAndSortedDocs.map((doc) => (
              <div
                key={doc.id}
                className="p-4 sm:p-5 hover:bg-[#F5F2EB] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-serif font-semibold text-[#20211D] text-base truncate">
                      {doc.originalName}
                    </span>
                    <span className="text-xs text-[#5C5E55]">
                      ({doc.pageCount} page{doc.pageCount > 1 ? 's' : ''})
                    </span>
                    <span className="text-xs text-[#5C5E55]">·</span>
                    <span className="text-xs text-[#5C5E55]">{formatBytes(doc.sizeBytes)}</span>
                    <span className="text-xs text-[#5C5E55]">·</span>
                    <span className="text-xs text-[#5C5E55] font-mono">
                      {doc.elementCount} elements
                    </span>
                    {doc.tableCount > 0 && (
                      <>
                        <span className="text-xs text-[#5C5E55]">·</span>
                        <span className="text-xs text-[#B84B2F] font-medium">
                          {doc.tableCount} table{doc.tableCount > 1 ? 's' : ''}
                        </span>
                      </>
                    )}
                    {doc.isScanned && (
                      <>
                        <span className="text-xs text-[#5C5E55]">·</span>
                        <span className="text-xs text-amber-800 font-medium bg-amber-100 px-1.5 py-0.5 rounded">
                          Scanned Image
                        </span>
                      </>
                    )}
                  </div>

                  {/* Summary / Warning */}
                  {doc.summary && (
                    <p className="text-xs text-[#5C5E55] line-clamp-2 max-w-3xl leading-relaxed">
                      {doc.summary}
                    </p>
                  )}

                  {doc.warningMessage && (
                    <p className="text-[11px] text-amber-800 leading-relaxed font-mono">
                      ⚠️ {doc.warningMessage}
                    </p>
                  )}

                  {/* Cryptographic SHA-256 fingerprint */}
                  <div className="flex items-center gap-2 text-[11px] text-[#5C5E55] pt-1">
                    <span className="font-mono text-[#8E9085]">SHA-256:</span>
                    <span className="font-mono text-[#20211D] truncate max-w-[220px] sm:max-w-md">
                      {doc.sha256}
                    </span>
                    <button
                      onClick={() => copyHash(doc.sha256)}
                      title="Copy SHA-256 checksum"
                      className="text-[#8E9085] hover:text-[#20211D] transition-colors"
                    >
                      {copiedHash === doc.sha256 ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <span className="text-[#8E9085]">·</span>
                    <span className="text-[#8E9085]">
                      Added {new Date(doc.createdAt).toLocaleDateString()} {new Date(doc.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                {/* Document Actions */}
                <div className="flex items-center gap-2 shrink-0 self-start md:self-center">
                  <button
                    onClick={() => onSelectDocumentForReader(doc.id)}
                    title="Read with Provenance Inspector"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-[#B84B2F]" />
                    <span>Reader</span>
                  </button>

                  {doc.tableCount > 0 && (
                    <button
                      onClick={() => onSelectDocumentForTables(doc.id)}
                      title="View & Export Extracted Tables"
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                    >
                      <Table className="w-3.5 h-3.5 text-[#5C5E55]" />
                      <span>Tables</span>
                    </button>
                  )}

                  <button
                    onClick={() => onSelectDocumentForCompare(doc.id)}
                    title="Compare against another revision"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                  >
                    <GitCompare className="w-3.5 h-3.5 text-[#5C5E55]" />
                    <span>Compare</span>
                  </button>

                  <button
                    onClick={() => setConfirmDeleteDoc(doc)}
                    title="Delete document and related records"
                    className="p-1.5 text-[#8E9085] hover:text-red-700 hover:bg-red-50 rounded transition-colors"
                    aria-label={`Delete ${doc.originalName}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmed Deletion Modal */}
      {confirmDeleteDoc && (
        <div className="fixed inset-0 bg-[#20211D]/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-red-50 border border-red-200 flex items-center justify-center text-red-700 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="font-serif font-semibold text-lg text-[#20211D]">
                  Permanently Delete Document?
                </h3>
                <p className="text-xs text-[#5C5E55] leading-relaxed">
                  You are about to delete <strong>"{confirmDeleteDoc.originalName}"</strong> from your
                  local IndexedDB repository.
                </p>
              </div>
            </div>

            <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded font-mono text-[11px] text-[#5C5E55] space-y-1">
              <div className="flex justify-between">
                <span>Pages:</span>
                <span className="text-[#20211D]">{confirmDeleteDoc.pageCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Extracted Elements:</span>
                <span className="text-[#20211D]">{confirmDeleteDoc.elementCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Provenance Chunks:</span>
                <span className="text-[#20211D]">{confirmDeleteDoc.chunkCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Tables:</span>
                <span className="text-[#20211D]">{confirmDeleteDoc.tableCount}</span>
              </div>
            </div>

            <div className="p-2.5 bg-[#FAF8F5] border border-[#E0D9CC] rounded text-[11px] text-[#5C5E55] leading-normal space-y-1">
              <span className="font-semibold block text-[#20211D]">Deletion Scope & Privacy:</span>
              <p>
                This operation immediately and permanently purges the document binary, extracted
                elements, lexical chunks, and extracted tables from your browser's IndexedDB.
                The DocuLens server stores zero copies; no remote or cloud records exist.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmDeleteDoc(null)}
                className="px-3.5 py-1.5 text-xs font-medium text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  const docId = confirmDeleteDoc.id;
                  setConfirmDeleteDoc(null);
                  await onDeleteDocument(docId);
                }}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-red-700 hover:bg-red-800 rounded transition-colors shadow-xs"
              >
                Confirm Deletion
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
