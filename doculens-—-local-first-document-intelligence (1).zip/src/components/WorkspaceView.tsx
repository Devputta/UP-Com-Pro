import React, { useState, useEffect, useRef } from 'react';
import {
  HardDrive,
  Download,
  Upload,
  Trash2,
  ShieldCheck,
  Cpu,
  Wifi,
  WifiOff,
  CheckCircle,
  AlertTriangle,
  Lock,
  FileCheck,
  Eye,
  Server,
  RefreshCw,
  Info,
} from 'lucide-react';
import { storage } from '../services/storage';

interface WorkspaceViewProps {
  documentsCount: number;
  chunksCount: number;
  tablesCount: number;
  inquiriesCount: number;
  notesCount: number;
  onRefreshAllData: () => Promise<void>;
  isOnline: boolean;
}

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  documentsCount,
  chunksCount,
  tablesCount,
  inquiriesCount,
  notesCount,
  onRefreshAllData,
  isOnline,
}) => {
  const [storageUsage, setStorageUsage] = useState<{ usedBytes: number; quotaBytes: number }>({
    usedBytes: 0,
    quotaBytes: 0,
  });
  const [exportMessage, setExportMessage] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanReport, setCleanReport] = useState<{
    orphanedElements: number;
    orphanedChunks: number;
    orphanedTables: number;
    orphanedNotes: number;
  } | null>(null);

  const importFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    storage.getStorageEstimate().then((est) => setStorageUsage(est));
  }, [documentsCount, chunksCount]);

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleExportArchive = async () => {
    try {
      const json = await storage.exportFullArchive();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `doculens_workspace_backup_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      setExportMessage('Workspace archive generated and downloaded successfully.');
      setTimeout(() => setExportMessage(null), 3500);
    } catch (e: any) {
      setExportMessage(`Export error: ${e?.message}`);
    }
  };

  const handleImportArchive = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (data.documents && Array.isArray(data.documents)) {
        for (const doc of data.documents) {
          await storage.saveDocument(doc);
        }
      }
      if (data.chunks && Array.isArray(data.chunks)) {
        await storage.saveChunks(data.chunks);
      }
      if (data.tables && Array.isArray(data.tables)) {
        await storage.saveTables(data.tables);
      }
      if (data.inquiries && Array.isArray(data.inquiries)) {
        for (const inq of data.inquiries) {
          await storage.saveInquiry(inq);
        }
      }

      await onRefreshAllData();
      setExportMessage('Archive restored successfully into local IndexedDB.');
      setTimeout(() => setExportMessage(null), 3500);
    } catch (err: any) {
      setExportMessage(`Import failure: ${err?.message || 'Invalid backup JSON file'}`);
    }
    if (importFileRef.current) importFileRef.current.value = '';
  };

  const handleClearAll = async () => {
    try {
      const docs = await storage.getDocuments();
      for (const d of docs) {
        await storage.deleteDocument(d.id);
      }
      await storage.clearInquiries();
      await onRefreshAllData();
      setConfirmClear(false);
      setExportMessage('Local workspace database cleared.');
      setTimeout(() => setExportMessage(null), 3000);
    } catch (e: any) {
      setExportMessage(`Clear failed: ${e?.message}`);
    }
  };

  const handleVerifyAndCleanStorage = async () => {
    setIsCleaning(true);
    try {
      const report = await storage.cleanupOrphanedRecords();
      setCleanReport(report);
      await onRefreshAllData();
      const totalPurged =
        report.orphanedElements +
        report.orphanedChunks +
        report.orphanedTables +
        report.orphanedNotes;
      if (totalPurged > 0) {
        setExportMessage(
          `Integrity audit cleaned ${totalPurged} orphaned record(s) from previous interrupted deletions.`
        );
      } else {
        setExportMessage('Storage integrity verified: Zero orphaned records found in database.');
      }
      setTimeout(() => setExportMessage(null), 4000);
    } catch (err: any) {
      setExportMessage(`Integrity check error: ${err?.message}`);
    } finally {
      setIsCleaning(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header */}
      <div className="border-b border-[#E0D9CC] pb-4">
        <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
          Settings & Security Boundaries
        </h1>
        <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
          Manage local IndexedDB storage, inspect cryptographic integrity (SHA-256), export portable
          offline archives, and review data transmission and deletion boundaries.
        </p>
      </div>

      {/* Brand & Public Product Overview */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 flex flex-col md:flex-row items-center md:items-start gap-6">
        <div className="w-24 h-24 rounded-lg border border-[#E0D9CC] bg-[#F5F2EB] p-2 flex items-center justify-center shrink-0 shadow-xs">
          <img
            src="/doculens-mark-transparent.png"
            alt="DocuLens Identity"
            className="w-full h-full object-contain"
          />
        </div>
        <div className="space-y-2 text-center md:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-xl font-serif font-semibold text-[#20211D]">
                DocuLens — Public Document Intelligence
              </h2>
              <p className="text-xs text-[#5C5E55] mt-0.5">
                Local-first research and inspection workspace for serious document analysis
              </p>
            </div>
            <span className="font-mono text-xs text-[#B84B2F] bg-[#F5F2EB] border border-[#E0D9CC] px-2.5 py-1 rounded self-center md:self-start">
              Release v1.2.0
            </span>
          </div>

          <p className="text-xs text-[#5C5E55] leading-relaxed max-w-2xl">
            DocuLens is engineered for analysts, researchers, students, and professionals who require
            uncompromising document privacy and rigorous evidence verification. Parsing, lexical search,
            table extraction, and revision diffing happen entirely inside your browser's local sandbox
            without cloud tracking.
          </p>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 text-[11px] text-[#5C5E55] font-mono">
            <span>Palette: #F4F1E9 / #242520 / #B84B2F</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Cloud Default</span>
            <span aria-hidden="true">·</span>
            <span>RFC-4180 Formula Defense</span>
            <span aria-hidden="true">·</span>
            <span>Rate-Limited Proxy</span>
          </div>
        </div>
      </div>

      {exportMessage && (
        <div className="p-3 bg-[#F5F2EB] border border-[#B84B2F]/40 text-[#20211D] text-xs rounded flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-[#B84B2F] shrink-0" />
          <span>{exportMessage}</span>
        </div>
      )}

      {/* Storage and Connectivity Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Connection status */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Network Mode</span>
            {isOnline ? (
              <Wifi className="w-4 h-4 text-emerald-700" />
            ) : (
              <WifiOff className="w-4 h-4 text-[#B84B2F]" />
            )}
          </div>
          <div className="text-lg font-serif font-semibold text-[#20211D]">
            {isOnline ? 'Online (Self-Contained)' : 'Completely Offline'}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            No internet required for ingestion, chunking, search, or citation verification.
          </p>
        </div>

        {/* Local Storage Quota */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">IndexedDB Usage</span>
            <HardDrive className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">
            {formatBytes(storageUsage.usedBytes || 120000)}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            Quota available: {formatBytes(storageUsage.quotaBytes || 1073741824)}
          </p>
        </div>

        {/* Provenance Chunks */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Indexed Chunks</span>
            <Cpu className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">{chunksCount}</div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            Across {documentsCount} active document{documentsCount === 1 ? '' : 's'}.
          </p>
        </div>

        {/* Tables & Marginalia */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Tables / Notes</span>
            <ShieldCheck className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">
            {tablesCount} / {notesCount}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            {inquiriesCount} grounded inquiry logs saved.
          </p>
        </div>
      </div>

      {/* Explicit Privacy & Data Transmission Boundaries */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-[#B84B2F]" />
          <h2 className="text-base font-serif font-semibold text-[#20211D]">
            Data Storage & AI Transmission Scope
          </h2>
        </div>
        <p className="text-xs text-[#5C5E55] max-w-2xl leading-relaxed">
          DocuLens maintains strict data isolation between your local device and optional external
          services. Below is the audited disclosure of data movement:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* What Stays Local */}
          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <div className="flex items-center gap-2 font-semibold text-[#20211D]">
              <HardDrive className="w-4 h-4 text-emerald-700" />
              <span>What Stays in Browser Storage (100% On-Device)</span>
            </div>
            <ul className="text-[#5C5E55] space-y-1.5 list-disc pl-4 leading-relaxed">
              <li>
                <strong>Raw PDF Files & Binaries:</strong> Never uploaded to any server or cloud storage.
              </li>
              <li>
                <strong>Extracted Layout Elements:</strong> Headings, paragraphs, bounding boxes, and footnotes.
              </li>
              <li>
                <strong>Lexical Search Index & Chunks:</strong> Indexed locally in browser IndexedDB.
              </li>
              <li>
                <strong>Extracted Tables & Marginalia Notes:</strong> Retained only in client storage.
              </li>
              <li>
                <strong>Origin Sandboxing:</strong> Isolated to this browser profile via the Same-Origin Policy (SOP).
              </li>
            </ul>
          </div>

          {/* What is Sent to Remote AI */}
          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <div className="flex items-center gap-2 font-semibold text-[#20211D]">
              <Server className="w-4 h-4 text-[#B84B2F]" />
              <span>What is Sent to Remote AI (Only when Assist is Enabled)</span>
            </div>
            <ul className="text-[#5C5E55] space-y-1.5 list-disc pl-4 leading-relaxed">
              <li>
                <strong>User Inquiry String:</strong> The question text typed into the Ask view (max 2,000 chars).
              </li>
              <li>
                <strong>Retrieved Excerpt Quotes:</strong> Only the top 1 to 4 relevant text chunks (max 5,000 chars each) needed to answer the question.
              </li>
              <li>
                <strong>Stateless Processing:</strong> The backend proxy retains zero copies or logs of document text.
              </li>
              <li>
                <strong>No Telemetry or Tracking:</strong> No analytics cookies, trackers, or user behavioral logs.
              </li>
              <li>
                <strong>Offline Deterministic Fallback:</strong> If remote AI is disabled or fails, synthesis is performed 100% on-device.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Deletion Scope & Interrupted Deletion Recovery */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Trash2 className="w-4 h-4 text-[#B84B2F]" />
          <h2 className="text-base font-serif font-semibold text-[#20211D]">
            Document Deletion Scope & Integrity Recovery
          </h2>
        </div>

        <p className="text-xs text-[#5C5E55] max-w-2xl leading-relaxed">
          When you delete a document in DocuLens, the purge is instantaneous and comprehensive across all
          local IndexedDB tables (documents, elements, chunks, tables, notes). Because the DocuLens server
          operates as a stateless proxy and maintains zero document copies, no residual cloud data remains.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            onClick={handleVerifyAndCleanStorage}
            disabled={isCleaning}
            className="flex items-center gap-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded px-3.5 py-2 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#B84B2F] ${isCleaning ? 'animate-spin' : ''}`} />
            <span>Verify Storage Integrity & Purge Orphaned Chunks</span>
          </button>

          {cleanReport && (
            <span className="text-xs text-[#5C5E55] font-mono">
              Audit result: {cleanReport.orphanedChunks} chunks, {cleanReport.orphanedElements} elements cleaned.
            </span>
          )}
        </div>
      </div>

      {/* Backup, Import & Maintenance */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-5">
        <h2 className="text-base font-serif font-semibold text-[#20211D]">
          Portability & Offline Backup
        </h2>
        <p className="text-xs text-[#5C5E55] max-w-xl leading-relaxed">
          Create an offline snapshot containing all documents, extracted tables, and inquiry logs.
          You can transfer this JSON snapshot to another browser or air-gapped machine.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportArchive}
            className="flex items-center gap-1.5 text-xs font-medium text-[#F5F2EB] bg-[#20211D] hover:bg-[#383933] rounded px-4 py-2 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Full JSON Archive</span>
          </button>

          <input
            type="file"
            ref={importFileRef}
            onChange={handleImportArchive}
            accept=".json"
            className="hidden"
            aria-label="Upload JSON workspace backup file"
          />
          <button
            onClick={() => importFileRef.current?.click()}
            className="flex items-center gap-1.5 text-xs font-medium text-[#20211D] border border-[#E0D9CC] hover:bg-[#F5F2EB] rounded px-4 py-2 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Restore Archive From File</span>
          </button>

          <button
            onClick={() => setConfirmClear(true)}
            className="flex items-center gap-1.5 text-xs font-medium text-red-800 border border-red-200 hover:bg-red-50 rounded px-4 py-2 transition-colors ml-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset Local Database</span>
          </button>
        </div>
      </div>

      {/* Security Policies & Enforcement Summary */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-4">
        <h2 className="text-base font-serif font-semibold text-[#20211D]">
          Enforced Application Security Controls
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">1. Server Rate & Size Limits</span>
            <p className="text-[#5C5E55] leading-relaxed">
              Inquiry requests are constrained to 2MB maximum payload and rate-limited to 25 requests/min.
              Calls are subject to a 25s timeout to prevent thread starvation.
            </p>
          </div>

          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">2. Formula Injection Defense</span>
            <p className="text-[#5C5E55] leading-relaxed">
              CSV exports escape all formula prefixes (`=, +, -, @, \t, \r, %, |`) using RFC-4180
              compliant single-quote wrapping to prevent spreadsheet code execution.
            </p>
          </div>

          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">3. Untrusted Input Isolation</span>
            <p className="text-[#5C5E55] leading-relaxed">
              PDF contents are treated strictly as untrusted raw strings. System overrides, markup tags,
              and command attempts are neutralized before AI synthesis.
            </p>
          </div>
        </div>

        <div className="pt-2 text-[11px] text-[#5C5E55] flex items-center justify-between border-t border-[#E0D9CC]">
          <span>Security & vulnerability reporting guidelines are maintained in root <code>SECURITY.md</code>.</span>
          <span className="font-mono">Zero Telemetry · Local-First</span>
        </div>
      </div>

      {/* Confirmation Modal for Reset */}
      {confirmClear && (
        <div className="fixed inset-0 bg-[#20211D]/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2 text-red-700 font-serif font-semibold text-lg">
              <AlertTriangle className="w-5 h-5" />
              <span>Reset Entire Workspace?</span>
            </div>
            <p className="text-xs text-[#5C5E55] leading-relaxed">
              This will permanently delete all stored documents, chunks, tables, and notes from your
              browser's IndexedDB.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmClear(false)}
                className="px-3 py-1.5 text-xs font-medium text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 text-xs font-medium text-white bg-red-700 hover:bg-red-800 rounded"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
