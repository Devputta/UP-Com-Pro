/**
 * DocuLens PDF Parser Adapter & Ingestion Pipeline
 * Strict validation (%PDF- signature, byte bounds, page count, SHA-256 checksums),
 * graceful handling of encrypted/corrupt PDFs, and provenance tracking.
 */

import {
  DocumentEntity,
  DocumentElement,
  DocumentChunk,
  DocumentTable,
  ElementType,
  UploadProgress,
} from '../types/doculens';

// Maximum upload limits from requirements
export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB
export const MAX_PAGES_LIMIT = 500;

export interface ParseResult {
  document: DocumentEntity;
  elements: DocumentElement[];
  chunks: DocumentChunk[];
  tables: DocumentTable[];
}

export interface ParseOptions {
  onProgress?: (progress: UploadProgress) => void;
}

/**
 * Calculates SHA-256 checksum using Web Crypto API.
 */
export async function calculateSHA256(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Validates file signature, extension, and byte bounds.
 */
export function validatePDFHeader(
  buffer: ArrayBuffer,
  filename?: string
): { valid: boolean; isPDF: boolean; error?: string } {
  if (!buffer || buffer.byteLength === 0) {
    return { valid: false, isPDF: false, error: 'File is empty (0 bytes).' };
  }
  if (buffer.byteLength > MAX_UPLOAD_BYTES) {
    const sizeMB = (buffer.byteLength / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      isPDF: false,
      error: `File size (${sizeMB} MB) exceeds the allowable threshold of ${MAX_UPLOAD_BYTES / (1024 * 1024)} MB.`,
    };
  }

  // Check file extension if provided
  if (filename) {
    const extMatch = filename.match(/\.([a-zA-Z0-9]+)$/);
    const ext = extMatch ? extMatch[1].toLowerCase() : '';
    const unsupportedBinaryExts = new Set([
      'exe', 'dll', 'bin', 'zip', 'tar', 'gz', 'rar', '7z',
      'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg',
      'mp3', 'mp4', 'mov', 'avi', 'mkv',
      'iso', 'dmg', 'pkg', 'deb', 'rpm'
    ]);
    if (unsupportedBinaryExts.has(ext)) {
      return {
        valid: false,
        isPDF: false,
        error: `Unsupported file type (.${ext}). DocuLens only accepts PDF documents (.pdf) or plain text/markdown (.txt, .md).`,
      };
    }
  }

  // Check for standard PDF magic bytes "%PDF-" anywhere in first 1024 bytes (per ISO 32000-1 specification)
  const headerBytes = new Uint8Array(buffer.slice(0, Math.min(buffer.byteLength, 1024)));
  let isPDF = false;
  for (let i = 0; i <= headerBytes.length - 5; i++) {
    if (
      headerBytes[i] === 0x25 && // %
      headerBytes[i + 1] === 0x50 && // P
      headerBytes[i + 2] === 0x44 && // D
      headerBytes[i + 3] === 0x46 && // F
      headerBytes[i + 4] === 0x2d // -
    ) {
      isPDF = true;
      break;
    }
  }

  if (!isPDF) {
    // Check if it's text/markdown/plain with printable characters
    const peekStr = String.fromCharCode(...new Uint8Array(buffer.slice(0, Math.min(buffer.byteLength, 200))));
    const isPrintable = /^[\x20-\x7E\r\n\t]+$/.test(peekStr);
    if (!isPrintable) {
      return {
        valid: false,
        isPDF: false,
        error: 'Unsupported document format: missing required %PDF- file header signature.',
      };
    }
  }

  return { valid: true, isPDF };
}

/**
 * Fallback parser for extracting text from text/markdown documents
 */
function parseTextDocument(
  text: string,
  docId: string
): { elements: DocumentElement[]; tables: DocumentTable[] } {
  const lines = text.split('\n');
  const elements: DocumentElement[] = [];
  const tables: DocumentTable[] = [];

  let currentPage = 1;
  let elementIndex = 1;
  let currentTableHeaders: string[] = [];
  let currentTableRows: string[][] = [];
  let inTable = false;

  const flushTable = () => {
    if (inTable && currentTableHeaders.length > 0) {
      const tableId = `${docId}-tbl-${tables.length + 1}`;
      const sourceElId = `${docId}-el-${elementIndex}`;
      elements.push({
        id: sourceElId,
        documentId: docId,
        type: 'table',
        pageNumber: currentPage,
        content: `Table: ${currentTableHeaders.join(' | ')} (${currentTableRows.length} rows)`,
        sourceElementId: `src_${tableId}`,
      });
      tables.push({
        id: tableId,
        documentId: docId,
        pageNumber: currentPage,
        sourceElementId: sourceElId,
        headers: currentTableHeaders,
        rows: currentTableRows,
      });
      elementIndex++;
      currentTableHeaders = [];
      currentTableRows = [];
      inTable = false;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // Check for explicit page break markers
    if (line.includes('--- Page') || line.includes('=== Page') || line === '---') {
      flushTable();
      currentPage++;
      continue;
    }

    if (!line) {
      flushTable();
      continue;
    }

    // Markdown table detection (| col1 | col2 |)
    if (line.startsWith('|') && line.endsWith('|')) {
      const cells = line
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());
      // Check if separator line
      if (cells.every((c) => /^:?-+:?$/.test(c))) {
        continue;
      }
      if (!inTable) {
        inTable = true;
        currentTableHeaders = cells;
      } else {
        currentTableRows.push(cells);
      }
      continue;
    } else {
      flushTable();
    }

    // Heading detection
    if (line.startsWith('# ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-1',
        pageNumber: currentPage,
        content: line.replace(/^#\s*/, ''),
        headingLevel: 1,
        sourceElementId: `src_h1_${elementIndex}`,
      });
    } else if (line.startsWith('## ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-2',
        pageNumber: currentPage,
        content: line.replace(/^##\s*/, ''),
        headingLevel: 2,
        sourceElementId: `src_h2_${elementIndex}`,
      });
    } else if (line.startsWith('### ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-3',
        pageNumber: currentPage,
        content: line.replace(/^###\s*/, ''),
        headingLevel: 3,
        sourceElementId: `src_h3_${elementIndex}`,
      });
    } else if (line.startsWith('* ') || line.startsWith('- ') || /^\d+\.\s/.test(line)) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'list-item',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_li_${elementIndex}`,
      });
    } else if (line.toLowerCase().startsWith('footnote') || line.startsWith('[^')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'footnote',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_fn_${elementIndex}`,
      });
    } else {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'paragraph',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_p_${elementIndex}`,
      });
    }
  }

  flushTable();
  return { elements, tables };
}

/**
 * Parses a PDF file with strict validation, error isolation, and stage-by-stage progress callbacks.
 */
export async function parsePDFFile(
  file: File | { name: string; buffer: ArrayBuffer },
  options?: ParseOptions
): Promise<ParseResult> {
  const onProgress = options?.onProgress;
  const originalName = file.name;

  onProgress?.({
    stage: 'reading',
    percent: 5,
    message: `Reading ${originalName}...`,
  });

  const buffer = 'buffer' in file ? file.buffer : await file.arrayBuffer();
  const sizeBytes = buffer.byteLength;

  // 1. Signature & Bounds Validation
  onProgress?.({
    stage: 'validating',
    percent: 15,
    message: 'Validating file signature, headers, and allowable size...',
  });

  const validation = validatePDFHeader(buffer, originalName);
  if (!validation.valid) {
    throw new Error(validation.error || 'Failed document validation.');
  }

  const sha256 = await calculateSHA256(buffer);
  const docId = `doc-${crypto.randomUUID().slice(0, 8)}`;
  const storedPath = `local://doculens/storage/${docId}-${originalName.replace(/\s+/g, '_')}`;

  let elements: DocumentElement[] = [];
  let tables: DocumentTable[] = [];
  let pageCount = 1;
  let isScanned = false;
  let warningMessage: string | undefined;

  if (validation.isPDF) {
    onProgress?.({
      stage: 'parsing',
      percent: 25,
      message: 'Initializing PDF layout engine and inspecting page structures...',
    });

    try {
      const pdfjs = await import('pdfjs-dist');
      if (typeof window !== 'undefined' && !pdfjs.GlobalWorkerOptions.workerSrc) {
        pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version || '4.0.379'}/pdf.worker.min.mjs`;
      }

      const loadingTask = pdfjs.getDocument({
        data: new Uint8Array(buffer),
        useSystemFonts: true,
      });

      const pdf = await loadingTask.promise;

      // Page Count Limit Check
      if (pdf.numPages > MAX_PAGES_LIMIT) {
        throw new Error(
          `Document exceeds maximum allowable limit of ${MAX_PAGES_LIMIT} pages (found ${pdf.numPages} pages). Please split the document before uploading.`
        );
      }

      pageCount = pdf.numPages;
      let elementIndex = 1;

      for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
        const percent = Math.round(25 + (pageNum / pageCount) * 50);
        onProgress?.({
          stage: 'parsing',
          percent,
          message: `Extracting page ${pageNum} of ${pageCount}...`,
          currentPage: pageNum,
          totalPages: pageCount,
        });

        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        const viewport = page.getViewport({ scale: 1.0 });

        const items = textContent.items as Array<{
          str: string;
          transform: number[];
          width: number;
          height: number;
        }>;

        // Group items by vertical position into lines
        const lineMap = new Map<number, string[]>();
        for (const item of items) {
          if (!item.str || !item.str.trim()) continue;
          const yBucket = Math.round(item.transform[5] / 4) * 4;
          if (!lineMap.has(yBucket)) {
            lineMap.set(yBucket, []);
          }
          lineMap.get(yBucket)!.push(item.str);
        }

        const sortedY = Array.from(lineMap.keys()).sort((a, b) => b - a);

        for (const y of sortedY) {
          const textPieces = lineMap.get(y) || [];
          const lineText = textPieces.join(' ').trim();
          if (!lineText) continue;

          let elType: ElementType = 'paragraph';
          let headingLevel: number | undefined;

          const normY = Math.max(0, Math.min(100, Math.round(((viewport.height - y) / viewport.height) * 100)));
          const bbox: [number, number, number, number] = [10, normY, 80, 5];

          if (
            lineText.length < 80 &&
            (lineText === lineText.toUpperCase() || lineText.startsWith('Chapter') || lineText.startsWith('Section')) &&
            !lineText.endsWith('.')
          ) {
            elType = 'heading-1';
            headingLevel = 1;
          } else if (lineText.length < 100 && /^[0-9]\.[0-9]/.test(lineText)) {
            elType = 'heading-2';
            headingLevel = 2;
          } else if (normY > 90 || lineText.toLowerCase().startsWith('footnote')) {
            elType = 'footnote';
          }

          elements.push({
            id: `${docId}-el-${elementIndex++}`,
            documentId: docId,
            type: elType,
            pageNumber: pageNum,
            content: lineText,
            headingLevel,
            bbox,
            sourceElementId: `src_p${pageNum}_e${elementIndex}`,
          });
        }
      }

      // Check if document has no extractable text layer (scanned PDF)
      if (elements.length === 0) {
        isScanned = true;
        warningMessage =
          'Scanned document without embedded OCR text layer. Text search, citation extraction, and diffing require a searchable text layer.';
        elements.push({
          id: `${docId}-el-1`,
          documentId: docId,
          type: 'callout',
          pageNumber: 1,
          content: `[Notice: Scanned document without embedded OCR text layer (${pageCount} page${pageCount > 1 ? 's' : ''}). Text search and citation extraction require searchable text.]`,
          sourceElementId: 'src_scanned_notice',
        });
      }
    } catch (pdfErr: any) {
      // Discriminate between specific PDF failure modes
      const errMsg = pdfErr?.message || String(pdfErr);
      const errName = pdfErr?.name || '';

      if (errName === 'PasswordException' || /password|encrypted|decrypt/i.test(errMsg)) {
        throw new Error(
          'This PDF document is encrypted or password-protected. Please unlock or decrypt the file before importing.'
        );
      }

      if (errName === 'InvalidPDFException' || /invalid pdf|corrupted|stream end|xref/i.test(errMsg)) {
        throw new Error(
          'Malformed or corrupted PDF file. The internal PDF structure could not be parsed.'
        );
      }

      // Re-throw page limit or custom errors directly
      if (errMsg.includes('Document exceeds maximum allowable limit')) {
        throw pdfErr;
      }

      console.warn('PDF.js binary decode fallback triggered:', pdfErr);
      const decoder = new TextDecoder('utf-8', { fatal: false });
      const rawText = decoder.decode(buffer);
      const textOnly = rawText.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, ' ');
      const parsed = parseTextDocument(textOnly, docId);
      elements = parsed.elements;
      tables = parsed.tables;
      pageCount = Math.max(1, Math.max(...elements.map((e) => e.pageNumber), 1));
    }
  } else {
    // Plain text / Markdown document
    const decoder = new TextDecoder('utf-8', { fatal: false });
    const rawText = decoder.decode(buffer);
    const parsed = parseTextDocument(rawText, docId);
    elements = parsed.elements;
    tables = parsed.tables;
    pageCount = Math.max(1, Math.max(...elements.map((e) => e.pageNumber), 1));
  }

  // 2. Chunks Construction
  onProgress?.({
    stage: 'chunking',
    percent: 85,
    message: 'Constructing provenance-linked chunks and section hierarchies...',
  });

  const chunks = createProvenanceChunks(elements, docId);

  // Document summary preview
  const previewText = elements
    .slice(0, 4)
    .map((e) => e.content)
    .join(' ');
  const summary = previewText.length > 250 ? `${previewText.slice(0, 247)}...` : previewText;

  // 3. Final Storage Packaging
  onProgress?.({
    stage: 'storing',
    percent: 95,
    message: 'Finalizing document record and IndexedDB storage...',
  });

  const document: DocumentEntity = {
    id: docId,
    originalName,
    storedPath,
    sha256,
    sizeBytes,
    pageCount,
    status: 'ready',
    parserName: 'DocuLens-PDF-Adapter',
    parserVersion: '1.2.0',
    createdAt: Date.now(),
    processedAt: Date.now(),
    summary,
    elementCount: elements.length,
    chunkCount: chunks.length,
    tableCount: tables.length,
    isScanned,
    warningMessage,
  };

  onProgress?.({
    stage: 'complete',
    percent: 100,
    message: 'Ingestion complete.',
  });

  return {
    document,
    elements,
    chunks,
    tables,
  };
}

/**
 * Creates provenance-aware chunks adhering to size boundaries (~1,800 chars target, max ~2,400).
 */
export function createProvenanceChunks(
  elements: DocumentElement[],
  documentId: string
): DocumentChunk[] {
  const chunks: DocumentChunk[] = [];
  const TARGET_CHUNK_CHARS = 1600;
  const MAX_CHUNK_CHARS = 2400;

  let currentText = '';
  let currentElementIds: string[] = [];
  let pageStart = 1;
  let pageEnd = 1;
  let currentSectionPath: string[] = [];
  let chunkIndex = 1;

  for (const el of elements) {
    if (el.type.startsWith('heading')) {
      currentSectionPath = [el.content];
    }

    const prospectiveLength = currentText.length + el.content.length + 2;

    if (prospectiveLength > MAX_CHUNK_CHARS && currentText.length > 0) {
      chunks.push({
        id: `${documentId}-chk-${chunkIndex++}`,
        documentId,
        text: currentText.trim(),
        pageStart,
        pageEnd,
        elementIds: [...currentElementIds],
        sectionPath: [...currentSectionPath],
        searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
      });

      currentText = `${el.content}\n\n`;
      currentElementIds = [el.id];
      pageStart = el.pageNumber;
      pageEnd = el.pageNumber;
    } else {
      if (currentText.length === 0) {
        pageStart = el.pageNumber;
      }
      currentText += `${el.content}\n\n`;
      currentElementIds.push(el.id);
      pageEnd = el.pageNumber;

      if (currentText.length >= TARGET_CHUNK_CHARS) {
        chunks.push({
          id: `${documentId}-chk-${chunkIndex++}`,
          documentId,
          text: currentText.trim(),
          pageStart,
          pageEnd,
          elementIds: [...currentElementIds],
          sectionPath: [...currentSectionPath],
          searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
        });
        currentText = '';
        currentElementIds = [];
      }
    }
  }

  if (currentText.trim().length > 0) {
    chunks.push({
      id: `${documentId}-chk-${chunkIndex++}`,
      documentId,
      text: currentText.trim(),
      pageStart,
      pageEnd,
      elementIds: [...currentElementIds],
      sectionPath: [...currentSectionPath],
      searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
    });
  }

  return chunks;
}
