/**
 * DocuLens Table Extraction & CSV Security Sanitizer
 * Implements strict Formula Injection Mitigation (RFC-4180 & OWASP CSV Injection Guidelines)
 * Escapes '=', '+', '-', '@', '\t', '\r', '%', '|' to prevent spreadsheet macro execution
 * and formula exploits across Microsoft Excel, Google Sheets, and LibreOffice Calc.
 */

import { DocumentTable } from '../types/doculens';

// Dangerous characters per OWASP CSV Injection guidelines that trigger formula evaluation
const DANGEROUS_FORMULA_PREFIXES = ['=', '+', '-', '@', '\t', '\r', '%', '|'];

/**
 * Sanitizes a single cell value against CSV formula injection.
 * Escapes malicious spreadsheet formula execution while preserving valid numbers.
 */
export function sanitizeCSVCell(value: string | number | undefined | null): string {
  if (value === null || value === undefined) return '';

  if (typeof value === 'number') {
    if (!isNaN(value) && isFinite(value)) {
      return String(value);
    }
    return '';
  }

  const rawStr = String(value);
  const trimmed = rawStr.trim();
  if (trimmed === '') return '';

  // Check if it's a legitimate number (e.g. "-12.5", "+4.2", "390", "342.0", "0")
  const isPureNumber = /^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(trimmed);
  if (isPureNumber) {
    return trimmed;
  }

  const firstChar = trimmed.charAt(0);
  const rawFirstChar = rawStr.charAt(0);
  const isFormulaRisk =
    DANGEROUS_FORMULA_PREFIXES.includes(firstChar) ||
    DANGEROUS_FORMULA_PREFIXES.includes(rawFirstChar);

  let sanitized = trimmed;
  if (isFormulaRisk) {
    // Prepend single quote (') to force spreadsheet software to treat the cell as raw string text
    sanitized = `'${trimmed}`;
  }

  // RFC-4180 CSV escaping:
  // If the cell contains quotes, commas, newlines, or carriage returns:
  // double up internal quotes and wrap the whole cell in double quotes.
  if (
    sanitized.includes('"') ||
    sanitized.includes(',') ||
    sanitized.includes('\n') ||
    sanitized.includes('\r')
  ) {
    return `"${sanitized.replace(/"/g, '""')}"`;
  }

  return sanitized;
}

/**
 * Converts a DocumentTable to a secure CSV string compliant with RFC-4180.
 */
export function exportTableToCSV(table: DocumentTable): string {
  const lines: string[] = [];

  // Title comment if present, sanitized to prevent injection or header splitting
  if (table.title) {
    const cleanTitle = table.title
      .replace(/[\r\n]+/g, ' ')
      .replace(/^([=+\-@%|])/g, "'$1")
      .trim();
    lines.push(`# ${cleanTitle}`);
  }

  // Header row
  const headerLine = table.headers.map((h) => sanitizeCSVCell(h)).join(',');
  lines.push(headerLine);

  // Data rows
  for (const row of table.rows) {
    const rowLine = row.map((cell) => sanitizeCSVCell(cell)).join(',');
    lines.push(rowLine);
  }

  return lines.join('\r\n');
}

/**
 * Computes numeric stats for a column if numerical.
 */
export function analyzeColumn(values: string[]): {
  isNumeric: boolean;
  count: number;
  min?: number;
  max?: number;
  average?: number;
  sum?: number;
} {
  const numericValues = values
    .map((v) => parseFloat(v.replace(/[^0-9.-]/g, '')))
    .filter((n) => !isNaN(n));

  if (numericValues.length >= values.length * 0.6 && numericValues.length > 0) {
    const sum = numericValues.reduce((acc, val) => acc + val, 0);
    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const average = sum / numericValues.length;

    return {
      isNumeric: true,
      count: values.length,
      min: Math.round(min * 100) / 100,
      max: Math.round(max * 100) / 100,
      average: Math.round(average * 100) / 100,
      sum: Math.round(sum * 100) / 100,
    };
  }

  return {
    isNumeric: false,
    count: values.length,
  };
}

/**
 * Triggers safe client-side CSV download with sanitized filename.
 */
export function downloadCSVFile(table: DocumentTable, filenamePrefix = 'doculens_table'): void {
  const csvContent = exportTableToCSV(table);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);

  // Sanitize filename against directory traversal and special chars
  const baseName = (table.title || filenamePrefix).replace(/[^a-zA-Z0-9_\-\.]/g, '_').slice(0, 80);
  link.setAttribute('download', `${baseName || 'table_export'}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
