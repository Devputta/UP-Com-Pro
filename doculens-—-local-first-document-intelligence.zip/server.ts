import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '30mb' }));

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'doculens-core',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    remoteAiAvailable: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Optional remote model synthesis proxy with citation constraint enforcement
app.post('/api/inquiry', async (req, res) => {
  try {
    const { query, context } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'Missing query parameter' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'Remote model is not configured on server (GEMINI_API_KEY not set). Using local deterministic engine.',
      });
    }

    const ai = new GoogleGenAI({ apiKey });

    const prompt = `You are DocuLens, an editorial research assistant.
Strict requirement: Answer the user's inquiry based SOLELY on the retrieved document excerpts provided below.
Do not hallucinate facts. Every assertion must cite the exact evidence bracket [ev-X].
If the excerpts do not contain the answer, say "The provided excerpts do not contain sufficient evidence."

User Inquiry: ${query}

Retrieved Grounded Excerpts:
${context || 'No excerpts retrieved.'}

Concise Editorial Answer with Citations:`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const answer = response.text || 'Unable to generate synthesis.';
    res.json({ answer, provider: 'gemini-2.5-flash' });
  } catch (err: any) {
    console.error('Inquiry synthesis error:', err);
    res.status(500).json({
      error: 'Remote synthesis failed',
      details: err?.message || String(err),
    });
  }
});

// Mount Vite or static server
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DocuLens server listening on port ${PORT}`);
  });
}

startServer();
