/**
 * DocuLens — Local-First PDF Intelligence Workspace
 * Human-centric minimalist tool for document ingestion,
 * evidence-grounded search, citation-verified inquiries,
 * table extraction, and revision comparison.
 */

import { useState, useEffect, useCallback } from 'react';
import {
  DocumentEntity,
  DocumentElement,
  DocumentChunk,
  DocumentTable,
  InquiryMessage,
  MarginaliaNote,
} from './types/doculens';
import { storage } from './services/storage';
import { generateSampleBundles } from './services/sampleDocuments';
import { parsePDFFile } from './services/pdfParser';

import { Header, ActiveTab } from './components/Header';
import { LibraryView } from './components/LibraryView';
import { ReaderView } from './components/ReaderView';
import { SearchView } from './components/SearchView';
import { InquiryView } from './components/InquiryView';
import { TablesView } from './components/TablesView';
import { CompareView } from './components/CompareView';
import { WorkspaceView } from './components/WorkspaceView';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('library');
  const [documents, setDocuments] = useState<DocumentEntity[]>([]);
  const [elements, setElements] = useState<DocumentElement[]>([]);
  const [chunks, setChunks] = useState<DocumentChunk[]>([]);
  const [tables, setTables] = useState<DocumentTable[]>([]);
  const [inquiries, setInquiries] = useState<InquiryMessage[]>([]);
  const [notes, setNotes] = useState<MarginaliaNote[]>([]);

  const [selectedDocId, setSelectedDocId] = useState<string | undefined>(undefined);
  const [readerTargetPage, setReaderTargetPage] = useState<number>(1);
  const [compareLeftDocId, setCompareLeftDocId] = useState<string | undefined>(undefined);
  const [compareRightDocId, setCompareRightDocId] = useState<string | undefined>(undefined);

  const [isProcessing, setIsProcessing] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Live online / offline detection
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Refresh all state from local storage
  const loadAllData = useCallback(async () => {
    const docs = await storage.getDocuments();

    if (docs.length === 0) {
      // First run: seed curated benchmark documents automatically
      const samples = generateSampleBundles();
      for (const sample of samples) {
        await storage.saveDocument(sample.document);
        await storage.saveElements(sample.elements);
        await storage.saveChunks(sample.chunks);
        await storage.saveTables(sample.tables);
      }
      setDocuments(samples.map((s) => s.document));
      setElements(samples.flatMap((s) => s.elements));
      setChunks(samples.flatMap((s) => s.chunks));
      setTables(samples.flatMap((s) => s.tables));
      setSelectedDocId(samples[0]?.document.id);
    } else {
      setDocuments(docs);
      const allChunks = await storage.getAllChunks();
      const allTables = await storage.getAllTables();
      const allInquiries = await storage.getInquiries();

      setChunks(allChunks);
      setTables(allTables);
      setInquiries(allInquiries);

      // Load elements for active doc or all
      const allElements: DocumentElement[] = [];
      for (const doc of docs) {
        const elList = await storage.getElementsByDocument(doc.id);
        allElements.push(...elList);
      }
      setElements(allElements);

      if (!selectedDocId && docs.length > 0) {
        setSelectedDocId(docs[0].id);
      }
    }
  }, [selectedDocId]);

  // Initial mount
  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Load notes when selectedDocId changes
  useEffect(() => {
    if (selectedDocId) {
      storage.getNotes(selectedDocId).then((n) => setNotes(n));
    }
  }, [selectedDocId]);

  // Handle PDF upload
  const handleUploadFile = async (file: File) => {
    setIsProcessing(true);
    try {
      const parsed = await parsePDFFile(file);
      await storage.saveDocument(parsed.document);
      await storage.saveElements(parsed.elements);
      await storage.saveChunks(parsed.chunks);
      await storage.saveTables(parsed.tables);

      setDocuments((prev) => [parsed.document, ...prev]);
      setElements((prev) => [...parsed.elements, ...prev]);
      setChunks((prev) => [...parsed.chunks, ...prev]);
      setTables((prev) => [...parsed.tables, ...prev]);
      setSelectedDocId(parsed.document.id);
    } finally {
      setIsProcessing(false);
    }
  };

  // Re-seed benchmark documents
  const handleLoadSampleData = async () => {
    setIsProcessing(true);
    try {
      const samples = generateSampleBundles();
      for (const sample of samples) {
        await storage.saveDocument(sample.document);
        await storage.saveElements(sample.elements);
        await storage.saveChunks(sample.chunks);
        await storage.saveTables(sample.tables);
      }
      await loadAllData();
    } finally {
      setIsProcessing(false);
    }
  };

  // Delete document
  const handleDeleteDocument = async (id: string) => {
    await storage.deleteDocument(id);
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    setElements((prev) => prev.filter((e) => e.documentId !== id));
    setChunks((prev) => prev.filter((c) => c.documentId !== id));
    setTables((prev) => prev.filter((t) => t.documentId !== id));
    if (selectedDocId === id) {
      setSelectedDocId(undefined);
    }
  };

  // Navigation helpers
  const handleNavigateToReader = (docId: string, pageNumber: number) => {
    setSelectedDocId(docId);
    setReaderTargetPage(pageNumber);
    setActiveTab('reader');
  };

  const handleSelectForTables = (docId: string) => {
    setSelectedDocId(docId);
    setActiveTab('tables');
  };

  const handleSelectForCompare = (docId: string) => {
    setCompareLeftDocId(docId);
    const other = documents.find((d) => d.id !== docId);
    if (other) setCompareRightDocId(other.id);
    setActiveTab('compare');
  };

  // Note actions
  const handleAddNote = async (noteData: {
    documentId: string;
    pageNumber: number;
    selectedText: string;
    noteText: string;
  }) => {
    const newNote: MarginaliaNote = {
      id: `note-${crypto.randomUUID().slice(0, 8)}`,
      createdAt: Date.now(),
      ...noteData,
    };
    await storage.saveNote(newNote);
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleDeleteNote = async (id: string) => {
    await storage.deleteNote(id);
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  // Inquiry actions
  const handleSaveInquiry = async (msg: InquiryMessage) => {
    await storage.saveInquiry(msg);
    setInquiries((prev) => [...prev, msg]);
  };

  const handleClearInquiries = async () => {
    await storage.clearInquiries();
    setInquiries([]);
  };

  return (
    <div className="min-h-full flex flex-col bg-[#F5F2EB] text-[#20211D]">
      {/* Editorial Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        documents={documents}
        selectedDocId={selectedDocId}
        onSelectDoc={setSelectedDocId}
        isOnline={isOnline}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'library' && (
          <LibraryView
            documents={documents}
            onUploadFile={handleUploadFile}
            onLoadSampleData={handleLoadSampleData}
            onDeleteDocument={handleDeleteDocument}
            onSelectDocumentForReader={(id) => handleNavigateToReader(id, 1)}
            onSelectDocumentForTables={handleSelectForTables}
            onSelectDocumentForCompare={handleSelectForCompare}
            isProcessing={isProcessing}
          />
        )}

        {activeTab === 'reader' && (
          <ReaderView
            documents={documents}
            selectedDocId={selectedDocId}
            onSelectDoc={(id) => setSelectedDocId(id)}
            elements={elements}
            notes={notes}
            onAddNote={handleAddNote}
            onDeleteNote={handleDeleteNote}
            targetPage={readerTargetPage}
          />
        )}

        {activeTab === 'search' && (
          <SearchView
            documents={documents}
            chunks={chunks}
            selectedDocId={selectedDocId}
            onSelectDoc={setSelectedDocId}
            onNavigateToReader={handleNavigateToReader}
          />
        )}

        {activeTab === 'inquiry' && (
          <InquiryView
            documents={documents}
            chunks={chunks}
            selectedDocId={selectedDocId}
            inquiries={inquiries}
            onSaveInquiry={handleSaveInquiry}
            onClearInquiries={handleClearInquiries}
            onNavigateToReader={handleNavigateToReader}
            isOnline={isOnline}
          />
        )}

        {activeTab === 'tables' && (
          <TablesView
            tables={tables}
            documents={documents}
            selectedDocId={selectedDocId}
            onSelectDoc={setSelectedDocId}
            onNavigateToReader={handleNavigateToReader}
          />
        )}

        {activeTab === 'compare' && (
          <CompareView
            documents={documents}
            chunks={chunks}
            initialLeftDocId={compareLeftDocId}
            initialRightDocId={compareRightDocId}
            onNavigateToReader={handleNavigateToReader}
          />
        )}

        {activeTab === 'workspace' && (
          <WorkspaceView
            documentsCount={documents.length}
            chunksCount={chunks.length}
            tablesCount={tables.length}
            inquiriesCount={inquiries.length}
            notesCount={notes.length}
            onRefreshAllData={loadAllData}
            isOnline={isOnline}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#E0D9CC] bg-[#FAF8F5] py-3 text-xs text-[#5C5E55] no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-serif font-semibold text-[#20211D]">DocuLens</span>
            <span>·</span>
            <span>Local-First Document Intelligence</span>
            <span>·</span>
            <span className="font-mono text-[11px] text-[#8E9085]">v1.0.0</span>
          </div>

          <div className="flex items-center gap-3 text-[11px]">
            <span>Privacy-Preserving On-Device Storage</span>
            <span>·</span>
            <span>Zero Remote Telemetry</span>
            <span>·</span>
            <span className="text-[#B84B2F]">Offline Operational</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
