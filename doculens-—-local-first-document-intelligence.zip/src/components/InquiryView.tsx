import React, { useState } from 'react';
import {
  Send,
  ShieldCheck,
  AlertTriangle,
  BookOpen,
  Trash2,
  Cpu,
  Globe,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import {
  DocumentChunk,
  DocumentEntity,
  InquiryMessage,
  CitationEvidence,
} from '../types/doculens';
import { processInquiry } from '../services/inquiryEngine';

interface InquiryViewProps {
  documents: DocumentEntity[];
  chunks: DocumentChunk[];
  selectedDocId?: string;
  inquiries: InquiryMessage[];
  onSaveInquiry: (msg: InquiryMessage) => Promise<void>;
  onClearInquiries: () => Promise<void>;
  onNavigateToReader: (docId: string, pageNumber: number) => void;
  isOnline: boolean;
}

export const InquiryView: React.FC<InquiryViewProps> = ({
  documents,
  chunks,
  selectedDocId,
  inquiries,
  onSaveInquiry,
  onClearInquiries,
  onNavigateToReader,
  isOnline,
}) => {
  const [question, setQuestion] = useState('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [useRemoteAssist, setUseRemoteAssist] = useState(false);
  const [selectedCitation, setSelectedCitation] = useState<CitationEvidence | null>(null);

  const sampleQuestions = [
    {
      q: 'What were the total clean energy investments and battery storage additions in 2025?',
      desc: 'Retrieves solar & battery expenditure figures from Energy Audit',
    },
    {
      q: 'What are the patient eligibility criteria and age ranges in Protocol B-709 Rev 2?',
      desc: 'Retrieves EASI scores, age bounds, and disease duration',
    },
    {
      q: 'Was mild hepatic impairment permitted or excluded in Protocol Revision 3?',
      desc: 'Retrieves the Amendment 1 safety rule on Child-Pugh Class A',
    },
    {
      q: 'What is the nuclear fission capital investment in Brazil?',
      desc: 'Triggers honest Insufficient Evidence status',
    },
  ];

  const handleSubmit = async (e?: React.FormEvent, customQ?: string) => {
    if (e) e.preventDefault();
    const query = customQ || question;
    if (!query.trim() || isSynthesizing) return;

    const userMsg: InquiryMessage = {
      id: `usr-${crypto.randomUUID().slice(0, 8)}`,
      role: 'user',
      content: query.trim(),
      timestamp: Date.now(),
      documentScopeId: selectedDocId,
      evidence: [],
      verificationStatus: 'verified',
      provider: 'local-deterministic',
    };

    await onSaveInquiry(userMsg);
    setQuestion('');
    setIsSynthesizing(true);

    try {
      const responseMsg = await processInquiry(
        query,
        chunks,
        documents,
        selectedDocId,
        useRemoteAssist && isOnline
      );
      await onSaveInquiry(responseMsg);
    } catch (err: any) {
      const errorMsg: InquiryMessage = {
        id: `err-${crypto.randomUUID().slice(0, 8)}`,
        role: 'assistant',
        content: `Error during evidence retrieval: ${err?.message || 'Processing failed'}`,
        timestamp: Date.now(),
        documentScopeId: selectedDocId,
        evidence: [],
        verificationStatus: 'insufficient_evidence',
        provider: 'local-deterministic',
      };
      await onSaveInquiry(errorMsg);
    } finally {
      setIsSynthesizing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E0D9CC] pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
            Grounded Inquiry & Provenance Synthesis
          </h1>
          <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
            Direct answers synthesized exclusively from verified document evidence. Every quote is
            checked byte-for-byte against stored page chunks. If the document does not contain
            facts, the system states insufficient evidence rather than hallucinating.
          </p>
        </div>

        {inquiries.length > 0 && (
          <button
            onClick={onClearInquiries}
            className="flex items-center gap-1.5 text-xs text-[#5C5E55] hover:text-red-700 border border-[#E0D9CC] rounded px-3 py-1.5 bg-[#FAF8F5] transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Inquiry Log</span>
          </button>
        )}
      </div>

      {/* Provider & Disclosure Bar */}
      <div className="p-3 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-medium text-[#20211D]">
            {useRemoteAssist && isOnline ? (
              <Globe className="w-4 h-4 text-[#B84B2F]" />
            ) : (
              <Cpu className="w-4 h-4 text-emerald-700" />
            )}
            <span>
              {useRemoteAssist && isOnline
                ? 'Remote Model Assist (Stylistic Refinement)'
                : '100% Local Deterministic Engine (Offline Default)'}
            </span>
          </div>

          <span className="text-[#8E9085]">·</span>

          <span className="text-[#5C5E55]">
            {useRemoteAssist && isOnline
              ? 'Disclosed: Selected excerpts sent to server model; citations verified locally.'
              : 'Zero data leaves your device. Fully operational offline.'}
          </span>
        </div>

        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={useRemoteAssist}
            onChange={(e) => setUseRemoteAssist(e.target.checked)}
            className="rounded border-[#E0D9CC] text-[#B84B2F] focus:ring-[#B84B2F]"
          />
          <span className="text-xs text-[#5C5E55]">Optional Remote Assist</span>
        </label>
      </div>

      {/* Suggested Inquiries (Button Controls) */}
      <div className="space-y-1.5">
        <span className="text-xs font-semibold uppercase tracking-wider text-[#5C5E55]">
          Curated Benchmark Tests:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {sampleQuestions.map((item, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setQuestion(item.q);
                handleSubmit(undefined, item.q);
              }}
              className="text-left p-2.5 rounded border border-[#E0D9CC] bg-[#FAF8F5] hover:border-[#B84B2F] hover:bg-[#F5F2EB] transition-colors group"
            >
              <div className="text-xs font-serif font-medium text-[#20211D] group-hover:text-[#B84B2F]">
                "{item.q}"
              </div>
              <div className="text-[11px] text-[#8E9085] mt-0.5">{item.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Conversation / Evidence Stream */}
      <div className="space-y-4">
        {inquiries.length === 0 ? (
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55] space-y-2">
            <HelpCircle className="w-8 h-8 mx-auto text-[#8E9085]" />
            <p className="font-serif text-base text-[#20211D]">No inquiries submitted yet</p>
            <p className="text-xs max-w-md mx-auto">
              Ask any specific question regarding facts, measurements, eligibility, or tables in your
              documents.
            </p>
          </div>
        ) : (
          inquiries.map((msg) => (
            <div
              key={msg.id}
              className={`p-5 rounded-lg border transition-colors space-y-3 ${
                msg.role === 'user'
                  ? 'bg-[#FAF8F5] border-[#E0D9CC]'
                  : msg.verificationStatus === 'insufficient_evidence'
                  ? 'bg-amber-50/60 border-amber-200'
                  : 'bg-[#FAF8F5] border-[#C8BFB0]'
              }`}
            >
              {/* Message Header */}
              <div className="flex items-center justify-between text-xs text-[#5C5E55]">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#20211D]">
                    {msg.role === 'user' ? 'Researcher Query' : 'DocuLens Synthesis'}
                  </span>
                  <span className="text-[#8E9085]">·</span>
                  <span className="text-[11px] font-mono">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2">
                    {msg.verificationStatus === 'verified' && (
                      <span className="flex items-center gap-1 text-[11px] text-emerald-800 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Verified Citations</span>
                      </span>
                    )}
                    {msg.verificationStatus === 'insufficient_evidence' && (
                      <span className="flex items-center gap-1 text-[11px] text-amber-800 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>No Grounded Evidence</span>
                      </span>
                    )}
                    <span className="font-mono text-[10px] text-[#8E9085]">
                      [{msg.provider}]
                    </span>
                  </div>
                )}
              </div>

              {/* Message Content */}
              <div className="text-xs sm:text-sm text-[#20211D] leading-relaxed whitespace-pre-wrap font-serif">
                {msg.content}
              </div>

              {/* Verified Evidence Bundles */}
              {msg.evidence && msg.evidence.length > 0 && (
                <div className="pt-2 border-t border-[#E0D9CC] space-y-2">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-[#5C5E55] flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Evidence Citations ({msg.evidence.length} validated):</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {msg.evidence.map((ev) => (
                      <div
                        key={ev.evidenceId}
                        onClick={() => setSelectedCitation(ev)}
                        className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] hover:border-[#B84B2F] rounded text-xs cursor-pointer transition-colors space-y-1.5"
                      >
                        <div className="flex items-center justify-between font-mono text-[11px]">
                          <span className="font-bold text-[#B84B2F]">[{ev.evidenceId}]</span>
                          <span className="text-[#5C5E55]">
                            Page {ev.pageNumber} · {ev.documentName}
                          </span>
                        </div>

                        <p className="font-serif italic text-[#383933] line-clamp-2">
                          "{ev.quote}"
                        </p>

                        <div className="flex items-center justify-between pt-1 border-t border-[#E0D9CC] text-[10px]">
                          <span className="text-emerald-700 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Byte-verified</span>
                          </span>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onNavigateToReader(ev.documentId, ev.pageNumber);
                            }}
                            className="text-[#20211D] hover:text-[#B84B2F] flex items-center gap-0.5 font-medium"
                          >
                            <BookOpen className="w-3 h-3" />
                            <span>Inspect p.{ev.pageNumber}</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        )}

        {isSynthesizing && (
          <div className="p-5 rounded-lg border border-[#E0D9CC] bg-[#FAF8F5] text-xs text-[#5C5E55] flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-[#B84B2F] border-t-transparent rounded-full animate-spin" />
            <span>Retrieving lexical evidence and validating citations...</span>
          </div>
        )}
      </div>

      {/* Inquiry Input Form */}
      <form onSubmit={(e) => handleSubmit(e)} className="sticky bottom-4 pt-2">
        <div className="flex items-stretch gap-2 bg-[#FAF8F5] p-2 border border-[#C8BFB0] rounded-lg shadow-sm">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question grounded in the ingested documents..."
            className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-sm text-[#20211D] placeholder-[#8E9085] focus:outline-none"
          />
          <button
            type="submit"
            disabled={!question.trim() || isSynthesizing}
            className="bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] px-4 py-2 rounded text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-40"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Inquire</span>
          </button>
        </div>
      </form>

      {/* Detailed Citation Modal */}
      {selectedCitation && (
        <div className="fixed inset-0 bg-[#20211D]/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg max-w-lg w-full p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-mono text-xs font-bold text-[#B84B2F]">
                  [{selectedCitation.evidenceId}] Citation Provenance
                </span>
                <h3 className="font-serif font-semibold text-base text-[#20211D] mt-0.5">
                  {selectedCitation.documentName}
                </h3>
              </div>
              <span className="text-xs font-mono text-[#5C5E55]">
                Page {selectedCitation.pageNumber}
              </span>
            </div>

            <div className="p-3 bg-[#F5F2EB] border border-[#E0D9CC] rounded">
              <span className="text-[10px] font-mono text-[#8E9085]">VERBATIM STORED EXCERPT:</span>
              <p className="mt-1 font-serif text-xs sm:text-sm text-[#20211D] leading-relaxed italic">
                "{selectedCitation.quote}"
              </p>
            </div>

            <div className="text-xs text-[#5C5E55] space-y-1 font-mono text-[11px]">
              <div>Chunk Reference: {selectedCitation.chunkId}</div>
              <div className="text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verification: {selectedCitation.verificationDetails}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedCitation(null)}
                className="px-3 py-1.5 text-xs font-medium text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onNavigateToReader(selectedCitation.documentId, selectedCitation.pageNumber);
                  setSelectedCitation(null);
                }}
                className="px-3 py-1.5 text-xs font-medium text-[#F5F2EB] bg-[#20211D] hover:bg-[#383933] rounded flex items-center gap-1"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Open in Reader</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
