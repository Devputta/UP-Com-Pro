import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  Trash2,
  BookOpen,
  Table,
  GitCompare,
  Copy,
  Check,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { DocumentEntity } from '../types/doculens';

interface LibraryViewProps {
  documents: DocumentEntity[];
  onUploadFile: (file: File) => Promise<void>;
  onLoadSampleData: () => Promise<void>;
  onDeleteDocument: (id: string) => Promise<void>;
  onSelectDocumentForReader: (id: string) => void;
  onSelectDocumentForTables: (id: string) => void;
  onSelectDocumentForCompare: (id: string) => void;
  isProcessing: boolean;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  documents,
  onUploadFile,
  onLoadSampleData,
  onDeleteDocument,
  onSelectDocumentForReader,
  onSelectDocumentForTables,
  onSelectDocumentForCompare,
  isProcessing,
}) => {
  const [dragOver, setDragOver] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    setUploadError(null);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      try {
        await onUploadFile(file);
      } catch (err: any) {
        setUploadError(err?.message || 'Failed to process document');
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      try {
        await onUploadFile(file);
      } catch (err: any) {
        setUploadError(err?.message || 'Failed to process document');
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E0D9CC] pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
            Document Library
          </h1>
          <p className="text-xs text-[#5C5E55] mt-1 max-w-xl">
            Ingest PDFs, evaluate cryptographic integrity (SHA-256), and extract element-level
            provenance. All files are parsed and retained locally in your browser storage.
          </p>
        </div>

        {documents.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={onLoadSampleData}
              className="text-xs text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] hover:border-[#C8BFB0] bg-[#FAF8F5] px-3 py-1.5 rounded transition-colors"
            >
              Reload Sample Benchmarks
            </button>
          </div>
        )}
      </div>

      {/* Upload Zone & Benchmark Loader */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`md:col-span-2 border-2 border-dashed rounded-lg p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-[#FAF8F5] ${
            dragOver
              ? 'border-[#B84B2F] bg-[#FAF8F5]'
              : 'border-[#D0C8B8] hover:border-[#B84B2F]/60'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.txt,.md"
            className="hidden"
            aria-label="Upload document file"
          />
          <div className="w-12 h-12 rounded-full bg-[#F5F2EB] border border-[#E0D9CC] flex items-center justify-center text-[#B84B2F] mb-3">
            <Upload className="w-5 h-5" />
          </div>
          <p className="text-sm font-medium text-[#20211D]">
            Drop PDF file here, or <span className="text-[#B84B2F] underline underline-offset-2">browse files</span>
          </p>
          <div className="text-xs text-[#5C5E55] mt-2 flex items-center gap-2 flex-wrap justify-center">
            <span>Standard %PDF- files</span>
            <span aria-hidden="true">·</span>
            <span>Up to 25 MB</span>
            <span aria-hidden="true">·</span>
            <span>Parsed locally with provenance</span>
          </div>

          {isProcessing && (
            <div className="mt-4 flex items-center gap-2 text-xs text-[#B84B2F]">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing layout and extracting elements...</span>
            </div>
          )}
        </div>

        {/* Quick Benchmark Card */}
        <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-[#B84B2F] font-serif font-medium text-sm mb-2">
              <Sparkles className="w-4 h-4" />
              <span>Curated Benchmarks</span>
            </div>
            <p className="text-xs text-[#5C5E55] leading-relaxed">
              Explore immediate functionality without searching for a PDF. Loads real sample audit
              reports and multi-revision clinical trial protocols.
            </p>
            <ul className="text-xs text-[#5C5E55] mt-3 space-y-1.5 list-disc pl-4">
              <li>FY2025 Renewable Energy & Grid Report</li>
              <li>Clinical Protocol B-709 (Revision 2.0)</li>
              <li>Clinical Protocol B-709 (Revision 3.0 Diff)</li>
            </ul>
          </div>

          <button
            onClick={onLoadSampleData}
            disabled={isProcessing}
            className="mt-4 w-full bg-[#20211D] hover:bg-[#383933] text-[#F5F2EB] text-xs font-medium py-2 px-3 rounded transition-colors text-center disabled:opacity-50"
          >
            Load Benchmark Documents
          </button>
        </div>
      </div>

      {uploadError && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Document Records Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-[#5C5E55]">
            Ingested Records ({documents.length})
          </h2>
          <span className="text-xs text-[#5C5E55]">
            Total Storage: {formatBytes(documents.reduce((acc, d) => acc + d.sizeBytes, 0))}
          </span>
        </div>

        {documents.length === 0 ? (
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-10 text-center text-[#5C5E55]">
            <FileText className="w-8 h-8 mx-auto mb-2 text-[#8E9085]" />
            <p className="text-sm font-medium text-[#20211D]">No documents in local repository</p>
            <p className="text-xs mt-1">
              Upload a PDF above or click "Load Benchmark Documents" to begin exploration.
            </p>
          </div>
        ) : (
          <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg overflow-hidden divide-y divide-[#E0D9CC]">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className="p-4 sm:p-5 hover:bg-[#F5F2EB] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-serif font-semibold text-[#20211D] text-base truncate">
                      {doc.originalName}
                    </span>
                    <span className="text-xs text-[#5C5E55]">
                      ({doc.pageCount} page{doc.pageCount > 1 ? 's' : ''})
                    </span>
                    <span className="text-xs text-[#5C5E55]">·</span>
                    <span className="text-xs text-[#5C5E55]">{formatBytes(doc.sizeBytes)}</span>
                    <span className="text-xs text-[#5C5E55]">·</span>
                    <span className="text-xs text-[#5C5E55] font-mono">
                      {doc.elementCount} elements
                    </span>
                    {doc.tableCount > 0 && (
                      <>
                        <span className="text-xs text-[#5C5E55]">·</span>
                        <span className="text-xs text-[#B84B2F] font-medium">
                          {doc.tableCount} table{doc.tableCount > 1 ? 's' : ''}
                        </span>
                      </>
                    )}
                  </div>

                  {/* Summary */}
                  {doc.summary && (
                    <p className="text-xs text-[#5C5E55] line-clamp-2 max-w-3xl leading-relaxed">
                      {doc.summary}
                    </p>
                  )}

                  {/* Cryptographic SHA-256 fingerprint */}
                  <div className="flex items-center gap-2 text-[11px] text-[#5C5E55] pt-1">
                    <span className="font-mono text-[#8E9085]">SHA-256:</span>
                    <span className="font-mono text-[#20211D] truncate max-w-[220px] sm:max-w-md">
                      {doc.sha256}
                    </span>
                    <button
                      onClick={() => copyHash(doc.sha256)}
                      title="Copy SHA-256 checksum"
                      className="text-[#8E9085] hover:text-[#20211D] transition-colors"
                    >
                      {copiedHash === doc.sha256 ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <span className="text-[#8E9085]">·</span>
                    <span className="text-[#8E9085]">
                      Added {new Date(doc.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Document Actions */}
                <div className="flex items-center gap-2 shrink-0 self-start md:self-center">
                  <button
                    onClick={() => onSelectDocumentForReader(doc.id)}
                    title="Read with Provenance Inspector"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-[#B84B2F]" />
                    <span>Reader</span>
                  </button>

                  {doc.tableCount > 0 && (
                    <button
                      onClick={() => onSelectDocumentForTables(doc.id)}
                      title="View & Export Extracted Tables"
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                    >
                      <Table className="w-3.5 h-3.5 text-[#5C5E55]" />
                      <span>Tables</span>
                    </button>
                  )}

                  <button
                    onClick={() => onSelectDocumentForCompare(doc.id)}
                    title="Compare against another revision"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#20211D] bg-[#F5F2EB] hover:bg-[#EAE4D7] border border-[#E0D9CC] rounded transition-colors"
                  >
                    <GitCompare className="w-3.5 h-3.5 text-[#5C5E55]" />
                    <span>Compare</span>
                  </button>

                  <button
                    onClick={() => setConfirmDeleteId(doc.id)}
                    title="Delete document and related data"
                    className="p-1.5 text-[#8E9085] hover:text-red-700 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Modal for Deletion */}
      {confirmDeleteId && (
        <div className="fixed inset-0 bg-[#20211D]/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg max-w-md w-full p-6 shadow-xl space-y-4">
            <h3 className="font-serif font-semibold text-lg text-[#20211D]">
              Confirm Document Removal
            </h3>
            <p className="text-xs text-[#5C5E55] leading-relaxed">
              This will remove the document, parsed chunks, extracted tables, and marginalia notes
              from your local IndexedDB storage. This operation is permanent.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmDeleteId(null)}
                className="px-3 py-1.5 text-xs font-medium text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteDocument(confirmDeleteId);
                  setConfirmDeleteId(null);
                }}
                className="px-3 py-1.5 text-xs font-medium text-white bg-red-700 hover:bg-red-800 rounded transition-colors"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
