import React, { useState, useEffect, useRef } from 'react';
import {
  HardDrive,
  Download,
  Upload,
  Trash2,
  ShieldCheck,
  Cpu,
  Wifi,
  WifiOff,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { storage } from '../services/storage';

interface WorkspaceViewProps {
  documentsCount: number;
  chunksCount: number;
  tablesCount: number;
  inquiriesCount: number;
  notesCount: number;
  onRefreshAllData: () => Promise<void>;
  isOnline: boolean;
}

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  documentsCount,
  chunksCount,
  tablesCount,
  inquiriesCount,
  notesCount,
  onRefreshAllData,
  isOnline,
}) => {
  const [storageUsage, setStorageUsage] = useState<{ usedBytes: number; quotaBytes: number }>({
    usedBytes: 0,
    quotaBytes: 0,
  });
  const [exportMessage, setExportMessage] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const importFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    storage.getStorageEstimate().then((est) => setStorageUsage(est));
  }, [documentsCount, chunksCount]);

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleExportArchive = async () => {
    try {
      const json = await storage.exportFullArchive();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `doculens_workspace_backup_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      setExportMessage('Workspace archive generated and downloaded successfully.');
      setTimeout(() => setExportMessage(null), 3500);
    } catch (e: any) {
      setExportMessage(`Export error: ${e?.message}`);
    }
  };

  const handleImportArchive = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (data.documents && Array.isArray(data.documents)) {
        for (const doc of data.documents) {
          await storage.saveDocument(doc);
        }
      }
      if (data.chunks && Array.isArray(data.chunks)) {
        await storage.saveChunks(data.chunks);
      }
      if (data.tables && Array.isArray(data.tables)) {
        await storage.saveTables(data.tables);
      }
      if (data.inquiries && Array.isArray(data.inquiries)) {
        for (const inq of data.inquiries) {
          await storage.saveInquiry(inq);
        }
      }

      await onRefreshAllData();
      setExportMessage('Archive restored successfully into local IndexedDB.');
      setTimeout(() => setExportMessage(null), 3500);
    } catch (err: any) {
      setExportMessage(`Import failure: ${err?.message || 'Invalid backup JSON file'}`);
    }
    if (importFileRef.current) importFileRef.current.value = '';
  };

  const handleClearAll = async () => {
    try {
      const docs = await storage.getDocuments();
      for (const d of docs) {
        await storage.deleteDocument(d.id);
      }
      await storage.clearInquiries();
      await onRefreshAllData();
      setConfirmClear(false);
      setExportMessage('Local workspace database cleared.');
      setTimeout(() => setExportMessage(null), 3000);
    } catch (e: any) {
      setExportMessage(`Clear failed: ${e?.message}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header */}
      <div className="border-b border-[#E0D9CC] pb-4">
        <h1 className="text-2xl font-serif font-semibold text-[#20211D]">
          Workspace Diagnostics & Offline Storage
        </h1>
        <p className="text-xs text-[#5C5E55] mt-1 max-w-2xl leading-relaxed">
          Inspect browser storage health, export full workspace archives for portability, and
          verify offline security boundaries. All data remains exclusively within client-side
          IndexedDB.
        </p>
      </div>

      {exportMessage && (
        <div className="p-3 bg-[#F5F2EB] border border-[#B84B2F]/40 text-[#20211D] text-xs rounded flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-[#B84B2F]" />
          <span>{exportMessage}</span>
        </div>
      )}

      {/* Storage and Connectivity Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Connection status */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Network Mode</span>
            {isOnline ? (
              <Wifi className="w-4 h-4 text-emerald-700" />
            ) : (
              <WifiOff className="w-4 h-4 text-[#B84B2F]" />
            )}
          </div>
          <div className="text-lg font-serif font-semibold text-[#20211D]">
            {isOnline ? 'Online (Self-Contained)' : 'Completely Offline'}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            No internet required for ingestion, chunking, search, or citation verification.
          </p>
        </div>

        {/* Local Storage Quota */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">IndexedDB Usage</span>
            <HardDrive className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">
            {formatBytes(storageUsage.usedBytes || 120000)}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            Quota available: {formatBytes(storageUsage.quotaBytes || 1073741824)}
          </p>
        </div>

        {/* Provenance Chunks */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Indexed Chunks</span>
            <Cpu className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">{chunksCount}</div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            Across {documentsCount} active document{documentsCount === 1 ? '' : 's'}.
          </p>
        </div>

        {/* Tables & Marginalia */}
        <div className="p-5 bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-[#5C5E55]">
            <span className="font-semibold uppercase tracking-wider">Tables / Notes</span>
            <ShieldCheck className="w-4 h-4 text-[#8E9085]" />
          </div>
          <div className="text-lg font-mono font-semibold text-[#20211D]">
            {tablesCount} / {notesCount}
          </div>
          <p className="text-[11px] text-[#5C5E55] leading-normal">
            {inquiriesCount} grounded inquiry logs saved.
          </p>
        </div>
      </div>

      {/* Backup, Import & Maintenance */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-5">
        <h2 className="text-base font-serif font-semibold text-[#20211D]">
          Portability & Offline Backup
        </h2>
        <p className="text-xs text-[#5C5E55] max-w-xl leading-relaxed">
          Create an offline snapshot containing all documents, extracted tables, and inquiry logs.
          You can transfer this JSON snapshot to another browser or air-gapped machine.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportArchive}
            className="flex items-center gap-1.5 text-xs font-medium text-[#F5F2EB] bg-[#20211D] hover:bg-[#383933] rounded px-4 py-2 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Full JSON Archive</span>
          </button>

          <input
            type="file"
            ref={importFileRef}
            onChange={handleImportArchive}
            accept=".json"
            className="hidden"
            aria-label="Upload JSON workspace backup file"
          />
          <button
            onClick={() => importFileRef.current?.click()}
            className="flex items-center gap-1.5 text-xs font-medium text-[#20211D] border border-[#E0D9CC] hover:bg-[#F5F2EB] rounded px-4 py-2 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Restore Archive From File</span>
          </button>

          <button
            onClick={() => setConfirmClear(true)}
            className="flex items-center gap-1.5 text-xs font-medium text-red-800 border border-red-200 hover:bg-red-50 rounded px-4 py-2 transition-colors ml-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset Local Database</span>
          </button>
        </div>
      </div>

      {/* Architecture & Verification Checklist */}
      <div className="border border-[#E0D9CC] bg-[#FAF8F5] rounded-lg p-6 space-y-4">
        <h2 className="text-base font-serif font-semibold text-[#20211D]">
          DocuLens Security & Provenance Principles
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">1. Local-First Boundary</span>
            <p className="text-[#5C5E55] leading-relaxed">
              Files are processed in-memory or persisted into client-side IndexedDB. No external
              cloud uploads occur by default.
            </p>
          </div>

          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">2. Byte-Level Citations</span>
            <p className="text-[#5C5E55] leading-relaxed">
              Every citation quote in the Inquiry view is verified byte-for-byte against stored
              chunks before rendering.
            </p>
          </div>

          <div className="p-4 bg-[#F5F2EB] border border-[#E0D9CC] rounded space-y-2">
            <span className="font-semibold text-[#20211D] block">3. Formula Injection Defense</span>
            <p className="text-[#5C5E55] leading-relaxed">
              CSV exports escape Excel/Sheets formula prefixes (`=, +, -, @`) with leading single
              quotes to safeguard against macro execution.
            </p>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Reset */}
      {confirmClear && (
        <div className="fixed inset-0 bg-[#20211D]/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#FAF8F5] border border-[#E0D9CC] rounded-lg max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2 text-red-700 font-serif font-semibold text-lg">
              <AlertTriangle className="w-5 h-5" />
              <span>Reset Entire Workspace?</span>
            </div>
            <p className="text-xs text-[#5C5E55] leading-relaxed">
              This will permanently delete all stored documents, chunks, tables, and notes from your
              browser's IndexedDB.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmClear(false)}
                className="px-3 py-1.5 text-xs font-medium text-[#5C5E55] hover:text-[#20211D] border border-[#E0D9CC] rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 text-xs font-medium text-white bg-red-700 hover:bg-red-800 rounded"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
