/**
 * DocuLens Document Comparison & Revision Diff Engine
 * Detects additions, removals, modifications, and unchanged sections
 * with linked page and chunk provenance from both document revisions.
 */

import {
  DocumentEntity,
  DocumentChunk,
  ComparisonResult,
  ComparisonChange,
  DiffChangeType,
} from '../types/doculens';

/**
 * Normalizes text for comparison by removing extra whitespace.
 */
function normalizeForDiff(text: string): string {
  return text.trim().replace(/\s+/g, ' ');
}

/**
 * Calculates string similarity using Levenshtein-based or token Jaccard similarity.
 */
function calculateSimilarity(str1: string, str2: string): number {
  const words1 = new Set(str1.toLowerCase().split(/\s+/));
  const words2 = new Set(str2.toLowerCase().split(/\s+/));

  let intersection = 0;
  for (const w of words1) {
    if (words2.has(w)) intersection++;
  }

  const union = new Set([...words1, ...words2]).size;
  return union === 0 ? 1 : intersection / union;
}

/**
 * Compares two documents by their chunks and structural elements.
 */
export function compareDocuments(
  leftDoc: DocumentEntity,
  rightDoc: DocumentEntity,
  leftChunks: DocumentChunk[],
  rightChunks: DocumentChunk[]
): ComparisonResult {
  const comparisonId = `cmp-${crypto.randomUUID().slice(0, 8)}`;
  const changes: ComparisonChange[] = [];

  const matchedRightChunks = new Set<string>();

  // Iterate through left chunks to find matched, modified, or removed chunks
  for (const leftChunk of leftChunks) {
    const normLeft = normalizeForDiff(leftChunk.text);
    let bestMatch: { chunk: DocumentChunk; similarity: number } | null = null;

    for (const rightChunk of rightChunks) {
      if (matchedRightChunks.has(rightChunk.id)) continue;
      const normRight = normalizeForDiff(rightChunk.text);

      if (normLeft === normRight) {
        bestMatch = { chunk: rightChunk, similarity: 1.0 };
        break;
      }

      const sim = calculateSimilarity(normLeft, normRight);
      if (sim > 0.4 && (!bestMatch || sim > bestMatch.similarity)) {
        bestMatch = { chunk: rightChunk, similarity: sim };
      }
    }

    if (bestMatch && bestMatch.similarity === 1.0) {
      matchedRightChunks.add(bestMatch.chunk.id);
      changes.push({
        id: `chg-${crypto.randomUUID().slice(0, 8)}`,
        type: 'unchanged',
        leftChunkId: leftChunk.id,
        rightChunkId: bestMatch.chunk.id,
        leftPage: leftChunk.pageStart,
        rightPage: bestMatch.chunk.pageStart,
        leftText: leftChunk.text,
        rightText: bestMatch.chunk.text,
        summary: `Identical content across revisions in ${leftChunk.sectionPath.join(' > ') || 'General Section'}`,
        confidence: 1.0,
        sectionPath: leftChunk.sectionPath,
      });
    } else if (bestMatch && bestMatch.similarity >= 0.4) {
      matchedRightChunks.add(bestMatch.chunk.id);
      changes.push({
        id: `chg-${crypto.randomUUID().slice(0, 8)}`,
        type: 'modification',
        leftChunkId: leftChunk.id,
        rightChunkId: bestMatch.chunk.id,
        leftPage: leftChunk.pageStart,
        rightPage: bestMatch.chunk.pageStart,
        leftText: leftChunk.text,
        rightText: bestMatch.chunk.text,
        summary: `Revised content in ${leftChunk.sectionPath.join(' > ') || 'Section'} (${Math.round((1 - bestMatch.similarity) * 100)}% divergence)`,
        confidence: Math.round(bestMatch.similarity * 100) / 100,
        sectionPath: leftChunk.sectionPath,
      });
    } else {
      // Existed in Left but not found in Right -> Removal
      changes.push({
        id: `chg-${crypto.randomUUID().slice(0, 8)}`,
        type: 'removal',
        leftChunkId: leftChunk.id,
        leftPage: leftChunk.pageStart,
        leftText: leftChunk.text,
        summary: `Clause or section removed from revision (${leftChunk.sectionPath.join(' > ') || 'Clause'})`,
        confidence: 0.95,
        sectionPath: leftChunk.sectionPath,
      });
    }
  }

  // Any remaining Right chunks that were never matched are Additions
  for (const rightChunk of rightChunks) {
    if (!matchedRightChunks.has(rightChunk.id)) {
      changes.push({
        id: `chg-${crypto.randomUUID().slice(0, 8)}`,
        type: 'addition',
        rightChunkId: rightChunk.id,
        rightPage: rightChunk.pageStart,
        rightText: rightChunk.text,
        summary: `New section or clause introduced in revision (${rightChunk.sectionPath.join(' > ') || 'New Clause'})`,
        confidence: 0.95,
        sectionPath: rightChunk.sectionPath,
      });
    }
  }

  const stats = {
    added: changes.filter((c) => c.type === 'addition').length,
    removed: changes.filter((c) => c.type === 'removal').length,
    modified: changes.filter((c) => c.type === 'modification').length,
    identical: changes.filter((c) => c.type === 'unchanged').length,
  };

  return {
    id: comparisonId,
    leftDocumentId: leftDoc.id,
    rightDocumentId: rightDoc.id,
    leftDocumentName: leftDoc.originalName,
    rightDocumentName: rightDoc.originalName,
    status: 'ready',
    createdAt: Date.now(),
    changes,
    statistics: stats,
  };
}
