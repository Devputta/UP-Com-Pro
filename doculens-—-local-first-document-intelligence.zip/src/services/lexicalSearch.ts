/**
 * Local-First Lexical Search Engine
 * BM25 / TF-IDF inspired term ranking, exact phrase matching,
 * and contextual quote highlighting. Runs 100% locally and offline.
 */

import { DocumentChunk, DocumentEntity, SearchResult } from '../types/doculens';

const STOP_WORDS = new Set([
  'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
  'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
  'to', 'was', 'were', 'will', 'with'
]);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP_WORDS.has(w));
}

export function searchChunks(
  query: string,
  chunks: DocumentChunk[],
  documents: DocumentEntity[],
  documentScopeId?: string
): SearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) return [];

  // Filter scope
  const targetChunks = documentScopeId
    ? chunks.filter((c) => c.documentId === documentScopeId)
    : chunks;

  const docMap = new Map(documents.map((d) => [d.id, d]));
  const queryTokens = tokenize(trimmed);
  const normalizedQuery = trimmed.toLowerCase();

  const results: SearchResult[] = [];

  for (const chunk of targetChunks) {
    const doc = docMap.get(chunk.documentId);
    if (!doc || doc.status !== 'ready') continue;

    const lowerChunkText = chunk.text.toLowerCase();
    let score = 0;
    const matchedTerms: string[] = [];

    // Exact phrase match bonus
    if (lowerChunkText.includes(normalizedQuery)) {
      score += 50;
      matchedTerms.push(trimmed);
    }

    // Token frequency matching
    for (const token of queryTokens) {
      if (lowerChunkText.includes(token)) {
        // Count occurrences
        const regex = new RegExp(`\\b${token}`, 'gi');
        const matches = lowerChunkText.match(regex);
        const count = matches ? matches.length : 1;
        score += 5 * Math.log(1 + count);
        matchedTerms.push(token);
      }
    }

    if (score > 0) {
      // Build highlights around matching terms
      const highlights: { before: string; match: string; after: string }[] = [];
      const primaryTerm = queryTokens[0] || normalizedQuery;
      const index = lowerChunkText.indexOf(primaryTerm);

      if (index !== -1) {
        const start = Math.max(0, index - 80);
        const end = Math.min(chunk.text.length, index + primaryTerm.length + 80);
        const before = (start > 0 ? '...' : '') + chunk.text.slice(start, index);
        const match = chunk.text.slice(index, index + primaryTerm.length);
        const after = chunk.text.slice(index + primaryTerm.length, end) + (end < chunk.text.length ? '...' : '');
        highlights.push({ before, match, after });
      } else {
        highlights.push({
          before: '',
          match: chunk.text.slice(0, 150),
          after: '...',
        });
      }

      results.push({
        chunk,
        document: doc,
        score,
        matchHighlights: highlights,
        matchedTerms: Array.from(new Set(matchedTerms)),
      });
    }
  }

  // Sort descending by relevance score
  return results.sort((a, b) => b.score - a.score);
}
