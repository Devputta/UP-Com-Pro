/**
 * DocuLens PDF Parser Adapter & Ingestion Pipeline
 * Strict validation (%PDF- signature, byte bounds, SHA-256 checksums),
 * provenance tracking, and chunk segmentation.
 */

import {
  DocumentEntity,
  DocumentElement,
  DocumentChunk,
  DocumentTable,
  ElementType,
} from '../types/doculens';

// Maximum upload limits from requirements
export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB
export const MAX_PAGES_LIMIT = 500;

export interface ParseResult {
  document: DocumentEntity;
  elements: DocumentElement[];
  chunks: DocumentChunk[];
  tables: DocumentTable[];
}

/**
 * Calculates SHA-256 checksum using Web Crypto API.
 */
export async function calculateSHA256(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Validates file signature, mime type, and bounds.
 */
export function validatePDFHeader(buffer: ArrayBuffer): { valid: boolean; error?: string } {
  if (!buffer || buffer.byteLength === 0) {
    return { valid: false, error: 'File is empty (0 bytes)' };
  }
  if (buffer.byteLength > MAX_UPLOAD_BYTES) {
    return {
      valid: false,
      error: `File size exceeds allowable threshold of ${MAX_UPLOAD_BYTES / (1024 * 1024)} MB`,
    };
  }

  // Check PDF magic bytes "%PDF-"
  const headerBytes = new Uint8Array(buffer.slice(0, 5));
  const headerStr = String.fromCharCode(...headerBytes);
  if (!headerStr.startsWith('%PDF-')) {
    // Check if it's text/markdown/plain which we can also safely ingest as a plain doc
    const peekStr = String.fromCharCode(...new Uint8Array(buffer.slice(0, 50)));
    const isPrintable = /^[\x20-\x7E\r\n\t]+$/.test(peekStr);
    if (!isPrintable) {
      return {
        valid: false,
        error: 'Invalid document signature: expected %PDF- or standard UTF-8 text file.',
      };
    }
  }

  return { valid: true };
}

/**
 * Fallback parser for extracting text from text/markdown or stream dumps
 */
function parseTextDocument(
  text: string,
  docId: string
): { elements: DocumentElement[]; tables: DocumentTable[] } {
  const lines = text.split('\n');
  const elements: DocumentElement[] = [];
  const tables: DocumentTable[] = [];

  let currentPage = 1;
  let elementIndex = 1;
  let currentTableHeaders: string[] = [];
  let currentTableRows: string[][] = [];
  let inTable = false;

  const flushTable = () => {
    if (inTable && currentTableHeaders.length > 0) {
      const tableId = `${docId}-tbl-${tables.length + 1}`;
      const sourceElId = `${docId}-el-${elementIndex}`;
      elements.push({
        id: sourceElId,
        documentId: docId,
        type: 'table',
        pageNumber: currentPage,
        content: `Table: ${currentTableHeaders.join(' | ')} (${currentTableRows.length} rows)`,
        sourceElementId: `src_${tableId}`,
      });
      tables.push({
        id: tableId,
        documentId: docId,
        pageNumber: currentPage,
        sourceElementId: sourceElId,
        headers: currentTableHeaders,
        rows: currentTableRows,
      });
      elementIndex++;
      currentTableHeaders = [];
      currentTableRows = [];
      inTable = false;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // Check for explicit page break markers
    if (line.includes('--- Page') || line.includes('=== Page') || line === '---') {
      flushTable();
      currentPage++;
      continue;
    }

    if (!line) {
      flushTable();
      continue;
    }

    // Markdown table detection (| col1 | col2 |)
    if (line.startsWith('|') && line.endsWith('|')) {
      const cells = line
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());
      // Check if separator line
      if (cells.every((c) => /^:?-+:?$/.test(c))) {
        continue;
      }
      if (!inTable) {
        inTable = true;
        currentTableHeaders = cells;
      } else {
        currentTableRows.push(cells);
      }
      continue;
    } else {
      flushTable();
    }

    // Heading detection
    if (line.startsWith('# ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-1',
        pageNumber: currentPage,
        content: line.replace(/^#\s*/, ''),
        headingLevel: 1,
        sourceElementId: `src_h1_${elementIndex}`,
      });
    } else if (line.startsWith('## ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-2',
        pageNumber: currentPage,
        content: line.replace(/^##\s*/, ''),
        headingLevel: 2,
        sourceElementId: `src_h2_${elementIndex}`,
      });
    } else if (line.startsWith('### ')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'heading-3',
        pageNumber: currentPage,
        content: line.replace(/^###\s*/, ''),
        headingLevel: 3,
        sourceElementId: `src_h3_${elementIndex}`,
      });
    } else if (line.startsWith('* ') || line.startsWith('- ') || /^\d+\.\s/.test(line)) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'list-item',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_li_${elementIndex}`,
      });
    } else if (line.toLowerCase().startsWith('footnote') || line.startsWith('[^')) {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'footnote',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_fn_${elementIndex}`,
      });
    } else {
      elements.push({
        id: `${docId}-el-${elementIndex++}`,
        documentId: docId,
        type: 'paragraph',
        pageNumber: currentPage,
        content: line,
        sourceElementId: `src_p_${elementIndex}`,
      });
    }
  }

  flushTable();
  return { elements, tables };
}

/**
 * Parses a PDF using pdfjs-dist with fallback.
 */
export async function parsePDFFile(
  file: File | { name: string; buffer: ArrayBuffer }
): Promise<ParseResult> {
  const buffer = 'buffer' in file ? file.buffer : await file.arrayBuffer();
  const originalName = file.name;
  const sizeBytes = buffer.byteLength;

  // Validation
  const validation = validatePDFHeader(buffer);
  if (!validation.valid) {
    throw new Error(validation.error || 'Failed document validation');
  }

  const sha256 = await calculateSHA256(buffer);
  const docId = `doc-${crypto.randomUUID().slice(0, 8)}`;
  const storedPath = `local://doculens/storage/${docId}-${originalName.replace(/\s+/g, '_')}`;

  let elements: DocumentElement[] = [];
  let tables: DocumentTable[] = [];
  let pageCount = 1;

  try {
    // Dynamically load pdfjs-dist
    const pdfjs = await import('pdfjs-dist');
    // Configure worker
    if (typeof window !== 'undefined' && !pdfjs.GlobalWorkerOptions.workerSrc) {
      pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version || '4.0.379'}/pdf.worker.min.mjs`;
    }

    const loadingTask = pdfjs.getDocument({
      data: new Uint8Array(buffer),
      useSystemFonts: true,
    });

    const pdf = await loadingTask.promise;
    pageCount = Math.min(pdf.numPages, MAX_PAGES_LIMIT);

    let elementIndex = 1;

    for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      const viewport = page.getViewport({ scale: 1.0 });

      const items = textContent.items as Array<{
        str: string;
        transform: number[];
        width: number;
        height: number;
      }>;

      // Group items by vertical position into lines
      const lineMap = new Map<number, string[]>();
      for (const item of items) {
        if (!item.str || !item.str.trim()) continue;
        // transform[5] is the Y-coordinate
        const yBucket = Math.round(item.transform[5] / 4) * 4;
        if (!lineMap.has(yBucket)) {
          lineMap.set(yBucket, []);
        }
        lineMap.get(yBucket)!.push(item.str);
      }

      // Sort lines top to bottom (descending Y in PDF coordinates)
      const sortedY = Array.from(lineMap.keys()).sort((a, b) => b - a);

      for (const y of sortedY) {
        const textPieces = lineMap.get(y) || [];
        const lineText = textPieces.join(' ').trim();
        if (!lineText) continue;

        let elType: ElementType = 'paragraph';
        let headingLevel: number | undefined;

        // Bounding box estimation normalized (0 - 100)
        const normY = Math.max(0, Math.min(100, Math.round(((viewport.height - y) / viewport.height) * 100)));
        const bbox: [number, number, number, number] = [10, normY, 80, 5];

        if (
          lineText.length < 80 &&
          (lineText === lineText.toUpperCase() || lineText.startsWith('Chapter') || lineText.startsWith('Section')) &&
          !lineText.endsWith('.')
        ) {
          elType = 'heading-1';
          headingLevel = 1;
        } else if (lineText.length < 100 && /^[0-9]\.[0-9]/.test(lineText)) {
          elType = 'heading-2';
          headingLevel = 2;
        } else if (normY > 90 || lineText.toLowerCase().startsWith('footnote')) {
          elType = 'footnote';
        }

        elements.push({
          id: `${docId}-el-${elementIndex++}`,
          documentId: docId,
          type: elType,
          pageNumber: pageNum,
          content: lineText,
          headingLevel,
          bbox,
          sourceElementId: `src_p${pageNum}_e${elementIndex}`,
        });
      }
    }
  } catch (pdfErr) {
    console.warn('PDF.js binary decode fallback triggered:', pdfErr);
    // Fallback: decode raw text content from buffer
    const decoder = new TextDecoder('utf-8', { fatal: false });
    const rawText = decoder.decode(buffer);
    const textOnly = rawText.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, ' ');
    const parsed = parseTextDocument(textOnly, docId);
    elements = parsed.elements;
    tables = parsed.tables;
    pageCount = Math.max(1, Math.max(...elements.map((e) => e.pageNumber), 1));
  }

  // If elements are too sparse or empty, create default readable paragraphs
  if (elements.length === 0) {
    elements.push({
      id: `${docId}-el-1`,
      documentId: docId,
      type: 'paragraph',
      pageNumber: 1,
      content: `Extracted content from ${originalName} (file size ${Math.round(sizeBytes / 1024)} KB).`,
      sourceElementId: 'src_fallback_1',
    });
  }

  // Segment elements into provenance-aware chunks (~1,800 chars target)
  const chunks = createProvenanceChunks(elements, docId);

  // Document summary preview
  const previewText = elements
    .slice(0, 4)
    .map((e) => e.content)
    .join(' ');
  const summary = previewText.length > 250 ? `${previewText.slice(0, 247)}...` : previewText;

  const document: DocumentEntity = {
    id: docId,
    originalName,
    storedPath,
    sha256,
    sizeBytes,
    pageCount,
    status: 'ready',
    parserName: 'DocuLens-PDF-Adapter',
    parserVersion: '1.0.0',
    createdAt: Date.now(),
    processedAt: Date.now(),
    summary,
    elementCount: elements.length,
    chunkCount: chunks.length,
    tableCount: tables.length,
  };

  return {
    document,
    elements,
    chunks,
    tables,
  };
}

/**
 * Creates provenance-aware chunks adhering to size boundaries (~1,800 chars, max ~2,600).
 */
export function createProvenanceChunks(
  elements: DocumentElement[],
  documentId: string
): DocumentChunk[] {
  const chunks: DocumentChunk[] = [];
  const TARGET_CHUNK_CHARS = 1600;
  const MAX_CHUNK_CHARS = 2400;

  let currentText = '';
  let currentElementIds: string[] = [];
  let pageStart = 1;
  let pageEnd = 1;
  let currentSectionPath: string[] = [];
  let chunkIndex = 1;

  for (const el of elements) {
    if (el.type.startsWith('heading')) {
      currentSectionPath = [el.content];
    }

    const prospectiveLength = currentText.length + el.content.length + 2;

    if (prospectiveLength > MAX_CHUNK_CHARS && currentText.length > 0) {
      // Flush current chunk
      chunks.push({
        id: `${documentId}-chk-${chunkIndex++}`,
        documentId,
        text: currentText.trim(),
        pageStart,
        pageEnd,
        elementIds: [...currentElementIds],
        sectionPath: [...currentSectionPath],
        searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
      });

      // Reset for next chunk
      currentText = `${el.content}\n\n`;
      currentElementIds = [el.id];
      pageStart = el.pageNumber;
      pageEnd = el.pageNumber;
    } else {
      if (currentText.length === 0) {
        pageStart = el.pageNumber;
      }
      currentText += `${el.content}\n\n`;
      currentElementIds.push(el.id);
      pageEnd = el.pageNumber;

      if (currentText.length >= TARGET_CHUNK_CHARS) {
        chunks.push({
          id: `${documentId}-chk-${chunkIndex++}`,
          documentId,
          text: currentText.trim(),
          pageStart,
          pageEnd,
          elementIds: [...currentElementIds],
          sectionPath: [...currentSectionPath],
          searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
        });
        currentText = '';
        currentElementIds = [];
      }
    }
  }

  if (currentText.trim().length > 0) {
    chunks.push({
      id: `${documentId}-chk-${chunkIndex++}`,
      documentId,
      text: currentText.trim(),
      pageStart,
      pageEnd,
      elementIds: [...currentElementIds],
      sectionPath: [...currentSectionPath],
      searchText: currentText.toLowerCase().replace(/[^a-z0-9\s]/g, ' '),
    });
  }

  return chunks;
}
