/**
 * DocuLens Table Extraction & CSV Security Sanitizer
 * Implements strict Formula Injection Mitigation (RFC-4180 compliant)
 * Escapes '=', '+', '-', '@', '\t', '\r' to prevent spreadsheet macro exploits.
 */

import { DocumentTable } from '../types/doculens';

/**
 * Sanitizes a single cell value against CSV formula injection.
 * Escapes malicious spreadsheet formula execution while preserving valid numbers.
 */
export function sanitizeCSVCell(value: string | number | undefined | null): string {
  if (value === null || value === undefined) return '';
  const str = String(value).trim();
  if (str === '') return '';

  // Check if it's a legitimate number (e.g., "-12.5" or "+4.2" or "390")
  const isPureNumber = /^[+-]?\d+(\.\d+)?$/.test(str);
  if (isPureNumber) {
    return str;
  }

  // Dangerous prefixes that trigger formula execution in Excel/Sheets/Calc
  const dangerousPrefixes = ['=', '+', '-', '@', '\t', '\r'];
  const firstChar = str.charAt(0);

  let sanitized = str;
  if (dangerousPrefixes.includes(firstChar)) {
    // Prepend single quote to force spreadsheet programs to treat as text
    sanitized = `'${str}`;
  }

  // RFC-4180 CSV escaping: if contains quote, comma, or newline, escape quotes and wrap
  if (sanitized.includes('"') || sanitized.includes(',') || sanitized.includes('\n') || sanitized.includes('\r')) {
    return `"${sanitized.replace(/"/g, '""')}"`;
  }

  return sanitized;
}

/**
 * Converts a DocumentTable to a secure CSV string.
 */
export function exportTableToCSV(table: DocumentTable): string {
  const lines: string[] = [];

  // Title comment if present
  if (table.title) {
    lines.push(`# ${table.title.replace(/[\r\n]/g, ' ')}`);
  }

  // Header row
  const headerLine = table.headers.map((h) => sanitizeCSVCell(h)).join(',');
  lines.push(headerLine);

  // Data rows
  for (const row of table.rows) {
    const rowLine = row.map((cell) => sanitizeCSVCell(cell)).join(',');
    lines.push(rowLine);
  }

  return lines.join('\r\n');
}

/**
 * Computes numeric stats for a column if numerical.
 */
export function analyzeColumn(values: string[]): {
  isNumeric: boolean;
  count: number;
  min?: number;
  max?: number;
  average?: number;
  sum?: number;
} {
  const numericValues = values
    .map((v) => parseFloat(v.replace(/[^0-9.-]/g, '')))
    .filter((n) => !isNaN(n));

  if (numericValues.length >= values.length * 0.6 && numericValues.length > 0) {
    const sum = numericValues.reduce((acc, val) => acc + val, 0);
    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const average = sum / numericValues.length;

    return {
      isNumeric: true,
      count: values.length,
      min: Math.round(min * 100) / 100,
      max: Math.round(max * 100) / 100,
      average: Math.round(average * 100) / 100,
      sum: Math.round(sum * 100) / 100,
    };
  }

  return {
    isNumeric: false,
    count: values.length,
  };
}

/**
 * Triggers safe client-side CSV download.
 */
export function downloadCSVFile(table: DocumentTable, filenamePrefix = 'doculens_table'): void {
  const csvContent = exportTableToCSV(table);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const cleanName = (table.title || filenamePrefix).replace(/[^a-zA-Z0-9_-]/g, '_');
  link.setAttribute('download', `${cleanName}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
