/**
 * DocuLens - Local-First PDF Intelligence Data Contracts
 * Strict adherence to provenance, element-level references, and verification.
 */

export type DocumentStatus = 'queued' | 'processing' | 'ready' | 'failed';

export type ElementType = 
  | 'heading-1' 
  | 'heading-2' 
  | 'heading-3' 
  | 'paragraph' 
  | 'table' 
  | 'list-item' 
  | 'footnote' 
  | 'callout';

export interface DocumentElement {
  id: string;
  documentId: string;
  type: ElementType;
  pageNumber: number; // 1-indexed
  content: string;
  headingLevel?: number;
  bbox?: [number, number, number, number]; // [x, y, width, height] normalized (0-100) or pts
  sourceElementId: string;
}

export interface DocumentChunk {
  id: string;
  documentId: string;
  text: string;
  pageStart: number;
  pageEnd: number;
  elementIds: string[];
  sectionPath: string[];
  searchText: string;
}

export interface DocumentTable {
  id: string;
  documentId: string;
  pageNumber: number;
  sourceElementId: string;
  title?: string;
  headers: string[];
  rows: string[][];
  warnings?: string[];
}

export interface DocumentEntity {
  id: string;
  originalName: string;
  storedPath: string;
  sha256: string;
  sizeBytes: number;
  pageCount: number;
  status: DocumentStatus;
  parserName: string;
  parserVersion: string;
  createdAt: number;
  processedAt?: number;
  errorCode?: string;
  errorMessage?: string;
  summary?: string;
  elementCount: number;
  chunkCount: number;
  tableCount: number;
}

export interface CitationEvidence {
  evidenceId: string;
  documentId: string;
  documentName: string;
  pageNumber: number;
  chunkId: string;
  quote: string;
  sourceElementIds: string[];
  verified: boolean;
  verificationDetails?: string;
}

export interface InquiryMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  documentScopeId?: string; // specific doc ID or undefined for all
  evidence: CitationEvidence[];
  verificationStatus: 'verified' | 'unverified' | 'insufficient_evidence';
  provider: 'local-deterministic' | 'remote-disclosed';
}

export type DiffChangeType = 'addition' | 'removal' | 'modification' | 'unchanged';

export interface ComparisonChange {
  id: string;
  type: DiffChangeType;
  leftChunkId?: string;
  rightChunkId?: string;
  leftPage?: number;
  rightPage?: number;
  leftText?: string;
  rightText?: string;
  summary: string;
  confidence: number;
  sectionPath?: string[];
}

export interface ComparisonResult {
  id: string;
  leftDocumentId: string;
  rightDocumentId: string;
  leftDocumentName: string;
  rightDocumentName: string;
  status: 'processing' | 'ready' | 'failed';
  createdAt: number;
  changes: ComparisonChange[];
  statistics: {
    added: number;
    removed: number;
    modified: number;
    identical: number;
  };
}

export interface MarginaliaNote {
  id: string;
  documentId: string;
  pageNumber: number;
  selectedText: string;
  noteText: string;
  createdAt: number;
  author?: string;
}

export interface SearchResult {
  chunk: DocumentChunk;
  document: DocumentEntity;
  score: number;
  matchHighlights: { before: string; match: string; after: string }[];
  matchedTerms: string[];
}
