# DocuLens — Document Intelligence Platform

**Blueprint v1.0 · Advanced MVP · Local-first + optional remote AI**

DocuLens lets users upload PDFs, ask evidence-grounded questions with page citations, extract tables, and compare documents.

## MVP
- PDF upload, validation, status, and deletion
- Structured extraction through an OpenDataLoader PDF adapter
- Search with document/page/element provenance
- AI chat with server-validated citations
- Table preview and CSV export
- Two-document comparison with evidence for each change
- Local-only operation remains useful without an AI API key

## Stack
- Frontend: React + TypeScript + Vite
- Backend: Python + FastAPI
- PDF parser: OpenDataLoader PDF
- Retrieval: local lexical baseline first; optional embeddings + FAISS later
- Metadata: SQLite
- Tests: pytest + HTTPX; Vitest + React Testing Library

## Quick start
Requires Python 3.10+ and Node 18+. Java 11+ and `opendataloader-pdf` are optional and give better tables and structure.

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"             # add ,opendataloader for the full parser
cp ../.env.example .env             # optional; defaults work for local-only use
python -m app.doctor                # checks Python, packages, Java, data folder, parser, AI mode
uvicorn app.main:app --reload       # http://127.0.0.1:8000/api/health

cd ../frontend
npm install && npm run dev          # http://localhost:5173
```

Configuration comes from `backend/.env`; real environment variables override it. A relative `DOCULENS_DATA_DIR` is resolved against `backend/`, so your data lands in the same place wherever you launch from. Remote AI stays off unless `DOCULENS_REMOTE_AI_ENABLED=true` and a provider, key, model and `https://` URL are all set (plain `http://` is accepted only for localhost models).

Tests: `cd backend && pytest` runs everything (needs the dev extras). Without pytest or FastAPI, `python -m unittest discover -s tests/unit -t . && python -m unittest discover -s tests/integration -t .` runs the core suite; `tests/api` needs pytest, fastapi and httpx. Frontend: `cd frontend && npm test`.

Without OpenDataLoader the app falls back to a pure-Python parser that estimates headings and detects tables from text alignment; it works on simple digital PDFs but is less reliable than OpenDataLoader on complex layouts. Without an AI key, answers are passages extracted directly from your documents.

## Status
See `docs/phase.md` for what has and has not been verified.

## Setup plan
Read `docs/requirements.md`, `docs/architecture.md`, `docs/design.md`, `docs/rules.md`, `docs/security.md`, and follow `docs/phase.md`. Daily coding prompts are in `docs/implementation-prompts.md`.

## Design
A research desk, not a generic AI dashboard: warm paper, charcoal, one burnt-orange accent, left-aligned typography, purposeful asymmetry, restrained borders, functional interaction, and deliberately designed mobile layouts.

## Important
Treat the parser as a replaceable adapter. Upstream currently states OpenDataLoader PDF v2.0+ uses Apache-2.0; verify the exact installed release and notices. Its parser “hybrid mode” is distinct from DocuLens's optional remote-LLM architecture. Do not send documents to remote providers without explicit disclosure.

₹0 is a development target using local tools and optional free quotas, not a guarantee of free hosted production.
