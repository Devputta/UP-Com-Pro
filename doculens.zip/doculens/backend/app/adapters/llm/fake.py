"""Deterministic extractive provider used locally and in tests. Makes no network calls."""
from __future__ import annotations

from app.adapters.llm.base import EvidenceItem, ModelAnswer
from app.services.text import excerpt


class FakeLLMProvider:
    name = "local-extractive"
    is_remote = False

    def __init__(self, scripted: ModelAnswer | None = None):
        self._scripted = scripted

    def answer(self, question: str, evidence: list[EvidenceItem]) -> ModelAnswer:
        if self._scripted is not None:
            return self._scripted
        top = evidence[:2]
        text = " ".join(f"{excerpt(e.text, 220)} [p. {e.page}]" for e in top)
        return ModelAnswer(answer=text, cited_chunk_ids=[e.chunk_id for e in top])
