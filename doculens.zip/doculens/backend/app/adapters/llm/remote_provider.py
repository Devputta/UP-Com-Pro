"""Optional OpenAI-compatible chat-completions provider. Opt-in only; keys stay on the backend."""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from app.adapters.llm.base import (
    SYSTEM_PROMPT,
    EvidenceItem,
    ModelAnswer,
    ProviderError,
    build_user_prompt,
)

MAX_OUTPUT_TOKENS = 600
TIMEOUT_SECONDS = 30


class RemoteProvider:
    is_remote = True

    def __init__(self, name: str, api_key: str, model: str, base_url: str):
        self.name = name or "remote"
        self._key = api_key
        self._model = model
        self._url = base_url.rstrip("/") + "/chat/completions"

    def answer(self, question: str, evidence: list[EvidenceItem]) -> ModelAnswer:
        payload = {
            "model": self._model,
            "max_tokens": MAX_OUTPUT_TOKENS,
            "temperature": 0,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": build_user_prompt(question, evidence)},
            ],
        }
        req = urllib.request.Request(
            self._url,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self._key}"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:  # noqa: S310
                body = json.loads(resp.read(1_000_000))
            content = body["choices"][0]["message"]["content"]
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, ValueError):
            raise ProviderError("The AI provider is unavailable or returned an unreadable reply.")
        return parse_model_output(content)


def parse_model_output(content: str) -> ModelAnswer:
    content = (content or "").strip()
    if content.startswith("```"):
        content = content.strip("`").removeprefix("json").strip()
    try:
        data = json.loads(content)
        answer = str(data["answer"])
        cites = [str(c) for c in data.get("citations", []) if isinstance(c, (str, int))]
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ProviderError("The AI provider returned an unreadable reply.")
    return ModelAnswer(answer=answer[:4000], cited_chunk_ids=cites[:20])
