"""Parser interface. DocuLens depends on this, never on a specific parser."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from app.services.models import Element


class ParserError(Exception):
    """Carries a safe error code from app.core.errors.MESSAGES. Never a path or traceback."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass
class ParseResult:
    parser_name: str
    parser_version: str
    page_count: int
    elements: list[Element]
    markdown: str = ""
    warnings: list[str] = field(default_factory=list)


class PdfParser(Protocol):
    name: str

    def parse(self, pdf_path: Path, document_id: str, timeout_seconds: int) -> ParseResult: ...
