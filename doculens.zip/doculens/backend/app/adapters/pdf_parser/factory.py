from __future__ import annotations

from app.adapters.pdf_parser.base import PdfParser
from app.adapters.pdf_parser.opendataloader import OpenDataLoaderParser
from app.adapters.pdf_parser.pypdf_parser import PypdfParser


def get_parser() -> PdfParser:
    """Prefer OpenDataLoader (structure + tables); fall back to pypdf (text only)."""
    return OpenDataLoaderParser() if OpenDataLoaderParser.available() else PypdfParser()
