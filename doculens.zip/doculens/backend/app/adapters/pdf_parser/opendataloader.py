"""OpenDataLoader PDF adapter. Requires `pip install opendataloader-pdf` and Java 11+.

NOTE: written against the upstream documented `opendataloader_pdf.convert(...)` entry point.
It has NOT been run in the authoring environment (no network). Verify the call signature and
JSON keys against the version you install, and adjust `_normalise_node` if they differ.
"""
from __future__ import annotations

import json
import shutil
import subprocess  # noqa: F401 - reserved for CLI fallback
import tempfile
import uuid
from pathlib import Path

from app.adapters.pdf_parser.base import ParseResult, ParserError
from app.services.models import Element


class OpenDataLoaderParser:
    name = "opendataloader-pdf"

    @staticmethod
    def available() -> bool:
        try:
            import opendataloader_pdf  # noqa: F401
        except ImportError:
            return False
        return shutil.which("java") is not None

    def parse(self, pdf_path: Path, document_id: str, timeout_seconds: int) -> ParseResult:
        try:
            import opendataloader_pdf
        except ImportError:
            raise ParserError("parser_unavailable")
        if shutil.which("java") is None:
            raise ParserError("parser_unavailable")
        with tempfile.TemporaryDirectory(prefix="doculens-odl-") as tmp:
            try:
                opendataloader_pdf.convert(input_path=[str(pdf_path)], output_dir=tmp, format="json,markdown")
            except Exception:  # noqa: BLE001 - upstream error types are not stable; map to safe code
                raise ParserError("parser_failed")
            json_files = sorted(Path(tmp).rglob("*.json"))
            if not json_files:
                raise ParserError("parser_failed")
            if json_files[0].stat().st_size > 50 * 1024 * 1024:
                raise ParserError("parser_failed")
            data = json.loads(json_files[0].read_text(encoding="utf-8"))
            md_files = sorted(Path(tmp).rglob("*.md"))
            markdown = md_files[0].read_text(encoding="utf-8") if md_files else ""
        elements: list[Element] = []
        self._walk(data.get("kids", []), document_id, elements)
        if not any(e.content.strip() or e.table_rows for e in elements):
            raise ParserError("no_text")
        pages = int(data.get("number of pages") or max((e.page_number for e in elements), default=1))
        version = str(data.get("version", "unknown"))
        return ParseResult(self.name, version, pages, elements, markdown)

    def _walk(self, nodes: list, document_id: str, out: list[Element]) -> None:
        for node in nodes:
            if not isinstance(node, dict):
                continue
            kind = str(node.get("type", "")).lower()
            if kind == "table":
                rows = [
                    [str(c.get("content", "")) for c in row.get("cells", [])]
                    for row in node.get("rows", [])
                ]
                out.append(self._el(node, document_id, "table", "", rows))
            elif kind in {"heading", "paragraph", "caption"}:
                etype = "heading" if kind == "heading" else "paragraph"
                el = self._el(node, document_id, etype, str(node.get("content", "")))
                if etype == "heading":
                    el.heading_level = int(node.get("heading level") or 1)
                out.append(el)
            elif kind in {"list", "list item"}:
                out.append(self._el(node, document_id, "list", str(node.get("content", ""))))
            for key in ("kids", "list items"):
                if isinstance(node.get(key), list):
                    self._walk(node[key], document_id, out)

    @staticmethod
    def _el(node: dict, document_id: str, etype: str, content: str, rows=None) -> Element:
        bbox = node.get("bounding box")
        return Element(
            id=str(uuid.uuid4()),
            document_id=document_id,
            type=etype,
            page_number=int(node.get("page number") or 1),
            content=content,
            bounding_box=[float(x) for x in bbox] if isinstance(bbox, list) else None,
            source_element_id=str(node["id"]) if "id" in node else None,
            table_rows=rows,
        )
