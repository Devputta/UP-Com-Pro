"""Pure-Python fallback parser (text, with alignment-based table detection). Used when OpenDataLoader/Java is absent
and for tests. Structure is inferred from font size and vertical spacing, which is heuristic:
expect weaker headings than a real layout parser."""
from __future__ import annotations

import re
import statistics
import uuid
from collections import Counter
from pathlib import Path

from app.adapters.pdf_parser.base import ParseResult, ParserError
from app.services.models import Element

_HEADING = re.compile(r"^(?:\d+(?:\.\d+)*[.)]?\s+)?[A-Z0-9][^.!?;:]{1,70}$")


def _version() -> str:
    try:
        import pypdf

        return pypdf.__version__
    except Exception:  # noqa: BLE001 - version lookup must never break parsing
        return "unknown"


def _page_lines(page) -> list[tuple[float, float, list[tuple[float, str]]]]:
    """Return (y, font_size, cells) rows top-to-bottom. A cell is (x, text); fragments that
    sit close together are merged, widely separated ones stay separate cells (table columns)."""
    segs: list[tuple[float, float, float, str]] = []

    def visitor(text, cm, tm, font_dict, font_size):
        if text and text.strip():
            y = tm[5] * (cm[3] if cm and cm[3] else 1) + (cm[5] if cm else 0)
            x = tm[4] * (cm[0] if cm and cm[0] else 1) + (cm[4] if cm else 0)
            segs.append((round(y, 1), round(x, 1), round(float(font_size or 0), 1), text))

    page.extract_text(visitor_text=visitor)
    rows: list[list] = []  # [y, size, [(x, text, size)]]
    for y, x, size, text in segs:
        if rows and abs(rows[-1][0] - y) < 1.0:
            rows[-1][1] = max(rows[-1][1], size)
            rows[-1][2].append((x, text, size))
        else:
            rows.append([y, size, [(x, text, size)]])
    out = []
    for y, size, parts in rows:
        parts.sort(key=lambda p: p[0])
        cells: list[list] = []
        for x, text, sz in parts:
            if cells:
                px, ptext, psz = cells[-1]
                end = px + len(ptext) * psz * 0.5
                if x - end < max(sz, 1) * 1.5:  # same run of text
                    cells[-1][1] = ptext + text
                    continue
            cells.append([x, text, sz])
        cleaned = [(c[0], " ".join(c[1].split())) for c in cells if c[1].strip()]
        if cleaned:
            out.append((y, size, cleaned))
    out.sort(key=lambda r: -r[0])
    return out


def _split_runs(rows):
    """Split rows into ('text', rows) and ('table', rows) runs. A table is >= 2 consecutive rows
    with >= 2 cells each and a consistent column count."""
    runs: list[tuple[str, list]] = []
    i = 0
    while i < len(rows):
        if len(rows[i][2]) >= 2:
            j = i
            width = len(rows[i][2])
            while j + 1 < len(rows) and len(rows[j + 1][2]) >= 2 and abs(len(rows[j + 1][2]) - width) <= 1:
                j += 1
            if j > i:
                runs.append(("table", rows[i : j + 1]))
                i = j + 1
                continue
        if runs and runs[-1][0] == "text":
            runs[-1][1].append(rows[i])
        else:
            runs.append(("text", [rows[i]]))
        i += 1
    return runs


def _table_matrix(rows) -> list[list[str]]:
    """Align cells to columns by x position. Missing cells stay empty, never guessed."""
    xs: list[float] = []
    for _, _, cells in rows:
        for x, _t in cells:
            if not any(abs(x - c) < 12 for c in xs):
                xs.append(x)
    xs.sort()
    matrix = []
    for _, _, cells in rows:
        row = [""] * len(xs)
        for x, text in cells:
            idx = min(range(len(xs)), key=lambda k: abs(xs[k] - x))
            row[idx] = (row[idx] + " " + text).strip()
        matrix.append(row)
    return matrix


def _group(lines) -> list[tuple[str, bool]]:
    """Group lines into (text, is_heading) blocks."""
    if not lines:
        return []
    lines = [(y, sz, " ".join(t for _, t in cells)) for y, sz, cells in lines]
    sizes = Counter()
    for _, sz, t in lines:
        sizes[sz] += len(t)
    body_size = sizes.most_common(1)[0][0]
    gaps = [lines[i][0] - lines[i + 1][0] for i in range(len(lines) - 1) if lines[i][1] == body_size]
    body_gap = statistics.median(gaps) if gaps else 14.0
    blocks: list[tuple[str, bool]] = []
    cur: list[str] = []

    def flush():
        if cur:
            blocks.append((" ".join(cur), False))
            cur.clear()

    for i, (y, sz, text) in enumerate(lines):
        words = len(text.split())
        nxt_longer = i + 1 < len(lines) and len(lines[i + 1][2]) > len(text)
        looks_heading = (
            words <= 10 and bool(_HEADING.match(text)) and not text.endswith((",", ";"))
            and (sz > body_size * 1.1 or (nxt_longer or i + 1 == len(lines)))
            and (sz > body_size * 1.1 or not cur or (lines[i - 1][0] - y) > body_gap * 0.9)
        )
        gap_before = (lines[i - 1][0] - y) if i else 0
        if looks_heading:
            flush()
            blocks.append((text, True))
        else:
            if cur and gap_before > body_gap * 1.6:
                flush()
            cur.append(text)
    flush()
    return blocks


class PypdfParser:
    name = "pypdf-fallback"

    def parse(self, pdf_path: Path, document_id: str, timeout_seconds: int) -> ParseResult:
        from pypdf import PdfReader
        from pypdf.errors import PdfReadError

        elements: list[Element] = []
        try:
            reader = PdfReader(str(pdf_path))
            if reader.is_encrypted:
                raise ParserError("encrypted")
            pages = list(reader.pages)
            for page_no, page in enumerate(pages, start=1):
                for kind, run in _split_runs(_page_lines(page)):
                    if kind == "table":
                        matrix = _table_matrix(run)
                        elements.append(Element(
                            id=str(uuid.uuid4()), document_id=document_id, type="table", page_number=page_no,
                            content="\n".join(" | ".join(r) for r in matrix), table_rows=matrix))
                        continue
                    for text, is_heading in _group(run):
                        elements.append(Element(
                            id=str(uuid.uuid4()), document_id=document_id,
                            type="heading" if is_heading else "paragraph", page_number=page_no,
                            content=text, heading_level=1 if is_heading else None))
        except ParserError:
            raise
        except (PdfReadError, ValueError, KeyError, OSError, RecursionError, TypeError, IndexError):
            raise ParserError("malformed")
        if not any(e.content.strip() for e in elements):
            raise ParserError("no_text")
        md = "\n\n".join(("# " + e.content) if e.type == "heading" else e.content for e in elements)
        return ParseResult(self.name, _version(), len(pages), elements, md,
                           ["Fallback parser: tables are estimated from text alignment and headings from font size; verify against the PDF."])
