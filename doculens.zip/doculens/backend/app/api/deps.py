from __future__ import annotations

from dataclasses import dataclass

from fastapi import Request

from app.adapters.llm.fake import FakeLLMProvider
from app.adapters.pdf_parser.base import PdfParser
from app.core.config import Settings
from app.core.errors import DocuLensError
from app.db.repository import Repository
from app.services.ingestion import IngestionService
from app.storage.local_files import LocalFiles, is_uuid


@dataclass
class Container:
    settings: Settings
    repo: Repository
    files: LocalFiles
    parser: PdfParser
    ingestion: IngestionService
    local_llm: FakeLLMProvider
    remote_llm: object | None


def get_container(request: Request) -> Container:
    return request.app.state.container


def require_id(value: str) -> str:
    if not is_uuid(value):
        raise DocuLensError("invalid_id", 422)
    return value


def doc_out(container: Container, d: dict) -> dict:
    from app.core.errors import MESSAGES

    out = dict(d)
    out.pop("sha256", None)
    out["error_message"] = MESSAGES.get(d["error_code"]) if d.get("error_code") else None
    return out
