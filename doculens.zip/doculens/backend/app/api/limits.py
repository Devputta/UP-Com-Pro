"""Reject oversized request bodies before the framework buffers them (pure ASGI, no dependencies)."""
from __future__ import annotations

import json

OVERHEAD = 64 * 1024  # multipart framing and form fields


class _TooLarge(Exception):
    pass


class BodySizeLimit:
    def __init__(self, app, max_bytes: int):
        self.app = app
        self.limit = max_bytes + OVERHEAD

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        declared = dict(scope.get("headers") or []).get(b"content-length")
        if declared is not None:
            if not declared.isdigit():
                return await self._reject(send, 400, "invalid_request", "The request was not valid.")
            if int(declared) > self.limit:
                return await self._reject(send, 413, "too_large", "This file is larger than the configured size limit.")
        seen = 0
        started = False

        async def counting_receive():
            nonlocal seen
            msg = await receive()
            if msg["type"] == "http.request":
                seen += len(msg.get("body", b""))
                if seen > self.limit:  # chunked bodies carry no Content-Length
                    raise _TooLarge
            return msg

        async def tracking_send(msg):
            nonlocal started
            if msg["type"] == "http.response.start":
                started = True
            await send(msg)

        try:
            await self.app(scope, counting_receive, tracking_send)
        except _TooLarge:
            if not started:
                await self._reject(send, 413, "too_large", "This file is larger than the configured size limit.")

    @staticmethod
    async def _reject(send, status: int, code: str, message: str):
        body = json.dumps({"error": {"code": code, "message": message}}).encode()
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode()),
                                (b"connection", b"close")]})
        await send({"type": "http.response.body", "body": body})
