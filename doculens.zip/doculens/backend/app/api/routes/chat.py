from fastapi import APIRouter, Depends

from app.adapters.llm.base import LLMProvider
from app.api.deps import Container, get_container, require_id
from app.api.schemas.models import ChatRequest, ChatResponse, CitationOut
from app.core.errors import DocuLensError
from app.services.chat import answer_question
from app.services.retrieval import LexicalRetriever

router = APIRouter()


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest, c: Container = Depends(get_container)):
    question = req.question.strip()
    if not question:
        raise DocuLensError("empty_question", 422)
    ids = [require_id(i) for i in req.document_ids]
    docs = {i: c.repo.get_document(i) for i in ids}
    ready = {i: d["original_name"] for i, d in docs.items() if d and d["status"] == "ready"}
    if not ready:
        raise DocuLensError("not_found", 404)
    provider: LLMProvider = c.local_llm
    if req.use_remote_ai:
        if not c.settings.remote_ai_configured or c.remote_llm is None:
            raise DocuLensError("remote_not_allowed", 403)
        provider = c.remote_llm  # type: ignore[assignment]
    retrieved = LexicalRetriever(c.repo.chunks(list(ready))).retrieve(question, list(ready), 5)
    res = answer_question(question, retrieved, ready, provider, c.local_llm)
    remote_used = bool(req.use_remote_ai and retrieved and res.provider == provider.name and provider.is_remote)
    return ChatResponse(
        answer=res.answer, citations=[CitationOut(**cit.__dict__) for cit in res.citations],
        insufficient_evidence=res.insufficient_evidence, ai_generated=res.ai_generated and provider.is_remote,
        provider=res.provider or provider.name, notice=res.notice, remote_used=remote_used)
