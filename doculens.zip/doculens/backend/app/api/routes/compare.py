from fastapi import APIRouter, Depends

from app.api.deps import Container, get_container, require_id
from app.api.schemas.models import ChangeOut, CompareRequest, ComparisonOut
from app.core.errors import DocuLensError
from app.services.comparison import compare_documents
from app.storage.local_files import new_id

router = APIRouter()


def _out(row: dict) -> ComparisonOut:
    return ComparisonOut(id=row["id"], left_document_id=row["left_document_id"],
                         right_document_id=row["right_document_id"],
                         changes=[ChangeOut(**ch) for ch in row["changes"]])


@router.post("/comparisons", response_model=ComparisonOut, status_code=201)
def create(req: CompareRequest, c: Container = Depends(get_container)):
    left, right = require_id(req.left_document_id), require_id(req.right_document_id)
    if left == right:
        raise DocuLensError("same_document", 422)
    docs = [c.repo.get_document(i) for i in (left, right)]
    if not all(d and d["status"] == "ready" for d in docs):
        raise DocuLensError("needs_two_ready", 409)
    changes = compare_documents(c.repo.chunks([left]), c.repo.chunks([right]))
    payload = [{"type": ch.type, "summary": ch.summary, "confidence": ch.confidence, "uncertain": ch.uncertain,
                "changed_figures": [list(p) for p in ch.changed_figures], "left_page": ch.left_page,
                "right_page": ch.right_page, "left_text": ch.left_text, "right_text": ch.right_text} for ch in changes]
    cid = new_id()
    c.repo.save_comparison(cid, left, right, payload)
    return _out(c.repo.get_comparison(cid))


@router.get("/comparisons/{cid}", response_model=ComparisonOut)
def get(cid: str, c: Container = Depends(get_container)):
    row = c.repo.get_comparison(require_id(cid))
    if not row:
        raise DocuLensError("not_found", 404)
    return _out(row)
