from fastapi import APIRouter, BackgroundTasks, Depends, File, Query, UploadFile
from fastapi.responses import FileResponse

from app.api.deps import Container, doc_out, get_container, require_id
from app.api.schemas.models import DocumentOut, SearchHit
from app.core.errors import DocuLensError
from app.services.retrieval import LexicalRetriever
from app.services.text import excerpt

router = APIRouter()


def _get(c: Container, doc_id: str) -> dict:
    d = c.repo.get_document(require_id(doc_id))
    if not d:
        raise DocuLensError("not_found", 404)
    return d


@router.post("/documents", response_model=DocumentOut, status_code=201)
async def upload(background: BackgroundTasks, file: UploadFile = File(...), c: Container = Depends(get_container)):
    limit = c.settings.max_upload_bytes
    data = await file.read(limit + 1)  # bounded read: never buffer more than limit + 1 byte
    doc = c.ingestion.accept(file.filename or "", file.content_type, data)
    background.add_task(c.ingestion.process, doc["id"])
    return doc_out(c, doc)


@router.get("/documents", response_model=list[DocumentOut])
def list_documents(c: Container = Depends(get_container)):
    return [doc_out(c, d) for d in c.repo.list_documents()]


@router.get("/documents/search", response_model=list[SearchHit])
def search(q: str = Query(min_length=1, max_length=300), document_ids: list[str] = Query(default=[]),
           limit: int = Query(8, ge=1, le=25), c: Container = Depends(get_container)):
    ids = [require_id(i) for i in document_ids]
    names = {d["id"]: d["original_name"] for d in c.repo.list_documents() if d["status"] == "ready"}
    ids = [i for i in ids if i in names] if ids else list(names)
    if not ids:
        return []
    hits = LexicalRetriever(c.repo.chunks(ids)).retrieve(q, ids, limit)
    return [SearchHit(chunk_id=h.chunk.id, document_id=h.chunk.document_id, document_name=names[h.chunk.document_id],
                      page_number=h.chunk.page_start, section=h.chunk.section_title,
                      excerpt=excerpt(h.chunk.text, 280), score=round(h.score, 4)) for h in hits]


@router.get("/documents/{doc_id}", response_model=DocumentOut)
def detail(doc_id: str, c: Container = Depends(get_container)):
    return doc_out(c, _get(c, doc_id))


@router.get("/documents/{doc_id}/outline")
def outline(doc_id: str, c: Container = Depends(get_container)):
    _get(c, doc_id)
    return c.repo.outline(doc_id)


@router.get("/documents/{doc_id}/pages/{page}")
def page_text(doc_id: str, page: int, c: Container = Depends(get_container)):
    d = _get(c, doc_id)
    if page < 1 or (d["page_count"] and page > d["page_count"]):
        raise DocuLensError("not_found", 404)
    return {"page_number": page, "elements": c.repo.page_text(doc_id, page)}


@router.get("/documents/{doc_id}/file")
def original(doc_id: str, c: Container = Depends(get_container)):
    d = _get(c, doc_id)
    path = c.files.upload_path(doc_id)
    if not path.exists():
        raise DocuLensError("not_found", 404)
    return FileResponse(path, media_type="application/pdf", filename="document.pdf",
                        headers={"Content-Disposition": 'inline; filename="document.pdf"',
                                 "X-Content-Type-Options": "nosniff"})


@router.post("/documents/{doc_id}/reprocess", response_model=DocumentOut, status_code=202)
def reprocess(doc_id: str, background: BackgroundTasks, c: Container = Depends(get_container)):
    d = _get(c, doc_id)
    if d["status"] == "processing":
        return doc_out(c, d)
    c.repo.set_status(doc_id, "queued")
    background.add_task(c.ingestion.process, doc_id)
    return doc_out(c, c.repo.get_document(doc_id))


@router.delete("/documents/{doc_id}", status_code=204)
def delete(doc_id: str, c: Container = Depends(get_container)):
    _get(c, doc_id)
    c.ingestion.delete(doc_id)
