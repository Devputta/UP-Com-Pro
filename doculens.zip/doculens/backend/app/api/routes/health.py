from fastapi import APIRouter, Depends

from app.api.deps import Container, get_container
from app.api.schemas.models import SettingsOut

router = APIRouter()
DISCLOSURE = ("Remote AI is off by default. If you turn it on for a question, only the retrieved excerpts "
              "for that question are sent to the configured provider. Documents stay on this machine.")


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/settings", response_model=SettingsOut)
def settings(c: Container = Depends(get_container)):
    s = c.settings
    return SettingsOut(
        mode="hybrid" if s.remote_ai_configured else "local",
        remote_ai_enabled=s.remote_ai_enabled, remote_ai_configured=s.remote_ai_configured,
        provider=s.llm_provider if s.remote_ai_configured else "local-extractive",
        parser=c.parser.name, max_upload_mb=s.max_upload_bytes / 1024 / 1024, max_pages=s.max_pages,
        disclosure=DISCLOSURE)
