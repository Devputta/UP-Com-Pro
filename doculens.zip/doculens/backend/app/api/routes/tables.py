from fastapi import APIRouter, Depends
from fastapi.responses import Response

from app.api.deps import Container, get_container, require_id
from app.api.schemas.models import TableOut
from app.core.errors import DocuLensError
from app.services.csv_export import safe_filename, table_to_csv

router = APIRouter()


def _out(t) -> TableOut:
    return TableOut(id=t.id, document_id=t.document_id, page_number=t.page_number,
                    columns=t.columns, rows=t.rows, warnings=t.warnings)


@router.get("/documents/{doc_id}/tables", response_model=list[TableOut])
def list_tables(doc_id: str, c: Container = Depends(get_container)):
    if not c.repo.get_document(require_id(doc_id)):
        raise DocuLensError("not_found", 404)
    return [_out(t) for t in c.repo.tables(doc_id)]


def _table(c: Container, table_id: str):
    t = c.repo.get_table(require_id(table_id))
    if not t:
        raise DocuLensError("not_found", 404)
    return t


@router.get("/tables/{table_id}", response_model=TableOut)
def table(table_id: str, c: Container = Depends(get_container)):
    return _out(_table(c, table_id))


@router.get("/tables/{table_id}/export.csv")
def export_csv(table_id: str, c: Container = Depends(get_container)):
    t = _table(c, table_id)
    doc = c.repo.get_document(t.document_id)
    name = f"{safe_filename(doc['original_name'] if doc else '')}_p{t.page_number}.csv"
    return Response(table_to_csv(t.columns, t.rows), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"', "X-Content-Type-Options": "nosniff"})
