from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Status = Literal["queued", "processing", "ready", "failed"]


class DocumentOut(BaseModel):
    id: str
    original_name: str
    size_bytes: int
    page_count: int | None
    status: Status
    error_code: str | None = None
    error_message: str | None = None
    parser_name: str | None = None
    parser_version: str | None = None
    created_at: str
    processed_at: str | None = None
    warnings: list[str] = []


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=1000)
    document_ids: list[str] = Field(min_length=1, max_length=20)
    use_remote_ai: bool = False


class CitationOut(BaseModel):
    document_id: str
    document_name: str
    page_number: int
    chunk_id: str
    quote: str
    section: str


class ChatResponse(BaseModel):
    answer: str
    citations: list[CitationOut]
    insufficient_evidence: bool
    ai_generated: bool
    provider: str
    notice: str = ""
    remote_used: bool = False


class SearchHit(BaseModel):
    chunk_id: str
    document_id: str
    document_name: str
    page_number: int
    section: str
    excerpt: str
    score: float


class TableOut(BaseModel):
    id: str
    document_id: str
    page_number: int
    columns: list[str]
    rows: list[list[str]]
    warnings: list[str]


class CompareRequest(BaseModel):
    left_document_id: str
    right_document_id: str


class ChangeOut(BaseModel):
    type: Literal["added", "removed", "changed", "possibly_equivalent"]
    summary: str
    confidence: float
    uncertain: bool
    changed_figures: list[list[str]] = []
    left_page: int | None = None
    right_page: int | None = None
    left_text: str = ""
    right_text: str = ""


class ComparisonOut(BaseModel):
    id: str
    left_document_id: str
    right_document_id: str
    changes: list[ChangeOut]


class SettingsOut(BaseModel):
    mode: Literal["local", "hybrid"]
    remote_ai_enabled: bool
    remote_ai_configured: bool
    provider: str
    parser: str
    max_upload_mb: float
    max_pages: int
    disclosure: str
