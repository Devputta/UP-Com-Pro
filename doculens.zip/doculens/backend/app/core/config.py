"""Typed settings read from environment variables with safe defaults."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


BACKEND_DIR = Path(__file__).resolve().parents[2]


def read_dotenv(path: Path) -> dict[str, str]:
    """Minimal KEY=VALUE parser (no interpolation). Missing or unreadable file means no values."""
    values: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        values[key.strip().removeprefix("export ").strip()] = val
    return values


def _safe_remote_url(url: str) -> bool:
    """Remote provider traffic must be encrypted, except for a model running on this machine."""
    from urllib.parse import urlparse

    u = urlparse(url)
    return u.scheme == "https" or (u.scheme == "http" and u.hostname in {"localhost", "127.0.0.1", "::1"})


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    env: str
    data_dir: Path
    max_upload_bytes: int
    max_pages: int
    parser_timeout_seconds: int
    remote_ai_enabled: bool
    llm_provider: str
    llm_api_key: str
    llm_model: str
    llm_base_url: str
    cors_origins: tuple[str, ...]

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"

    @property
    def processed_dir(self) -> Path:
        return self.data_dir / "processed"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "doculens.db"

    @property
    def remote_ai_configured(self) -> bool:
        return bool(
            self.remote_ai_enabled
            and self.llm_provider
            and self.llm_api_key
            and self.llm_model
            and _safe_remote_url(self.llm_base_url)
        )


def _resolve_dir(value: str) -> Path:
    """Relative paths resolve against backend/, not the launch directory, so data lands in one place."""
    p = Path(value).expanduser()
    return (p if p.is_absolute() else BACKEND_DIR / p).resolve()


def load_settings(environ: dict[str, str] | None = None) -> Settings:
    """Real environment variables win over backend/.env. Passing `environ` skips both (tests)."""
    if environ is None:
        e = {**read_dotenv(BACKEND_DIR / ".env"), **os.environ}
    else:
        e = environ
    origins = e.get("DOCULENS_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    return Settings(
        env=e.get("DOCULENS_ENV", "development"),
        data_dir=_resolve_dir(e.get("DOCULENS_DATA_DIR", "../data")),
        max_upload_bytes=int(float(e.get("DOCULENS_MAX_UPLOAD_MB", "25")) * 1024 * 1024),
        max_pages=int(e.get("DOCULENS_MAX_PAGES", "250")),
        parser_timeout_seconds=int(e.get("DOCULENS_PARSER_TIMEOUT_SECONDS", "120")),
        remote_ai_enabled=_bool(e.get("DOCULENS_REMOTE_AI_ENABLED")),
        llm_provider=e.get("LLM_PROVIDER", ""),
        llm_api_key=e.get("LLM_API_KEY", ""),
        llm_model=e.get("LLM_MODEL", ""),
        llm_base_url=e.get("LLM_BASE_URL", ""),
        cors_origins=tuple(o.strip() for o in origins.split(",") if o.strip()),
    )
