"""Safe, user-facing error codes. Never carry paths or tracebacks."""
from __future__ import annotations

MESSAGES = {
    "not_pdf": "This file is not a PDF.",
    "empty_file": "This file is empty.",
    "too_large": "This file is larger than the configured size limit.",
    "too_many_pages": "This PDF has more pages than the configured limit.",
    "encrypted": "This PDF is encrypted. Remove the password and add it again.",
    "malformed": "This PDF could not be read. It may be damaged.",
    "no_text": "No extractable text was found. Scanned PDFs are not supported yet.",
    "parser_timeout": "Parsing took too long and was stopped.",
    "parser_unavailable": "The PDF parser is not available on this machine.",
    "parser_failed": "The parser failed on this PDF.",
    "not_found": "Not found.",
    "invalid_id": "Invalid identifier.",
    "needs_two_ready": "Comparison needs two ready documents.",
    "same_document": "Choose two different documents to compare.",
    "remote_not_allowed": "Remote AI is turned off.",
    "delete_incomplete": "Some files could not be removed. Retry deletion.",
    "empty_question": "Enter a question.",
}


class DocuLensError(Exception):
    def __init__(self, code: str, status: int = 400):
        super().__init__(code)
        self.code = code
        self.status = status

    @property
    def message(self) -> str:
        return MESSAGES.get(self.code, "Something went wrong.")
