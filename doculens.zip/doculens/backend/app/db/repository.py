"""All SQL lives here. Services stay free of SQL."""
from __future__ import annotations

from datetime import datetime, timezone

from app.db.session import Database, dumps, loads
from app.services.models import Chunk, Element, Table


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Repository:
    def __init__(self, db: Database):
        self.db = db

    # documents
    def create_document(self, doc_id, name, sha256, size) -> None:
        with self.db.conn() as c:
            c.execute(
                "INSERT INTO documents (id, original_name, sha256, size_bytes, status, created_at)"
                " VALUES (?,?,?,?,?,?)", (doc_id, name, sha256, size, "queued", now()))

    def set_status(self, doc_id, status, *, error_code=None, page_count=None, parser=None, version=None, warnings=None):
        with self.db.conn() as c:
            c.execute(
                "UPDATE documents SET status=?, error_code=?, page_count=COALESCE(?, page_count),"
                " parser_name=COALESCE(?, parser_name), parser_version=COALESCE(?, parser_version),"
                " processed_at=CASE WHEN ? IN ('ready','failed') THEN ? ELSE processed_at END,"
                " warnings=COALESCE(?, warnings) WHERE id=?",
                (status, error_code, page_count, parser, version, status, now(),
                 dumps(warnings) if warnings is not None else None, doc_id))

    def get_document(self, doc_id) -> dict | None:
        with self.db.conn() as c:
            row = c.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
        return self._doc(row) if row else None

    def list_documents(self) -> list[dict]:
        with self.db.conn() as c:
            rows = c.execute("SELECT * FROM documents ORDER BY created_at DESC, rowid DESC").fetchall()
        return [self._doc(r) for r in rows]

    @staticmethod
    def _doc(row) -> dict:
        d = dict(row)
        d["warnings"] = loads(d["warnings"] or "[]")
        return d

    # derived data
    def clear_derived(self, doc_id) -> None:
        with self.db.conn() as c:
            for t in ("elements", "chunks", "tables_"):
                c.execute(f"DELETE FROM {t} WHERE document_id=?", (doc_id,))  # noqa: S608 - fixed names

    def save_derived(self, doc_id, elements: list[Element], chunks: list[Chunk], tables: list[Table]) -> None:
        with self.db.conn() as c:
            for t in ("elements", "chunks", "tables_"):
                c.execute(f"DELETE FROM {t} WHERE document_id=?", (doc_id,))  # noqa: S608
            c.executemany(
                "INSERT INTO elements VALUES (?,?,?,?,?,?,?,?,?)",
                [(e.id, doc_id, e.type, e.page_number, e.content, e.heading_level,
                  dumps(e.bounding_box) if e.bounding_box else None, e.source_element_id, i)
                 for i, e in enumerate(elements)])
            c.executemany(
                "INSERT INTO chunks VALUES (?,?,?,?,?,?,?,?)",
                [(k.id, doc_id, k.text, k.page_start, k.page_end, dumps(k.element_ids), dumps(k.section_path), i)
                 for i, k in enumerate(chunks)])
            c.executemany(
                "INSERT INTO tables_ VALUES (?,?,?,?,?,?,?)",
                [(t.id, doc_id, t.page_number, t.source_element_id, dumps(t.columns), dumps(t.rows), dumps(t.warnings))
                 for t in tables])

    def chunks(self, document_ids: list[str] | None = None) -> list[Chunk]:
        sql, args = "SELECT * FROM chunks", []
        if document_ids:
            sql += f" WHERE document_id IN ({','.join('?' * len(document_ids))})"
            args = list(document_ids)
        with self.db.conn() as c:
            rows = c.execute(sql + " ORDER BY document_id, ord", args).fetchall()
        return [Chunk(r["id"], r["document_id"], r["text"], r["page_start"], r["page_end"],
                      loads(r["element_ids"]), loads(r["section_path"])) for r in rows]

    def outline(self, doc_id) -> list[dict]:
        with self.db.conn() as c:
            rows = c.execute(
                "SELECT content, page_number, heading_level FROM elements WHERE document_id=? AND type='heading' ORDER BY ord",
                (doc_id,)).fetchall()
        return [dict(r) for r in rows]

    def page_text(self, doc_id, page) -> list[dict]:
        with self.db.conn() as c:
            rows = c.execute(
                "SELECT type, content FROM elements WHERE document_id=? AND page_number=? ORDER BY ord",
                (doc_id, page)).fetchall()
        return [dict(r) for r in rows]

    def tables(self, doc_id) -> list[Table]:
        with self.db.conn() as c:
            rows = c.execute("SELECT * FROM tables_ WHERE document_id=? ORDER BY page_number", (doc_id,)).fetchall()
        return [self._table(r) for r in rows]

    def get_table(self, table_id) -> Table | None:
        with self.db.conn() as c:
            r = c.execute("SELECT * FROM tables_ WHERE id=?", (table_id,)).fetchone()
        return self._table(r) if r else None

    @staticmethod
    def _table(r) -> Table:
        return Table(r["id"], r["document_id"], r["page_number"], r["source_element_id"],
                     loads(r["columns"]), loads(r["rows"]), loads(r["warnings"]))

    # comparisons
    def save_comparison(self, cid, left, right, changes: list[dict]) -> None:
        with self.db.conn() as c:
            c.execute("INSERT INTO comparisons VALUES (?,?,?,?,?,?)", (cid, left, right, "ready", now(), dumps(changes)))

    def get_comparison(self, cid) -> dict | None:
        with self.db.conn() as c:
            r = c.execute("SELECT * FROM comparisons WHERE id=?", (cid,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["changes"] = loads(d["changes"])
        return d

    def delete_document_rows(self, doc_id) -> None:
        with self.db.conn() as c:
            for t in ("elements", "chunks", "tables_"):
                c.execute(f"DELETE FROM {t} WHERE document_id=?", (doc_id,))  # noqa: S608
            c.execute("DELETE FROM comparisons WHERE left_document_id=? OR right_document_id=?", (doc_id, doc_id))
            c.execute("DELETE FROM documents WHERE id=?", (doc_id,))

    def count_rows(self, doc_id) -> int:
        with self.db.conn() as c:
            total = 0
            for t in ("documents", "elements", "chunks", "tables_"):
                col = "id" if t == "documents" else "document_id"
                total += c.execute(f"SELECT COUNT(*) FROM {t} WHERE {col}=?", (doc_id,)).fetchone()[0]  # noqa: S608
        return total
