"""SQLite persistence using the stdlib driver (see memory.md ADR-006)."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY, original_name TEXT NOT NULL, sha256 TEXT NOT NULL, size_bytes INTEGER NOT NULL,
  page_count INTEGER, status TEXT NOT NULL, parser_name TEXT, parser_version TEXT,
  created_at TEXT NOT NULL, processed_at TEXT, error_code TEXT, warnings TEXT NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS elements (
  id TEXT PRIMARY KEY, document_id TEXT NOT NULL, type TEXT NOT NULL, page_number INTEGER NOT NULL,
  content TEXT NOT NULL, heading_level INTEGER, bounding_box TEXT, source_element_id TEXT, ord INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS chunks (
  id TEXT PRIMARY KEY, document_id TEXT NOT NULL, text TEXT NOT NULL, page_start INTEGER NOT NULL,
  page_end INTEGER NOT NULL, element_ids TEXT NOT NULL, section_path TEXT NOT NULL, ord INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tables_ (
  id TEXT PRIMARY KEY, document_id TEXT NOT NULL, page_number INTEGER NOT NULL, source_element_id TEXT NOT NULL,
  columns TEXT NOT NULL, rows TEXT NOT NULL, warnings TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS comparisons (
  id TEXT PRIMARY KEY, left_document_id TEXT NOT NULL, right_document_id TEXT NOT NULL,
  status TEXT NOT NULL, created_at TEXT NOT NULL, changes TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_elements_doc ON elements(document_id);
CREATE INDEX IF NOT EXISTS idx_tables_doc ON tables_(document_id);
"""


class Database:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self.conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def conn(self):
        c = sqlite3.connect(self.path, timeout=15)
        c.row_factory = sqlite3.Row
        try:
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise
        finally:
            c.close()


def dumps(v) -> str:
    return json.dumps(v, ensure_ascii=False)


def loads(s: str):
    return json.loads(s)
