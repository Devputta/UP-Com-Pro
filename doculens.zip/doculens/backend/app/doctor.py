"""Setup check: `python -m app.doctor`. Prints what works, what is missing, and how to fix it.
Never prints secret values."""
from __future__ import annotations

import importlib.util
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass

from app.core.config import load_settings


@dataclass
class Check:
    name: str
    ok: bool
    detail: str
    required: bool = True


def _has(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def java_major() -> int | None:
    exe = shutil.which("java")
    if not exe:
        return None
    try:
        out = subprocess.run([exe, "-version"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r'version "(\d+)(?:\.(\d+))?', out.stderr + out.stdout)
    if not m:
        return None
    major = int(m.group(1))
    return int(m.group(2) or 0) if major == 1 else major  # "1.8" means Java 8


def run_checks() -> list[Check]:
    s = load_settings()
    checks = [Check("Python 3.10+", sys.version_info >= (3, 10), sys.version.split()[0])]
    for mod, pkg in [("fastapi", "fastapi"), ("uvicorn", "uvicorn"), ("multipart", "python-multipart"), ("pypdf", "pypdf")]:
        checks.append(Check(f"package {pkg}", _has(mod), "installed" if _has(mod) else 'missing: pip install -e .'))
    try:
        s.data_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=s.data_dir):
            pass
        checks.append(Check("data folder writable", True, str(s.data_dir)))
    except OSError:
        checks.append(Check("data folder writable", False, f"cannot write to {s.data_dir}; set DOCULENS_DATA_DIR"))
    jv, odl = java_major(), _has("opendataloader_pdf")
    checks.append(Check("Java 11+ (for OpenDataLoader)", bool(jv and jv >= 11),
                        f"Java {jv}" if jv else "not found; the pure-Python fallback parser will be used", required=False))
    checks.append(Check("opendataloader-pdf package", odl,
                        "installed" if odl else 'not installed: pip install -e ".[opendataloader]"', required=False))
    parser = "opendataloader-pdf" if (odl and jv and jv >= 11) else "pypdf-fallback (tables and headings are estimated)"
    checks.append(Check("PDF parser in use", True, parser, required=False))
    mode = "hybrid (remote AI available per question)" if s.remote_ai_configured else "local only"
    if s.remote_ai_enabled and not s.remote_ai_configured:
        mode += "; remote AI is enabled but incomplete or insecure (needs provider, key, model, https URL)"
    checks.append(Check("AI mode", True, mode, required=False))
    return checks


def main() -> int:
    failed = False
    for c in run_checks():
        mark = "ok  " if c.ok else ("FAIL" if c.required else "note")
        print(f"[{mark}] {c.name}: {c.detail}")
        failed |= c.required and not c.ok
    print("\nReady." if not failed else "\nFix the FAIL items above, then run again.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
