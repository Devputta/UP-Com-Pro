"""DocuLens API entry point. Run: uvicorn app.main:app --reload (from backend/)."""
from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.adapters.llm.fake import FakeLLMProvider
from app.adapters.llm.remote_provider import RemoteProvider
from app.adapters.pdf_parser.factory import get_parser
from app.api.deps import Container
from app.api.limits import BodySizeLimit
from app.api.routes import chat, compare, documents, health, tables
from app.core.config import Settings, load_settings
from app.core.errors import DocuLensError
from app.db.repository import Repository
from app.db.session import Database
from app.services.ingestion import IngestionService
from app.storage.local_files import LocalFiles

log = logging.getLogger("doculens")  # never log document text, questions, or keys


def create_app(settings: Settings | None = None, parser=None, in_process: bool = False) -> FastAPI:
    s = settings or load_settings()
    app = FastAPI(title="DocuLens", version="0.1.0", docs_url="/api/docs" if s.env == "development" else None,
                  redoc_url=None, openapi_url="/api/openapi.json" if s.env == "development" else None)
    files = LocalFiles(s.uploads_dir, s.processed_dir)
    repo = Repository(Database(s.db_path))
    parser = parser or get_parser()
    remote = RemoteProvider(s.llm_provider, s.llm_api_key, s.llm_model, s.llm_base_url) if s.remote_ai_configured else None
    app.state.container = Container(s, repo, files, parser, IngestionService(s, repo, files, parser, in_process),
                                    FakeLLMProvider(), remote)
    app.add_middleware(BodySizeLimit, max_bytes=s.max_upload_bytes)
    app.add_middleware(CORSMiddleware, allow_origins=list(s.cors_origins), allow_methods=["GET", "POST", "DELETE"],
                       allow_headers=["Content-Type"], allow_credentials=False)

    @app.exception_handler(DocuLensError)
    async def _known(_: Request, exc: DocuLensError):
        return JSONResponse({"error": {"code": exc.code, "message": exc.message}}, status_code=exc.status)

    @app.exception_handler(RequestValidationError)
    async def _invalid(_: Request, __: RequestValidationError):
        return JSONResponse({"error": {"code": "invalid_request", "message": "The request was not valid."}}, status_code=422)

    @app.exception_handler(Exception)
    async def _unexpected(_: Request, exc: Exception):
        log.error("unhandled error: %s", type(exc).__name__)  # type only: no message, path or content
        return JSONResponse({"error": {"code": "internal", "message": "Something went wrong."}}, status_code=500)

    for r in (health.router, documents.router, chat.router, tables.router, compare.router):
        app.include_router(r, prefix="/api")
    return app


app = create_app() if __name__ != "__main__" else None
