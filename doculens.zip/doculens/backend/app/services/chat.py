"""Chat orchestration: retrieve first, call a model only with evidence, validate citations."""
from __future__ import annotations

from dataclasses import dataclass, field

from app.adapters.llm.base import EvidenceItem, LLMProvider, ProviderError
from app.services.citations import Citation, build_citations
from app.services.retrieval import RetrievedChunk
from app.services.text import excerpt

MIN_SCORE = 0.02
NO_EVIDENCE_TEXT = "No supporting passage found in the selected documents."


@dataclass
class ChatResult:
    answer: str
    citations: list[Citation] = field(default_factory=list)
    insufficient_evidence: bool = False
    ai_generated: bool = False
    provider: str = ""
    notice: str = ""
    rejected_citation_ids: list[str] = field(default_factory=list)


def answer_question(
    question: str,
    retrieved: list[RetrievedChunk],
    doc_names: dict[str, str],
    provider: LLMProvider,
    fallback: LLMProvider,
) -> ChatResult:
    retrieved = [r for r in retrieved if r.score >= MIN_SCORE]
    if not retrieved:
        return ChatResult(answer=NO_EVIDENCE_TEXT, insufficient_evidence=True)

    evidence = [
        EvidenceItem(r.chunk.id, doc_names.get(r.chunk.document_id, "Document"), r.chunk.page_start, r.chunk.text)
        for r in retrieved
    ]
    notice = ""
    used = provider
    try:
        out = provider.answer(question, evidence)
    except ProviderError as exc:
        used, notice = fallback, f"{exc} Showing local extractive results instead."
        out = fallback.answer(question, evidence)

    if "INSUFFICIENT_EVIDENCE" in out.answer:
        return ChatResult(answer=NO_EVIDENCE_TEXT, insufficient_evidence=True, provider=used.name, notice=notice)

    citations, rejected = build_citations(out.cited_chunk_ids, retrieved, doc_names)
    if not citations:
        # Uncited model prose is not evidence. Fall back to showing the top passages themselves.
        top = retrieved[0].chunk
        citations, _ = build_citations([top.id], retrieved, doc_names)
        return ChatResult(
            answer=f"The model gave no verifiable citation. Closest passage: {excerpt(top.text, 300)}",
            citations=citations,
            ai_generated=False,
            provider=used.name,
            notice=notice or "Model answer discarded because none of its citations could be verified.",
            rejected_citation_ids=rejected,
        )
    return ChatResult(
        answer=out.answer,
        citations=citations,
        ai_generated=True,
        provider=used.name,
        notice=notice,
        rejected_citation_ids=rejected,
    )
