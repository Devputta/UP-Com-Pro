"""Section-aware chunking. Every chunk keeps document, page range, element IDs, section path."""
from __future__ import annotations

import uuid

from app.services.models import Chunk, Element
from app.services.text import normalize

MAX_CHARS = 900


def build_chunks(elements: list[Element], max_chars: int = MAX_CHARS) -> list[Chunk]:
    chunks: list[Chunk] = []
    section: list[str] = []
    buf: list[Element] = []

    def flush() -> None:
        if not buf:
            return
        text = "\n".join(normalize(e.content) for e in buf if normalize(e.content))
        if text:
            chunks.append(
                Chunk(
                    id=str(uuid.uuid4()),
                    document_id=buf[0].document_id,
                    text=text,
                    page_start=min(e.page_number for e in buf),
                    page_end=max(e.page_number for e in buf),
                    element_ids=[e.id for e in buf],
                    section_path=list(section),
                )
            )
        buf.clear()

    for el in elements:
        if el.type == "heading":
            flush()
            level = max(1, el.heading_level or 1)
            section[:] = section[: level - 1] + [normalize(el.content)]
            continue
        if not normalize(el.content):
            continue
        size = sum(len(e.content) for e in buf)
        if buf and buf[-1].page_number != el.page_number:
            flush()  # a chunk never spans pages, so a citation points at exactly one page
        elif buf and size + len(el.content) > max_chars:
            flush()
        buf.append(el)
        if len(el.content) > max_chars:
            flush()
    flush()
    return chunks
