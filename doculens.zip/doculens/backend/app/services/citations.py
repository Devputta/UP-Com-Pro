"""Server-side citation validation. The model's IDs, pages and quotes are never trusted."""
from __future__ import annotations

from dataclasses import dataclass

from app.services.retrieval import RetrievedChunk
from app.services.text import excerpt


@dataclass
class Citation:
    document_id: str
    document_name: str
    page_number: int
    chunk_id: str
    quote: str
    section: str


def build_citations(
    cited_ids: list[str],
    retrieved: list[RetrievedChunk],
    doc_names: dict[str, str],
) -> tuple[list[Citation], list[str]]:
    """Return (valid citations, rejected ids). Quote and page come from stored chunk text."""
    by_id = {r.chunk.id: r.chunk for r in retrieved}
    valid: list[Citation] = []
    rejected: list[str] = []
    seen: set[str] = set()
    for cid in cited_ids:
        if cid in seen:
            continue
        seen.add(cid)
        chunk = by_id.get(cid)
        if chunk is None:
            rejected.append(cid)
            continue
        valid.append(
            Citation(
                document_id=chunk.document_id,
                document_name=doc_names.get(chunk.document_id, "Document"),
                page_number=chunk.page_start,
                chunk_id=chunk.id,
                quote=excerpt(chunk.text, 200),
                section=chunk.section_title,
            )
        )
    return valid, rejected
