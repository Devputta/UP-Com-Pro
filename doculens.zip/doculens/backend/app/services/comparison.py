"""Match chunks across two documents and classify changes, exposing uncertainty."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

from app.services.models import Chunk
from app.services.text import excerpt, normalize, search_tokens

_FIGURE = re.compile(r"[$€£₹]?\d[\d,]*(?:\.\d+)?%?")
MATCH_FLOOR = 0.45
EQUIVALENT_AT = 0.92
CONFIDENT_AT = 0.7


@dataclass
class Change:
    type: str  # added | removed | changed | possibly_equivalent
    left_chunk_id: str | None
    right_chunk_id: str | None
    summary: str
    confidence: float
    uncertain: bool
    changed_figures: list[tuple[str, str]] = field(default_factory=list)
    left_page: int | None = None
    right_page: int | None = None
    left_text: str = ""
    right_text: str = ""


def _figures(text: str) -> list[str]:
    return [f.rstrip(".,") for f in _FIGURE.findall(text)]


def _similarity(a: Chunk, b: Chunk) -> float:
    ta, tb = set(search_tokens(a.text)), set(search_tokens(b.text))
    jaccard = len(ta & tb) / len(ta | tb) if ta | tb else 0.0
    seq = SequenceMatcher(None, normalize(a.text).lower(), normalize(b.text).lower()).ratio()
    section_bonus = 0.05 if a.section_path and a.section_path == b.section_path else 0.0
    return min(1.0, 0.5 * jaccard + 0.5 * seq + section_bonus)


def _figure_changes(left: str, right: str) -> list[tuple[str, str]]:
    lf, rf = _figures(left), _figures(right)
    if lf == rf:
        return []
    pairs = []
    for old, new in zip(lf, rf):
        if old != new:
            pairs.append((old, new))
    if len(lf) != len(rf):
        extra_l, extra_r = [f for f in lf if f not in rf], [f for f in rf if f not in lf]
        for old, new in zip(extra_l, extra_r):
            if (old, new) not in pairs:
                pairs.append((old, new))
    return pairs


def compare_documents(left: list[Chunk], right: list[Chunk]) -> list[Change]:
    scored = sorted(
        ((_similarity(l, r), i, j) for i, l in enumerate(left) for j, r in enumerate(right)),
        reverse=True,
    )
    used_l: set[int] = set()
    used_r: set[int] = set()
    changes: list[Change] = []
    for sim, i, j in scored:
        if sim < MATCH_FLOOR:
            break
        if i in used_l or j in used_r:
            continue
        used_l.add(i)
        used_r.add(j)
        l, r = left[i], right[j]
        if normalize(l.text) == normalize(r.text):
            continue  # identical: not a change
        figs = _figure_changes(l.text, r.text)
        if sim >= EQUIVALENT_AT and not figs:
            kind, summary = "possibly_equivalent", "Wording differs slightly; meaning may be the same."
        else:
            kind = "changed"
            summary = (
                "Figures differ: " + "; ".join(f"{o} → {n}" for o, n in figs[:4])
                if figs
                else "Passage was reworded or edited."
            )
        changes.append(
            Change(kind, l.id, r.id, summary, round(sim, 3), sim < CONFIDENT_AT or kind == "possibly_equivalent",
                   figs, l.page_start, r.page_start, excerpt(l.text, 400), excerpt(r.text, 400))
        )
    for i, l in enumerate(left):
        if i not in used_l:
            changes.append(Change("removed", l.id, None, "Passage appears only in the left document.", 0.9,
                                  False, [], l.page_start, None, excerpt(l.text, 400), ""))
    for j, r in enumerate(right):
        if j not in used_r:
            changes.append(Change("added", None, r.id, "Passage appears only in the right document.", 0.9,
                                  False, [], None, r.page_start, "", excerpt(r.text, 400)))
    order = {"changed": 0, "removed": 1, "added": 2, "possibly_equivalent": 3}
    changes.sort(key=lambda c: (order[c.type], c.left_page or c.right_page or 0))
    return changes
