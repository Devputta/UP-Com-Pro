"""CSV export with spreadsheet formula-injection mitigation and safe filenames."""
from __future__ import annotations

import csv
import io
import re

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_TRIGGERS = ("=", "+", "-", "@")
_NUMBER = re.compile(r"^[+-]?\d+(?:[.,]\d+)*%?$")


def sanitize_cell(value: str) -> str:
    value = _CONTROL.sub("", value or "")
    probe = value.lstrip(" \t\r\n")
    if probe.startswith(_TRIGGERS) and not _NUMBER.match(probe):
        return "'" + value
    if probe.startswith(("\t", "\r")):
        return "'" + value
    return value


def table_to_csv(columns: list[str], rows: list[list[str]]) -> str:
    out = io.StringIO()
    writer = csv.writer(out, quoting=csv.QUOTE_MINIMAL, lineterminator="\r\n")
    writer.writerow([sanitize_cell(c) for c in columns])
    for row in rows:
        writer.writerow([sanitize_cell(c) for c in row])
    return out.getvalue()


def safe_filename(name: str, default: str = "table") -> str:
    stem = re.sub(r"\.pdf$", "", name or "", flags=re.I)
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")[:60]
    return stem or default
