"""Upload validation, bounded parsing, status transitions, and deletion."""
from __future__ import annotations

import hashlib
import multiprocessing as mp
import re
from pathlib import Path

from app.adapters.pdf_parser.base import ParseResult, ParserError, PdfParser
from app.core.config import Settings
from app.core.errors import DocuLensError
from app.db.repository import Repository
from app.services.chunking import build_chunks
from app.services.table_extraction import extract_tables
from app.storage.local_files import LocalFiles, new_id

PDF_MAGIC = b"%PDF-"


def validate_upload(filename: str, content_type: str | None, data: bytes, settings: Settings) -> None:
    if not data:
        raise DocuLensError("empty_file")
    if len(data) > settings.max_upload_bytes:
        raise DocuLensError("too_large", 413)
    if not (filename or "").lower().endswith(".pdf"):
        raise DocuLensError("not_pdf", 415)
    if content_type and content_type.split(";")[0].strip().lower() not in {
        "application/pdf", "application/x-pdf", "application/octet-stream"}:
        raise DocuLensError("not_pdf", 415)
    if not data[:1024].lstrip(b"\x00\r\n\t ").startswith(PDF_MAGIC):
        raise DocuLensError("not_pdf", 415)


def clean_display_name(name: str) -> str:
    """Display only. Never used as a path."""
    base = re.split(r"[\\/]", name or "document.pdf")[-1]
    base = re.sub(r"[\x00-\x1f\x7f]", "", base).strip()
    return (base or "document.pdf")[:200]


def _parse_worker(parser: PdfParser, path: str, doc_id: str, timeout: int, q) -> None:
    try:
        q.put(("ok", parser.parse(Path(path), doc_id, timeout)))
    except ParserError as exc:
        q.put(("err", exc.code))
    except Exception:  # noqa: BLE001 - mapped to a safe code; details are deliberately dropped
        q.put(("err", "parser_failed"))


def parse_with_timeout(parser: PdfParser, path: Path, doc_id: str, timeout: int) -> ParseResult:
    """Run the parser in a separate process so a hang can be killed."""
    ctx = mp.get_context("spawn")
    q = ctx.Queue(maxsize=1)
    proc = ctx.Process(target=_parse_worker, args=(parser, str(path), doc_id, timeout, q), daemon=True)
    proc.start()
    try:
        kind, payload = q.get(timeout=timeout)
    except Exception:  # queue.Empty on timeout
        raise ParserError("parser_timeout")
    finally:
        if proc.is_alive():
            proc.terminate()
        proc.join(timeout=5)
    if kind == "err":
        raise ParserError(payload)
    return payload


class IngestionService:
    def __init__(self, settings: Settings, repo: Repository, files: LocalFiles, parser: PdfParser,
                 in_process: bool = False):
        self.s, self.repo, self.files, self.parser = settings, repo, files, parser
        self.in_process = in_process  # tests may skip the subprocess

    def accept(self, filename: str, content_type: str | None, data: bytes) -> dict:
        validate_upload(filename, content_type, data, self.s)
        doc_id = new_id()
        self.files.save_upload(doc_id, data)
        self.repo.create_document(doc_id, clean_display_name(filename), hashlib.sha256(data).hexdigest(), len(data))
        return self.repo.get_document(doc_id)

    def process(self, doc_id: str) -> None:
        doc = self.repo.get_document(doc_id)
        if not doc:
            return
        self.repo.set_status(doc_id, "processing")
        path = self.files.upload_path(doc_id)
        try:
            if not path.exists():
                raise ParserError("malformed")
            if self.in_process:
                result = self.parser.parse(path, doc_id, self.s.parser_timeout_seconds)
            else:
                result = parse_with_timeout(self.parser, path, doc_id, self.s.parser_timeout_seconds)
            if result.page_count > self.s.max_pages:
                raise ParserError("too_many_pages")
            if self.repo.get_document(doc_id) is None:  # deleted while processing
                return
            chunks = build_chunks(result.elements)
            tables = extract_tables(result.elements)
            self.repo.save_derived(doc_id, result.elements, chunks, tables)
            self.files.write_derived(doc_id, "content.md", result.markdown)
            self.repo.set_status(doc_id, "ready", page_count=result.page_count, parser=result.parser_name,
                                 version=result.parser_version, warnings=result.warnings)
        except ParserError as exc:
            self.repo.clear_derived(doc_id)
            self.repo.set_status(doc_id, "failed", error_code=exc.code)

    def delete(self, doc_id: str) -> None:
        """Remove files first; drop metadata only when cleanup fully succeeded so retry is possible."""
        if not self.repo.get_document(doc_id):
            raise DocuLensError("not_found", 404)
        if not self.files.delete_all(doc_id):
            raise DocuLensError("delete_incomplete", 500)
        self.repo.delete_document_rows(doc_id)
