"""Plain domain objects shared across services. Provenance is carried on every one."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Element:
    id: str
    document_id: str
    type: str  # heading | paragraph | table | list | other
    page_number: int  # 1-indexed
    content: str
    heading_level: int | None = None
    bounding_box: list[float] | None = None
    source_element_id: str | None = None
    table_rows: list[list[str]] | None = None  # raw rows for table elements


@dataclass
class Chunk:
    id: str
    document_id: str
    text: str
    page_start: int
    page_end: int
    element_ids: list[str]
    section_path: list[str] = field(default_factory=list)

    @property
    def section_title(self) -> str:
        return self.section_path[-1] if self.section_path else ""


@dataclass
class Table:
    id: str
    document_id: str
    page_number: int
    source_element_id: str
    columns: list[str]
    rows: list[list[str]]
    warnings: list[str] = field(default_factory=list)
