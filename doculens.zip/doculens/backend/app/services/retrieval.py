"""Deterministic lexical retriever (TF-IDF with cosine-style scoring)."""
from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass

from app.services.models import Chunk
from app.services.text import search_tokens


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


class LexicalRetriever:
    def __init__(self, chunks: list[Chunk]):
        self._chunks = chunks
        self._tf: list[Counter[str]] = []
        df: Counter[str] = Counter()
        for c in chunks:
            title = " ".join(c.section_path)
            toks = search_tokens(f"{title} {c.text}")
            tf = Counter(toks)
            self._tf.append(tf)
            df.update(tf.keys())
        n = max(len(chunks), 1)
        self._idf = {t: math.log((n + 1) / (d + 0.5)) + 1 for t, d in df.items()}
        self._norms = [
            math.sqrt(sum((cnt * self._idf[t]) ** 2 for t, cnt in tf.items())) or 1.0
            for tf in self._tf
        ]

    def retrieve(self, query: str, document_ids: list[str] | None = None, limit: int = 5):
        q = Counter(search_tokens(query))
        if not q:
            return []
        allowed = set(document_ids) if document_ids else None
        scored: list[RetrievedChunk] = []
        for chunk, tf, norm in zip(self._chunks, self._tf, self._norms):
            if allowed is not None and chunk.document_id not in allowed:
                continue
            score = sum(qc * self._idf.get(t, 0) * tf[t] * self._idf[t] for t, qc in q.items() if t in tf)
            if score > 0:
                scored.append(RetrievedChunk(chunk, score / norm))
        scored.sort(key=lambda r: (-r.score, r.chunk.page_start, r.chunk.id))
        return scored[:limit]
