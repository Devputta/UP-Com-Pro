"""Normalise table candidates. Never invent values: gaps stay empty and produce warnings."""
from __future__ import annotations

import re
import uuid

from app.services.models import Element, Table
from app.services.text import normalize


def parse_pipe_table(content: str) -> list[list[str]]:
    rows: list[list[str]] = []
    for line in content.splitlines():
        line = line.strip()
        if not line or "|" not in line:
            continue
        if re.fullmatch(r"\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?", line):
            continue
        cells = [normalize(c) for c in line.strip("|").split("|")]
        rows.append(cells)
    return rows


def normalize_table(element: Element) -> Table | None:
    raw = element.table_rows if element.table_rows else parse_pipe_table(element.content)
    raw = [[normalize(str(c)) for c in r] for r in raw if any(normalize(str(c)) for c in r)]
    if not raw:
        return None
    warnings: list[str] = []
    width = max(len(r) for r in raw)
    if len({len(r) for r in raw}) > 1:
        warnings.append("Rows have different numbers of cells; short rows were padded with empty cells.")
    padded = [r + [""] * (width - len(r)) for r in raw]
    header, body = padded[0], padded[1:]
    if any(not h for h in header):
        warnings.append("Some column headers were not detected.")
        header = [h or f"Column {i + 1}" for i, h in enumerate(header)]
    if len(set(header)) != len(header):
        warnings.append("Duplicate column headers were found.")
    if not body:
        warnings.append("Only a header row was detected.")
    empty = sum(1 for r in body for c in r if not c)
    if empty:
        warnings.append(f"{empty} empty cell(s) were left blank, not guessed.")
    return Table(
        id=str(uuid.uuid4()),
        document_id=element.document_id,
        page_number=element.page_number,
        source_element_id=element.id,
        columns=header,
        rows=body,
        warnings=warnings,
    )


def extract_tables(elements: list[Element]) -> list[Table]:
    out = []
    for el in elements:
        if el.type == "table":
            t = normalize_table(el)
            if t:
                out.append(t)
    return out
