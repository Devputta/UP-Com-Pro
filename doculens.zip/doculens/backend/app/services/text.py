"""Shared text helpers."""
from __future__ import annotations

import re
import unicodedata

_TOKEN = re.compile(r"[a-z0-9]+(?:[.,][0-9]+)*")
STOPWORDS = frozenset(
    "a an and are as at be by for from has have in is it its of on or that the this to was were "
    "with which what when where who how do does did can could should would about into than then "
    "their there these those".split()
)


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text: str, *, drop_stopwords: bool = True) -> list[str]:
    tokens = _TOKEN.findall(normalize(text).lower())
    if drop_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS]
    return tokens


def stem(token: str) -> str:
    for suffix in ("ing", "ed", "es", "s"):
        if len(token) > len(suffix) + 2 and token.endswith(suffix):
            return token[: -len(suffix)]
    return token


def search_tokens(text: str) -> list[str]:
    return [stem(t) for t in tokenize(text)]


def excerpt(text: str, limit: int = 240) -> str:
    text = normalize(text)
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"
