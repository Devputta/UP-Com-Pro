"""Private local file storage. Paths are built only from validated UUIDs."""
from __future__ import annotations

import re
import shutil
import uuid
from pathlib import Path

_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def is_uuid(value: str) -> bool:
    return bool(_UUID.match(value or ""))


class LocalFiles:
    def __init__(self, uploads: Path, processed: Path):
        self.uploads, self.processed = uploads, processed
        uploads.mkdir(parents=True, exist_ok=True)
        processed.mkdir(parents=True, exist_ok=True)

    def upload_path(self, doc_id: str) -> Path:
        if not is_uuid(doc_id):
            raise ValueError("invalid id")
        return self.uploads / f"{doc_id}.pdf"

    def derived_dir(self, doc_id: str) -> Path:
        if not is_uuid(doc_id):
            raise ValueError("invalid id")
        return self.processed / doc_id

    def save_upload(self, doc_id: str, data: bytes) -> Path:
        path = self.upload_path(doc_id)
        path.write_bytes(data)
        return path

    def write_derived(self, doc_id: str, name: str, text: str) -> None:
        d = self.derived_dir(doc_id)
        d.mkdir(parents=True, exist_ok=True)
        (d / Path(name).name).write_text(text, encoding="utf-8")

    def delete_all(self, doc_id: str) -> bool:
        """Remove owned files. Returns True only if nothing remains."""
        ok = True
        try:
            self.upload_path(doc_id).unlink(missing_ok=True)
        except OSError:
            ok = False
        try:
            shutil.rmtree(self.derived_dir(doc_id), ignore_errors=False)
        except FileNotFoundError:
            pass
        except OSError:
            ok = False
        return ok and not self.upload_path(doc_id).exists() and not self.derived_dir(doc_id).exists()


def new_id() -> str:
    return str(uuid.uuid4())
