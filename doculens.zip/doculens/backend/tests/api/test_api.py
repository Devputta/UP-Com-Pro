"""HTTP-level tests. Require fastapi + httpx (pip install -e '.[dev]'). Run with pytest."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app.adapters.pdf_parser.pypdf_parser import PypdfParser  # noqa: E402
from app.core.config import load_settings  # noqa: E402
from app.main import create_app  # noqa: E402
from tests.fixtures.make_pdf import REPORT_2023, REPORT_2024, make_pdf  # noqa: E402


@pytest.fixture()
def client(tmp_path):
    s = load_settings({"DOCULENS_DATA_DIR": str(tmp_path), "DOCULENS_MAX_UPLOAD_MB": "1"})
    return TestClient(create_app(s, parser=PypdfParser(), in_process=True))


def upload(client, data, name="r.pdf", ctype="application/pdf"):
    return client.post("/api/documents", files={"file": (name, data, ctype)})


def test_health(client):
    assert client.get("/api/health").json() == {"status": "ok"}


@pytest.mark.parametrize("data,name,status", [
    (b"", "a.pdf", 400), (b"hello", "a.pdf", 415), (b"%PDF-1.4" + b"0" * 2_000_000, "a.pdf", 413),
    (make_pdf([["x"]]), "a.txt", 415)])
def test_rejects_bad_uploads(client, data, name, status):
    r = upload(client, data, name)
    assert r.status_code == status
    assert "Traceback" not in r.text and "/tmp" not in r.text


def test_full_flow(client):
    doc = upload(client, make_pdf(REPORT_2023), "../../evil.pdf").json()
    assert doc["original_name"] == "evil.pdf"
    detail = client.get(f"/api/documents/{doc['id']}").json()
    assert detail["status"] == "ready"  # background task has run by the time TestClient returns
    hits = client.get("/api/documents/search", params={"q": "two suppliers"}).json()
    assert hits and hits[0]["page_number"] == 1
    chat = client.post("/api/chat", json={"question": "two suppliers hardware", "document_ids": [doc["id"]]}).json()
    assert chat["citations"] and not chat["ai_generated"]
    none = client.post("/api/chat", json={"question": "airspeed swallow", "document_ids": [doc["id"]]}).json()
    assert none["insufficient_evidence"] and none["citations"] == []
    assert client.delete(f"/api/documents/{doc['id']}").status_code == 204
    assert client.get(f"/api/documents/{doc['id']}").status_code == 404


def test_remote_ai_refused_when_not_configured(client):
    doc = upload(client, make_pdf(REPORT_2023)).json()
    r = client.post("/api/chat", json={"question": "suppliers", "document_ids": [doc["id"]], "use_remote_ai": True})
    assert r.status_code == 403


def test_compare(client):
    a, b = upload(client, make_pdf(REPORT_2023), "a.pdf").json(), upload(client, make_pdf(REPORT_2024), "b.pdf").json()
    r = client.post("/api/comparisons", json={"left_document_id": a["id"], "right_document_id": b["id"]})
    assert r.status_code == 201 and r.json()["changes"]
    same = client.post("/api/comparisons", json={"left_document_id": a["id"], "right_document_id": a["id"]})
    assert same.status_code == 422


def test_invalid_ids(client):
    assert client.get("/api/documents/not-a-uuid").status_code == 422
    assert client.get("/api/tables/..%2f..%2fetc").status_code in (404, 422)
