"""Generate small redistributable PDFs for tests (no binary fixtures committed)."""
from __future__ import annotations

from io import BytesIO

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def make_pdf(pages: list[list[str]]) -> bytes:
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    for lines in pages:
        y = 740
        for line in lines:
            c.drawString(72, y, line)
            y -= 28 if line.isupper() or len(line) < 40 else 18
        c.showPage()
    c.save()
    return buf.getvalue()


REPORT_2023 = [
    ["Annual Report 2023", "", "Revenue", "Revenue grew 12% to $4.2 million in 2023, driven by subscriptions.",
     "", "Risks", "The company depends on two suppliers for its core hardware."],
    ["Outlook", "", "Management expects revenue growth of 8% in 2024 and plans to hire 40 engineers."],
]
REPORT_2024 = [
    ["Annual Report 2024", "", "Revenue", "Revenue grew 15% to $5.1 million in 2024, driven by subscriptions.",
     "", "Risks", "The company depends on two suppliers for its core hardware."],
    ["Outlook", "", "Management expects revenue growth of 8% in 2024 and plans to hire 40 engineers.",
     "", "Sustainability", "A new recycling programme was launched in Mysuru."],
]


def make_table_pdf(intro: str, rows: list[list[str]], col_x=(72, 220, 360, 480)) -> bytes:
    """One page: an intro paragraph line, then a grid of cells drawn at fixed x positions."""
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    c.drawString(72, 740, "Financial Summary")
    c.drawString(72, 712, intro)
    y = 670
    for row in rows:
        for x, cell in zip(col_x, row):
            if cell:
                c.drawString(x, y, cell)
        y -= 20
    c.drawString(72, y - 30, "Figures are unaudited and subject to revision.")
    c.showPage()
    c.save()
    return buf.getvalue()


def make_encrypted_pdf(password: str = "secret") -> bytes:
    from pypdf import PdfReader, PdfWriter

    r = PdfReader(BytesIO(make_pdf([["Hidden"]])))
    w = PdfWriter()
    w.add_page(r.pages[0])
    w.encrypt(password)
    out = BytesIO()
    w.write(out)
    return out.getvalue()


TABLE_ROWS = [
    ["Year", "Revenue", "Profit", "Notes"],
    ["2022", "3.7", "0.4", "Baseline"],
    ["2023", "4.2", "", "Restated"],
    ["2024", "=SUM(A1:A9)", "0.9", "Forecast"],
]
