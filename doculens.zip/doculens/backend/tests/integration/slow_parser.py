import time


class SlowParser:
    name = "slow"

    def parse(self, pdf_path, document_id, timeout_seconds):
        time.sleep(60)
