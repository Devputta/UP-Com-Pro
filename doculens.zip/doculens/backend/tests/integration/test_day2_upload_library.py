import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app.adapters.pdf_parser.pypdf_parser import PypdfParser
from app.core import config
from app.core.config import load_settings
from app.core.errors import DocuLensError
from app.db.repository import Repository
from app.db.session import Database
from app.services.ingestion import IngestionService
from app.storage.local_files import LocalFiles, is_uuid
from tests.fixtures.make_pdf import REPORT_2023, make_pdf


class UploadLibraryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.s = load_settings({"DOCULENS_DATA_DIR": self.tmp.name, "DOCULENS_MAX_UPLOAD_MB": "1"})
        self.repo = Repository(Database(self.s.db_path))
        self.files = LocalFiles(self.s.uploads_dir, self.s.processed_dir)
        self.svc = IngestionService(self.s, self.repo, self.files, PypdfParser(), in_process=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_new_upload_is_queued_with_metadata_and_checksum(self):
        data = make_pdf(REPORT_2023)
        d = self.svc.accept("Annual Report.pdf", "application/pdf", data)
        self.assertEqual(d["status"], "queued")  # the Day 2 "done when" condition
        self.assertTrue(is_uuid(d["id"]))
        self.assertEqual(d["sha256"], hashlib.sha256(data).hexdigest())
        self.assertEqual(d["size_bytes"], len(data))
        self.assertEqual(d["original_name"], "Annual Report.pdf")
        self.assertEqual(self.files.upload_path(d["id"]).read_bytes(), data)

    def test_duplicate_filename_creates_two_independent_documents(self):
        a = self.svc.accept("report.pdf", "application/pdf", make_pdf(REPORT_2023))
        b = self.svc.accept("report.pdf", "application/pdf", make_pdf([["Different", "", "Other content entirely here."]]))
        self.assertNotEqual(a["id"], b["id"])
        self.assertNotEqual(self.files.upload_path(a["id"]), self.files.upload_path(b["id"]))
        self.assertEqual({d["original_name"] for d in self.repo.list_documents()}, {"report.pdf"})
        self.assertEqual(len(self.repo.list_documents()), 2)
        self.svc.process(a["id"]); self.svc.process(b["id"])
        self.svc.delete(a["id"])  # deleting one must not touch the other
        self.assertIsNone(self.repo.get_document(a["id"]))
        self.assertEqual(self.repo.get_document(b["id"])["status"], "ready")
        self.assertTrue(self.files.upload_path(b["id"]).exists())

    def test_identical_content_twice_is_kept_as_two_documents(self):
        data = make_pdf(REPORT_2023)
        a = self.svc.accept("one.pdf", "application/pdf", data)
        b = self.svc.accept("two.pdf", "application/pdf", data)
        self.assertEqual(a["sha256"], b["sha256"])
        self.assertNotEqual(a["id"], b["id"])  # same checksum is recorded, not silently merged

    def test_listing_is_newest_first(self):
        ids = [self.svc.accept(f"{n}.pdf", "application/pdf", make_pdf([[n]]))["id"] for n in "abc"]
        self.assertEqual([d["id"] for d in self.repo.list_documents()], ids[::-1])

    def test_rejected_upload_leaves_nothing_behind(self):
        for name, ctype, data in [("a.pdf", "application/pdf", b""), ("a.pdf", "application/pdf", b"%PDF-" + b"0" * 2_000_000),
                                  ("a.txt", "application/pdf", b"%PDF-1.4"), ("a.pdf", "text/html", b"%PDF-1.4"),
                                  ("a.pdf", "application/pdf", b"MZ not a pdf")]:
            with self.assertRaises(DocuLensError):
                self.svc.accept(name, ctype, data)
        self.assertEqual(self.repo.list_documents(), [])
        self.assertEqual(list(self.s.uploads_dir.iterdir()), [])

    def test_traversal_and_odd_filenames_never_touch_the_filesystem_path(self):
        names = ["../../etc/passwd.pdf", "..\\..\\boot.pdf", "/abs/path.pdf", "a\x00b.pdf", "x" * 400 + ".pdf", "résumé 报告.pdf"]
        for n in names:
            d = self.svc.accept(n, "application/pdf", make_pdf([["Hello world"]]))
            path = self.files.upload_path(d["id"])
            self.assertEqual(path.parent, self.s.uploads_dir)
            self.assertTrue(path.name.endswith(".pdf") and is_uuid(path.stem))
            self.assertLessEqual(len(d["original_name"]), 200)
            self.assertNotIn("/", d["original_name"]); self.assertNotIn("\\", d["original_name"]); self.assertNotIn("\x00", d["original_name"])
        self.assertEqual(len(list(self.s.uploads_dir.iterdir())), len(names))
        outside = [p for p in Path(self.tmp.name).rglob("*") if self.s.uploads_dir not in p.parents and p.is_file() and p.suffix == ".pdf"]
        self.assertEqual(outside, [])

    def test_missing_document_is_not_found(self):
        self.assertIsNone(self.repo.get_document("00000000-0000-4000-8000-000000000000"))
        with self.assertRaises(DocuLensError) as cm:
            self.svc.delete("00000000-0000-4000-8000-000000000000")
        self.assertEqual(cm.exception.status, 404)

    def test_library_survives_restart(self):
        d = self.svc.accept("keep.pdf", "application/pdf", make_pdf(REPORT_2023))
        self.svc.process(d["id"])
        reopened = Repository(Database(self.s.db_path))  # new connection pool == app restart
        got = reopened.get_document(d["id"])
        self.assertEqual((got["status"], got["page_count"]), ("ready", 2))


class DotenvLoadingTests(unittest.TestCase):
    def test_env_file_is_used_and_real_env_wins(self):
        with tempfile.TemporaryDirectory() as t:
            (Path(t) / ".env").write_text("DOCULENS_MAX_PAGES=11\nDOCULENS_MAX_UPLOAD_MB=3\n", encoding="utf-8")
            with mock.patch.object(config, "BACKEND_DIR", Path(t)), mock.patch.dict(os.environ, {"DOCULENS_MAX_PAGES": "99"}):
                s = config.load_settings()
            self.assertEqual(s.max_pages, 99)  # environment overrides file
            self.assertEqual(s.max_upload_bytes, 3 * 1024 * 1024)  # file used where env is silent


if __name__ == "__main__":
    unittest.main()
