import tempfile
import unittest
from pathlib import Path

from app.adapters.llm.fake import FakeLLMProvider
from app.adapters.pdf_parser.base import ParserError
from app.adapters.pdf_parser.pypdf_parser import PypdfParser
from app.core.config import load_settings
from app.core.errors import DocuLensError
from app.db.repository import Repository
from app.db.session import Database
from app.services.chat import answer_question
from app.services.comparison import compare_documents
from app.services.ingestion import IngestionService, parse_with_timeout
from app.services.retrieval import LexicalRetriever
from app.storage.local_files import LocalFiles
from tests.fixtures.make_pdf import REPORT_2023, REPORT_2024, make_pdf


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.s = load_settings({"DOCULENS_DATA_DIR": str(root), "DOCULENS_MAX_PAGES": "5"})
        self.repo = Repository(Database(self.s.db_path))
        self.files = LocalFiles(self.s.uploads_dir, self.s.processed_dir)
        self.svc = IngestionService(self.s, self.repo, self.files, PypdfParser(), in_process=True)

    def tearDown(self):
        self.tmp.cleanup()

    def ingest(self, pages, name="r.pdf"):
        doc = self.svc.accept(name, "application/pdf", make_pdf(pages))
        self.assertEqual(doc["status"], "queued")
        self.svc.process(doc["id"])
        return self.repo.get_document(doc["id"])

    def test_upload_parse_search_cite(self):
        doc = self.ingest(REPORT_2023)
        self.assertEqual(doc["status"], "ready")
        self.assertEqual(doc["page_count"], 2)
        chunks = self.repo.chunks([doc["id"]])
        self.assertTrue(chunks)
        retr = LexicalRetriever(chunks)
        hits = retr.retrieve("two suppliers hardware", [doc["id"]], 3)
        self.assertEqual(hits[0].chunk.page_start, 1)
        fake = FakeLLMProvider()
        res = answer_question("two suppliers hardware", hits, {doc["id"]: "r.pdf"}, fake, fake)
        self.assertEqual(res.citations[0].page_number, 1)
        self.assertEqual(res.citations[0].document_name, "r.pdf")

    def test_page_provenance_second_page(self):
        doc = self.ingest(REPORT_2023)
        hits = LexicalRetriever(self.repo.chunks()).retrieve("hire engineers", None, 3)
        self.assertEqual(hits[0].chunk.page_start, 2)

    def test_malformed_pdf_fails_safely(self):
        doc = self.svc.accept("bad.pdf", "application/pdf", b"%PDF-1.4\nthis is not really a pdf")
        self.svc.process(doc["id"])
        d = self.repo.get_document(doc["id"])
        self.assertEqual(d["status"], "failed")
        self.assertIn(d["error_code"], {"malformed", "no_text"})
        self.assertNotIn(self.tmp.name, str(d))

    def test_too_many_pages(self):
        doc = self.ingest([["Page"]] * 6)
        self.assertEqual((doc["status"], doc["error_code"]), ("failed", "too_many_pages"))

    def test_compare_two_documents(self):
        a, b = self.ingest(REPORT_2023, "a.pdf"), self.ingest(REPORT_2024, "b.pdf")
        changes = compare_documents(self.repo.chunks([a["id"]]), self.repo.chunks([b["id"]]))
        kinds = {c.type for c in changes}
        self.assertIn("changed", kinds)
        figs = [f for c in changes for f in c.changed_figures]
        self.assertTrue(any("12%" == o and "15%" == n for o, n in figs), figs)
        self.assertTrue(all(c.left_text or c.right_text for c in changes))

    def test_delete_removes_everything_and_retry(self):
        doc = self.ingest(REPORT_2023)
        did = doc["id"]
        self.assertGreater(self.repo.count_rows(did), 1)
        self.assertTrue(self.files.upload_path(did).exists())
        self.svc.delete(did)
        self.assertEqual(self.repo.count_rows(did), 0)
        self.assertFalse(self.files.upload_path(did).exists())
        self.assertFalse(self.files.derived_dir(did).exists())
        with self.assertRaises(DocuLensError) as cm:
            self.svc.delete(did)
        self.assertEqual(cm.exception.code, "not_found")

    def test_partial_delete_failure_is_reported_and_retryable(self):
        doc = self.ingest(REPORT_2023)
        real = self.files.delete_all
        self.files.delete_all = lambda _id: False
        with self.assertRaises(DocuLensError) as cm:
            self.svc.delete(doc["id"])
        self.assertEqual(cm.exception.code, "delete_incomplete")
        self.assertIsNotNone(self.repo.get_document(doc["id"]))  # metadata kept so retry is possible
        self.files.delete_all = real
        self.svc.delete(doc["id"])
        self.assertIsNone(self.repo.get_document(doc["id"]))

    def test_parser_timeout_kills_process(self):
        from tests.integration.slow_parser import SlowParser

        doc = self.svc.accept("slow.pdf", "application/pdf", make_pdf([["x"]]))
        with self.assertRaises(ParserError) as cm:
            parse_with_timeout(SlowParser(), self.files.upload_path(doc["id"]), doc["id"], 2)
        self.assertEqual(cm.exception.code, "parser_timeout")

    def test_subprocess_parse_roundtrip(self):
        doc = self.svc.accept("ok.pdf", "application/pdf", make_pdf(REPORT_2023))
        res = parse_with_timeout(PypdfParser(), self.files.upload_path(doc["id"]), doc["id"], 60)
        self.assertEqual(res.page_count, 2)


if __name__ == "__main__":
    unittest.main()
