"""Small retrieval evaluation over generated PDFs. Reports hit@3 and enforces a floor.
The question set is deliberately mixed: some phrased with the document's words, some paraphrased."""
import tempfile
import unittest
from pathlib import Path

from app.adapters.pdf_parser.pypdf_parser import PypdfParser
from app.core.config import load_settings
from app.db.repository import Repository
from app.db.session import Database
from app.services.ingestion import IngestionService
from app.services.retrieval import LexicalRetriever
from app.storage.local_files import LocalFiles
from tests.fixtures.make_pdf import make_pdf

CORPUS = {
    "finance.pdf": [
        ["Revenue", "Subscription revenue rose 12 percent to 4.2 million dollars in 2023.", "",
         "Costs", "Operating costs increased because of hiring in the engineering department."],
        ["Liquidity", "Cash reserves remained above six months of expenses at year end."]],
    "safety.pdf": [
        ["Fire Safety", "Employees must evacuate through the nearest marked exit when the alarm sounds.", "",
         "First Aid", "First aid kits are located beside every stairwell on each floor."],
        ["Reporting", "Report any workplace injury to your supervisor within twenty four hours."]],
    "travel.pdf": [
        ["Booking", "Flights must be booked at least fourteen days before departure.", "",
         "Expenses", "Meals are reimbursed up to fifty dollars per day with itemised receipts."],
        ["Visas", "Travellers are responsible for obtaining the required visa before departure."]],
}
# (question, expected document, expected page)
QUESTIONS = [
    ("How much did subscription revenue rise in 2023?", "finance.pdf", 1),
    ("Why did operating costs increase?", "finance.pdf", 1),
    ("How much cash reserves remained at year end?", "finance.pdf", 2),
    ("What should employees do when the alarm sounds?", "safety.pdf", 1),
    ("Where are first aid kits located?", "safety.pdf", 1),
    ("Who do I tell about a workplace injury?", "safety.pdf", 2),
    ("How early must flights be booked?", "travel.pdf", 1),
    ("What is the meal reimbursement limit per day?", "travel.pdf", 1),
    ("Who obtains the visa before departure?", "travel.pdf", 2),
    ("What are the hiring plans for the engineering department?", "finance.pdf", 1),
]
FLOOR = 0.8


class RetrievalEval(unittest.TestCase):
    def test_hit_at_3(self):
        with tempfile.TemporaryDirectory() as tmp:
            s = load_settings({"DOCULENS_DATA_DIR": tmp})
            repo = Repository(Database(s.db_path))
            svc = IngestionService(s, repo, LocalFiles(s.uploads_dir, s.processed_dir), PypdfParser(), in_process=True)
            ids = {}
            for name, pages in CORPUS.items():
                d = svc.accept(name, "application/pdf", make_pdf(pages))
                svc.process(d["id"])
                ids[name] = d["id"]
            r = LexicalRetriever(repo.chunks())
            hits, misses = 0, []
            for q, doc, page in QUESTIONS:
                top = r.retrieve(q, None, 3)
                ok = any(h.chunk.document_id == ids[doc] and h.chunk.page_start == page for h in top)
                hits += ok
                if not ok:
                    misses.append(q)
            rate = hits / len(QUESTIONS)
            print(f"\nretrieval hit@3 = {hits}/{len(QUESTIONS)} = {rate:.0%}; misses: {misses}")
            self.assertGreaterEqual(rate, FLOOR, misses)


if __name__ == "__main__":
    unittest.main()
