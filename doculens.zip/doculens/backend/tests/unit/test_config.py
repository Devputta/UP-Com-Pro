import tempfile
import unittest
from pathlib import Path

from app.core.config import BACKEND_DIR, load_settings, read_dotenv


class SettingsTests(unittest.TestCase):
    def test_safe_defaults_local_only(self):
        s = load_settings({})
        self.assertFalse(s.remote_ai_enabled)
        self.assertFalse(s.remote_ai_configured)
        self.assertEqual(s.max_upload_bytes, 25 * 1024 * 1024)
        self.assertEqual((s.max_pages, s.parser_timeout_seconds), (250, 120))
        self.assertEqual(s.data_dir, (BACKEND_DIR / "../data").resolve())  # not the launch directory
        self.assertEqual(s.db_path.parent, s.data_dir)

    def test_remote_needs_every_piece(self):
        full = {"DOCULENS_REMOTE_AI_ENABLED": "true", "LLM_PROVIDER": "p", "LLM_API_KEY": "k",
                "LLM_MODEL": "m", "LLM_BASE_URL": "https://api.example.com/v1"}
        self.assertTrue(load_settings(full).remote_ai_configured)
        for missing in ("LLM_PROVIDER", "LLM_API_KEY", "LLM_MODEL", "LLM_BASE_URL", "DOCULENS_REMOTE_AI_ENABLED"):
            self.assertFalse(load_settings({k: v for k, v in full.items() if k != missing}).remote_ai_configured, missing)

    def test_key_without_opt_in_stays_off(self):
        s = load_settings({"LLM_PROVIDER": "p", "LLM_API_KEY": "k", "LLM_MODEL": "m", "LLM_BASE_URL": "https://x.test/v1"})
        self.assertFalse(s.remote_ai_configured)

    def test_plain_http_remote_rejected_except_localhost(self):
        base = {"DOCULENS_REMOTE_AI_ENABLED": "1", "LLM_PROVIDER": "p", "LLM_API_KEY": "k", "LLM_MODEL": "m"}
        self.assertFalse(load_settings({**base, "LLM_BASE_URL": "http://api.example.com/v1"}).remote_ai_configured)
        self.assertTrue(load_settings({**base, "LLM_BASE_URL": "http://localhost:11434/v1"}).remote_ai_configured)
        self.assertFalse(load_settings({**base, "LLM_BASE_URL": "ftp://x"}).remote_ai_configured)

    def test_absolute_data_dir_and_limits(self):
        with tempfile.TemporaryDirectory() as t:
            s = load_settings({"DOCULENS_DATA_DIR": t, "DOCULENS_MAX_UPLOAD_MB": "0.5", "DOCULENS_MAX_PAGES": "7"})
            self.assertEqual(s.data_dir, Path(t).resolve())
            self.assertEqual((s.max_upload_bytes, s.max_pages), (524288, 7))

    def test_bool_parsing(self):
        for v, want in [("true", True), ("YES", True), ("1", True), ("false", False), ("", False), ("nope", False)]:
            self.assertEqual(load_settings({"DOCULENS_REMOTE_AI_ENABLED": v}).remote_ai_enabled, want, v)


class DotenvTests(unittest.TestCase):
    def test_parse(self):
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / ".env"
            f.write_text('# comment\n\nA=1\nB = "two words"\nexport C=\'x\'\nBAD LINE\nD=a=b\n', encoding="utf-8")
            self.assertEqual(read_dotenv(f), {"A": "1", "B": "two words", "C": "x", "D": "a=b"})

    def test_missing_file_is_empty(self):
        self.assertEqual(read_dotenv(Path("/nonexistent/.env")), {})

    def test_example_file_matches_settings_names(self):
        example = read_dotenv(BACKEND_DIR.parent / ".env.example")
        s = load_settings(example)  # the shipped example must load cleanly and stay local-only
        self.assertFalse(s.remote_ai_configured)
        self.assertEqual(s.env, "development")
        self.assertEqual(set(example), {"DOCULENS_ENV", "DOCULENS_DATA_DIR", "DOCULENS_MAX_UPLOAD_MB", "DOCULENS_MAX_PAGES",
                                        "DOCULENS_PARSER_TIMEOUT_SECONDS", "DOCULENS_REMOTE_AI_ENABLED", "LLM_PROVIDER",
                                        "LLM_API_KEY", "LLM_MODEL", "LLM_BASE_URL"})


if __name__ == "__main__":
    unittest.main()
