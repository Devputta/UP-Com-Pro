import unittest
from unittest import mock

from app import doctor


class DoctorTests(unittest.TestCase):
    def test_reports_missing_required_package_and_fails(self):
        with mock.patch.object(doctor, "_has", side_effect=lambda m: m != "fastapi"):
            checks = {c.name: c for c in doctor.run_checks()}
        self.assertFalse(checks["package fastapi"].ok)
        self.assertTrue(checks["package fastapi"].required)
        self.assertTrue(checks["package pypdf"].ok)

    def test_missing_java_is_a_note_not_a_failure(self):
        with mock.patch.object(doctor, "java_major", return_value=None):
            checks = {c.name: c for c in doctor.run_checks()}
        java = checks["Java 11+ (for OpenDataLoader)"]
        self.assertFalse(java.ok)
        self.assertFalse(java.required)
        self.assertIn("fallback", checks["PDF parser in use"].detail)

    def test_old_java_not_accepted(self):
        with mock.patch.object(doctor, "java_major", return_value=8):
            self.assertFalse({c.name: c for c in doctor.run_checks()}["Java 11+ (for OpenDataLoader)"].ok)

    def test_never_prints_secrets(self):
        env = {"DOCULENS_REMOTE_AI_ENABLED": "true", "LLM_PROVIDER": "p", "LLM_API_KEY": "sk-SECRET-123",
               "LLM_MODEL": "m", "LLM_BASE_URL": "https://x.test/v1"}
        with mock.patch.dict("os.environ", env):
            text = " ".join(f"{c.name} {c.detail}" for c in doctor.run_checks())
        self.assertNotIn("SECRET", text)
        self.assertIn("hybrid", text)


if __name__ == "__main__":
    unittest.main()
