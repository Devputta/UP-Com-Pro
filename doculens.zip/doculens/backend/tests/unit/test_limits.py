import asyncio
import json
import unittest

from app.api.limits import OVERHEAD, BodySizeLimit

LIMIT = 1000


async def echo_app(scope, receive, send):
    total = 0
    while True:
        msg = await receive()
        total += len(msg.get("body", b""))
        if not msg.get("more_body"):
            break
    await send({"type": "http.response.start", "status": 200, "headers": []})
    await send({"type": "http.response.body", "body": str(total).encode()})


def call(headers, chunks):
    sent = []
    queue = list(chunks)

    async def receive():
        body = queue.pop(0) if queue else b""
        return {"type": "http.request", "body": body, "more_body": bool(queue)}

    async def send(m):
        sent.append(m)

    scope = {"type": "http", "method": "POST", "path": "/api/documents", "headers": headers}
    asyncio.run(BodySizeLimit(echo_app, LIMIT)(scope, receive, send))
    status = sent[0]["status"]
    return status, sent[1]["body"]


class BodyLimitTests(unittest.TestCase):
    def test_small_body_passes(self):
        self.assertEqual(call([(b"content-length", b"10")], [b"x" * 10]), (200, b"10"))

    def test_declared_oversize_rejected_before_reading(self):
        status, body = call([(b"content-length", str(LIMIT + OVERHEAD + 1).encode())], [b"x"])
        self.assertEqual(status, 413)
        self.assertEqual(json.loads(body)["error"]["code"], "too_large")

    def test_chunked_oversize_without_content_length_is_cut_off(self):
        status, body = call([], [b"x" * 600] * (2 + (LIMIT + OVERHEAD) // 600))
        self.assertEqual(status, 413)

    def test_lying_content_length_is_still_cut_off(self):
        status, _ = call([(b"content-length", b"5")], [b"x" * 800] * ((LIMIT + OVERHEAD) // 800 + 2))
        self.assertEqual(status, 413)

    def test_garbage_content_length_rejected(self):
        status, body = call([(b"content-length", b"abc")], [b""])
        self.assertEqual(status, 400)

    def test_exactly_at_limit_passes(self):
        n = LIMIT + OVERHEAD
        self.assertEqual(call([(b"content-length", str(n).encode())], [b"x" * n])[0], 200)

    def test_non_http_scopes_untouched(self):
        hit = []

        async def app(scope, receive, send):
            hit.append(scope["type"])

        asyncio.run(BodySizeLimit(app, 1)({"type": "lifespan"}, None, None))
        self.assertEqual(hit, ["lifespan"])


if __name__ == "__main__":
    unittest.main()
