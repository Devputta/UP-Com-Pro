# Project Memory and Decisions

## Current state
- Product: DocuLens Document Intelligence Platform.
- Scope: Advanced MVP.
- Processing: local parsing + optional remote LLM.
- Budget: ₹0 target for local development/testing.
- Priorities: cited AI chat, table extraction, document comparison.
- Status: MVP implemented in one pass (Days 1–8 backend scope, Day 9 UI first draft). Not yet run end-to-end with FastAPI, Vite or OpenDataLoader (see phase.md).
- Current phase: verification on a networked machine, then Day 9 polish and Day 10 release checks.

## Fixed decisions
1. PDF-only input in MVP.
2. Local parsing, metadata, and lexical retrieval.
3. Remote calls are optional and disclosed.
4. Parser and model integrations are replaceable adapters.
5. Backend validates every citation.
6. No evidence means no confident factual answer.
7. No authentication/team features in local MVP.
8. Warm paper, charcoal, burnt-orange design; no generic AI aesthetic.

## ADR-001: FastAPI
Use FastAPI/Pydantic for typed contracts and Python parser integration. Revisit if deployment constraints change.

## ADR-002: OpenDataLoader adapter
Use OpenDataLoader behind `PdfParser`; structured Markdown/JSON and page/element metadata help retrieval and citations. Output quality varies; test representative PDFs and verify installed version licensing.

## ADR-003: SQLite
Use SQLite for local simplicity. Revisit for multi-user concurrency.

## ADR-004: Lexical retrieval first
Start with a deterministic local baseline. Add embeddings after evaluation shows a need.

## ADR-005: Fake model in tests
Critical flows must be repeatable without an API key.

## ADR-006: stdlib sqlite3 instead of SQLAlchemy
The build environment had no package access, so SQLAlchemy could not be installed or tested. The persistence layer uses stdlib `sqlite3` behind `db/repository.py`, which keeps all SQL in one place and is covered by tests. Revisit if the schema grows or a different database is needed.

## ADR-007: fallback parser
`PypdfParser` is a pure-Python fallback used when OpenDataLoader or Java is missing, and for tests. It estimates headings from font size and spacing, and detects tables as runs of rows whose cells sit at separated x positions. Ruled tables without text gaps, merged cells and multi-line cells are not handled. `get_parser()` prefers OpenDataLoader when available.

## ADR-008: chunks never span pages
Found during testing: a chunk spanning pages made the citation page imprecise. Chunks now split at page boundaries so every citation names exactly one page.

## ADR-009: configuration loading
Found by audit: the README told users to copy `.env.example` but nothing read it, so keys and limits were silently ignored. `load_settings()` now merges `backend/.env` under real environment variables using a small stdlib parser. Relative data paths resolve against `backend/` so storage does not depend on the launch directory. Remote AI additionally requires an `https://` base URL (plain `http://` only for localhost).

## ADR-010: upload size enforced before buffering
A pure-ASGI `BodySizeLimit` rejects oversized bodies (by `Content-Length` and by counting streamed bytes) before multipart parsing, because the route's bounded read alone cannot stop the framework from buffering an oversized upload first.

## Known limitations
- Lexical retrieval cannot match irregular word forms ("grow"/"grew"). Embeddings are the planned remedy once evaluated.
- Fallback table detection is alignment-based: it can miss tables or mistake aligned prose for one. Always check the source page.
- Scanned (image-only) PDFs are rejected with `no_text`; no OCR.
- The OpenDataLoader adapter is written to upstream's documented API but untested; verify JSON keys against the installed release.
- Comparison similarity can misjudge semantic changes; uncertain matches are labelled.

## Risks
Complex tables/scans may parse imperfectly; coordinate mapping needs care; remote providers may receive sensitive excerpts; similarity can misclassify semantic changes; free quotas can change.

## Changelog
- 1.0: initial blueprint.
- 1.1: first implementation; see phase.md for verified status.
