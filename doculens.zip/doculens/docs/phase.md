# Phases and Day-by-Day Plan

Target: 10 focused development days. This is a plan, not a guarantee; PDF edge cases may take longer. Every day ends with something testable.

## Day 1 — Repository and contracts
Build frontend/backend skeleton, Python environment, settings, health endpoint, README, `.gitignore`. Test clean startup and `/api/health`. Done when a fresh clone follows documented setup.

## Day 2 — Upload and library
Implement upload, signature/type checks, size limit, UUID path, checksum, SQLite metadata, library UI. Test invalid file, oversize, duplicate filename, traversal filename. Done when uploaded PDFs appear as queued.

## Day 3 — Parser adapter
Define `PdfParser`, implement OpenDataLoader adapter, parse Markdown/JSON, preserve provenance, add timeout and safe failures. Test fixture PDF and parser failure. Check Java 11+ and Python 3.10+ requirements.

## Day 4 — Chunking and search
Add section-aware chunks, local lexical retrieval, source excerpts, page navigation. Test provenance, document scoping, empty results.

## Day 5 — Chat and citations
Add fake model provider, optional remote adapter, evidence-grounded prompt, citation validation, chat UI. Test unknown citations, missing evidence, absent API key. All tests must run without paid services.

## Day 6 — Tables
Normalize table elements, add list/detail endpoints, preview, CSV export. Test CSV quoting, formula-injection mitigation, and source page.

## Day 7 — Comparison
Match sections/paragraphs; classify added/removed/changed; show both source passages. Test identical docs, changed numbers, added content, ambiguous matches.

## Day 8 — Security and deletion
Add deletion cascade, cleanup retry, parser timeout/output bounds, secret handling, remote-use disclosure, prompt-injection tests. Verify no path traversal and no false deletion-success message.

## Day 9 — UI and accessibility
Polish responsive workspace, keyboard navigation, focus states, statuses, table/comparison usability. Test mobile, long filenames, large tables, reduced motion.

## Day 10 — Release candidate
Review README, license notices, dependency versions, local-only mode, clean install, tests and limitations. Update `memory.md` and `phase.md` only with verified status.

## Phase gate
Do not advance just because code exists. Advance when tests pass and the workflow works from the interface.

## Verified status (honest ledger)
Verified by running in the build sandbox (Python 3.12, stdlib `unittest`, pypdf, reportlab): 48 unit tests and 29 integration tests pass.

Unit: settings (defaults, `.env` parsing, remote-AI opt-in and https rule, the shipped `.env.example` loads cleanly), request-body size limit (declared, chunked and lying Content-Length), setup doctor, chunking and provenance, lexical retrieval and document scoping, citation validation (unknown IDs rejected, no-evidence handling, provider-outage fallback), CSV quoting and formula-injection mitigation, table normalisation warnings, comparison logic, upload validation, traversal filenames, UUID-only paths.

Integration, on real generated PDFs (Day 2 specifically: uploads land as `queued` with checksum and UUID path; duplicate filenames and identical content become independent documents and deleting one leaves the other; rejected uploads leave no files or rows; traversal, NUL, over-long and non-Latin filenames never reach the filesystem path; the library survives a restart; `.env` is honoured and real env vars override it): parse → search → cite with page provenance; two-document comparison; deletion and retry after partial failure; parser timeout kills the process; page-limit failure; a drawn table extracted with its page, a blank cell preserved and a `=SUM(...)` cell neutralised in CSV; encrypted, truncated, random-bytes and text-free PDFs fail with safe codes and leave no derived data; script-like text is stored as plain text; a 10-question retrieval check (hit@3 = 10/10 on a small self-authored corpus, so a regression guard rather than a quality claim).

NOT verified (no network in the sandbox): FastAPI routes and `tests/api/test_api.py`; the React build and Vitest; the OpenDataLoader adapter; the remote provider against a real service. The frontend source passed only a partial type-check with stand-in React typings and contains no raw-HTML sinks.

| Day | Scope | Status |
|---|---|---|
| 1 | Skeleton, settings, health | Settings, `.env` loading and `python -m app.doctor` verified; `/api/health` and clean `uvicorn` startup untested (FastAPI not installable here) |
| 2 | Upload, library | Service, storage, database and size-limit logic verified against every listed test; the HTTP route and library UI not yet run |
| 3 | Parser adapter | Fallback verified incl. hostile PDFs; OpenDataLoader untested |
| 4 | Chunking, search | Verified; small eval baseline |
| 5 | Chat, citations | Verified with the local provider; remote untested |
| 6 | Tables, CSV | Verified on a drawn-table PDF; complex layouts untested |
| 7 | Comparison | Verified on generated PDFs |
| 8 | Security, deletion | Verified at service level; HTTP-level and larger fuzzing untested |
| 9 | UI | First draft; needs browser, mobile and keyboard review |
| 10 | Release | Not started |
