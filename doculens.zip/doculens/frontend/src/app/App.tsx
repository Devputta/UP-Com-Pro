import { useCallback, useEffect, useState } from "react";
import { api, type Citation, type Doc, type Settings } from "../lib/api";
import { ErrorPanel, Toast } from "../components/common";
import { Library } from "../features/library/Library";
import { Ask } from "../features/chat/Ask";
import { Search } from "../features/reader/Search";
import { Evidence } from "../features/reader/Evidence";
import { Tables } from "../features/tables/Tables";
import { Compare } from "../features/compare/Compare";

type View = "library" | "ask" | "tables" | "compare" | "settings";
const TABS: { id: View; label: string }[] = [
  { id: "ask", label: "Ask" }, { id: "tables", label: "Tables" }, { id: "compare", label: "Compare" }, { id: "settings", label: "Settings" },
];

export function App() {
  const [docs, setDocs] = useState<Doc[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [view, setView] = useState<View>("library");
  const [cite, setCite] = useState<Citation | null>(null);
  const [toast, setToast] = useState("");
  const [offline, setOffline] = useState("");

  const refresh = useCallback(async () => {
    try { const d = await api.documents(); setDocs(d); setOffline("");
      setSelected((s) => s.filter((id) => d.some((x) => x.id === id && x.status === "ready"))); }
    catch (e) { setOffline((e as Error).message); }
  }, []);

  useEffect(() => { refresh(); api.settings().then(setSettings).catch(() => undefined); }, [refresh]);
  const busy = docs.some((d) => d.status === "queued" || d.status === "processing");
  useEffect(() => { if (!busy) return; const t = setInterval(refresh, 2000); return () => clearInterval(t); }, [busy, refresh]);

  const toggle = (id: string) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const open = (c: Citation) => { setCite(c); };
  const processing = docs.filter((d) => d.status === "processing" || d.status === "queued").length;

  return (
    <div className={`shell view-${view}`}>
      <a className="skip" href="#main">Skip to content</a>
      <header className="topbar">
        <h1 className="brand">DocuLens</h1>
        <nav aria-label="Workspace" className="tabs">
          {TABS.map((t) => (
            <button key={t.id} className={view === t.id ? "tab is-active" : "tab"} aria-current={view === t.id ? "page" : undefined}
              onClick={() => setView(t.id)}>{t.label}</button>
          ))}
        </nav>
        <span className="mode" title={settings?.disclosure}>{settings?.mode === "hybrid" ? "Hybrid mode" : "Local only"}</span>
      </header>

      {processing > 0 && <p className="banner" role="status">Processing {processing} document{processing > 1 ? "s" : ""}…</p>}
      {offline && <ErrorPanel message={offline} onRetry={refresh} />}

      <div className="body">
        <aside className="rail" aria-label="Library">
          <Library docs={docs} selected={selected} onToggle={toggle} onChanged={refresh} onMessage={setToast}
            maxMb={settings?.max_upload_mb ?? 25} />
        </aside>
        <main id="main" className="pane" tabIndex={-1}>
          {view === "library" && <p className="hint mobile-only">Select documents above, then open Ask, Tables, or Compare.</p>}
          {(view === "ask" || view === "library") && (
            <><Ask selected={selected} settings={settings} onOpenSource={open} /><Search selected={selected} onOpen={open} /></>
          )}
          {view === "tables" && <Tables docs={docs} selected={selected} />}
          {view === "compare" && <Compare docs={docs} />}
          {view === "settings" && <SettingsView s={settings} />}
        </main>
        <div className={cite ? "evidence-wrap is-open" : "evidence-wrap"}><Evidence cite={cite} onClose={() => setCite(null)} /></div>
      </div>

      <nav className="bottom-nav" aria-label="Sections">
        {(["library", "ask", "tables", "compare"] as View[]).map((v) => (
          <button key={v} className={view === v ? "is-active" : ""} onClick={() => setView(v)}>{v[0].toUpperCase() + v.slice(1)}</button>
        ))}
      </nav>
      {toast && <Toast message={toast} onDone={() => setToast("")} />}
    </div>
  );
}

function SettingsView({ s }: { s: Settings | null }) {
  if (!s) return <p className="hint">Loading settings…</p>;
  return (
    <section aria-labelledby="set-h">
      <h2 id="set-h">Settings</h2>
      <dl className="facts">
        <dt>Mode</dt><dd>{s.mode === "hybrid" ? "Hybrid: local processing, optional remote AI answers" : "Local only: nothing leaves this machine"}</dd>
        <dt>Answer provider</dt><dd>{s.provider}</dd>
        <dt>PDF parser</dt><dd>{s.parser}{s.parser.includes("fallback") && " (estimated structure; install OpenDataLoader + Java for best results)"}</dd>
        <dt>Limits</dt><dd>{s.max_upload_mb} MB per file · {s.max_pages} pages</dd>
      </dl>
      <h3>Privacy</h3>
      <p className="wrap">{s.disclosure}</p>
      <p className="wrap">Remote AI is configured only through backend environment variables (see <code>.env.example</code>). Keys are never sent to this page.</p>
      <h3>Deleting data</h3>
      <p className="wrap">Deleting a document removes its file, extracted text, tables and comparisons from this machine. It cannot recall anything you exported, or excerpts a remote provider already received; those follow the provider's own retention rules.</p>
    </section>
  );
}
