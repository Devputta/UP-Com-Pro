import { useEffect, useRef, type ReactNode } from "react";
import type { Status } from "../lib/api";

const LABEL: Record<Status, string> = { queued: "Queued", processing: "Processing", ready: "Ready", failed: "Failed" };

export function StatusBadge({ status, pages }: { status: Status; pages?: number | null }) {
  const text = status === "ready" && pages ? `Ready · ${pages} pp.` : LABEL[status];
  return <span className={`status status-${status}`}>{text}</span>;
}

export function EmptyState({ title, children }: { title: string; children?: ReactNode }) {
  return <div className="empty"><h3>{title}</h3>{children && <p>{children}</p>}</div>;
}

export function ErrorPanel({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="error-panel" role="alert">
      <p>{message}</p>
      {onRetry && <button className="btn" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function ConfirmDeleteDialog({ name, onConfirm, onCancel }: { name: string; onConfirm: () => void; onCancel: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLButtonElement>("button")?.focus();
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") onCancel(); };
    document.addEventListener("keydown", key);
    return () => { document.removeEventListener("keydown", key); prev?.focus(); };
  }, [onCancel]);
  return (
    <div className="scrim">
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="del-title" ref={ref}>
        <h2 id="del-title">Delete this document?</h2>
        <p className="wrap">“{name}” and everything extracted from it (text, tables, comparisons) will be removed from this machine.
          Copies you exported or sent to a remote AI provider are not affected.</p>
        <div className="row-end">
          <button className="btn" onClick={onCancel}>Keep it</button>
          <button className="btn btn-danger" onClick={onConfirm}>Delete</button>
        </div>
      </div>
    </div>
  );
}

export function Toast({ message, onDone }: { message: string; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 5000); return () => clearTimeout(t); }, [message, onDone]);
  return <div className="toast" role="status" aria-live="polite">{message}</div>;
}
