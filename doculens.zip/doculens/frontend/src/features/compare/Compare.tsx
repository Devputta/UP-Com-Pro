import { useState } from "react";
import { api, type Change, type Comparison, type Doc } from "../../lib/api";
import { EmptyState, ErrorPanel } from "../../components/common";

const LABEL: Record<Change["type"], string> = {
  added: "Added", removed: "Removed", changed: "Changed", possibly_equivalent: "Possibly equivalent",
};
const MARK: Record<Change["type"], string> = { added: "+", removed: "−", changed: "~", possibly_equivalent: "≈" };

export function Compare({ docs }: { docs: Doc[] }) {
  const ready = docs.filter((d) => d.status === "ready");
  const [left, setLeft] = useState(""); const [right, setRight] = useState("");
  const [res, setRes] = useState<Comparison | null>(null);
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true); setError(""); setRes(null);
    try { setRes(await api.compare(left, right)); } catch (e) { setError((e as Error).message); }
    setBusy(false);
  }
  const name = (id: string) => docs.find((d) => d.id === id)?.original_name ?? "Document";

  return (
    <section aria-labelledby="cmp-h">
      <h2 id="cmp-h">Compare</h2>
      {ready.length < 2 ? (
        <EmptyState title="Comparison needs two ready documents">Add and finish processing a second PDF.</EmptyState>
      ) : (
        <div className="cmp-pick">
          <label>Left (earlier)<select value={left} onChange={(e) => setLeft(e.target.value)}>
            <option value="">Choose…</option>{ready.map((d) => <option key={d.id} value={d.id}>{d.original_name}</option>)}</select></label>
          <label>Right (later)<select value={right} onChange={(e) => setRight(e.target.value)}>
            <option value="">Choose…</option>{ready.map((d) => <option key={d.id} value={d.id}>{d.original_name}</option>)}</select></label>
          <button className="btn btn-primary" disabled={!left || !right || left === right || busy} onClick={run}>
            {busy ? "Comparing…" : "Compare"}</button>
        </div>
      )}
      {left && left === right && <p className="hint">Choose two different documents.</p>}
      {error && <ErrorPanel message={error} />}
      {res && res.changes.length === 0 && <EmptyState title="No differences found">The extracted text of both documents matches.</EmptyState>}
      {res && res.changes.length > 0 && (
        <>
          <p className="muted">{res.changes.length} difference(s). Matches are estimated from text similarity; check both passages.</p>
          <ol className="changes">
            {res.changes.map((c, i) => (
              <li key={i} className={`change change-${c.type}`}>
                <div className="change-head">
                  <span className="mark" aria-hidden="true">{MARK[c.type]}</span>
                  <strong>{LABEL[c.type]}</strong>
                  {c.uncertain && <span className="uncertain">Uncertain match · {Math.round(c.confidence * 100)}%</span>}
                </div>
                <p>{c.summary}</p>
                <div className="sides">
                  <blockquote><span className="side-h">{name(res.left_document_id)}{c.left_page ? ` · page ${c.left_page}` : ""}</span>
                    {c.left_text || <em>Not present</em>}</blockquote>
                  <blockquote><span className="side-h">{name(res.right_document_id)}{c.right_page ? ` · page ${c.right_page}` : ""}</span>
                    {c.right_text || <em>Not present</em>}</blockquote>
                </div>
              </li>
            ))}
          </ol>
        </>
      )}
    </section>
  );
}
