import { useRef, useState } from "react";
import { api, formatBytes, type Doc } from "../../lib/api";
import { ConfirmDeleteDialog, EmptyState, StatusBadge } from "../../components/common";

interface Props {
  docs: Doc[]; selected: string[]; onToggle: (id: string) => void; onChanged: () => void;
  onMessage: (m: string) => void; maxMb: number;
}

export function Library({ docs, selected, onToggle, onChanged, onMessage, maxMb }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [toDelete, setToDelete] = useState<Doc | null>(null);

  async function add(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    for (const f of Array.from(files)) {
      try { await api.upload(f); } catch (e) { onMessage(`${f.name}: ${(e as Error).message}`); }
    }
    setBusy(false);
    if (input.current) input.current.value = "";
    onChanged();
  }

  async function confirmDelete() {
    const d = toDelete; setToDelete(null);
    if (!d) return;
    try { await api.remove(d.id); onMessage(`Deleted “${d.original_name}”.`); }
    catch (e) { onMessage(`Not fully deleted: ${(e as Error).message}`); }
    onChanged();
  }

  return (
    <section aria-labelledby="lib-h" className="library">
      <h2 id="lib-h" className="rail-title">Library</h2>
      <input ref={input} type="file" accept="application/pdf,.pdf" multiple hidden id="pdf-input"
        onChange={(e) => add(e.target.files)} />
      <button className="btn btn-primary btn-block" disabled={busy} onClick={() => input.current?.click()}>
        {busy ? "Uploading…" : "Add a PDF"}
      </button>
      <p className="hint">PDF only · up to {maxMb} MB. Files stay on this machine.</p>
      {docs.length === 0 ? (
        <EmptyState title="No documents yet">Add a PDF to search it, ask questions with page citations, and pull out its tables.</EmptyState>
      ) : (
        <ul className="doclist">
          {docs.map((d) => (
            <li key={d.id} className={selected.includes(d.id) ? "doc is-selected" : "doc"}>
              <label className="doc-main">
                <input type="checkbox" checked={selected.includes(d.id)} disabled={d.status !== "ready"}
                  onChange={() => onToggle(d.id)} aria-label={`Select ${d.original_name}`} />
                <span className="doc-text">
                  <span className="doc-name" title={d.original_name}>{d.original_name}</span>
                  <span className="doc-meta"><StatusBadge status={d.status} pages={d.page_count} /> · {formatBytes(d.size_bytes)}</span>
                </span>
              </label>
              {d.status === "failed" && (
                <p className="doc-error">{d.error_message ?? "Processing failed."}{" "}
                  <button className="link" onClick={() => api.reprocess(d.id).then(onChanged)}>Retry</button></p>
              )}
              {d.warnings.length > 0 && d.status === "ready" && <p className="doc-warn">{d.warnings[0]}</p>}
              <button className="link link-quiet" onClick={() => setToDelete(d)} aria-label={`Delete ${d.original_name}`}>Delete</button>
            </li>
          ))}
        </ul>
      )}
      {toDelete && <ConfirmDeleteDialog name={toDelete.original_name} onConfirm={confirmDelete} onCancel={() => setToDelete(null)} />}
    </section>
  );
}
