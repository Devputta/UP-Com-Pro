import { useEffect, useRef, useState } from "react";
import { api, pdfUrl, type Citation } from "../../lib/api";

export function Evidence({ cite, onClose }: { cite: Citation | null; onClose: () => void }) {
  const [text, setText] = useState<string[]>([]);
  const [err, setErr] = useState("");
  const closeBtn = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!cite) return;
    setText([]); setErr("");
    api.page(cite.document_id, cite.page_number).then((p) => setText(p.elements.map((e) => e.content))).catch((e) => setErr(e.message));
    closeBtn.current?.focus();
  }, [cite]);

  if (!cite) return <aside className="evidence is-empty" aria-label="Source evidence"><p className="hint">Open a citation to see its source here.</p></aside>;
  return (
    <aside className="evidence" aria-label="Source evidence" onKeyDown={(e) => e.key === "Escape" && onClose()}>
      <div className="row-between">
        <h2>Source · page {cite.page_number}</h2>
        <button ref={closeBtn} className="btn" onClick={onClose}>Close</button>
      </div>
      <p className="muted wrap">{cite.document_name}{cite.section ? ` · ${cite.section}` : ""}</p>
      <blockquote className="quote">{cite.quote}</blockquote>
      <h3>Extracted text on this page</h3>
      {err ? <p className="doc-error">{err}</p> : text.map((t, i) => (
        <p key={i} className={t.includes(cite.quote.slice(0, 40).replace("…", "")) ? "page-p is-hit" : "page-p"}>{t}</p>
      ))}
      <a className="btn" href={pdfUrl(cite.document_id, cite.page_number)} target="_blank" rel="noopener noreferrer">Open original PDF</a>
    </aside>
  );
}
