import { useState } from "react";
import { api, type Citation, type SearchHit } from "../../lib/api";

export function Search({ selected, onOpen }: { selected: string[]; onOpen: (c: Citation) => void }) {
  const [q, setQ] = useState(""); const [hits, setHits] = useState<SearchHit[] | null>(null); const [err, setErr] = useState("");
  async function go(e: React.FormEvent) {
    e.preventDefault(); if (!q.trim()) return; setErr("");
    try { setHits(await api.search(q.trim(), selected)); } catch (x) { setErr((x as Error).message); }
  }
  return (
    <section aria-labelledby="s-h" className="search">
      <h2 id="s-h">Search</h2>
      <form onSubmit={go} role="search" className="search-form">
        <label htmlFor="sq" className="sr-only">Search passages</label>
        <input id="sq" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Keyword search, no AI" />
        <button className="btn">Search</button>
      </form>
      {err && <p className="doc-error">{err}</p>}
      {hits && hits.length === 0 && <p className="no-evidence">No supporting passage found.</p>}
      <ul className="hits">
        {hits?.map((h) => (
          <li key={h.chunk_id}>
            <p className="wrap">{h.excerpt}</p>
            <button className="cite" onClick={() => onOpen({ ...h, quote: h.excerpt, section: h.section })}>
              Open source · page {h.page_number}<span className="cite-doc"> — {h.document_name}</span></button>
          </li>
        ))}
      </ul>
    </section>
  );
}
