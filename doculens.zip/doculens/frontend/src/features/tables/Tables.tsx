import { useEffect, useState } from "react";
import { api, csvUrl, type Doc, type TableT } from "../../lib/api";
import { EmptyState, ErrorPanel } from "../../components/common";

export function Tables({ docs, selected }: { docs: Doc[]; selected: string[] }) {
  const [tables, setTables] = useState<TableT[] | null>(null);
  const [error, setError] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const key = selected.join(",");

  useEffect(() => {
    setTables(null); setError(""); setOpen(null);
    if (selected.length === 0) { setTables([]); return; }
    Promise.all(selected.map((id) => api.tables(id))).then((r) => setTables(r.flat())).catch((e) => setError(e.message));
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps

  const name = (id: string) => docs.find((d) => d.id === id)?.original_name ?? "Document";
  const current = tables?.find((t) => t.id === open) ?? tables?.[0];

  return (
    <section aria-labelledby="tab-h">
      <h2 id="tab-h">Tables</h2>
      {error && <ErrorPanel message={error} />}
      {tables && tables.length === 0 && !error && (
        <EmptyState title={selected.length ? "No tables detected" : "Select a document"}>
          {selected.length ? "The parser found no tables in the selected documents. Tables in scanned pages are not detected." : "Tables appear here once you select a ready document."}
        </EmptyState>
      )}
      {tables && tables.length > 0 && current && (
        <div className="tables-layout">
          <ul className="table-list">
            {tables.map((t) => (
              <li key={t.id}><button className={t.id === current.id ? "tl is-active" : "tl"} onClick={() => setOpen(t.id)}>
                <span className="wrap">{name(t.document_id)}</span><span className="muted">page {t.page_number}</span>
              </button></li>
            ))}
          </ul>
          <div className="table-pane">
            <div className="row-between">
              <p className="muted">Source: {name(current.document_id)} · page {current.page_number}</p>
              <a className="btn" href={csvUrl(current.id)} download>Export CSV</a>
            </div>
            {current.warnings.length > 0 && (
              <ul className="warnings" aria-label="Extraction warnings">{current.warnings.map((w) => <li key={w}>{w}</li>)}</ul>
            )}
            <div className="table-scroll" tabIndex={0} role="region" aria-label="Table preview">
              <table>
                <thead><tr>{current.columns.map((c, i) => <th key={i} scope="col">{c}</th>)}</tr></thead>
                <tbody>{current.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
