export type Status = "queued" | "processing" | "ready" | "failed";
export interface Doc {
  id: string; original_name: string; size_bytes: number; page_count: number | null; status: Status;
  error_code: string | null; error_message: string | null; created_at: string; warnings: string[];
}
export interface Citation {
  document_id: string; document_name: string; page_number: number; chunk_id: string; quote: string; section: string;
}
export interface ChatResponse {
  answer: string; citations: Citation[]; insufficient_evidence: boolean; ai_generated: boolean;
  provider: string; notice: string; remote_used: boolean;
}
export interface TableT {
  id: string; document_id: string; page_number: number; columns: string[]; rows: string[][]; warnings: string[];
}
export interface Change {
  type: "added" | "removed" | "changed" | "possibly_equivalent"; summary: string; confidence: number;
  uncertain: boolean; changed_figures: string[][]; left_page: number | null; right_page: number | null;
  left_text: string; right_text: string;
}
export interface Comparison { id: string; left_document_id: string; right_document_id: string; changes: Change[] }
export interface SearchHit {
  chunk_id: string; document_id: string; document_name: string; page_number: number; section: string; excerpt: string;
}
export interface Settings {
  mode: "local" | "hybrid"; remote_ai_enabled: boolean; remote_ai_configured: boolean; provider: string;
  parser: string; max_upload_mb: number; max_pages: number; disclosure: string;
}
export interface PageText { page_number: number; elements: { type: string; content: string }[] }

export class ApiError extends Error {
  constructor(public code: string, message: string) { super(message); }
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`/api${path}`, init);
  } catch {
    throw new ApiError("network", "Can't reach the DocuLens server. Is the backend running?");
  }
  if (!res.ok) {
    let code = "error", message = "Something went wrong.";
    try { const b = await res.json(); code = b.error?.code ?? code; message = b.error?.message ?? message; } catch { /* keep defaults */ }
    throw new ApiError(code, message);
  }
  return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
}

const json = (body: unknown): RequestInit => ({
  method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
});

export const api = {
  settings: () => req<Settings>("/settings"),
  documents: () => req<Doc[]>("/documents"),
  upload: (file: File) => { const f = new FormData(); f.append("file", file); return req<Doc>("/documents", { method: "POST", body: f }); },
  remove: (id: string) => req<void>(`/documents/${id}`, { method: "DELETE" }),
  reprocess: (id: string) => req<Doc>(`/documents/${id}/reprocess`, { method: "POST" }),
  search: (q: string, ids: string[]) =>
    req<SearchHit[]>(`/documents/search?q=${encodeURIComponent(q)}${ids.map((i) => `&document_ids=${i}`).join("")}`),
  page: (id: string, n: number) => req<PageText>(`/documents/${id}/pages/${n}`),
  chat: (question: string, document_ids: string[], use_remote_ai: boolean) =>
    req<ChatResponse>("/chat", json({ question, document_ids, use_remote_ai })),
  tables: (id: string) => req<TableT[]>(`/documents/${id}/tables`),
  compare: (left: string, right: string) =>
    req<Comparison>("/comparisons", json({ left_document_id: left, right_document_id: right })),
};

export const csvUrl = (tableId: string) => `/api/tables/${tableId}/export.csv`;
export const pdfUrl = (docId: string, page: number) => `/api/documents/${docId}/file#page=${page}`;

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
