import React, { useState } from 'react';
import {
  Send,
  ShieldCheck,
  AlertTriangle,
  BookOpen,
  Trash2,
  Cpu,
  Globe,
  CheckCircle2,
  HelpCircle,
  XCircle,
  Quote,
  CheckSquare,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  DocumentChunk,
  DocumentEntity,
  InquiryMessage,
  CitationEvidence,
} from '../types/doculens';
import { processInquiry } from '../services/inquiryEngine';

interface InquiryViewProps {
  documents: DocumentEntity[];
  chunks: DocumentChunk[];
  selectedDocId?: string;
  inquiries: InquiryMessage[];
  onSaveInquiry: (msg: InquiryMessage) => Promise<void>;
  onClearInquiries: () => Promise<void>;
  onNavigateToReader: (
    docId: string,
    pageNumber: number,
    highlightQuery?: string,
    targetElementId?: string
  ) => void;
  isOnline: boolean;
}

export const InquiryView: React.FC<InquiryViewProps> = ({
  documents,
  chunks,
  selectedDocId,
  inquiries,
  onSaveInquiry,
  onClearInquiries,
  onNavigateToReader,
  isOnline,
}) => {
  const [question, setQuestion] = useState('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [useRemoteAssist, setUseRemoteAssist] = useState(false);
  const [selectedCitation, setSelectedCitation] = useState<CitationEvidence | null>(null);

  const sampleQuestions = [
    {
      q: 'What were the total clean energy investments and battery storage additions in 2025?',
      desc: 'Retrieves solar & battery expenditure figures from Energy Audit',
    },
    {
      q: 'What are the patient eligibility criteria and age ranges in Protocol B-709 Rev 2?',
      desc: 'Retrieves EASI scores, age bounds, and disease duration',
    },
    {
      q: 'Was mild hepatic impairment permitted or excluded in Protocol Revision 3?',
      desc: 'Retrieves the Amendment 1 safety rule on Child-Pugh Class A',
    },
    {
      q: 'What is the nuclear fission capital investment in Brazil?',
      desc: 'Triggers honest Insufficient Evidence status',
    },
  ];

  const handleSubmit = async (e?: React.FormEvent, customQ?: string) => {
    if (e) e.preventDefault();
    const query = customQ || question;
    if (!query.trim() || isSynthesizing) return;

    const userMsg: InquiryMessage = {
      id: `usr-${crypto.randomUUID().slice(0, 8)}`,
      role: 'user',
      content: query.trim(),
      timestamp: Date.now(),
      documentScopeId: selectedDocId,
      evidence: [],
      verificationStatus: 'verified',
      provider: 'local-deterministic',
    };

    await onSaveInquiry(userMsg);
    setQuestion('');
    setIsSynthesizing(true);

    try {
      const responseMsg = await processInquiry(
        query,
        chunks,
        documents,
        selectedDocId,
        useRemoteAssist && isOnline
      );
      await onSaveInquiry(responseMsg);
    } catch (err: any) {
      const errorMsg: InquiryMessage = {
        id: `err-${crypto.randomUUID().slice(0, 8)}`,
        role: 'assistant',
        content: `Error during evidence retrieval: ${err?.message || 'Processing failed'}`,
        timestamp: Date.now(),
        documentScopeId: selectedDocId,
        evidence: [],
        verificationStatus: 'insufficient_evidence',
        provider: 'local-deterministic',
      };
      await onSaveInquiry(errorMsg);
    } finally {
      setIsSynthesizing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-paper-border pb-4">
        <div>
          <h1 className="text-2xl font-serif font-semibold text-ink">
            Grounded Inquiry & Provenance Synthesis
          </h1>
        </div>

        {inquiries.length > 0 && (
          <button
            onClick={onClearInquiries}
            className="flex items-center gap-2 text-[13px] text-ink-muted hover:text-red-400 border border-paper-border rounded-md px-3.5 py-2 min-h-[36px] bg-paper-light hover:bg-paper-dim transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Inquiry Log</span>
          </button>
        )}
      </div>

      {/* Provider & Disclosure Bar */}
      <div className="p-4 bg-paper-light border border-paper-border rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-[13px]">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 font-medium text-ink">
            {useRemoteAssist && isOnline ? (
              <Globe className="w-4 h-4 text-accent" />
            ) : (
              <Cpu className="w-4 h-4 text-emerald-400" />
            )}
            <span>
              {useRemoteAssist && isOnline
                ? 'Remote Model Assist (Stylistic Refinement)'
                : '100% Local Deterministic Engine (Offline Default)'}
            </span>
          </div>

          <span className="text-ink-faint">·</span>

          <span className="text-ink-muted">
            {useRemoteAssist && isOnline
              ? 'Disclosed: Selected excerpts (titles, page numbers, text) and query sent to Google Gemini; verified on backend.'
              : 'Zero external network calls. Runs 100% locally on your machine.'}
          </span>
        </div>

        <label className="flex items-center gap-2 cursor-pointer select-none shrink-0">
          <input
            type="checkbox"
            checked={useRemoteAssist}
            onChange={(e) => setUseRemoteAssist(e.target.checked)}
            className="w-4 h-4 rounded border-paper-border text-accent focus:ring-accent"
          />
          <span className="text-[13px] text-ink-muted">Optional Remote Assist</span>
        </label>
      </div>

      {/* Suggested Inquiries (Curated Benchmark Controls) */}
      <div className="space-y-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-ink-muted">
          Curated Reliability Benchmarks:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {sampleQuestions.map((item, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setQuestion(item.q);
                handleSubmit(undefined, item.q);
              }}
              className="text-left p-3.5 rounded-lg border border-paper-border bg-paper-light hover:border-accent hover:bg-paper-dim transition-all duration-150 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              <div className="text-[13px] font-sans font-medium text-ink group-hover:text-accent">
                "{item.q}"
              </div>
              <div className="text-xs text-ink-faint mt-1">{item.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Conversation / Evidence Stream */}
      <div className="space-y-5">
        {inquiries.length === 0 ? (
          <div className="border border-paper-border bg-paper-light rounded-lg p-8 sm:p-12 text-center text-ink-muted space-y-4 shadow-xs">
            <div className="w-16 h-16 mx-auto rounded-full bg-paper border border-paper-border p-3 flex items-center justify-center shadow-xs">
              <img
                src="/doculens-mark-transparent.png"
                alt="DocuLens Evidence Engine"
                className="w-full h-full object-contain"
              />
            </div>
            <p className="font-serif text-xl font-medium text-ink">
              Ask Documents With Grounded Citations
            </p>
            <p className="text-[13px] max-w-md mx-auto text-ink-muted leading-relaxed">
              Inquire about facts, requirements, tables, or measurements. DocuLens retrieves source
              passages, verifies every quote verbatim against the stored document text, and provides
              direct page references.
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-2">
              {sampleQuestions.slice(0, 2).map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setQuestion(item.q);
                    handleSubmit(undefined, item.q);
                  }}
                  className="px-3.5 py-2 min-h-[36px] bg-paper hover:bg-paper-dim border border-paper-border text-ink rounded-md text-[13px] transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  Ask "{item.q.slice(0, 45)}..."
                </button>
              ))}
            </div>
          </div>
        ) : (
          inquiries.map((msg) => (
            <div
              key={msg.id}
              className={`p-5 sm:p-6 rounded-lg border transition-all duration-150 space-y-4 shadow-xs ${
                msg.role === 'user'
                  ? 'bg-paper-light border-paper-border'
                  : msg.verificationStatus === 'insufficient_evidence'
                  ? 'bg-amber-500/10 border-amber-500/30'
                  : msg.verificationStatus === 'unverified'
                  ? 'bg-red-500/10 border-red-500/30'
                  : 'bg-paper-light border-paper-border-dark'
              }`}
            >
              {/* Message Header */}
              <div className="flex items-center justify-between text-xs text-ink-muted flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-ink text-[13px]">
                    {msg.role === 'user' ? 'Researcher Query' : 'DocuLens Synthesis'}
                  </span>
                  <span className="text-ink-faint">·</span>
                  <span className="text-xs font-mono text-ink-faint">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2">
                    {msg.verificationStatus === 'verified' && (
                      <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Verified Citations</span>
                      </span>
                    )}
                    {msg.verificationStatus === 'unverified' && (
                      <span className="flex items-center gap-1.5 text-xs text-red-400 font-medium">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Unverified / Citation Rejected</span>
                      </span>
                    )}
                    {msg.verificationStatus === 'insufficient_evidence' && (
                      <span className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>No Grounded Evidence</span>
                      </span>
                    )}
                    <span className="font-mono text-[11px] text-ink-faint">
                      [{msg.provider}]
                    </span>
                  </div>
                )}
              </div>

              {/* Validation Warnings / Rejection Reasons if unverified */}
              {msg.validationErrors && msg.validationErrors.length > 0 && (
                <div className="p-3.5 bg-red-500/10 border border-red-500/30 rounded-md text-[13px] text-red-300 space-y-1">
                  <div className="font-semibold flex items-center gap-1.5 text-xs uppercase tracking-wide text-red-200">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Citation Verification Alert:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-xs">
                    {msg.validationErrors.map((err, idx) => (
                      <li key={idx}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Provider Disclosures */}
              {msg.disclosures && msg.disclosures.length > 0 && (
                <div className="p-3 bg-paper border border-paper-border rounded-md text-xs text-ink-muted flex items-center gap-2">
                  <Info className="w-3.5 h-3.5 text-accent shrink-0" />
                  <span>{msg.disclosures.join(' ')}</span>
                </div>
              )}

              {/* Structured Presentation of Quotes, Facts, Summary, and AI Interpretation */}
              {msg.structured ? (
                <div className="space-y-4">
                  {/* Direct Quotations */}
                  {msg.structured.directQuotations && msg.structured.directQuotations.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-xs font-semibold uppercase tracking-wider text-ink-muted flex items-center gap-1.5">
                        <Quote className="w-3.5 h-3.5 text-accent" />
                        <span>Direct Quotations ({msg.structured.directQuotations.length})</span>
                      </div>
                      <div className="space-y-2.5">
                        {msg.structured.directQuotations.map((dq, idx) => {
                          const matchingEv = msg.evidence?.find((e) => e.evidenceId === dq.citationId);
                          const docForDq = documents.find((d) => d.originalName === dq.documentName);
                          const targetDocId = matchingEv?.documentId || docForDq?.id || selectedDocId || '';
                          const targetElementId = matchingEv?.sourceElementIds?.[0];
                          const isClickable = dq.verified && Boolean(targetDocId);

                          return (
                            <div
                              key={idx}
                              onClick={() => {
                                if (isClickable) {
                                  onNavigateToReader(targetDocId, dq.pageNumber, dq.quote, targetElementId);
                                }
                              }}
                              role={isClickable ? 'button' : undefined}
                              tabIndex={isClickable ? 0 : undefined}
                              onKeyDown={(e) => {
                                if (isClickable && (e.key === 'Enter' || e.key === ' ')) {
                                  e.preventDefault();
                                  onNavigateToReader(targetDocId, dq.pageNumber, dq.quote, targetElementId);
                                }
                              }}
                              aria-label={
                                isClickable
                                  ? `Jump to cited passage on page ${dq.pageNumber} of ${dq.documentName} in Reader`
                                  : undefined
                              }
                              aria-disabled={!isClickable ? 'true' : undefined}
                              className={`p-3.5 rounded-md border text-[13px] sm:text-sm font-serif leading-relaxed transition-all duration-150 ${
                                isClickable
                                  ? 'bg-paper border-paper-border text-ink hover:border-accent hover:bg-paper-dim/80 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent shadow-2xs'
                                  : dq.verified
                                  ? 'bg-paper border-paper-border text-ink'
                                  : 'bg-red-500/10 border-red-500/30 text-red-200 cursor-default opacity-85 select-none'
                              }`}
                            >
                              <p className="italic">"{dq.quote}"</p>
                              <div className="mt-2 flex items-center justify-between text-xs font-mono text-ink-muted">
                                <span className={isClickable ? 'text-accent hover:underline' : ''}>
                                  — {dq.documentName}, Page {dq.pageNumber} [{dq.citationId}]
                                  {isClickable && ' ↗'}
                                </span>
                                {dq.verified ? (
                                  <span className="text-emerald-400 flex items-center gap-1 font-medium">
                                    <CheckCircle2 className="w-3 h-3" />
                                    <span>Verified verbatim</span>
                                  </span>
                                ) : (
                                  <span className="text-red-400 flex items-center gap-1 font-medium bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
                                    <XCircle className="w-3 h-3" />
                                    <span>{dq.rejectionReason || 'Unverified'}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Extracted Facts */}
                  {msg.structured.extractedFacts && msg.structured.extractedFacts.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-xs font-semibold uppercase tracking-wider text-ink-muted flex items-center gap-1.5">
                        <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Extracted Facts</span>
                      </div>
                      <div className="p-3.5 bg-paper rounded-md border border-paper-border space-y-2 text-[13px] sm:text-sm text-ink font-sans">
                        {msg.structured.extractedFacts.map((fact, idx) => (
                          <div key={idx} className="flex items-start gap-2.5">
                            <span className="text-accent font-bold">•</span>
                            <span className="leading-relaxed">{fact}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Summary */}
                  {msg.structured.summary && (
                    <div className="space-y-1.5">
                      <div className="text-xs font-semibold uppercase tracking-wider text-ink-muted">
                        Synthesis Summary
                      </div>
                      <div className="p-3.5 bg-paper border border-paper-border rounded-md text-[13px] sm:text-sm text-ink font-serif leading-relaxed">
                        {msg.structured.summary}
                      </div>
                    </div>
                  )}

                  {/* AI Interpretation */}
                  {msg.structured.aiInterpretation && msg.provider === 'remote-disclosed' && (
                    <div className="space-y-1.5">
                      <div className="text-xs font-semibold uppercase tracking-wider text-accent flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>AI-Generated Interpretation (Non-Authoritative)</span>
                      </div>
                      <div className="p-3.5 bg-paper border border-paper-border-dark rounded-md text-[13px] sm:text-sm text-ink leading-relaxed whitespace-pre-wrap font-sans">
                        {msg.structured.aiInterpretation}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Fallback raw content formatting */
                <div className="text-[13px] sm:text-sm text-ink leading-relaxed whitespace-pre-wrap font-serif">
                  {msg.content}
                </div>
              )}

              {/* Verified Evidence Bundles */}
              {msg.evidence && msg.evidence.length > 0 && (
                <div className="pt-2.5 border-t border-paper-border space-y-2.5">
                  <div className="text-xs font-semibold uppercase tracking-wider text-ink-muted flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Evidence Citations ({msg.evidence.length} validated):</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {msg.evidence.map((ev) => {
                      const isClickable = ev.verified;
                      return (
                        <div
                          key={ev.evidenceId}
                          onClick={() => {
                            if (isClickable) {
                              onNavigateToReader(ev.documentId, ev.pageNumber, ev.quote, ev.sourceElementIds?.[0]);
                            }
                          }}
                          role={isClickable ? 'button' : undefined}
                          tabIndex={isClickable ? 0 : undefined}
                          onKeyDown={(e) => {
                            if (isClickable && (e.key === 'Enter' || e.key === ' ')) {
                              e.preventDefault();
                              onNavigateToReader(ev.documentId, ev.pageNumber, ev.quote, ev.sourceElementIds?.[0]);
                            }
                          }}
                          aria-label={
                            isClickable
                              ? `Jump to cited passage [${ev.evidenceId}] on page ${ev.pageNumber} in Reader`
                              : undefined
                          }
                          aria-disabled={!isClickable ? 'true' : undefined}
                          className={`p-3.5 border rounded-md text-[13px] transition-all duration-150 space-y-2 ${
                            isClickable
                              ? 'bg-paper border-paper-border hover:border-accent hover:bg-paper-dim/80 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent shadow-2xs'
                              : 'bg-red-500/10 border-red-500/30 cursor-default opacity-85 select-none'
                          }`}
                        >
                          <div className="flex items-center justify-between font-mono text-xs">
                            <span
                              className={`font-bold ${
                                isClickable ? 'text-accent' : 'text-red-400'
                              }`}
                            >
                              [{ev.evidenceId}]
                            </span>
                            <span className="text-ink-muted">
                              Page {ev.pageNumber} · {ev.documentName}
                            </span>
                          </div>

                          <p className="font-serif italic text-ink line-clamp-2">
                            "{ev.quote}"
                          </p>

                          <div className="flex items-center justify-between pt-2 border-t border-paper-border text-xs">
                            {ev.verified ? (
                              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Byte-verified</span>
                              </span>
                            ) : (
                              <span className="text-red-400 flex items-center gap-1 font-medium bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
                                <XCircle className="w-3.5 h-3.5" />
                                <span>{ev.rejectionReason || 'Unverified'}</span>
                              </span>
                            )}

                            {isClickable ? (
                              <span className="text-accent hover:underline flex items-center gap-1 font-medium">
                                <BookOpen className="w-3.5 h-3.5" />
                                <span>Inspect in Reader →</span>
                              </span>
                            ) : (
                              <span className="text-xs font-mono text-red-400/80">
                                Unverified citation
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ))
        )}

        {isSynthesizing && (
          <div className="p-4 rounded-lg border border-paper-border bg-paper-light text-[13px] text-ink-muted flex items-center gap-3 shadow-xs">
            <img
              src="/doculens-mark-transparent.png"
              alt="Synthesizing"
              className="w-5 h-5 object-contain animate-pulse shrink-0"
            />
            <div className="w-4 h-4 border-2 border-accent border-t-transparent rounded-full animate-spin shrink-0" />
            <span>Retrieving lexical evidence, checking page bounds, and validating citations...</span>
          </div>
        )}
      </div>

      {/* Inquiry Input Form */}
      <form onSubmit={(e) => handleSubmit(e)} className="sticky bottom-4 pt-2">
        <div className="flex items-stretch gap-2.5 bg-paper-light p-2 border border-paper-border-dark rounded-lg shadow-lg">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question grounded in the ingested documents..."
            className="flex-1 bg-transparent px-3 py-2 min-h-[36px] text-[13px] sm:text-sm text-ink placeholder:text-ink-faint focus:outline-none"
          />
          <button
            type="submit"
            disabled={!question.trim() || isSynthesizing}
            className="bg-ink hover:opacity-90 text-paper px-5 py-2 min-h-[36px] rounded-md text-[13px] font-semibold flex items-center gap-2 transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <Send className="w-4 h-4" />
            <span>Inquire</span>
          </button>
        </div>
      </form>

      {/* Detailed Citation Modal */}
      {selectedCitation && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-paper-light border border-paper-border rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span
                  className={`font-mono text-xs font-bold ${
                    selectedCitation.verified ? 'text-accent' : 'text-red-400'
                  }`}
                >
                  [{selectedCitation.evidenceId}] Citation Provenance
                </span>
                <h3 className="font-serif font-semibold text-lg text-ink mt-0.5">
                  {selectedCitation.documentName}
                </h3>
              </div>
              <span className="text-xs font-mono text-ink-muted">
                Page {selectedCitation.pageNumber}
              </span>
            </div>

            <div className="p-3.5 bg-paper border border-paper-border rounded-md">
              <span className="text-xs font-mono text-ink-faint">VERBATIM STORED EXCERPT:</span>
              <p className="mt-1.5 font-serif text-[13px] sm:text-sm text-ink leading-relaxed italic">
                "{selectedCitation.quote}"
              </p>
            </div>

            <div className="text-xs text-ink-muted space-y-1 font-mono">
              <div>Chunk Reference: {selectedCitation.chunkId}</div>
              {selectedCitation.verified ? (
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verification: {selectedCitation.verificationDetails}</span>
                </div>
              ) : (
                <div className="text-red-400 flex items-center gap-1.5">
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Rejection: {selectedCitation.rejectionReason}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-paper-border">
              <button
                onClick={() => setSelectedCitation(null)}
                className="px-4 py-2 min-h-[36px] text-[13px] font-medium text-ink-muted hover:text-ink border border-paper-border hover:bg-paper rounded-md transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onNavigateToReader(selectedCitation.documentId, selectedCitation.pageNumber);
                  setSelectedCitation(null);
                }}
                className="px-4 py-2 min-h-[36px] text-[13px] font-semibold text-paper bg-ink hover:opacity-90 rounded-md flex items-center gap-2 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                <BookOpen className="w-4 h-4" />
                <span>Open in Reader</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
