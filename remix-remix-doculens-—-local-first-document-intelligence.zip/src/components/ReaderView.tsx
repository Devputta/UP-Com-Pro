import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Bookmark,
  Plus,
  Trash2,
  Maximize2,
  Minimize2,
  Crosshair,
  Printer,
  FileWarning,
  Search,
  X,
  Highlighter,
  FileText,
  PanelLeft,
  PanelLeftOpen,
} from 'lucide-react';
import {
  DocumentEntity,
  DocumentElement,
  MarginaliaNote,
} from '../types/doculens';
import { highlightTextSegments } from '../services/lexicalSearch';
import { PageThumbnail } from './PageThumbnail';
import { thumbnailService } from '../services/thumbnailService';

interface ReaderViewProps {
  documents: DocumentEntity[];
  selectedDocId?: string;
  onSelectDoc: (id: string) => void;
  elements: DocumentElement[];
  notes: MarginaliaNote[];
  onAddNote: (note: {
    documentId: string;
    pageNumber: number;
    selectedText: string;
    noteText: string;
  }) => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
  targetPage?: number;
  highlightQuery?: string;
  targetElementId?: string;
  onClearHighlight?: () => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  documents,
  selectedDocId,
  onSelectDoc,
  elements,
  notes,
  onAddNote,
  onDeleteNote,
  targetPage,
  highlightQuery: initialHighlightQuery,
  targetElementId,
  onClearHighlight,
}) => {
  const currentDoc = documents.find((d) => d.id === selectedDocId) || documents[0];
  const [currentPage, setCurrentPage] = useState<number>(targetPage || 1);
  const [pageInput, setPageInput] = useState<string>(String(targetPage || 1));
  const [selectedElement, setSelectedElement] = useState<DocumentElement | null>(null);
  const [citedElementId, setCitedElementId] = useState<string | null>(targetElementId || null);
  const [newNoteText, setNewNoteText] = useState('');
  const [selectedTextForNote, setSelectedTextForNote] = useState('');
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [isThumbnailStripOpen, setIsThumbnailStripOpen] = useState(true);
  const activeThumbButtonRef = useRef<HTMLButtonElement | null>(null);

  // In-Reader Search & Term Highlighting State (Instant Input + 250ms Debounced Matcher)
  const [activeHighlightQuery, setActiveHighlightQuery] = useState<string>(
    initialHighlightQuery || ''
  );
  const [debouncedHighlightQuery, setDebouncedHighlightQuery] = useState<string>(
    initialHighlightQuery || ''
  );
  const [isSearchToolbarOpen, setIsSearchToolbarOpen] = useState(
    Boolean(initialHighlightQuery)
  );

  // Debounce the highlight query by 250ms so the page highlight only updates when typing pauses
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedHighlightQuery(activeHighlightQuery);
    }, 250);
    return () => clearTimeout(timer);
  }, [activeHighlightQuery]);

  // Cancel pending thumbnail renders when Reader unmounts or selected document changes
  useEffect(() => {
    return () => {
      thumbnailService.cancelPendingRenders('reader');
    };
  }, []);

  useEffect(() => {
    thumbnailService.cancelPendingRenders('reader');
  }, [currentDoc?.id]);

  // Smoothly scroll active thumbnail button into view within the thumbnail strip without jumping outer page
  useEffect(() => {
    if (activeThumbButtonRef.current && isThumbnailStripOpen) {
      activeThumbButtonRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest',
      });
    }
  }, [currentPage, isThumbnailStripOpen]);

  // Jumping to a page via thumbnail without scroll jumping
  const handleThumbnailClick = (pageNum: number) => {
    if (pageNum === currentPage) return;
    setCurrentPage(pageNum);
    setPageInput(String(pageNum));
    setSelectedElement(null);
    setCitedElementId(null);
  };

  const canvasRef = useRef<HTMLDivElement>(null);
  const firstMatchRef = useRef<HTMLDivElement>(null);

  // Guard auto-scrolling to a cited or highlighted passage only ONCE per navigation.
  // Stores the last handled citation element id and query so re-renders, typing,
  // clicking paragraphs, or user page changes never re-trigger auto-scroll or fight user scrolling.
  const lastHandledNavRef = useRef<string | null>(null);
  const lastScrolledQueryRef = useRef<string>('');

  // Sync highlight query from external navigation (e.g. from Search or Citation click)
  useEffect(() => {
    if (initialHighlightQuery !== undefined) {
      setActiveHighlightQuery(initialHighlightQuery);
      setDebouncedHighlightQuery(initialHighlightQuery);
      if (initialHighlightQuery) {
        setIsSearchToolbarOpen(true);
      }
    }
  }, [initialHighlightQuery]);

  // Filter elements for the current document
  const docElements = React.useMemo(
    () => (currentDoc ? elements.filter((e) => e.documentId === currentDoc.id) : []),
    [currentDoc?.id, elements]
  );
  const totalPages = currentDoc
    ? Math.max(1, currentDoc.pageCount, ...docElements.map((e) => e.pageNumber))
    : 1;

  // Sync targetPage prop when it changes (e.g. from Search or Citation click)
  useEffect(() => {
    if (targetPage && targetPage >= 1 && targetPage <= totalPages) {
      setCurrentPage(targetPage);
      setPageInput(String(targetPage));
    }
  }, [targetPage, totalPages]);

  // Auto-scroll to a cited or highlighted passage only ONCE per navigation.
  useEffect(() => {
    if (!targetElementId && !initialHighlightQuery) {
      return;
    }

    const navToken = `${currentDoc?.id || ''}:${targetPage || 1}:${targetElementId || ''}:${initialHighlightQuery || ''}`;
    if (lastHandledNavRef.current === navToken) {
      return;
    }

    const matchEl = targetElementId
      ? elements.find((e) => e.id === targetElementId && (!currentDoc || e.documentId === currentDoc.id))
      : initialHighlightQuery
      ? elements.find(
          (e) =>
            (!currentDoc || e.documentId === currentDoc.id) &&
            e.content.toLowerCase().includes(initialHighlightQuery.toLowerCase())
        )
      : null;

    if (!matchEl) {
      return;
    }

    lastHandledNavRef.current = navToken;
    setSelectedElement(matchEl);
    setCitedElementId(matchEl.id);
    if (matchEl.pageNumber !== currentPage) {
      setCurrentPage(matchEl.pageNumber);
      setPageInput(String(matchEl.pageNumber));
    }

    // Auto-scroll ONCE per navigation with block: 'nearest'
    const timer = setTimeout(() => {
      const domEl = document.getElementById(`doc-el-${matchEl.id}`);
      if (domEl) {
        domEl.scrollIntoView({ behavior: 'auto', block: 'nearest' });
      }
    }, 80);
  }, [targetElementId, initialHighlightQuery, currentDoc?.id, targetPage, elements]);

  // Auto-scroll to the first match only after the debounce, with block: 'nearest'
  useEffect(() => {
    const trimmed = debouncedHighlightQuery.trim();
    if (!trimmed) {
      lastScrolledQueryRef.current = '';
      return;
    }
    if (lastScrolledQueryRef.current === trimmed) {
      return;
    }
    lastScrolledQueryRef.current = trimmed;
    if (firstMatchRef.current) {
      firstMatchRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [debouncedHighlightQuery]);

  // Keep page within bounds when document changes
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
      setPageInput(String(totalPages));
    }
  }, [totalPages, currentPage]);

  // Keyboard navigation: Left Arrow (prev), Right Arrow (next), Escape (clear selection & citation)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedElement(null);
        setCitedElementId(null);
        return;
      }

      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (e.key === 'ArrowLeft') {
        if (currentPage > 1) {
          setCurrentPage((p) => {
            const next = p - 1;
            setPageInput(String(next));
            return next;
          });
          setSelectedElement(null);
          setCitedElementId(null);
        }
      } else if (e.key === 'ArrowRight') {
        if (currentPage < totalPages) {
          setCurrentPage((p) => {
            const next = p + 1;
            setPageInput(String(next));
            return next;
          });
          setSelectedElement(null);
          setCitedElementId(null);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, totalPages]);

  // Count total matches on the current page
  const pageElements = docElements.filter((e) => e.pageNumber === currentPage);
  const pageNotes = notes.filter((n) => n.documentId === currentDoc?.id && n.pageNumber === currentPage);

  const pageMatchesCount = React.useMemo(() => {
    if (!debouncedHighlightQuery.trim()) return 0;
    let count = 0;
    for (const el of pageElements) {
      const segs = highlightTextSegments(el.content, debouncedHighlightQuery);
      count += segs.filter((s) => s.isMatch).length;
    }
    return count;
  }, [pageElements, debouncedHighlightQuery]);


  if (!currentDoc) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center text-ink-muted space-y-4">
        <div className="w-16 h-16 mx-auto rounded-full bg-paper-light border border-paper-border p-3 flex items-center justify-center shadow-xs">
          <img
            src="/doculens-mark-transparent.png"
            alt="DocuLens Emblem"
            className="w-full h-full object-contain"
          />
        </div>
        <p className="font-serif text-xl font-medium text-ink">
          No documents loaded for reading
        </p>
        <p className="text-[13px] max-w-sm mx-auto text-ink-muted leading-relaxed">
          Please select or ingest a document in the Library view to inspect page layout, element
          provenance, and add marginalia notes.
        </p>
      </div>
    );
  }

  const handlePrevPage = () => {
    if (currentPage > 1) {
      const prev = currentPage - 1;
      setCurrentPage(prev);
      setPageInput(String(prev));
      setSelectedElement(null);
      setCitedElementId(null);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      const next = currentPage + 1;
      setCurrentPage(next);
      setPageInput(String(next));
      setSelectedElement(null);
      setCitedElementId(null);
    }
  };

  const handlePageJumpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(pageInput, 10);
    if (!isNaN(parsed) && parsed >= 1 && parsed <= totalPages) {
      setCurrentPage(parsed);
      setSelectedElement(null);
      setCitedElementId(null);
    } else {
      setPageInput(String(currentPage));
    }
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    await onAddNote({
      documentId: currentDoc.id,
      pageNumber: currentPage,
      selectedText: selectedTextForNote.trim() || `Page ${currentPage} observation`,
      noteText: newNoteText.trim(),
    });
    setNewNoteText('');
    setSelectedTextForNote('');
  };

  const clearHighlighting = () => {
    setActiveHighlightQuery('');
    setDebouncedHighlightQuery('');
    setSelectedElement(null);
    setCitedElementId(null);
    if (onClearHighlight) onClearHighlight();
  };

  /**
   * Helper to render text with search highlighting
   */
  const renderHighlightedContent = (text: string, isFirstEl: boolean) => {
    if (!debouncedHighlightQuery.trim()) {
      return <span>{text}</span>;
    }

    const segments = highlightTextSegments(text, debouncedHighlightQuery);
    let isFirstMatchAssigned = false;

    return (
      <>
        {segments.map((seg, i) => {
          if (seg.isMatch) {
            const assignRef = isFirstEl && !isFirstMatchAssigned;
            if (assignRef) isFirstMatchAssigned = true;

            return (
              <mark
                key={i}
                ref={assignRef ? (firstMatchRef as any) : undefined}
                className="bg-[#E8A94A]/65 text-[#0F1217] font-normal no-underline rounded-[3px] [box-decoration-break:clone] [-webkit-box-decoration-break:clone] transition-none animate-none px-1 py-0.5"
                title={`Match for "${debouncedHighlightQuery}"`}
              >
                {seg.text}
              </mark>
            );
          }
          return <span key={i}>{seg.text}</span>;
        })}
      </>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-4">
      {/* Top Reading Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-paper-border bg-paper-light p-3 sm:p-4 rounded-lg shadow-xs">
        {/* Document Switcher */}
        <div className="flex items-center gap-2.5 min-w-0">
          <FileText className="w-4 h-4 text-ink-faint shrink-0" />
          <select
            id="reader-doc-select"
            aria-label="Select document to read"
            value={currentDoc.id}
            onChange={(e) => {
              onSelectDoc(e.target.value);
              setCurrentPage(1);
              setPageInput('1');
              setSelectedElement(null);
            }}
            className="text-[13px] font-sans font-medium bg-paper border border-paper-border hover:border-accent text-ink rounded-md px-3 py-1.5 min-h-[36px] max-w-xs truncate cursor-pointer transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            {documents.map((d) => (
              <option key={d.id} value={d.id} className="bg-paper-light text-ink">
                {d.originalName} ({d.pageCount}p){d.ocrProcessed ? ' [OCR]' : ''}
              </option>
            ))}
          </select>
          {currentDoc.ocrProcessed && (
            <span className="text-xs text-accent font-medium bg-accent-subtle border border-accent-border px-2 py-1 rounded font-mono hidden md:inline-flex items-center gap-1">
              OCR Layer {typeof currentDoc.ocrConfidence === 'number' ? `(${Math.round(currentDoc.ocrConfidence)}%)` : ''}
            </span>
          )}
        </div>

        {/* Page Stepper, Search Toggle & Provenance Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            aria-label="Previous Page (Left Arrow)"
            title="Previous Page (←)"
            className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-ink-muted hover:text-ink hover:bg-paper-dim border border-paper-border rounded-md transition-all duration-150 disabled:opacity-30 disabled:cursor-not-allowed bg-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Direct page jump form */}
          <form onSubmit={handlePageJumpSubmit} className="flex items-center gap-1.5 text-[13px] text-ink font-sans">
            <span className="text-ink-faint">Page</span>
            <input
              type="text"
              inputMode="numeric"
              value={pageInput}
              onChange={(e) => setPageInput(e.target.value)}
              onBlur={() => {
                const p = parseInt(pageInput, 10);
                if (!isNaN(p) && p >= 1 && p <= totalPages) {
                  setCurrentPage(p);
                } else {
                  setPageInput(String(currentPage));
                }
              }}
              className="w-14 min-h-[36px] text-center font-mono font-medium bg-paper border border-paper-border focus:border-accent rounded-md py-1 px-2 text-[13px] text-ink transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              aria-label="Go to page"
            />
            <span className="text-ink-faint">of {totalPages}</span>
          </form>

          <button
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
            aria-label="Next Page (Right Arrow)"
            title="Next Page (→)"
            className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-ink-muted hover:text-ink hover:bg-paper-dim border border-paper-border rounded-md transition-all duration-150 disabled:opacity-30 disabled:cursor-not-allowed bg-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="h-5 w-px bg-paper-border mx-1" />

          {/* Toggle Thumbnail Strip */}
          <button
            onClick={() => setIsThumbnailStripOpen(!isThumbnailStripOpen)}
            title="Toggle Page Thumbnail Strip"
            aria-label="Toggle Page Thumbnail Strip"
            className={`px-3 py-1.5 min-h-[36px] border rounded-md text-[13px] font-medium flex items-center gap-1.5 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
              isThumbnailStripOpen
                ? 'border-accent text-accent bg-accent-subtle'
                : 'border-paper-border text-ink-muted hover:text-ink hover:bg-paper-dim bg-paper'
            }`}
          >
            <PanelLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Thumbnails</span>
          </button>

          {/* Toggle In-Page Search Toolbar */}
          <button
            onClick={() => setIsSearchToolbarOpen(!isSearchToolbarOpen)}
            title="Find & Highlight on Page"
            aria-label="Toggle Page Search Highlighting"
            className={`px-3 py-1.5 min-h-[36px] border rounded-md text-[13px] font-medium flex items-center gap-1.5 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
              isSearchToolbarOpen || activeHighlightQuery
                ? 'border-accent text-accent bg-accent-subtle'
                : 'border-paper-border text-ink-muted hover:text-ink hover:bg-paper-dim bg-paper'
            }`}
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">Highlight</span>
          </button>

          {/* Print button */}
          <button
            onClick={() => window.print()}
            title="Print Page View"
            aria-label="Print Page View"
            className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-ink-muted hover:text-ink hover:bg-paper-dim border border-paper-border rounded-md transition-all duration-150 bg-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <Printer className="w-4 h-4" />
          </button>

          {/* Toggle Inspector */}
          <button
            onClick={() => setIsInspectorOpen(!isInspectorOpen)}
            title="Toggle Element Provenance Sidebar"
            aria-label="Toggle Element Provenance Sidebar"
            className={`px-3 py-1.5 min-h-[36px] border rounded-md text-[13px] font-medium flex items-center gap-1.5 transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
              isInspectorOpen
                ? 'border-accent text-accent bg-accent-subtle'
                : 'border-paper-border text-ink-muted hover:text-ink hover:bg-paper-dim bg-paper'
            }`}
          >
            {isInspectorOpen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            <span className="hidden sm:inline">Provenance</span>
          </button>
        </div>
      </div>

      {/* In-Reader Search & Highlight Toolbar */}
      {isSearchToolbarOpen && (
        <div className="border border-paper-border bg-paper p-3 sm:p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-[13px]">
          <div className="flex items-center gap-2.5 flex-1">
            <Highlighter className="w-4 h-4 text-accent shrink-0" />
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                value={activeHighlightQuery}
                onChange={(e) => setActiveHighlightQuery(e.target.value)}
                placeholder="Type word, phrase, or code to highlight on this page..."
                className="w-full min-h-[36px] bg-paper-light border border-paper-border focus:border-accent rounded-md px-3 py-1.5 text-[13px] text-ink placeholder:text-ink-faint transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              />
              {activeHighlightQuery && (
                <button
                  type="button"
                  onClick={clearHighlighting}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-faint hover:text-ink p-1 min-h-[28px] min-w-[28px] flex items-center justify-center rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {activeHighlightQuery.trim() ? (
              <span className="font-mono text-xs text-ink-muted bg-paper-light px-2.5 py-1.5 rounded-md border border-paper-border">
                {pageMatchesCount} match{pageMatchesCount === 1 ? '' : 'es'} on Page {currentPage}
              </span>
            ) : null}

            {activeHighlightQuery && (
              <button
                onClick={clearHighlighting}
                className="text-xs text-ink-faint hover:text-accent px-2 py-1.5 underline transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* Scanned Image Document Alert Banner */}
      {currentDoc.isScanned && (
        <div className="p-3 sm:p-4 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-lg text-[13px] flex items-center gap-2.5 shadow-xs">
          <FileWarning className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong className="text-amber-200">Scanned Document Notice:</strong> This PDF contains scanned image pages without
            an embedded OCR text layer. Text-based lexical search and automatic element citations
            are limited.
          </span>
        </div>
      )}

      {/* Main Reading Workspace Split */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Collapsible Left Thumbnail Strip */}
        {isThumbnailStripOpen ? (
          <aside
            aria-label="Page Thumbnails"
            className="w-full lg:w-44 shrink-0 border border-paper-border bg-paper-light rounded-lg p-3 space-y-3 shadow-xs lg:sticky lg:top-4 max-h-[340px] lg:max-h-[calc(100vh-6rem)] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-paper-border pb-2 text-xs font-mono text-ink-muted">
              <span>{totalPages} Pages</span>
              <button
                type="button"
                onClick={() => setIsThumbnailStripOpen(false)}
                title="Collapse thumbnail strip"
                aria-label="Collapse thumbnail strip"
                className="p-1 text-ink-faint hover:text-ink rounded transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>

            <div className="flex lg:flex-col gap-2.5 overflow-x-auto lg:overflow-x-hidden pb-1 lg:pb-0">
              {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNum) => {
                const isActive = pageNum === currentPage;
                return (
                  <button
                    key={pageNum}
                    ref={isActive ? (activeThumbButtonRef as any) : undefined}
                    type="button"
                    onClick={() => handleThumbnailClick(pageNum)}
                    aria-label={`Jump to page ${pageNum}`}
                    aria-current={isActive ? 'page' : undefined}
                    className={`shrink-0 w-28 lg:w-full text-left p-1.5 rounded-md border transition-all text-xs flex flex-col items-center gap-1.5 group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
                      isActive
                        ? 'border-accent bg-accent-subtle/50 ring-1 ring-accent'
                        : 'border-paper-border bg-paper hover:border-paper-border-dark hover:bg-paper-dim'
                    }`}
                  >
                    <div className="w-full aspect-[3/4] rounded overflow-hidden bg-paper-light border border-paper-border/60">
                      <PageThumbnail
                        documentId={currentDoc.id}
                        pageNumber={pageNum}
                        viewScope="reader"
                        alt={`Page ${pageNum} thumbnail`}
                      />
                    </div>
                    <span
                      className={`font-mono text-[11px] ${
                        isActive ? 'text-accent font-semibold' : 'text-ink-muted group-hover:text-ink'
                      }`}
                    >
                      Page {pageNum}
                    </span>
                  </button>
                );
              })}
            </div>
          </aside>
        ) : (
          /* Collapsed strip bar button on desktop */
          <div className="hidden lg:block shrink-0 sticky top-4">
            <button
              type="button"
              onClick={() => setIsThumbnailStripOpen(true)}
              title="Expand page thumbnails"
              aria-label="Expand page thumbnails"
              className="p-2 border border-paper-border bg-paper-light hover:bg-paper-dim text-ink-muted hover:text-accent rounded-lg flex flex-col items-center gap-2 transition-all shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              <PanelLeftOpen className="w-4 h-4 text-accent" />
              <span className="[writing-mode:vertical-rl] rotate-180 font-mono text-[11px] tracking-wider text-ink-faint">
                Pages ({totalPages})
              </span>
            </button>
          </div>
        )}

        {/* Center Canvas and Right Inspector */}
        <div className="flex-1 min-w-0 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Document Canvas (Page Surface) */}
          <div
            ref={canvasRef}
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setSelectedElement(null);
                setCitedElementId(null);
              }
            }}
            className={`${
              isInspectorOpen ? 'lg:col-span-8' : 'lg:col-span-12'
            } border border-paper-border-dark bg-paper-light rounded-lg shadow-xs min-h-[680px] p-6 sm:p-10 space-y-6 relative`}
          >
          {/* Page Header Watermark / Provenance Kicker */}
          <div className="flex items-center justify-between text-xs text-ink-faint border-b border-paper-border pb-3 mb-6 font-mono">
            <span>DOCULENS PROVENANCE SURFACE</span>
            <span className="truncate max-w-sm">
              {currentDoc.originalName} — PAGE {currentPage}
            </span>
          </div>

          {pageElements.length === 0 ? (
            <div className="text-center py-20 text-ink-muted space-y-2">
              <p className="font-serif text-lg text-ink">No text elements on page {currentPage}</p>
              <p className="text-[13px] max-w-sm mx-auto text-ink-faint">
                This page may contain graphical diagrams, empty space, or unscanned image scans.
              </p>
            </div>
          ) : (
            <div className="space-y-4 font-serif text-ink leading-relaxed">
              {pageElements.map((el, elIdx) => {
                const isSelected = selectedElement?.id === el.id;
                const isCited = citedElementId === el.id || targetElementId === el.id;
                const isTargetPassage = isSelected || isCited;
                const hasMatch =
                  Boolean(debouncedHighlightQuery.trim()) &&
                  el.content.toLowerCase().includes(debouncedHighlightQuery.toLowerCase());

                const baseClass = `relative cursor-pointer p-3 rounded-md transition-none ${
                  isTargetPassage
                    ? 'bg-[#E8A94A]/10 border-l-2 border-[#E8A94A]'
                    : hasMatch
                    ? 'border-l-2 border-[#E8A94A]/40 hover:bg-paper-dim'
                    : 'border-l-2 border-transparent hover:bg-paper-dim'
                }`;

                const renderPassageHeader = () => {
                  if (!isCited && !el.isOcr) return null;
                  return (
                    <div className="mb-1 flex items-center gap-2 select-none">
                      {isCited && (
                        <span className="font-mono text-[10px] font-semibold text-[#E8A94A] tracking-wider uppercase">
                          Cited Passage
                        </span>
                      )}
                      {el.isOcr && !isCited && (
                        <span
                          className="inline-flex items-center gap-1 font-mono text-[10px] font-medium uppercase text-accent bg-accent-subtle border border-accent-border px-1.5 py-0.5 rounded"
                          title={`In-Browser OCR Extracted (${typeof el.ocrConfidence === 'number' ? Math.round(el.ocrConfidence) : 0}% Confidence)`}
                        >
                          OCR {typeof el.ocrConfidence === 'number' ? `${Math.round(el.ocrConfidence)}%` : ''}
                        </span>
                      )}
                    </div>
                  );
                };

                if (el.type === 'heading-1') {
                  return (
                    <div
                      key={el.id}
                      id={`doc-el-${el.id}`}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                        setCitedElementId(null);
                      }}
                      className={baseClass}
                    >
                      {renderPassageHeader()}
                      <h1 className="text-xl sm:text-2xl font-semibold text-ink">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h1>
                    </div>
                  );
                }

                if (el.type === 'heading-2') {
                  return (
                    <div
                      key={el.id}
                      id={`doc-el-${el.id}`}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                        setCitedElementId(null);
                      }}
                      className={baseClass}
                    >
                      {renderPassageHeader()}
                      <h2 className="text-lg font-semibold text-ink mt-2">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h2>
                    </div>
                  );
                }

                if (el.type === 'heading-3') {
                  return (
                    <div
                      key={el.id}
                      id={`doc-el-${el.id}`}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                        setCitedElementId(null);
                      }}
                      className={baseClass}
                    >
                      {renderPassageHeader()}
                      <h3 className="text-base font-semibold text-ink">
                        {renderHighlightedContent(el.content, elIdx === 0)}
                      </h3>
                    </div>
                  );
                }

                if (el.type === 'footnote') {
                  return (
                    <div
                      key={el.id}
                      id={`doc-el-${el.id}`}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                        setCitedElementId(null);
                      }}
                      className={`${baseClass} pt-4 border-t border-paper-border text-xs text-ink-muted italic`}
                    >
                      {renderPassageHeader()}
                      <p>{renderHighlightedContent(el.content, elIdx === 0)}</p>
                    </div>
                  );
                }

                if (el.type === 'callout') {
                  return (
                    <div
                      key={el.id}
                      id={`doc-el-${el.id}`}
                      onClick={() => {
                        setSelectedElement(el);
                        setSelectedTextForNote(el.content);
                        setCitedElementId(null);
                      }}
                      className={`${baseClass} p-3.5 ${
                        isTargetPassage ? '' : 'bg-accent-subtle border-l-2 border-accent-border'
                      } text-[13px] text-[#E6E9EF] rounded-md font-sans`}
                    >
                      {renderPassageHeader()}
                      <p>{renderHighlightedContent(el.content, elIdx === 0)}</p>
                    </div>
                  );
                }

                return (
                  <div
                    key={el.id}
                    id={`doc-el-${el.id}`}
                    onClick={() => {
                      setSelectedElement(el);
                      setSelectedTextForNote(el.content);
                      setCitedElementId(null);
                    }}
                    className={baseClass}
                  >
                    {renderPassageHeader()}
                    <p className="text-[14px] sm:text-base text-[#E6E9EF] leading-relaxed">
                      {renderHighlightedContent(el.content, elIdx === 0)}
                    </p>
                  </div>
                );
              })}
            </div>
          )}

          {/* Page Footer Footprint */}
          <div className="flex items-center justify-between text-xs text-ink-faint border-t border-paper-border pt-4 mt-8 font-mono">
            <span>SHA: {currentDoc.sha256.slice(0, 16)}...</span>
            <span>— {currentPage} of {totalPages} —</span>
            <span>{currentDoc.parserName}</span>
          </div>
        </div>

        {/* Sidebar: Element Provenance & Marginalia */}
        {isInspectorOpen && (
          <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-4 lg:max-h-[calc(100vh-2rem)] lg:overflow-y-auto">
            {/* Element Provenance Card */}
            <div className="border border-paper-border bg-paper-light rounded-lg p-5 space-y-3.5 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-ink-muted">
                <Crosshair className="w-3.5 h-3.5 text-accent" />
                <span>Provenance Inspector</span>
              </div>

              {selectedElement ? (
                <div className="space-y-3 text-[13px]">
                  <div className="p-3 bg-paper rounded-md border border-paper-border font-mono space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-ink-muted">Element ID:</span>
                      <span className="font-semibold text-ink">{selectedElement.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink-muted">Source ID:</span>
                      <span className="text-ink">{selectedElement.sourceElementId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink-muted">Type:</span>
                      <span className="text-accent font-semibold">{selectedElement.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-ink-muted">Page Number:</span>
                      <span className="text-ink">{selectedElement.pageNumber}</span>
                    </div>
                    {selectedElement.bbox && (
                      <div className="flex justify-between">
                        <span className="text-ink-muted">Bounding Box:</span>
                        <span className="text-ink">
                          [{selectedElement.bbox.join(', ')}]
                        </span>
                      </div>
                    )}
                    {selectedElement.isOcr && (
                      <div className="flex justify-between items-center pt-1 border-t border-paper-border">
                        <span className="text-ink-muted">Text Layer Origin:</span>
                        <span className="font-mono text-accent font-semibold inline-flex items-center gap-1">
                          <span className="bg-accent-subtle border border-accent-border px-1.5 py-0.5 rounded text-[11px]">
                            OCR {typeof selectedElement.ocrConfidence === 'number' ? `(${Math.round(selectedElement.ocrConfidence)}% Confidence)` : ''}
                          </span>
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-1">
                    <span className="text-xs text-ink-muted font-medium">Selected Passage:</span>
                    <p className="mt-1.5 p-3 bg-paper rounded-md border border-paper-border text-[13px] text-ink italic max-h-36 overflow-y-auto font-serif leading-relaxed">
                      "{selectedElement.content}"
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-[13px] text-ink-faint">
                  <p>No element selected</p>
                </div>
              )}
            </div>

            {/* Marginalia & Researcher Notes */}
            <div className="border border-paper-border bg-paper-light rounded-lg p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-ink-muted">
                  <Bookmark className="w-3.5 h-3.5 text-accent" />
                  <span>Marginalia Notes (p.{currentPage})</span>
                </div>
                <span className="text-xs text-ink-faint font-mono">{pageNotes.length} notes</span>
              </div>

              {/* Note creator */}
              <form onSubmit={handleCreateNote} className="space-y-2.5">
                <textarea
                  value={newNoteText}
                  onChange={(e) => setNewNoteText(e.target.value)}
                  placeholder="Annotate this page with research or audit notes..."
                  rows={2}
                  className="w-full text-[13px] p-3 bg-paper border border-paper-border rounded-md text-ink placeholder:text-ink-faint focus:border-accent transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                />
                <button
                  type="submit"
                  disabled={!newNoteText.trim()}
                  className="w-full min-h-[36px] flex items-center justify-center gap-2 bg-ink hover:opacity-90 text-paper text-[13px] font-medium py-2 px-3 rounded-md transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <Plus className="w-4 h-4" />
                  <span>Attach Marginalia Note</span>
                </button>
              </form>

              {/* Existing page notes */}
              <div className="space-y-2.5 pt-2 max-h-60 overflow-y-auto">
                {pageNotes.length === 0 ? (
                  <p className="text-xs text-ink-faint text-center py-2">
                    No annotations on this page yet.
                  </p>
                ) : (
                  pageNotes.map((note) => (
                    <div
                      key={note.id}
                      className="p-3 bg-paper border border-paper-border rounded-md space-y-1.5 relative group"
                    >
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-xs font-mono text-ink-faint">
                          {new Date(note.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <button
                          onClick={() => onDeleteNote(note.id)}
                          className="opacity-0 group-hover:opacity-100 text-ink-faint hover:text-red-400 p-1 min-h-[28px] min-w-[28px] flex items-center justify-center rounded transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                          title="Delete note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[13px] text-ink leading-relaxed font-sans">{note.noteText}</p>
                      {note.selectedText && (
                        <p className="text-xs text-ink-muted italic truncate border-t border-paper-border pt-1 font-serif">
                          Ref: "{note.selectedText}"
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
        </div>
      </div>
    </div>
  );
};
